<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import AlertDialog from '../components/AlertDialog.vue';
import ConfirmationDialog from '../components/ConfirmationDialog.vue';
import LocationMapModal from '../components/LocationMapModal.vue';
import ProgramBenefitsEditor from '../components/ProgramBenefitsEditor.vue';
import ProviderSidebar from '../components/ProviderSidebar.vue';
import TaskPageHeader from '../components/TaskPageHeader.vue';
import TermsAgreement from '../components/TermsAgreement.vue';
import { useConfirmationDialog } from '../composables/useConfirmationDialog';
import { limitPhoneNumber } from '../support/phoneNumber';
import {
    canonicalProgramPath,
    canonicalizeProgramPathList,
    isOpenProgramPath,
    normalizeProgramPath,
    providerProgramPathOptionsForTarget,
    splitProgramPaths,
} from '../support/learnerProgramPaths';
import {
    citiesForLocation,
    findLocationOption,
    findPhilippineRegion,
    philippineRegionOptions,
    provincesForRegion,
} from '../support/philippineLocations';
import { cashGrantAmount, normalizeScholarshipBenefits as normalizeBenefits } from '../support/scholarshipBenefits';
import { providerObjectiveDetails, providerObjectiveOptions } from '../support/providerObjectives';
import {
    providerProgramFormSections as formSections,
    providerProgramFormStepUrl,
    providerProgramFormSubsections as formSubsections,
    sectionFromProviderProgramFormPath,
} from '../support/providerProgramFormNavigation';

const programFormPathMatch = window.location.pathname.match(/\/provider\/programs\/(\d+)\/edit(?:\/([a-z-]+))?$/);
const scholarshipId = ref(programFormPathMatch?.[1] ?? null);
const isEditMode = computed(() => Boolean(scholarshipId.value));
const isLoading = ref(true);
const isSaving = ref(false);
const errorMessage = ref('');
const formError = ref('');
const user = ref(null);
const existingApplicationCount = ref(0);
const awardedSlotsCount = ref(0);
const scholarshipFormElement = ref(null);
const imageInputElement = ref(null);
const imageFile = ref(null);
const imagePreviewUrl = ref('');
const useProviderLogoSelected = ref(false);
const providerLocationMessage = ref('');
const activeFormSection = ref(sectionFromProviderProgramFormPath(window.location.pathname));
const showLocationMap = ref(false);
const showProviderPurpose = ref(false);
const showCoreMatchingRules = ref(false);
const showAdditionalMatchingRules = ref(false);
const showDocumentChecklist = ref(false);
const showRecipientReleaseDetails = ref(false);
const showRecipientExceptionDetails = ref(false);
const showProgramReviewSummary = ref(false);
const customizeRubric = ref(false);
const selectedTargetPresetKey = ref('');
const customProgramPath = ref('');
const coverageLevel = ref('city');
const coverageRegionCode = ref('');
const coverageProvinceCode = ref('');
const coverageCity = ref('');
const coverageProvinceOptions = ref([]);
const coverageCityOptions = ref([]);
const isLoadingCoverageProvinces = ref(false);
const isLoadingCoverageCities = ref(false);
const coverageOptionsError = ref('');
let coverageRequestId = 0;
const programProvinceOptions = ref([]);
const programCityOptions = ref([]);
const isLoadingProgramProvinces = ref(false);
const isLoadingProgramCities = ref(false);
const programLocationOptionsError = ref('');
let programLocationRequestId = 0;
const autosaveReady = ref(false);
const draftSavedAt = ref('');
let autosaveTimer = null;
const createDraftStorageKey = 'scholarship-portal:provider-program:create:v1';
const {
    confirmation,
    requestConfirmation,
    confirmConfirmation,
    cancelConfirmation,
} = useConfirmationDialog();

const labelClass = 'mb-1.5 block text-sm font-semibold text-slate-700';
const requiredHintClass = 'ml-1 text-xs font-normal text-amber-700';
const optionalHintClass = 'ml-1 text-xs font-normal text-slate-400';
const inputClass = 'w-full min-w-0 rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-100';
const sectionCardClass = 'min-w-0 rounded-lg border border-slate-200 bg-slate-50/60 p-4 sm:p-5';
const fieldCardClass = 'min-w-0';
const fieldStackClass = 'min-w-0 flex flex-col';
const basicFieldStackClass = fieldStackClass;
const wideFieldStackClass = `${fieldStackClass} xl:col-span-2`;
const formGridClass = 'grid items-start gap-x-5 gap-y-5 md:grid-cols-2';
const currentLocalDateTime = new Date(Date.now() - new Date().getTimezoneOffset() * 60_000)
    .toISOString();
const todayDate = currentLocalDateTime.slice(0, 10);
const activeFormSubsection = ref({
    eligibility: 'requirements',
    application: 'files',
    selection: 'flow',
});
const activeFormSubsectionTabs = computed(() => formSubsections[activeFormSection.value] ?? []);
const categoryOptions = ['Academic merit', 'Financial assistance', 'Community grant', 'STEM scholarship', 'Leadership grant', 'Athletic scholarship'];
const customEligibilityOption = '__custom__';
const eligibilityOptions = [
    {
        key: 'currently_enrolled',
        label: 'Currently enrolled',
        description: 'Applicant must be enrolled in a school or recognized learning program.',
        summary: 'Currently enrolled in an eligible school or recognized learning program.',
        verificationType: 'automatic',
    },
    {
        key: 'learner_group',
        label: 'Target learner group',
        description: 'Use the education level, grade, strand, course, and school rules below.',
        summary: 'Meets the listed education level, grade or year level, track, strand, course, and school requirements.',
        verificationType: 'automatic',
    },
    {
        key: 'academic_performance',
        label: 'Academic requirement',
        description: 'Applicant must meet the average or GWA configured below.',
        summary: 'Meets the academic average or GWA requirement listed in this program.',
        verificationType: 'automatic',
    },
    {
        key: 'financial_need',
        label: 'Financial need',
        description: 'Applicant must fall within the selected household-income range.',
        summary: 'Meets the household-income requirement listed in this program.',
        verificationType: 'automatic',
    },
    {
        key: 'location_coverage',
        label: 'Location coverage',
        description: 'Applicant must live or study in an eligible location.',
        summary: 'Lives or studies within the locations covered by this program.',
        verificationType: 'automatic',
    },
    {
        key: 'required_documents',
        label: 'Required documents',
        description: 'Applicant must provide the documents selected in the next step.',
        summary: 'Can provide the required documents listed in this program.',
        verificationType: 'provider_verification',
    },
    {
        key: 'open_to_all',
        label: 'Open to all learners',
        description: 'Sets the detailed matching fields to all education levels, locations, and income groups.',
        summary: 'Open to all learners. The provider will review the submitted profile and required documents.',
        verificationType: 'information',
    },
];
const eligibilityVerificationOptions = [
    { value: 'applicant_declaration', label: 'Applicant confirms', help: 'The applicant confirms this condition before submitting.' },
    { value: 'provider_verification', label: 'Provider verifies', help: 'Your reviewer checks this condition using the profile or supporting evidence.' },
    { value: 'information', label: 'Information only', help: 'This explains the program but does not block the applicant.' },
];
const legacyEligibilityMappings = new Map([
    ['Open to applicants who meet the education, academic, location, income, and document requirements listed in this program.', ['currently_enrolled', 'learner_group', 'academic_performance', 'financial_need', 'location_coverage', 'required_documents']],
    ['Open to applicants who meet the listed academic, education-level, and document requirements.', ['currently_enrolled', 'learner_group', 'academic_performance', 'required_documents']],
    ['Open to applicants who meet the listed income, education-level, and document requirements.', ['currently_enrolled', 'learner_group', 'financial_need', 'required_documents']],
    ['Open to applicants in the listed education levels, grade or year levels, tracks, strands, courses, or training programs.', ['learner_group']],
    ['Open to applicants who live or study within the locations covered by this program and meet the listed requirements.', ['location_coverage']],
    ['Open to all applicants. The provider will review the submitted profile and required documents.', ['open_to_all']],
]);
const selectedEligibilityOptions = ref([]);
const customEligibilityText = ref('');
const defaultCommitmentText = 'The provider will explain any final recipient commitments after the applicant is accepted.';
const commitmentOptions = [
    {
        value: 'provider_briefing',
        label: 'Provider will explain after acceptance',
        field: 'otherContractTerms',
        text: defaultCommitmentText,
    },
    {
        value: 'none',
        label: 'No recipient commitment',
        field: null,
        text: '',
    },
    {
        value: 'renewal',
        label: 'Enrollment or renewal requirements',
        field: 'renewalPolicy',
        text: 'Maintain the stated enrollment and academic requirements and submit the records listed for renewal review.',
    },
    {
        value: 'service',
        label: 'Service or community commitment',
        field: 'returnServiceContract',
        text: 'Complete the specific service or community activities listed in the recipient agreement.',
    },
    {
        value: 'activities',
        label: 'Required program activities',
        field: 'otherContractTerms',
        text: 'Attend the specific orientation or program activities listed in the recipient agreement.',
    },
    {
        value: 'reporting',
        label: 'Progress or utilization report',
        field: 'otherContractTerms',
        text: 'Submit the academic progress or benefit-use records listed in the recipient agreement.',
    },
    {
        value: 'custom',
        label: 'Custom short preview',
        field: 'otherContractTerms',
        text: null,
    },
];
const selectedCommitmentOption = ref('provider_briefing');
const customCommitmentText = ref('');
const incomeOptions = ['Any', 'Below PHP 10,000', 'PHP 10,000 - 20,000', 'PHP 20,001 - 40,000', 'PHP 40,001 - 60,000', 'Above PHP 60,000'];
const coverageLevelOptions = [
    { value: 'region', label: 'Whole region' },
    { value: 'province', label: 'Province' },
    { value: 'city', label: 'City / municipality' },
];
const applicationModeOptions = [
    { value: 'online', label: 'Portal review', detail: 'Review the applicant profile and uploaded files in the portal.' },
    { value: 'onsite', label: 'Portal review with in-person verification', detail: 'Review uploads first, then request original documents on-site when needed.' },
    { value: 'provider_review', label: 'Profile review only' },
];
const handoffModeOptions = [
    {
        value: 'onsite',
        label: 'Visit your office',
        detail: 'Qualified applicants bring original records to a provider location.',
        icon: 'fa-solid fa-building',
    },
    {
        value: 'online',
        label: 'Use an official link',
        detail: 'Qualified applicants continue through your external application page.',
        icon: 'fa-solid fa-arrow-up-right-from-square',
    },
    {
        value: 'provider_contact',
        label: 'Wait for provider contact',
        detail: 'Your team contacts each qualified applicant with the next instructions.',
        icon: 'fa-solid fa-phone-volume',
    },
];
const selectionStageOptions = [
    {
        value: 'screening',
        label: 'Pre-screening review',
        description: 'Check eligibility, profile details, and submitted files.',
        icon: 'fa-solid fa-list-check',
        required: true,
    },
    {
        value: 'formal_application',
        label: 'Formal application',
        description: 'Complete provider forms or present original records.',
        icon: 'fa-solid fa-file-signature',
        required: true,
    },
    {
        value: 'exam',
        label: 'Exam',
        description: 'Complete an exam managed by your organization.',
        icon: 'fa-solid fa-clipboard-question',
        required: false,
    },
    {
        value: 'interview',
        label: 'Interview',
        description: 'Meet your team before the final decision.',
        icon: 'fa-solid fa-comments',
        required: false,
    },
    {
        value: 'decision',
        label: 'Final decision',
        description: 'Record selected, waitlisted, or not selected.',
        icon: 'fa-solid fa-award',
        required: true,
    },
];
const configurableStageOptions = selectionStageOptions.filter((stage) => ['formal_application', 'exam', 'interview'].includes(stage.value));
const scholarshipForm = ref(emptyScholarshipForm());
const gradeScaleOptions = [
    {
        value: '',
        label: 'No academic minimum',
        inputLabel: 'Academic requirement',
        placeholder: '',
        help: 'Use this when grades are not part of the eligibility rules.',
    },
    {
        value: 'percentage',
        label: 'General average / percentage',
        inputLabel: 'Minimum average',
        placeholder: 'Example: 85',
        help: 'Higher values meet the requirement, such as 85 or above.',
    },
    {
        value: 'grade_point',
        label: 'GWA / GPA grade point',
        inputLabel: 'Maximum GWA / GPA',
        placeholder: 'Example: 2.00',
        help: 'Lower values meet the requirement, such as 2.00 or better.',
    },
    {
        value: 'pass_fail',
        label: 'Pass/fail or competency based',
        inputLabel: 'Document-based review',
        placeholder: '',
        help: 'Use this for competency, pass/fail, or certification-based programs.',
    },
    {
        value: 'other',
        label: 'Other grading scale / manual review',
        inputLabel: 'Manual academic review',
        placeholder: '',
        help: 'Use eligibility details to explain the scale reviewers should check.',
    },
];
const educationLevelOptions = [
    { value: 'preschool', label: 'Preschool / Kindergarten' },
    { value: 'elementary', label: 'Elementary' },
    { value: 'junior_high_school', label: 'Junior High School' },
    { value: 'senior_high_school', label: 'Senior High School' },
    { value: 'college', label: 'College / University' },
    { value: 'tvet', label: 'TVET / Vocational' },
    { value: 'als', label: 'ALS / Alternative Learning' },
];
const allEducationLevelValues = educationLevelOptions.map((option) => option.value);
const schoolTypeOptions = [
    { value: 'daycare_learning_center', label: 'Daycare / learning center' },
    { value: 'public', label: 'Public school' },
    { value: 'private', label: 'Private school' },
    { value: 'state_university', label: 'State university / college' },
    { value: 'local_college', label: 'Local college / university' },
    { value: 'tvet_center', label: 'TVET center' },
    { value: 'als_center', label: 'ALS center' },
];
const documentRequirementOptions = [
    'Certificate of enrollment',
    'Latest report card or grades',
    'Transcript of records',
    'Recent school ID',
    'Birth certificate',
    'Good moral certificate',
    'Barangay certificate of residency',
    'Certificate of indigency',
    'Parent or guardian valid ID',
    'Proof of income',
    'Government-issued ID',
    'Admission or acceptance letter',
    'Recommendation letter',
];
const targetApplicantPresets = [
    {
        key: 'all',
        label: 'All learners',
        icon: 'fa-solid fa-people-group',
        description: 'Use this when the program is open to any Filipino learner regardless of level.',
        educationLevels: allEducationLevelValues,
        schoolTypes: [],
        courses: 'Any',
        years: 'Any grade or year level',
        locations: 'Nationwide',
        eligibility: 'Open to Filipino learners who meet the document, academic, location, and income requirements listed by the provider.',
        requirements: ['Certificate of enrollment', 'Latest report card or grades', 'Recent school ID'],
    },
    {
        key: 'early_basic',
        label: 'Preschool / Elementary',
        icon: 'fa-solid fa-child-reaching',
        description: 'Best for younger learners where a parent or guardian may manage the account.',
        educationLevels: ['preschool', 'elementary'],
        schoolTypes: ['daycare_learning_center', 'public', 'private'],
        courses: 'N/A',
        years: 'Nursery\nKinder 1\nKinder 2\nGrade 1\nGrade 2\nGrade 3\nGrade 4\nGrade 5\nGrade 6',
        locations: 'Nationwide',
        eligibility: 'Open to preschool or elementary learners. A parent or guardian may manage the applicant profile and provide contact information.',
        requirements: ['Certificate of enrollment', 'Latest report card or grades', 'Birth certificate', 'Parent or guardian valid ID', 'Proof of income'],
    },
    {
        key: 'junior_high',
        label: 'Junior High School',
        icon: 'fa-solid fa-school',
        description: 'For Grade 7 to Grade 10 learners, including general or special curriculum programs.',
        educationLevels: ['junior_high_school'],
        schoolTypes: ['public', 'private'],
        courses: 'Any',
        years: 'Grade 7\nGrade 8\nGrade 9\nGrade 10',
        locations: 'Nationwide',
        eligibility: 'Open to Junior High School learners who meet the provider requirements and maintain the required general average.',
        requirements: ['Certificate of enrollment', 'Latest report card or grades', 'Recent school ID', 'Proof of income'],
    },
    {
        key: 'senior_high',
        label: 'Senior High School',
        icon: 'fa-solid fa-book-open-reader',
        description: 'For Grade 11 to Grade 12 applicants where track or strand matters.',
        educationLevels: ['senior_high_school'],
        schoolTypes: ['public', 'private'],
        courses: 'STEM\nABM\nHUMSS\nGAS\nTVL',
        years: 'Grade 11\nGrade 12',
        locations: 'Nationwide',
        eligibility: 'Open to Senior High School learners in eligible tracks or strands who meet the academic and document requirements.',
        requirements: ['Certificate of enrollment', 'Latest report card or grades', 'Recent school ID', 'Proof of income'],
    },
    {
        key: 'college',
        label: 'College / University',
        icon: 'fa-solid fa-user-graduate',
        description: 'For degree program applicants where course and year level are key matching fields.',
        educationLevels: ['college'],
        schoolTypes: ['state_university', 'local_college', 'private'],
        courses: 'Any course',
        years: '1st year\n2nd year\n3rd year\n4th year\n5th year\nGraduating',
        locations: 'Nationwide',
        eligibility: 'Open to college or university students enrolled in eligible degree programs and year levels.',
        requirements: ['Certificate of enrollment', 'Transcript of records', 'Recent school ID', 'Proof of income'],
    },
    {
        key: 'tvet',
        label: 'TVET / Vocational',
        icon: 'fa-solid fa-screwdriver-wrench',
        description: 'For skills training, qualification, and certification-focused scholarship programs.',
        educationLevels: ['tvet'],
        schoolTypes: ['tvet_center'],
        courses: 'Cookery NC II\nICT / Computer Systems Servicing\nAutomotive Servicing\nElectrical Installation and Maintenance\nCaregiving',
        years: 'NC I\nNC II\nNC III\nNC IV\nFirst term\nSecond term',
        locations: 'Nationwide',
        eligibility: 'Open to TVET or vocational learners enrolled in eligible training programs or qualifications.',
        requirements: ['Certificate of enrollment', 'Recent school ID', 'Proof of income', 'Good moral certificate'],
    },
    {
        key: 'als',
        label: 'ALS learners',
        icon: 'fa-solid fa-person-chalkboard',
        description: 'For Alternative Learning System learners and non-traditional pathways.',
        educationLevels: ['als'],
        schoolTypes: ['als_center', 'public'],
        courses: 'Any',
        years: 'Basic literacy\nElementary level\nJunior high school level',
        locations: 'Nationwide',
        eligibility: 'Open to ALS learners who can provide enrollment or learning center verification and meet listed requirements.',
        requirements: ['Certificate of enrollment', 'Latest report card or grades', 'Birth certificate', 'Proof of income'],
    },
];
const targetFormProfiles = {
    all: {
        key: 'all',
        title: 'All learners',
        shortLabel: 'all learners',
        icon: 'fa-solid fa-people-group',
        guidance: 'Use broad rules and only add restrictions that truly matter for matching.',
        showProgramPath: true,
        programPathLabel: 'Eligible tracks, strands, courses, or programs',
        programPathPlaceholder: 'Leave blank or use Any when all paths are accepted',
        programPathHelp: 'For open programs, keeping this blank or set to Any prevents false mismatches.',
        programPathTemplate: 'Any',
        levelLabel: 'Eligible grade, year, or training levels',
        levelPlaceholder: 'Example: Any grade or year level',
        levelTemplate: 'Any grade or year level',
        averageLabel: 'Minimum GWA / general average',
        averagePlaceholder: 'Example: 85',
        averageHelp: 'Use the same scale students will enter in their profile.',
        schoolTypeValues: null,
        notes: ['Best for wide public calls', 'Keep restrictions minimal', 'Good for discovery and matching'],
        emptyPathSummary: 'Any track, strand, course, or program',
        emptyLevelSummary: 'Any grade, year, or training level',
    },
    early_basic: {
        key: 'early_basic',
        title: 'Preschool / Elementary form',
        shortLabel: 'preschool or elementary learners',
        icon: 'fa-solid fa-child-reaching',
        guidance: 'Focus on grade level, guardian documents, location, and school type. Course or strand is not needed here.',
        showProgramPath: false,
        programPathLabel: 'Course or strand',
        programPathPlaceholder: '',
        programPathHelp: 'Hidden for younger learners because they do not have a college course or SHS strand.',
        programPathTemplate: 'N/A',
        levelLabel: 'Eligible grade levels',
        levelPlaceholder: 'Example: Kinder 2, Grade 1, Grade 2',
        levelTemplate: 'Nursery\nKinder 1\nKinder 2\nGrade 1\nGrade 2\nGrade 3\nGrade 4\nGrade 5\nGrade 6',
        averageLabel: 'Minimum general average',
        averagePlaceholder: 'Example: 85',
        averageHelp: 'Use report-card average if the scholarship requires grades.',
        schoolTypeValues: ['daycare_learning_center', 'public', 'private'],
        notes: ['No college course field', 'Guardian documents are common', 'Grade level matters most'],
        emptyPathSummary: 'No course or strand required',
        emptyLevelSummary: 'Any preschool or elementary level',
    },
    junior_high: {
        key: 'junior_high',
        title: 'Junior High School form',
        shortLabel: 'junior high school learners',
        icon: 'fa-solid fa-school',
        guidance: 'Use grade level first. Add curriculum or special program only when the scholarship is limited to one.',
        showProgramPath: true,
        programPathLabel: 'Curriculum or special program',
        programPathPlaceholder: 'Optional: STE, SPA, sports program, general curriculum',
        programPathHelp: 'Use Any when the program accepts all Junior High School curricula.',
        programPathTemplate: 'Any',
        levelLabel: 'Eligible grade levels',
        levelPlaceholder: 'Example: Grade 7, Grade 8, Grade 9, Grade 10',
        levelTemplate: 'Grade 7\nGrade 8\nGrade 9\nGrade 10',
        averageLabel: 'Minimum general average',
        averagePlaceholder: 'Example: 85',
        averageHelp: 'Use the learner report-card average.',
        schoolTypeValues: ['public', 'private'],
        notes: ['Grade 7-10 focused', 'Curriculum is optional', 'Good for report-card based matching'],
        emptyPathSummary: 'Any Junior High School curriculum',
        emptyLevelSummary: 'Any Junior High School grade level',
    },
    senior_high: {
        key: 'senior_high',
        title: 'Senior High School form',
        shortLabel: 'senior high school learners',
        icon: 'fa-solid fa-book-open-reader',
        guidance: 'Track and strand are useful here because many SHS scholarships target STEM, ABM, HUMSS, GAS, or TVL.',
        showProgramPath: true,
        programPathLabel: 'Eligible tracks or strands',
        programPathPlaceholder: 'Example: STEM, ABM, HUMSS, GAS, TVL',
        programPathHelp: 'Choose each accepted track or strand. Use Any strand when there is no restriction.',
        programPathTemplate: 'STEM\nABM\nHUMSS\nGAS\nTVL',
        levelLabel: 'Eligible SHS grade levels',
        levelPlaceholder: 'Example: Grade 11, Grade 12',
        levelTemplate: 'Grade 11\nGrade 12',
        averageLabel: 'Minimum general average',
        averagePlaceholder: 'Example: 85',
        averageHelp: 'Use the senior high report-card average.',
        schoolTypeValues: ['public', 'private'],
        notes: ['Track or strand can matter', 'Grade 11-12 focused', 'Useful for STEM/TVL targeting'],
        emptyPathSummary: 'Any SHS track or strand',
        emptyLevelSummary: 'Any Senior High School level',
    },
    college: {
        key: 'college',
        title: 'College / University form',
        shortLabel: 'college or university students',
        icon: 'fa-solid fa-user-graduate',
        guidance: 'Course and year level are important matching fields for college scholarships.',
        showProgramPath: true,
        programPathLabel: 'Eligible courses or degree programs',
        programPathPlaceholder: 'Choose one or more eligible courses',
        programPathHelp: 'Use Any course when the scholarship is not course-specific.',
        programPathTemplate: 'Any course',
        levelLabel: 'Eligible college year levels',
        levelPlaceholder: 'Example: 1st year, 2nd year, Graduating',
        levelTemplate: '1st year\n2nd year\n3rd year\n4th year\n5th year\nGraduating',
        averageLabel: 'Minimum GWA / general average',
        averagePlaceholder: 'Example: 85 or 2.00',
        averageHelp: 'If using grade-point GWA, explain the scale in eligibility details.',
        schoolTypeValues: ['state_university', 'local_college', 'private'],
        notes: ['Course matching is useful', 'Year level matters', 'Transcript is usually required'],
        emptyPathSummary: 'Any college course',
        emptyLevelSummary: 'Any college year level',
    },
    tvet: {
        key: 'tvet',
        title: 'TVET / Vocational form',
        shortLabel: 'TVET or vocational learners',
        icon: 'fa-solid fa-screwdriver-wrench',
        guidance: 'Target the training qualification, certification level, or term instead of college course/year wording.',
        showProgramPath: true,
        programPathLabel: 'Eligible qualifications or training programs',
        programPathPlaceholder: 'Choose one or more eligible training programs',
        programPathHelp: 'Choose each qualification or training program accepted by the provider.',
        programPathTemplate: 'Cookery NC II\nICT / Computer Systems Servicing\nAutomotive Servicing\nElectrical Installation and Maintenance\nCaregiving',
        levelLabel: 'Eligible certification or training level',
        levelPlaceholder: 'Example: NC I, NC II, First term',
        levelTemplate: 'NC I\nNC II\nNC III\nNC IV\nFirst term\nSecond term',
        averageLabel: 'Minimum average or competency rating',
        averagePlaceholder: 'Optional',
        averageHelp: 'Leave blank if the scholarship is based on enrollment or certification readiness instead.',
        schoolTypeValues: ['tvet_center'],
        notes: ['Qualification matters', 'Uses training-level wording', 'Good for skills-based programs'],
        emptyPathSummary: 'Any TVET qualification',
        emptyLevelSummary: 'Any training level',
    },
    als: {
        key: 'als',
        title: 'ALS learner form',
        shortLabel: 'ALS learners',
        icon: 'fa-solid fa-person-chalkboard',
        guidance: 'Focus on ALS level, learning center verification, location, and support needs.',
        showProgramPath: false,
        programPathLabel: 'Course or strand',
        programPathPlaceholder: '',
        programPathHelp: 'Hidden for ALS because matching should use ALS level instead of college course wording.',
        programPathTemplate: 'N/A',
        levelLabel: 'Eligible ALS levels',
        levelPlaceholder: 'Example: Basic literacy, Elementary level, Junior high school level',
        levelTemplate: 'Basic literacy\nElementary level\nJunior high school level',
        averageLabel: 'Minimum assessment score or average',
        averagePlaceholder: 'Optional',
        averageHelp: 'Leave blank when assessment score is not required.',
        schoolTypeValues: ['als_center', 'public'],
        notes: ['No course field needed', 'Learning center proof matters', 'Works for non-traditional pathways'],
        emptyPathSummary: 'No course or strand required',
        emptyLevelSummary: 'Any ALS level',
    },
    mixed: {
        key: 'mixed',
        title: 'Mixed target form',
        shortLabel: 'selected learner groups',
        icon: 'fa-solid fa-layer-group',
        guidance: 'You selected multiple learner groups. Keep labels broad and only restrict fields that apply to every selected group.',
        showProgramPath: true,
        programPathLabel: 'Eligible path, strand, course, or program',
        programPathPlaceholder: 'Choose one or more eligible learner paths',
        programPathHelp: 'Use Any when the selected groups do not share one common path field.',
        programPathTemplate: 'Any',
        levelLabel: 'Eligible grade, year, or training levels',
        levelPlaceholder: 'Example: Grade 12, 1st year, NC II',
        levelTemplate: '',
        averageLabel: 'Minimum GWA / general average',
        averagePlaceholder: 'Example: 85',
        averageHelp: 'Use eligibility notes when different groups use different grade scales.',
        schoolTypeValues: null,
        notes: ['Mixed target', 'Use broad wording', 'Avoid over-restricting matches'],
        emptyPathSummary: 'Any applicable path',
        emptyLevelSummary: 'Any applicable level',
    },
};
const gradeLevelOptionsByEducationLevel = {
    preschool: ['Nursery', 'Kinder 1', 'Kinder 2'],
    elementary: ['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6'],
    junior_high_school: ['Grade 7', 'Grade 8', 'Grade 9', 'Grade 10'],
    senior_high_school: ['Grade 11', 'Grade 12'],
    college: ['1st year', '2nd year', '3rd year', '4th year', '5th year', 'Graduating'],
    tvet: ['NC I', 'NC II', 'NC III', 'NC IV', 'First term', 'Second term'],
    als: ['Basic literacy', 'Elementary level', 'Junior high school level'],
};

const customDocumentRequirements = computed(() => splitRequirementText(scholarshipForm.value.customRequirements)
    .filter((requirement) => !documentRequirementOptions.includes(requirement)));
const customOptionalDocumentRequirements = computed(() => splitRequirementText(scholarshipForm.value.customOptionalRequirements)
    .filter((requirement) => !documentRequirementOptions.includes(requirement)));
const allDocumentRequirements = computed(() => [...new Set([
    ...scholarshipForm.value.requirements,
    ...customDocumentRequirements.value,
])]);
const allOptionalDocumentRequirements = computed(() => [...new Set([
    ...scholarshipForm.value.optionalRequirements,
    ...customOptionalDocumentRequirements.value,
])].filter((requirement) => !allDocumentRequirements.value.includes(requirement)));
const providerProgramDefaults = computed(() => ({
    organizationName: String(user.value?.provider_name ?? '').trim(),
    address: String(user.value?.provider_address ?? '').trim(),
    email: String(user.value?.provider_contact_email ?? '').trim(),
    phone: String(user.value?.provider_contact_number ?? '').trim(),
    website: String(user.value?.provider_website ?? '').trim(),
    logoUrl: String(user.value?.provider_logo_url ?? '').trim(),
}));
const hasProviderAddress = computed(() => Boolean(providerProgramDefaults.value.address));
const hasProviderPublicContact = computed(() => Boolean(
    providerProgramDefaults.value.email
    || providerProgramDefaults.value.phone
    || providerProgramDefaults.value.website,
));
const postQualificationRequirementItems = computed(() =>
    splitRequirementText(scholarshipForm.value.postQualificationRequirements));
const selectedRequirementCount = computed(() => allDocumentRequirements.value.length);
const selectedOptionalRequirementCount = computed(() => allOptionalDocumentRequirements.value.length);
const isProfileReviewOnly = computed(() => scholarshipForm.value.applicationMode === 'provider_review');
const rubricWeightTotal = computed(() => scholarshipForm.value.reviewRubric
    .reduce((total, criterion) => total + Number(criterion.weight || 0), 0));
const reviewRubricReady = computed(() => scholarshipForm.value.reviewRubric.length > 0
    && scholarshipForm.value.reviewRubric.every((criterion) => hasText(criterion.label))
    && rubricWeightTotal.value === 100);
const canPostScholarships = computed(() => user.value?.can_post_scholarships);
const selectionPlanLocked = computed(() => isEditMode.value && existingApplicationCount.value > 0);
const schedulableSelectionStages = computed(() => scholarshipForm.value.selectionStages
    .filter((stage) => ['formal_application', 'exam', 'interview'].includes(stage)));
const hasSchedulableSelectionStage = computed(() => schedulableSelectionStages.value.length > 0);
const schedulableSelectionStageLabel = computed(() => schedulableSelectionStages.value
    .map((stage) => ({
        formal_application: 'formal application',
        exam: 'exam',
        interview: 'interview',
    }[stage]))
    .join(' and '));
const minimumAwardSlots = computed(() => Math.max(1, awardedSlotsCount.value));
const minimumApplicationLimit = computed(() => Math.max(1, existingApplicationCount.value));
const scholarshipImagePreview = computed(() => imagePreviewUrl.value || scholarshipForm.value.imageUrl || '/uploads/scholarship-default.jpg');
const hasSavedProgramLogo = computed(() => isEditMode.value
    && hasText(scholarshipForm.value.imageUrl)
    && !String(scholarshipForm.value.imageUrl).includes('/uploads/scholarship-default.jpg'));
const hasProgramLogo = computed(() => Boolean(
    imageFile.value
    || (useProviderLogoSelected.value && providerProgramDefaults.value.logoUrl)
    || hasSavedProgramLogo.value,
));
const officialProgramPreviewUrl = computed(() => {
    const value = String(scholarshipForm.value.officialProgramUrl || '').trim();

    return /^https?:\/\//i.test(value) ? value : '';
});
const scholarshipFormMapAddress = computed(() => {
    const parts = [
        scholarshipForm.value.locationCity,
        scholarshipForm.value.locationProvince,
        scholarshipForm.value.locationRegion,
    ].filter(Boolean);

    return parts.length ? [...parts, 'Philippines'].join(', ') : '';
});
const scholarshipGoogleMapsAddress = computed(() => {
    const parts = [
        scholarshipForm.value.locationName,
        scholarshipForm.value.locationAddressLine,
        scholarshipForm.value.locationBarangay,
        scholarshipForm.value.locationCity,
        scholarshipForm.value.locationProvince,
        scholarshipForm.value.locationRegion,
    ].map((part) => String(part ?? '').trim()).filter(Boolean);

    return parts.length ? [...parts, 'Philippines'].join(', ') : '';
});
const selectedGradeScaleOption = computed(() => gradeScaleOptions.find((option) => option.value === scholarshipForm.value.minimumGradeScale) ?? gradeScaleOptions[0]);
const academicRequirementNeedsValue = computed(() => ['percentage', 'grade_point'].includes(scholarshipForm.value.minimumGradeScale));
const academicRequirementSummary = computed(() => {
    if (scholarshipForm.value.minimumGradeScale === 'pass_fail') {
        return 'Pass/fail or competency';
    }

    if (scholarshipForm.value.minimumGradeScale === 'other') {
        return 'Manual academic review';
    }

    if (!academicRequirementNeedsValue.value || !hasText(scholarshipForm.value.minimumGwa)) {
        return 'No academic minimum';
    }

    return scholarshipForm.value.minimumGradeScale === 'grade_point'
        ? `Max GWA/GPA ${scholarshipForm.value.minimumGwa}`
        : `Min average ${scholarshipForm.value.minimumGwa}%`;
});
const academicRequirementInputMax = computed(() => scholarshipForm.value.minimumGradeScale === 'grade_point' ? 5 : 100);
const academicRequirementInputStep = computed(() => scholarshipForm.value.minimumGradeScale === 'grade_point' ? '0.01' : '0.01');
const hasRestrictiveFinderSettings = computed(() => (
    (scholarshipForm.value.eligibleEducationLevels.length > 0
        && !hasSameMembers(scholarshipForm.value.eligibleEducationLevels, allEducationLevelValues))
    || !isOpenEligibilityRule(scholarshipForm.value.eligibleCourses)
    || scholarshipForm.value.eligibleSchoolTypes.length > 0
    || !isOpenEligibilityRule(scholarshipForm.value.eligibleYearLevels)
    || !isOpenEligibilityRule(scholarshipForm.value.eligibleLocations)
    || scholarshipForm.value.excludeCurrentScholarshipRecipients
    || !isOpenEligibilityRule(scholarshipForm.value.incomeRequirement)
    || hasText(scholarshipForm.value.minimumGradeScale)
    || hasText(scholarshipForm.value.minimumGwa)
));
const eligibilityRuleIssues = computed(() => {
    const selected = new Set(selectedEligibilityOptions.value);
    const issues = [];

    if (selected.has('open_to_all')
        && (selectedEligibilityOptions.value.length > 1 || hasRestrictiveFinderSettings.value)) {
        issues.push('Open to all learners cannot be combined with another condition or a restrictive matching field.');
    }

    if (selected.has('academic_performance')
        && !hasText(scholarshipForm.value.minimumGradeScale)
        && !hasText(scholarshipForm.value.minimumGwa)) {
        issues.push('Choose an academic grading rule or remove Academic requirement.');
    }

    if (selected.has('financial_need') && isOpenEligibilityRule(scholarshipForm.value.incomeRequirement)) {
        issues.push('Choose an income range or remove Financial need.');
    }

    if (selected.has('location_coverage') && isOpenEligibilityRule(scholarshipForm.value.eligibleLocations)) {
        issues.push('Add a covered location or remove Location coverage.');
    }

    if (selected.has('required_documents') && isProfileReviewOnly.value) {
        issues.push('Profile review only cannot verify required files. Choose a portal document review method or remove Required documents.');
    } else if (selected.has('required_documents') && selectedRequirementCount.value === 0) {
        issues.push('Select at least one pre-screening file or remove Required documents.');
    }

    if (selected.has(customEligibilityOption) && !hasText(customEligibilityText.value)) {
        issues.push('Write the custom condition or remove Custom eligibility.');
    }

    return issues;
});
const reviewSubmissionSelected = computed(() => ['pending_review', 'rejected'].includes(scholarshipForm.value.status));
const termsRequiredForSave = computed(() => !['draft', 'closed'].includes(scholarshipForm.value.status));
const deadlineReady = computed(() => hasText(scholarshipForm.value.deadline)
    && scholarshipForm.value.deadline >= todayDate);
const applicationWindowReady = computed(() => !hasText(scholarshipForm.value.applicationOpensAt)
    || !hasText(scholarshipForm.value.deadline)
    || scholarshipForm.value.applicationOpensAt <= scholarshipForm.value.deadline);
const resultsDateReady = computed(() => !hasText(scholarshipForm.value.expectedResultsAt)
    || !hasText(scholarshipForm.value.deadline)
    || scholarshipForm.value.expectedResultsAt >= scholarshipForm.value.deadline);
const supportPeriodReady = computed(() => hasText(scholarshipForm.value.supportStartsAt)
    && hasText(scholarshipForm.value.supportEndsAt)
    && scholarshipForm.value.supportEndsAt >= scholarshipForm.value.supportStartsAt);
const recipientAgreementReady = computed(() => {
    if (!hasText(scholarshipForm.value.recipientAgreement.release_conditions)) {
        return false;
    }

    if (selectedCommitmentOption.value === 'none') {
        return true;
    }

    return selectedCommitmentOption.value !== 'provider_briefing'
        && hasText(scholarshipForm.value.recipientAgreement.responsibilities)
        && hasText(scholarshipForm.value.recipientAgreement.required_evidence)
        && hasText(scholarshipForm.value.recipientAgreement.duration)
        && hasText(scholarshipForm.value.recipientAgreement.noncompliance_consequence)
        && hasText(scholarshipForm.value.recipientAgreement.exit_or_exception_process);
});
const recipientReleaseDetailsReady = computed(() => (
    hasText(scholarshipForm.value.recipientAgreement.required_evidence)
    && hasText(scholarshipForm.value.recipientAgreement.release_conditions)
    && hasText(scholarshipForm.value.recipientAgreement.duration)
));
const recipientExceptionDetailsReady = computed(() => (
    hasText(scholarshipForm.value.recipientAgreement.noncompliance_consequence)
    && hasText(scholarshipForm.value.recipientAgreement.exit_or_exception_process)
));
const programReadinessItems = computed(() => [
    {
        label: 'Program overview',
        section: 'details',
        complete: hasText(scholarshipForm.value.title)
            && hasText(scholarshipForm.value.category)
            && hasText(scholarshipForm.value.programCycle)
            && hasText(scholarshipForm.value.description),
        help: 'Title, category, program cycle, and a clear description.',
    },
    {
        label: 'Program logo',
        section: 'details',
        complete: hasProgramLogo.value,
        help: 'Upload a program logo or reuse the provider logo.',
    },
    {
        label: 'Support package',
        section: 'support',
        complete: scholarshipForm.value.benefits.length > 0,
        help: 'Add at least one benefit recipients will receive.',
    },
    {
        label: 'Program dates',
        section: 'logistics',
        complete: deadlineReady.value
            && applicationWindowReady.value
            && resultsDateReady.value
            && supportPeriodReady.value,
        help: 'Set a valid deadline and recipient support period.',
    },
    {
        label: 'Eligibility and matching rules',
        section: 'eligibility',
        complete: hasText(scholarshipForm.value.eligibility)
            && eligibilityRuleIssues.value.length === 0
            && (
                scholarshipForm.value.eligibleEducationLevels.length > 0
                || hasText(scholarshipForm.value.eligibleCourses)
                || scholarshipForm.value.eligibleSchoolTypes.length > 0
                || hasText(scholarshipForm.value.eligibleYearLevels)
                || hasText(scholarshipForm.value.eligibleLocations)
                || scholarshipForm.value.incomeRequirement !== 'Any'
                || scholarshipForm.value.minimumGradeScale === 'pass_fail'
                || scholarshipForm.value.minimumGradeScale === 'other'
                || hasText(scholarshipForm.value.minimumGwa)
            ),
        help: eligibilityRuleIssues.value[0] || 'Eligibility text and at least one finder rule.',
    },
    {
        label: 'Verification method',
        section: 'application',
        complete: hasText(scholarshipForm.value.applicationMode),
        help: 'How applicants will complete portal pre-screening.',
    },
    {
        label: 'Document checklist',
        section: 'application',
        complete: isProfileReviewOnly.value || selectedRequirementCount.value > 0,
        help: isProfileReviewOnly.value
            ? 'No program files are required for the initial profile review.'
            : 'Minimal proof applicants upload for portal review.',
    },
    {
        label: 'Formal application handoff',
        section: 'application',
        complete: postQualificationRequirementItems.value.length > 0
            && hasText(scholarshipForm.value.handoffMode)
            && hasText(scholarshipForm.value.handoffInstructions)
            && (scholarshipForm.value.handoffMode !== 'onsite' || hasText(scholarshipForm.value.handoffLocationAddress))
            && (scholarshipForm.value.handoffMode !== 'online' || hasText(scholarshipForm.value.handoffUrl)),
        help: 'Documents and instructions released when an applicant qualifies.',
    },
    {
        label: 'Selection flow',
        section: 'selection',
        complete: scholarshipForm.value.selectionStages.includes('screening'),
        help: 'A review stage and any additional stages used by the provider.',
    },
    {
        label: 'Review scoring',
        section: 'selection',
        complete: reviewRubricReady.value,
        help: 'A complete rubric with weights totaling 100%.',
    },
    {
        label: 'Provider expectation disclosure',
        section: 'application',
        complete: recipientAgreementReady.value,
        help: 'State what your organization expects from recipients so applicants and admins can compare it with the support offered.',
    },
    {
        label: 'Program location',
        section: 'logistics',
        complete: hasText(scholarshipForm.value.locationName)
            && hasText(scholarshipForm.value.locationRegion)
            && hasText(scholarshipForm.value.locationProvince)
            && hasText(scholarshipForm.value.locationCity)
            && hasText(scholarshipForm.value.latitude)
            && hasText(scholarshipForm.value.longitude),
        help: 'General location and map pin for distance estimates.',
    },
    {
        label: 'Public contact',
        section: 'logistics',
        complete: hasText(scholarshipForm.value.contactEmail)
            || hasText(scholarshipForm.value.contactNumber),
        help: 'An official email address or phone number applicants can use.',
    },
]);
const missingProgramReadinessItems = computed(() => programReadinessItems.value.filter((item) => !item.complete));
const completedProgramReadinessCount = computed(() => programReadinessItems.value.length - missingProgramReadinessItems.value.length);
const activeFormSectionIndex = computed(() => formSections.findIndex((section) => section.id === activeFormSection.value));
const activeFormSectionMeta = computed(() => formSections[activeFormSectionIndex.value] ?? formSections[0]);
const finderRuleSummary = computed(() => [
    scholarshipForm.value.eligibleEducationLevels.length
        && !hasSameMembers(scholarshipForm.value.eligibleEducationLevels, allEducationLevelValues)
        ? `${scholarshipForm.value.eligibleEducationLevels.length} education level${scholarshipForm.value.eligibleEducationLevels.length === 1 ? '' : 's'}`
        : 'All education levels',
    scholarshipForm.value.eligibleSchoolTypes.length ? `${scholarshipForm.value.eligibleSchoolTypes.length} school type${scholarshipForm.value.eligibleSchoolTypes.length === 1 ? '' : 's'}` : 'All school types',
    academicRequirementSummary.value,
    scholarshipForm.value.incomeRequirement && scholarshipForm.value.incomeRequirement !== 'Any' ? scholarshipForm.value.incomeRequirement : 'Any income',
]);
const activeTargetKey = computed(() => inferTargetFormKey(scholarshipForm.value.eligibleEducationLevels));
const activeTargetForm = computed(() => targetFormProfiles[activeTargetKey.value] ?? targetFormProfiles.mixed);
const programPathSelectOptions = computed(() => providerProgramPathOptionsForTarget(activeTargetKey.value));
const selectedProgramPaths = computed(() => splitProgramPaths(scholarshipForm.value.eligibleCourses));
const customSelectedProgramPaths = computed(() => selectedProgramPaths.value.filter((path) => (
    !programPathSelectOptions.value.some((option) => (
        normalizeProgramPath(option) === normalizeProgramPath(path)
    ))
)));
const selectedGradeLevels = computed(() => splitRequirementText(scholarshipForm.value.eligibleYearLevels));
const selectedEligibleLocations = computed(() => splitRequirementText(scholarshipForm.value.eligibleLocations));
const gradeLevelSelectOptions = computed(() => {
    const selectedEducationLevels = scholarshipForm.value.eligibleEducationLevels.length
        ? scholarshipForm.value.eligibleEducationLevels
        : allEducationLevelValues;
    const levels = selectedEducationLevels.flatMap((level) => gradeLevelOptionsByEducationLevel[level] ?? []);

    return ['Any grade or year level', ...new Set(levels)];
});
const targetSchoolTypeOptions = computed(() => {
    const values = activeTargetForm.value.schoolTypeValues;

    if (!Array.isArray(values)) {
        return schoolTypeOptions;
    }

    return schoolTypeOptions.filter((option) => values.includes(option.value));
});
const hiddenSelectedSchoolTypeLabels = computed(() => {
    const visibleValues = new Set(targetSchoolTypeOptions.value.map((option) => option.value));
    const hiddenValues = scholarshipForm.value.eligibleSchoolTypes.filter((value) => !visibleValues.has(value));

    return optionLabels(hiddenValues, schoolTypeOptions);
});
const additionalRestrictionCount = computed(() => [
    selectedProgramPaths.value.some((path) => !isOpenProgramPath(path)),
    selectedGradeLevels.value.some((level) => !['any', 'all', 'any grade or year level'].includes(String(level).trim().toLowerCase())),
    !isOpenEligibilityRule(scholarshipForm.value.eligibleLocations),
    !isOpenEligibilityRule(scholarshipForm.value.incomeRequirement),
    scholarshipForm.value.excludeCurrentScholarshipRecipients,
].filter(Boolean).length);
const statusOptions = computed(() => {
    const options = [
        { value: 'draft', label: 'Save as draft', help: 'Only provider can see it.' },
        { value: 'pending_review', label: 'Submit for admin review', help: 'Admin must approve before students see it.' },
    ];

    if (scholarshipForm.value.status === 'rejected') {
        options.push({ value: 'rejected', label: 'Rejected by admin', help: 'Edit and resubmit when ready.' });
    }

    if (scholarshipForm.value.status === 'published') {
        options.push({ value: 'published', label: 'Published', help: 'Currently visible to students.' });
        options.push({ value: 'closed', label: 'Closed', help: 'Stop accepting new student applications.' });
    }

    if (scholarshipForm.value.status === 'closed') {
        options.push({ value: 'closed', label: 'Closed', help: 'Stop accepting new student applications.' });
    }

    return options;
});
const submitButtonLabel = computed(() => {
    if (isSaving.value) {
        return 'Saving...';
    }

    if (scholarshipForm.value.status === 'draft') {
        return 'Save draft';
    }

    if (scholarshipForm.value.status === 'closed') {
        return 'Close program';
    }

    if (scholarshipForm.value.status === 'published') {
        return 'Save changes';
    }

    return scholarshipForm.value.status === 'rejected'
        ? 'Resubmit for review'
        : 'Submit for review';
});
const stepNavigationSaves = computed(() => !isEditMode.value || scholarshipForm.value.status === 'draft');

function formSectionFromLocation() {
    return sectionFromProviderProgramFormPath(window.location.pathname);
}

function programStepUrl(sectionId) {
    return providerProgramFormStepUrl(scholarshipId.value, sectionId);
}

function syncProgramStepUrl(sectionId, replace = false) {
    const url = programStepUrl(sectionId);

    if (!url || window.location.pathname === url) {
        return;
    }

    window.history[replace ? 'replaceState' : 'pushState']({}, '', url);
}

async function openFormSection(sectionId, options = {}) {
    if (!formSections.some((section) => section.id === sectionId)) {
        return;
    }

    activeFormSection.value = sectionId;
    if (options.syncUrl !== false) {
        syncProgramStepUrl(sectionId, Boolean(options.replaceUrl));
    }
    await nextTick();
    scholarshipFormElement.value?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function handleProgramStepHistory() {
    activeFormSection.value = formSectionFromLocation();
}

function openFormSubsection(subsectionId) {
    if (!formSubsections[activeFormSection.value]?.some((subsection) => subsection.id === subsectionId)) {
        return;
    }

    activeFormSubsection.value[activeFormSection.value] = subsectionId;
}

function revealFieldSubsection(sectionId, fieldId) {
    if (sectionId === 'eligibility') {
        const requirementsFields = [
            'scholarship-eligibility',
            'target-applicant-preset',
            'scholarship-grade-scale',
            'scholarship-minimum-gwa',
            'scholarship-custom-eligibility',
        ];
        activeFormSubsection.value.eligibility = requirementsFields.includes(fieldId)
            ? 'requirements'
            : 'matching';

        if (['scholarship-education-levels', 'scholarship-school-types'].includes(fieldId)) {
            showCoreMatchingRules.value = true;
        }

        if (['scholarship-courses', 'scholarship-years', 'scholarship-eligible-locations', 'scholarship-income'].includes(fieldId)) {
            showAdditionalMatchingRules.value = true;
        }
    }

    if (sectionId === 'application') {
        if (['scholarship-mode', 'scholarship-custom-requirements', 'scholarship-custom-optional-requirements'].includes(fieldId)) {
            activeFormSubsection.value.application = 'files';
            showDocumentChecklist.value = fieldId !== 'scholarship-mode';
        } else if (fieldId === 'scholarship-commitment-option' || fieldId?.startsWith('scholarship-agreement-')) {
            activeFormSubsection.value.application = 'expectations';

            if (['scholarship-agreement-evidence', 'scholarship-agreement-release-conditions', 'scholarship-agreement-duration'].includes(fieldId)) {
                showRecipientReleaseDetails.value = true;
            }

            if (['scholarship-agreement-consequence', 'scholarship-agreement-exit'].includes(fieldId)) {
                showRecipientExceptionDetails.value = true;
            }
        } else {
            activeFormSubsection.value.application = 'handoff';
        }
    }

    if (sectionId === 'selection') {
        activeFormSubsection.value.selection = fieldId?.startsWith('rubric-') ? 'scoring' : 'flow';
    }
}

async function focusFormField(sectionId, fieldId) {
    activeFormSection.value = sectionId;
    syncProgramStepUrl(sectionId);
    revealFieldSubsection(sectionId, fieldId);
    await nextTick();

    const field = document.getElementById(fieldId);

    field?.focus({ preventScroll: true });
    field?.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function readinessFocusTarget(item) {
    if (item.label === 'Program overview') {
        if (!hasText(scholarshipForm.value.title)) return 'scholarship-title';
        if (!hasText(scholarshipForm.value.category)) return 'scholarship-category';
        if (!hasText(scholarshipForm.value.programCycle)) return 'scholarship-program-cycle';

        return 'scholarship-description';
    }

    if (item.label === 'Program logo') return 'scholarship-image';

    if (item.label === 'Support package') return 'program-benefit-type';

    if (item.label === 'Program dates') {
        if (!applicationWindowReady.value) return 'scholarship-application-opens';
        if (!resultsDateReady.value) return 'scholarship-expected-results';
        if (!hasText(scholarshipForm.value.supportStartsAt)) return 'scholarship-support-starts';
        if (!hasText(scholarshipForm.value.supportEndsAt) || !supportPeriodReady.value) return 'scholarship-support-ends';

        return 'scholarship-deadline';
    }

    if (item.label === 'Eligibility and matching rules') {
        if (!hasText(scholarshipForm.value.eligibility)) return 'scholarship-eligibility';

        const issue = eligibilityRuleIssues.value[0] ?? '';

        if (issue.includes('academic grading')) return 'scholarship-grade-scale';
        if (issue.includes('income range')) return 'scholarship-income';
        if (issue.includes('covered location')) return 'scholarship-eligible-locations';
        if (issue.includes('custom condition')) return 'scholarship-custom-eligibility';

        return 'target-applicant-preset';
    }

    if (item.label === 'Verification method') return 'scholarship-mode';
    if (item.label === 'Document checklist') return 'scholarship-custom-requirements';
    if (item.label === 'Formal application handoff') {
        if (!postQualificationRequirementItems.value.length) return 'scholarship-post-qualification-requirements';
        if (!hasText(scholarshipForm.value.handoffMode)) return 'scholarship-handoff-mode';
        if (scholarshipForm.value.handoffMode === 'onsite' && !hasText(scholarshipForm.value.handoffLocationAddress)) return 'scholarship-handoff-location-address';
        if (scholarshipForm.value.handoffMode === 'online' && !hasText(scholarshipForm.value.handoffUrl)) return 'scholarship-handoff-url';

        return 'scholarship-handoff-instructions';
    }

    if (item.label === 'Program location') {
        if (!hasText(scholarshipForm.value.locationName)) return 'scholarship-location-name';
        if (!hasText(scholarshipForm.value.locationRegion)) return 'scholarship-location-region';
        if (!hasText(scholarshipForm.value.locationProvince)) return 'scholarship-location-province';
        if (!hasText(scholarshipForm.value.locationCity)) return 'scholarship-location-city';

        return 'scholarship-map-toggle';
    }

    if (item.label === 'Selection flow') return 'scholarship-selection-stages';
    if (item.label === 'Public contact') return 'scholarship-contact-email';
    if (item.label === 'Exam details') return 'scholarship-exam-duration';
    if (item.label === 'Review scoring') return `rubric-label-${scholarshipForm.value.reviewRubric[0]?.key}`;
    if (item.label === 'Provider expectation disclosure') {
        if (selectedCommitmentOption.value === 'provider_briefing') return 'scholarship-commitment-option';
        if (selectedCommitmentOption.value !== 'none' && !hasText(scholarshipForm.value.recipientAgreement.responsibilities)) return 'scholarship-agreement-responsibilities';
        if (selectedCommitmentOption.value !== 'none' && !hasText(scholarshipForm.value.recipientAgreement.required_evidence)) return 'scholarship-agreement-evidence';
        if (!hasText(scholarshipForm.value.recipientAgreement.release_conditions)) {
            return selectedCommitmentOption.value === 'none'
                ? 'scholarship-agreement-release-conditions-none'
                : 'scholarship-agreement-release-conditions';
        }
        if (selectedCommitmentOption.value !== 'none' && !hasText(scholarshipForm.value.recipientAgreement.duration)) return 'scholarship-agreement-duration';
        if (selectedCommitmentOption.value !== 'none' && !hasText(scholarshipForm.value.recipientAgreement.noncompliance_consequence)) return 'scholarship-agreement-consequence';
        if (selectedCommitmentOption.value !== 'none' && !hasText(scholarshipForm.value.recipientAgreement.exit_or_exception_process)) return 'scholarship-agreement-exit';

        return 'scholarship-commitment-option';
    }

    return '';
}

async function validateActiveFormSection() {
    const missingItem = programReadinessItems.value.find((item) => (
        item.section === activeFormSection.value && !item.complete
    ));

    if (!missingItem) {
        return true;
    }

    const fieldId = readinessFocusTarget(missingItem);

    if (fieldId) {
        await focusFormField(missingItem.section, fieldId);
    }

    formError.value = `${missingItem.label} is incomplete. ${missingItem.help}`;

    return false;
}

async function navigateFromFormSection(sectionId, validateCurrent = false) {
    if (sectionId === activeFormSection.value || isSaving.value) {
        return;
    }

    formError.value = '';

    if (validateCurrent && !await validateActiveFormSection()) {
        return;
    }

    if (!isEditMode.value || scholarshipForm.value.status === 'draft') {
        await saveScholarship({ mode: 'step', targetSection: sectionId });
        return;
    }

    await openFormSection(sectionId);
}

function goToPreviousFormSection() {
    const previous = formSections[activeFormSectionIndex.value - 1];

    if (previous) {
        navigateFromFormSection(previous.id);
    }
}

function goToNextFormSection() {
    const next = formSections[activeFormSectionIndex.value + 1];

    if (next) {
        navigateFromFormSection(next.id, true);
    }
}

function hasText(value) {
    return value !== null && value !== undefined && String(value).trim() !== '';
}

function isOpenEligibilityRule(value) {
    const normalized = String(value ?? '').trim().toLowerCase().replace(/\s+/g, ' ');

    return ['', 'any', 'all', 'open to all', 'nationwide', 'no restriction', 'no income requirement', 'any income']
        .includes(normalized);
}

function formatPreviewDate(value, fallback = 'Not specified') {
    if (!hasText(value)) {
        return fallback;
    }

    return new Intl.DateTimeFormat('en-PH', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
    }).format(new Date(`${value}T00:00:00`));
}

function applicationModeLabel(value) {
    const normalizedValue = value === 'hybrid' ? 'onsite' : value;

    return applicationModeOptions.find((option) => option.value === normalizedValue)?.label ?? 'Not specified';
}

function applicationModeDetail(value) {
    if (value === 'provider_review') {
        return 'Use profile and matching data for the initial review. Applicants are not required to upload program files before submitting.';
    }

    const normalizedValue = value === 'hybrid' ? 'onsite' : value;

    return applicationModeOptions.find((option) => option.value === normalizedValue)?.detail
        ?? 'Choose how the provider will verify applicants during the portal review.';
}

function optionLabels(values, options) {
    return values
        .map((value) => options.find((option) => option.value === value)?.label ?? value)
        .filter(Boolean);
}

function hasSameMembers(values, expectedValues) {
    return values.length === expectedValues.length
        && expectedValues.every((value) => values.includes(value));
}

function onlyContains(values, allowedValues) {
    return values.length > 0 && values.every((value) => allowedValues.includes(value));
}

function inferTargetFormKey(educationLevels) {
    const selectedLevels = [...new Set(educationLevels.filter(Boolean))];

    if (selectedLevels.length === 0 || hasSameMembers(selectedLevels, allEducationLevelValues)) {
        return 'all';
    }

    if (onlyContains(selectedLevels, ['preschool', 'elementary'])) {
        return 'early_basic';
    }

    if (hasSameMembers(selectedLevels, ['junior_high_school'])) {
        return 'junior_high';
    }

    if (hasSameMembers(selectedLevels, ['senior_high_school'])) {
        return 'senior_high';
    }

    if (hasSameMembers(selectedLevels, ['college'])) {
        return 'college';
    }

    if (hasSameMembers(selectedLevels, ['tvet'])) {
        return 'tvet';
    }

    if (hasSameMembers(selectedLevels, ['als'])) {
        return 'als';
    }

    return 'mixed';
}

function defaultReviewRubric() {
    return [
        {
            key: 'eligibility_fit',
            label: 'Eligibility fit',
            weight: 35,
            guidance: 'Confirm that the applicant meets the program-specific target and restrictions.',
        },
        {
            key: 'academic_merit',
            label: 'Academic merit',
            weight: 25,
            guidance: 'Review grades using the scale and education level required by this program.',
        },
        {
            key: 'financial_need',
            label: 'Financial need',
            weight: 20,
            guidance: 'Review declared need and supporting income documents where applicable.',
        },
        {
            key: 'document_quality',
            label: 'Document quality',
            weight: 20,
            guidance: 'Check whether required documents are complete, readable, current, and valid.',
        },
    ];
}

function emptyScholarshipForm() {
    return {
        title: '',
        category: '',
        programCycle: '',
        description: '',
        providerObjectives: [],
        providerObjectiveNotes: '',
        eligibility: '',
        customEligibilityVerification: 'provider_verification',
        eligibleEducationLevels: [],
        eligibleCourses: '',
        eligibleSchoolTypes: [],
        eligibleYearLevels: '',
        eligibleLocations: '',
        incomeRequirement: 'Any',
        excludeCurrentScholarshipRecipients: false,
        locationName: '',
        locationAddress: '',
        locationAddressLine: '',
        locationBarangay: '',
        locationCity: '',
        locationProvince: '',
        locationRegion: '',
        latitude: '',
        longitude: '',
        requirements: [
            'Certificate of enrollment',
            'Latest report card or grades',
            'Recent school ID',
            'Proof of income',
        ],
        customRequirements: '',
        optionalRequirements: [],
        customOptionalRequirements: '',
        postQualificationRequirements: '',
        handoffMode: 'onsite',
        handoffInstructions: 'Bring the listed documents to the provider for final verification and the formal application process.',
        handoffDeadline: '',
        handoffLocationName: '',
        handoffLocationAddress: '',
        handoffUrl: '',
        reviewRubric: defaultReviewRubric(),
        applicationQuestions: [],
        benefits: [],
        minimumGwa: '',
        minimumGradeScale: '',
        slotsAvailable: '',
        applicationLimit: '',
        applicationMode: 'online',
        selectionStages: ['screening', 'formal_application', 'decision'],
        renewalPolicy: '',
        returnServiceContract: '',
        otherContractTerms: defaultCommitmentText,
        recipientAgreement: {
            commitment_type: 'provider_briefing',
            responsibilities: '',
            required_evidence: '',
            release_conditions: '',
            duration: '',
            noncompliance_consequence: '',
            exit_or_exception_process: '',
        },
        contactEmail: window.portalUser?.provider_contact_email ?? '',
        contactNumber: window.portalUser?.provider_contact_number ?? '',
        applicationOpensAt: '',
        expectedResultsAt: '',
        supportStartsAt: '',
        supportEndsAt: '',
        officialProgramUrl: '',
        contactPerson: '',
        contactDepartment: '',
        deadline: '',
        status: 'draft',
        imageUrl: '/uploads/scholarship-default.jpg',
        termsAccepted: false,
    };
}

function splitRequirementText(requirements) {
    if (!requirements) {
        return [];
    }

    return String(requirements)
        .split(/\r?\n|,/)
        .map((requirement) => requirement.trim())
        .filter(Boolean);
}

function parseRequirements(requirements) {
    return splitRequirementText(requirements)
        .filter((requirement) => documentRequirementOptions.includes(requirement));
}

function parseCustomRequirements(requirements) {
    return splitRequirementText(requirements)
        .filter((requirement) => !documentRequirementOptions.includes(requirement));
}

function parseSelections(value, validOptions) {
    const validValues = validOptions.map((option) => option.value);

    if (!value) {
        return [];
    }

    return String(value)
        .split(/\r?\n|,/)
        .map((item) => item.trim())
        .filter((item) => validValues.includes(item));
}

function toggleSelectionStage(stage) {
    const option = selectionStageOptions.find((item) => item.value === stage);

    if (option?.required || selectionPlanLocked.value || !['exam', 'interview'].includes(stage)) {
        return;
    }

    const selected = scholarshipForm.value.selectionStages.includes(stage)
        ? scholarshipForm.value.selectionStages.filter((item) => item !== stage)
        : [
            ...scholarshipForm.value.selectionStages.filter((item) => item !== 'decision'),
            stage,
            'decision',
        ];

    scholarshipForm.value.selectionStages = normalizeSelectionStages(selected);
}

function normalizeSelectionStages(stages) {
    const allowedMiddle = ['formal_application', 'exam', 'interview'];
    const middle = (Array.isArray(stages) ? stages : [])
        .map((stage) => stage === 'distribution' ? 'decision' : stage)
        .filter((stage, index, values) => allowedMiddle.includes(stage) && values.indexOf(stage) === index);

    if (!middle.includes('formal_application')) {
        middle.unshift('formal_application');
    }

    return ['screening', ...middle, 'decision'];
}

function moveSelectionStage(stage, direction) {
    if (selectionPlanLocked.value) {
        return;
    }

    const stages = normalizeSelectionStages(scholarshipForm.value.selectionStages);
    const middle = stages.filter((item) => !['screening', 'decision'].includes(item));
    const currentIndex = middle.indexOf(stage);
    const nextIndex = currentIndex + direction;

    if (currentIndex < 0 || nextIndex < 0 || nextIndex >= middle.length) {
        return;
    }

    [middle[currentIndex], middle[nextIndex]] = [middle[nextIndex], middle[currentIndex]];
    scholarshipForm.value.selectionStages = ['screening', ...middle, 'decision'];
}

function selectAllOptions(field, options) {
    scholarshipForm.value[field] = options.map((option) => option.value);
}

function setEligibleProgramPaths(paths) {
    scholarshipForm.value.eligibleCourses = canonicalizeProgramPathList(paths.join('\n'));
}

function isProgramPathSelected(path) {
    const normalizedPath = normalizeProgramPath(canonicalProgramPath(path));

    return selectedProgramPaths.value.some((selectedPath) => (
        normalizeProgramPath(selectedPath) === normalizedPath
    ));
}

function addEligibleProgramPath(path) {
    const nextPath = canonicalProgramPath(path);

    if (!nextPath || nextPath === 'Other') {
        return;
    }

    if (isOpenProgramPath(nextPath)) {
        setEligibleProgramPaths([nextPath]);
        return;
    }

    const specificPaths = selectedProgramPaths.value.filter((selectedPath) => (
        !isOpenProgramPath(selectedPath)
        && normalizeProgramPath(selectedPath) !== normalizeProgramPath(nextPath)
    ));

    setEligibleProgramPaths([...specificPaths, nextPath]);
}

function toggleEligibleProgramPath(path) {
    if (isProgramPathSelected(path)) {
        removeEligibleProgramPath(path);
        return;
    }

    addEligibleProgramPath(path);
}

function addCustomProgramPath() {
    if (!customProgramPath.value.trim()) {
        return;
    }

    addEligibleProgramPath(customProgramPath.value);
    customProgramPath.value = '';
}

function removeEligibleProgramPath(path) {
    setEligibleProgramPaths(selectedProgramPaths.value.filter((selectedPath) => (
        normalizeProgramPath(selectedPath) !== normalizeProgramPath(path)
    )));
}

function setEligibleGradeLevels(levels) {
    scholarshipForm.value.eligibleYearLevels = [...new Set(levels)].join('\n');
}

function isGradeLevelSelected(level) {
    return selectedGradeLevels.value.includes(level);
}

function toggleEligibleGradeLevel(level) {
    if (isGradeLevelSelected(level)) {
        removeEligibleGradeLevel(level);
        return;
    }

    if (level === 'Any grade or year level') {
        setEligibleGradeLevels([level]);
    } else {
        setEligibleGradeLevels([
            ...selectedGradeLevels.value.filter((selectedLevel) => selectedLevel !== 'Any grade or year level'),
            level,
        ]);
    }
}

function removeEligibleGradeLevel(level) {
    setEligibleGradeLevels(selectedGradeLevels.value.filter((selectedLevel) => selectedLevel !== level));
}

function setEligibleLocations(locations) {
    scholarshipForm.value.eligibleLocations = [...new Set(locations)].join('\n');
}

async function loadCoverageCities(requestId = coverageRequestId) {
    coverageCityOptions.value = [];
    coverageCity.value = '';

    if (!coverageRegionCode.value || !coverageProvinceCode.value || coverageLevel.value !== 'city') {
        return;
    }

    isLoadingCoverageCities.value = true;

    try {
        const cities = await citiesForLocation(coverageRegionCode.value, coverageProvinceCode.value);

        if (requestId === coverageRequestId) {
            coverageCityOptions.value = cities;
        }
    } catch (error) {
        if (requestId === coverageRequestId) {
            coverageOptionsError.value = 'City and municipality options could not be loaded. Check your internet connection and try again.';
        }
    } finally {
        if (requestId === coverageRequestId) {
            isLoadingCoverageCities.value = false;
        }
    }
}

async function handleCoverageRegionChange() {
    const requestId = ++coverageRequestId;

    coverageProvinceCode.value = '';
    coverageCity.value = '';
    coverageProvinceOptions.value = [];
    coverageCityOptions.value = [];
    coverageOptionsError.value = '';

    if (!coverageRegionCode.value || coverageLevel.value === 'region') {
        return;
    }

    isLoadingCoverageProvinces.value = true;

    try {
        const provinces = await provincesForRegion(coverageRegionCode.value);

        if (requestId !== coverageRequestId) {
            return;
        }

        coverageProvinceOptions.value = provinces;

        if (coverageRegionCode.value === '1300000000') {
            coverageProvinceCode.value = '1300000000';
            await loadCoverageCities(requestId);
        }
    } catch (error) {
        if (requestId === coverageRequestId) {
            coverageOptionsError.value = 'Province options could not be loaded. Check your internet connection and try the region again.';
        }
    } finally {
        if (requestId === coverageRequestId) {
            isLoadingCoverageProvinces.value = false;
        }
    }
}

function handleCoverageProvinceChange() {
    const requestId = ++coverageRequestId;

    coverageOptionsError.value = '';
    loadCoverageCities(requestId);
}

function handleCoverageLevelChange() {
    handleCoverageRegionChange();
}

function addEligibleLocation() {
    const region = philippineRegionOptions.find((option) => option.code === coverageRegionCode.value);
    const province = coverageProvinceOptions.value.find((option) => option.code === coverageProvinceCode.value);
    const location = coverageLevel.value === 'region'
        ? region?.value
        : coverageLevel.value === 'province'
            ? province?.value
            : coverageCity.value;

    if (!location) {
        coverageOptionsError.value = `Select a ${coverageLevel.value === 'city' ? 'city or municipality' : coverageLevel.value} before adding coverage.`;
        return;
    }

    const existing = selectedEligibleLocations.value
        .filter((item) => !['nationwide', 'any', 'open to all'].includes(item.toLowerCase()));

    if (!existing.some((item) => item.toLowerCase() === location.toLowerCase())) {
        setEligibleLocations([...existing, location]);
    }

    selectedEligibilityOptions.value = [
        ...selectedEligibilityOptions.value.filter((key) => key !== 'open_to_all'),
        ...(selectedEligibilityOptions.value.includes('location_coverage') ? [] : ['location_coverage']),
    ];
    updateEligibilitySummary();

    coverageOptionsError.value = '';
}

function removeEligibleLocation(location) {
    setEligibleLocations(selectedEligibleLocations.value.filter((item) => item !== location));
}

function setNationwideCoverage() {
    setEligibleLocations(['Nationwide']);
    selectedEligibilityOptions.value = selectedEligibilityOptions.value.filter((key) => key !== 'location_coverage');
    updateEligibilitySummary();
    coverageOptionsError.value = '';
}

function applyActiveTargetDefaults() {
    const targetForm = activeTargetForm.value;

    if (targetForm.programPathTemplate !== undefined) {
        scholarshipForm.value.eligibleCourses = canonicalizeProgramPathList(targetForm.programPathTemplate);
    }

    if (targetForm.levelTemplate) {
        scholarshipForm.value.eligibleYearLevels = targetForm.levelTemplate;
    }

    if (Array.isArray(targetForm.schoolTypeValues)) {
        scholarshipForm.value.eligibleSchoolTypes = [...targetForm.schoolTypeValues];
    }
}

function clearHiddenSchoolTypes() {
    const visibleValues = new Set(targetSchoolTypeOptions.value.map((option) => option.value));

    scholarshipForm.value.eligibleSchoolTypes = scholarshipForm.value.eligibleSchoolTypes
        .filter((value) => visibleValues.has(value));
}

function applyTargetApplicantPreset(preset) {
    scholarshipForm.value.eligibleEducationLevels = [...preset.educationLevels];
    scholarshipForm.value.eligibleSchoolTypes = [...preset.schoolTypes];
    scholarshipForm.value.eligibleCourses = canonicalizeProgramPathList(preset.courses);
    scholarshipForm.value.eligibleYearLevels = preset.years;
    scholarshipForm.value.eligibleLocations = preset.locations;
    scholarshipForm.value.eligibility = preset.eligibility;
    syncEligibilityOptions();
    scholarshipForm.value.requirements = preset.requirements
        .filter((requirement) => documentRequirementOptions.includes(requirement));

    if (!scholarshipForm.value.description) {
        scholarshipForm.value.description = `A scholarship assistance program for ${preset.label.toLowerCase()}. Review the target applicant rules, prepare documents, and submit before the deadline.`;
    }

    if (!scholarshipForm.value.applicationMode) {
        scholarshipForm.value.applicationMode = 'online';
    }
}

function syncEligibilityOptions() {
    const eligibility = String(scholarshipForm.value.eligibility ?? '').trim();
    const legacySelection = legacyEligibilityMappings.get(eligibility);

    selectedEligibilityOptions.value = legacySelection ? [...legacySelection] : [];
    customEligibilityText.value = '';

    if (!eligibility || legacySelection) {
        return;
    }

    const unmatchedLines = [];

    eligibility.split(/\r?\n/).map((line) => line.trim()).filter(Boolean).forEach((line) => {
        const option = eligibilityOptions.find((item) => item.summary === line);

        if (option && !selectedEligibilityOptions.value.includes(option.key)) {
            selectedEligibilityOptions.value.push(option.key);
        } else {
            unmatchedLines.push(line);
        }
    });

    if (unmatchedLines.length) {
        selectedEligibilityOptions.value.push(customEligibilityOption);
        customEligibilityText.value = unmatchedLines.join('\n');
    }
}

function updateEligibilitySummary() {
    const summaries = selectedEligibilityOptions.value
        .filter((key) => key !== customEligibilityOption)
        .map((key) => eligibilityOptions.find((option) => option.key === key)?.summary)
        .filter(Boolean);
    const customSummary = customEligibilityText.value.trim();

    if (selectedEligibilityOptions.value.includes(customEligibilityOption) && customSummary) {
        summaries.push(customSummary);
    }

    scholarshipForm.value.eligibility = summaries.join('\n');
}

function eligibilityVerificationLabel(type) {
    if (type === 'automatic') {
        return 'Portal check';
    }

    return eligibilityVerificationOptions.find((option) => option.value === type)?.label || 'Provider verifies';
}

function eligibilityConditionPayload() {
    const selectedConditions = selectedEligibilityOptions.value
        .filter((key) => key !== customEligibilityOption)
        .map((key) => eligibilityOptions.find((option) => option.key === key))
        .filter(Boolean)
        .map((option) => ({
            key: option.key,
            label: option.label,
            statement: option.summary,
            verification_type: option.verificationType,
            source: 'structured_rule',
        }));
    const customConditions = selectedEligibilityOptions.value.includes(customEligibilityOption)
        ? customEligibilityText.value
            .split(/\r?\n/)
            .map((statement) => statement.trim())
            .filter(Boolean)
            .map((statement, index) => ({
                key: `custom_${index + 1}`,
                label: 'Additional condition',
                statement,
                verification_type: scholarshipForm.value.customEligibilityVerification || 'provider_verification',
                source: 'provider_condition',
            }))
        : [];

    return [...selectedConditions, ...customConditions];
}

function applyEligibilityOption(changedOption) {
    if (changedOption === 'open_to_all' && selectedEligibilityOptions.value.includes('open_to_all')) {
        selectedEligibilityOptions.value = ['open_to_all'];
        customEligibilityText.value = '';
        scholarshipForm.value.eligibleEducationLevels = [...allEducationLevelValues];
        scholarshipForm.value.eligibleCourses = 'Any';
        scholarshipForm.value.eligibleSchoolTypes = [];
        scholarshipForm.value.eligibleYearLevels = 'Any grade or year level';
        scholarshipForm.value.eligibleLocations = 'Nationwide';
        scholarshipForm.value.incomeRequirement = 'Any';
        scholarshipForm.value.minimumGradeScale = '';
        scholarshipForm.value.minimumGwa = '';
    } else if (changedOption !== 'open_to_all' && selectedEligibilityOptions.value.includes(changedOption)) {
        selectedEligibilityOptions.value = selectedEligibilityOptions.value.filter((key) => key !== 'open_to_all');
    }

    if (!selectedEligibilityOptions.value.includes(customEligibilityOption)) {
        customEligibilityText.value = '';
    }

    updateEligibilitySummary();
}

async function applyTargetApplicantPresetByKey(event) {
    const nextPresetKey = event.target.value;
    const previousPresetKey = selectedTargetPresetKey.value;
    const preset = targetApplicantPresets.find((item) => item.key === nextPresetKey);

    if (!preset) {
        event.target.value = previousPresetKey;
        return;
    }

    if (
        previousPresetKey
        && previousPresetKey !== nextPresetKey
        && !await requestConfirmation({
            title: 'Replace the current applicant rules?',
            message: 'This preset will replace the matching rules, eligibility notes, and document checklist currently entered.',
            confirmLabel: 'Apply preset',
        })
    ) {
        event.target.value = previousPresetKey;
        return;
    }

    selectedTargetPresetKey.value = nextPresetKey;
    applyTargetApplicantPreset(preset);
}

function commitmentEntries() {
    return [
        { field: 'renewalPolicy', value: scholarshipForm.value.renewalPolicy },
        { field: 'returnServiceContract', value: scholarshipForm.value.returnServiceContract },
        { field: 'otherContractTerms', value: scholarshipForm.value.otherContractTerms },
    ].filter((entry) => hasText(entry.value));
}

function clearCommitmentFields() {
    scholarshipForm.value.renewalPolicy = '';
    scholarshipForm.value.returnServiceContract = '';
    scholarshipForm.value.otherContractTerms = '';
}

function syncCommitmentEditor() {
    const entries = commitmentEntries();
    const matchingPreset = commitmentOptions.find((option) => (
        option.text !== null
        && entries.length === (option.text ? 1 : 0)
        && (!option.text || (entries[0]?.field === option.field && entries[0]?.value === option.text))
    ));

    if (matchingPreset) {
        selectedCommitmentOption.value = matchingPreset.value;
        customCommitmentText.value = '';
        return;
    }

    selectedCommitmentOption.value = entries.length ? 'custom' : 'none';
    customCommitmentText.value = entries.map((entry) => entry.value).join('\n\n');
}

function applySelectedCommitment() {
    const option = commitmentOptions.find((item) => item.value === selectedCommitmentOption.value);

    if (!option) {
        return;
    }

    scholarshipForm.value.recipientAgreement.commitment_type = option.value;

    if (option.value === 'none' || option.value === 'provider_briefing') {
        scholarshipForm.value.recipientAgreement.responsibilities = '';
        scholarshipForm.value.recipientAgreement.required_evidence = '';
        scholarshipForm.value.recipientAgreement.duration = '';
        scholarshipForm.value.recipientAgreement.noncompliance_consequence = '';
        scholarshipForm.value.recipientAgreement.exit_or_exception_process = '';
    }

    if (option.value === 'custom') {
        if (!hasText(customCommitmentText.value)) {
            customCommitmentText.value = commitmentEntries().map((entry) => entry.value).join('\n\n');
        }

        clearCommitmentFields();
        scholarshipForm.value.otherContractTerms = customCommitmentText.value;
        scholarshipForm.value.recipientAgreement.responsibilities = customCommitmentText.value;
        return;
    }

    clearCommitmentFields();

    if (option.field && option.text) {
        scholarshipForm.value[option.field] = option.text;
        scholarshipForm.value.recipientAgreement.responsibilities = option.text;
    }

    customCommitmentText.value = '';
}

function applyCustomCommitment() {
    const responsibilities = scholarshipForm.value.recipientAgreement.responsibilities;
    const option = commitmentOptions.find((item) => item.value === selectedCommitmentOption.value);

    customCommitmentText.value = responsibilities;

    if (option?.field) {
        scholarshipForm.value[option.field] = responsibilities;
    } else if (selectedCommitmentOption.value !== 'none') {
        scholarshipForm.value.otherContractTerms = responsibilities;
    }
}

function composeProgramAddress(form = scholarshipForm.value) {
    return [
        form.locationAddressLine,
        form.locationBarangay,
        form.locationCity,
        form.locationProvince,
        form.locationRegion,
    ].map((part) => String(part ?? '').trim()).filter(Boolean).join(', ');
}

function splitProgramAddress(value) {
    const parts = String(value ?? '')
        .split(',')
        .map((part) => part.trim())
        .filter(Boolean);
    const fields = {
        locationAddressLine: '',
        locationBarangay: '',
        locationCity: '',
        locationProvince: '',
        locationRegion: '',
    };

    if (/^philippines$/i.test(parts.at(-1) ?? '')) {
        parts.pop();
    }

    const region = findPhilippineRegion(parts.at(-1));

    if (region) {
        fields.locationRegion = region.value;
        parts.pop();
    }

    if (parts.length >= 2) {
        fields.locationProvince = parts.pop() ?? '';
        fields.locationCity = parts.pop() ?? '';
    }

    if (parts.length && /^(barangay|brgy\.?)(\s|$)/i.test(parts.at(-1))) {
        fields.locationBarangay = parts.pop() ?? '';
    }

    fields.locationAddressLine = parts.join(', ');

    return fields;
}

function syncProgramAddress({ clearCoordinates = true } = {}) {
    scholarshipForm.value.locationAddress = composeProgramAddress();

    if (clearCoordinates) {
        clearScholarshipMapPoint();
    }
}

async function loadProgramCities(requestId = programLocationRequestId) {
    const region = findPhilippineRegion(scholarshipForm.value.locationRegion);
    const province = findLocationOption(programProvinceOptions.value, scholarshipForm.value.locationProvince);

    programCityOptions.value = [];

    if (!region || !province) {
        return;
    }

    isLoadingProgramCities.value = true;

    try {
        const cities = await citiesForLocation(region.code, province.code);

        if (requestId === programLocationRequestId) {
            programCityOptions.value = cities;
        }
    } catch (error) {
        if (requestId === programLocationRequestId) {
            programLocationOptionsError.value = 'City and municipality options could not be loaded. Check your connection and try again.';
        }
    } finally {
        if (requestId === programLocationRequestId) {
            isLoadingProgramCities.value = false;
        }
    }
}

async function loadProgramLocationHierarchy({ resetProvince = false, resetCity = false } = {}) {
    const requestId = ++programLocationRequestId;
    const region = findPhilippineRegion(scholarshipForm.value.locationRegion);

    programLocationOptionsError.value = '';
    programProvinceOptions.value = [];
    programCityOptions.value = [];

    if (resetProvince) {
        scholarshipForm.value.locationProvince = '';
    }

    if (resetProvince || resetCity) {
        scholarshipForm.value.locationCity = '';
    }

    if (!region) {
        syncProgramAddress({ clearCoordinates: false });
        return;
    }

    scholarshipForm.value.locationRegion = region.value;
    isLoadingProgramProvinces.value = true;

    try {
        const provinces = await provincesForRegion(region.code);

        if (requestId !== programLocationRequestId) {
            return;
        }

        programProvinceOptions.value = provinces;

        if (region.value === 'NCR') {
            scholarshipForm.value.locationProvince = 'Metro Manila';
        }

        await loadProgramCities(requestId);
    } catch (error) {
        if (requestId === programLocationRequestId) {
            programLocationOptionsError.value = 'Province options could not be loaded. Check your connection and select the region again.';
        }
    } finally {
        if (requestId === programLocationRequestId) {
            isLoadingProgramProvinces.value = false;
            syncProgramAddress({ clearCoordinates: false });
        }
    }
}

function handleProgramRegionChange() {
    clearScholarshipMapPoint();
    loadProgramLocationHierarchy({ resetProvince: true });
}

function handleProgramProvinceChange() {
    const requestId = ++programLocationRequestId;

    scholarshipForm.value.locationCity = '';
    programLocationOptionsError.value = '';
    syncProgramAddress();
    loadProgramCities(requestId);
}

function handleProgramAddressChange() {
    syncProgramAddress();
}

function handleProgramDetailAddressChange() {
    syncProgramAddress({ clearCoordinates: false });
}

function fillScholarshipForm(scholarship) {
    const programAddress = splitProgramAddress(scholarship.location_address);

    existingApplicationCount.value = Number(scholarship.applications_count ?? 0);
    awardedSlotsCount.value = Number(scholarship.awarded_slots_count ?? 0);
    scholarshipForm.value = {
        title: scholarship.title ?? '',
        category: scholarship.category ?? '',
        programCycle: scholarship.program_cycle ?? '',
        description: scholarship.description ?? '',
        providerObjectives: Array.isArray(scholarship.provider_objectives) ? scholarship.provider_objectives : [],
        providerObjectiveNotes: scholarship.provider_objective_notes ?? '',
        eligibility: scholarship.eligibility ?? '',
        customEligibilityVerification: Array.isArray(scholarship.eligibility_conditions)
            ? (scholarship.eligibility_conditions.find((condition) => condition.source === 'provider_condition')?.verification_type ?? 'provider_verification')
            : 'provider_verification',
        eligibleEducationLevels: parseSelections(scholarship.eligible_education_levels, educationLevelOptions),
        eligibleCourses: canonicalizeProgramPathList(scholarship.eligible_courses),
        eligibleSchoolTypes: parseSelections(scholarship.eligible_school_types, schoolTypeOptions),
        eligibleYearLevels: scholarship.eligible_year_levels ?? '',
        eligibleLocations: scholarship.eligible_locations ?? '',
        incomeRequirement: scholarship.income_requirement ?? 'Any',
        excludeCurrentScholarshipRecipients: Boolean(scholarship.exclude_current_scholarship_recipients),
        locationName: scholarship.location_name ?? '',
        locationAddress: scholarship.location_address ?? '',
        ...programAddress,
        latitude: scholarship.latitude ?? '',
        longitude: scholarship.longitude ?? '',
        requirements: parseRequirements(scholarship.requirements),
        customRequirements: parseCustomRequirements(scholarship.requirements).join('\n'),
        optionalRequirements: parseRequirements(scholarship.optional_requirements),
        customOptionalRequirements: parseCustomRequirements(scholarship.optional_requirements).join('\n'),
        postQualificationRequirements: scholarship.post_qualification_requirements ?? '',
        handoffMode: scholarship.handoff_mode ?? 'onsite',
        handoffInstructions: scholarship.handoff_instructions
            ?? 'Bring the listed documents to the provider for final verification and the formal application process.',
        handoffDeadline: scholarship.handoff_deadline ?? '',
        handoffLocationName: scholarship.handoff_location_name ?? '',
        handoffLocationAddress: scholarship.handoff_location_address ?? '',
        handoffUrl: scholarship.handoff_url ?? '',
        reviewRubric: Array.isArray(scholarship.review_rubric) && scholarship.review_rubric.length
            ? scholarship.review_rubric.map((criterion) => ({ ...criterion }))
            : defaultReviewRubric(),
        applicationQuestions: Array.isArray(scholarship.application_questions)
            ? scholarship.application_questions.map((question, index) => ({
                id: question.id || `question_${Date.now()}_${index + 1}`,
                prompt: question.prompt ?? '',
                required: Boolean(question.required),
            }))
            : [],
        benefits: normalizeBenefits(scholarship),
        minimumGwa: scholarship.minimum_gwa ?? '',
        minimumGradeScale: scholarship.minimum_grade_scale ?? inferGradeScale(scholarship.minimum_gwa),
        slotsAvailable: scholarship.slots_available ?? '',
        applicationLimit: scholarship.application_limit ?? '',
        applicationMode: scholarship.application_mode === 'hybrid' ? 'onsite' : (scholarship.application_mode ?? ''),
        selectionStages: normalizeSelectionStages(scholarship.selection_stages),
        renewalPolicy: scholarship.renewal_policy ?? '',
        returnServiceContract: scholarship.return_service_contract ?? '',
        otherContractTerms: scholarship.other_contract_terms ?? '',
        recipientAgreement: {
            commitment_type: scholarship.recipient_agreement?.commitment_type ?? 'provider_briefing',
            responsibilities: scholarship.recipient_agreement?.responsibilities
                ?? scholarship.return_service_contract
                ?? scholarship.other_contract_terms
                ?? scholarship.renewal_policy
                ?? '',
            required_evidence: scholarship.recipient_agreement?.required_evidence ?? '',
            release_conditions: scholarship.recipient_agreement?.release_conditions ?? '',
            duration: scholarship.recipient_agreement?.duration ?? '',
            noncompliance_consequence: scholarship.recipient_agreement?.noncompliance_consequence ?? '',
            exit_or_exception_process: scholarship.recipient_agreement?.exit_or_exception_process ?? '',
        },
        contactEmail: scholarship.contact_email ?? user.value?.provider_contact_email ?? window.portalUser?.provider_contact_email ?? '',
        contactNumber: scholarship.contact_number ?? user.value?.provider_contact_number ?? window.portalUser?.provider_contact_number ?? '',
        applicationOpensAt: scholarship.application_opens_at ?? '',
        expectedResultsAt: scholarship.expected_results_at ?? '',
        supportStartsAt: scholarship.support_starts_at ?? '',
        supportEndsAt: scholarship.support_ends_at ?? '',
        officialProgramUrl: scholarship.official_program_url ?? '',
        contactPerson: scholarship.contact_person ?? '',
        contactDepartment: scholarship.contact_department ?? '',
        deadline: scholarship.deadline ?? '',
        status: scholarship.status ?? 'draft',
        imageUrl: scholarship.image_url ?? '/uploads/scholarship-default.jpg',
        termsAccepted: false,
    };
    imageFile.value = null;
    imagePreviewUrl.value = '';
    useProviderLogoSelected.value = false;
    selectedTargetPresetKey.value = inferTargetFormKey(scholarshipForm.value.eligibleEducationLevels);
    syncEligibilityOptions();
    syncCommitmentEditor();
    loadProgramLocationHierarchy();
    if (commitmentOptions.some((option) => option.value === scholarshipForm.value.recipientAgreement.commitment_type)) {
        selectedCommitmentOption.value = scholarshipForm.value.recipientAgreement.commitment_type;
    }
}

function isRequirementSelected(requirement) {
    return scholarshipForm.value.requirements.includes(requirement);
}

function isOptionalRequirementSelected(requirement) {
    return scholarshipForm.value.optionalRequirements.includes(requirement);
}

function setRequirementLevel(requirement, level) {
    scholarshipForm.value.requirements = scholarshipForm.value.requirements.filter((item) => item !== requirement);
    scholarshipForm.value.optionalRequirements = scholarshipForm.value.optionalRequirements.filter((item) => item !== requirement);

    if (level === 'required') {
        scholarshipForm.value.requirements.push(requirement);
    } else if (level === 'optional') {
        scholarshipForm.value.optionalRequirements.push(requirement);
    }
}

function selectCommonRequirements() {
    scholarshipForm.value.requirements = [
        'Certificate of enrollment',
        'Latest report card or grades',
        'Recent school ID',
        'Proof of income',
    ];
    scholarshipForm.value.optionalRequirements = [];
}

function clearRequirements() {
    scholarshipForm.value.requirements = [];
    scholarshipForm.value.customRequirements = '';
    scholarshipForm.value.optionalRequirements = [];
    scholarshipForm.value.customOptionalRequirements = '';
}

function addApplicationQuestion() {
    if (scholarshipForm.value.applicationQuestions.length >= 5) {
        return;
    }

    scholarshipForm.value.applicationQuestions.push({
        id: `question_${Date.now()}_${scholarshipForm.value.applicationQuestions.length + 1}`,
        prompt: '',
        required: true,
    });
}

function removeApplicationQuestion(index) {
    scholarshipForm.value.applicationQuestions.splice(index, 1);
}

function useProgramLocationForHandoff() {
    scholarshipForm.value.handoffLocationName = scholarshipForm.value.locationName;
    scholarshipForm.value.handoffLocationAddress = scholarshipForm.value.locationAddress;
}

function useProviderPublicContact(overwrite = true) {
    const defaults = providerProgramDefaults.value;

    if (defaults.email && (overwrite || !hasText(scholarshipForm.value.contactEmail))) {
        scholarshipForm.value.contactEmail = defaults.email;
    }

    if (defaults.phone && (overwrite || !hasText(scholarshipForm.value.contactNumber))) {
        scholarshipForm.value.contactNumber = defaults.phone;
    }

    if (defaults.website && (overwrite || !hasText(scholarshipForm.value.officialProgramUrl))) {
        scholarshipForm.value.officialProgramUrl = defaults.website;
    }
}

function useProviderAddress(overwrite = true) {
    const defaults = providerProgramDefaults.value;
    let addressChanged = false;

    if (defaults.organizationName && (overwrite || !hasText(scholarshipForm.value.locationName))) {
        scholarshipForm.value.locationName = defaults.organizationName;
    }

    if (defaults.address && (overwrite || !hasText(scholarshipForm.value.locationAddress))) {
        addressChanged = scholarshipForm.value.locationAddress !== defaults.address;
        scholarshipForm.value.locationAddress = defaults.address;
        Object.assign(scholarshipForm.value, splitProgramAddress(defaults.address));
        syncProgramAddress({ clearCoordinates: false });
        loadProgramLocationHierarchy();
    }

    if (addressChanged) {
        scholarshipForm.value.latitude = '';
        scholarshipForm.value.longitude = '';
        providerLocationMessage.value = 'Provider profile address added. Set the map pin to confirm this program location.';
    }
}

function useProviderAddressForHandoff() {
    const defaults = providerProgramDefaults.value;

    if (defaults.organizationName) {
        scholarshipForm.value.handoffLocationName = defaults.organizationName;
    }

    scholarshipForm.value.handoffLocationAddress = defaults.address;
}

function applyProviderProfileDefaults() {
    useProviderPublicContact(false);
    useProviderAddress(false);

    if (!isEditMode.value && providerProgramDefaults.value.logoUrl && !imageFile.value) {
        scholarshipForm.value.imageUrl = providerProgramDefaults.value.logoUrl;
        useProviderLogoSelected.value = true;
    }
}

function addReviewCriterion() {
    if (scholarshipForm.value.reviewRubric.length >= 6) {
        return;
    }

    scholarshipForm.value.reviewRubric.push({
        key: `criterion_${Date.now().toString(36)}`,
        label: '',
        weight: 10,
        guidance: '',
    });
}

function removeReviewCriterion(index) {
    scholarshipForm.value.reviewRubric.splice(index, 1);
}

function resetReviewRubric() {
    scholarshipForm.value.reviewRubric = defaultReviewRubric();
}

function inferGradeScale(value) {
    if (!hasText(value)) {
        return '';
    }

    return Number(value) <= 5 ? 'grade_point' : 'percentage';
}

function handleGradeScaleChange() {
    if (!academicRequirementNeedsValue.value) {
        scholarshipForm.value.minimumGwa = '';
        return;
    }

    const value = Number(scholarshipForm.value.minimumGwa);

    if (
        (scholarshipForm.value.minimumGradeScale === 'percentage' && value > 0 && value <= 5)
        || (scholarshipForm.value.minimumGradeScale === 'grade_point' && value > 5)
    ) {
        scholarshipForm.value.minimumGwa = '';
    }
}

function clearScholarshipMapPoint() {
    scholarshipForm.value.latitude = '';
    scholarshipForm.value.longitude = '';
    providerLocationMessage.value = '';
}

function openLocationMap() {
    showLocationMap.value = true;
}

function closeLocationMap() {
    showLocationMap.value = false;
}

function handleScholarshipLocationResolved(location) {
    scholarshipForm.value.latitude = Number(location.latitude).toFixed(7);
    scholarshipForm.value.longitude = Number(location.longitude).toFixed(7);
    providerLocationMessage.value = 'Address found on the map. Save the scholarship to keep this map point.';
}

function handleScholarshipLocationPicked(location) {
    const address = location.address ?? {};
    const streetAddress = [address.house_number, address.road].filter(Boolean).join(' ');
    const locationName = address.office
        || address.amenity
        || address.building
        || address.school
        || address.university
        || address.tourism
        || scholarshipForm.value.locationName;

    scholarshipForm.value.latitude = Number(location.latitude).toFixed(7);
    scholarshipForm.value.longitude = Number(location.longitude).toFixed(7);
    scholarshipForm.value.locationName = locationName;
    scholarshipForm.value.locationAddressLine = streetAddress || scholarshipForm.value.locationAddressLine;
    scholarshipForm.value.locationBarangay = address.neighbourhood
        || address.suburb
        || address.quarter
        || address.village
        || scholarshipForm.value.locationBarangay;
    scholarshipForm.value.locationCity = address.city
        || address.municipality
        || address.town
        || address.city_district
        || scholarshipForm.value.locationCity;
    scholarshipForm.value.locationProvince = address.province
        || address.state
        || address.county
        || scholarshipForm.value.locationProvince;
    const resolvedRegion = findPhilippineRegion(address.region
        || address.state
        || scholarshipForm.value.locationRegion);
    scholarshipForm.value.locationRegion = resolvedRegion?.value || scholarshipForm.value.locationRegion;
    syncProgramAddress({ clearCoordinates: false });
    loadProgramLocationHierarchy();
    providerLocationMessage.value = location.displayName
        ? 'Pin set. The structured address was filled from the selected map point.'
        : 'Pin set. Save the scholarship to keep this map point.';
}

function handleScholarshipLocationError(message) {
    providerLocationMessage.value = message;
}

function resetScholarshipForm() {
    scholarshipForm.value = emptyScholarshipForm();
    existingApplicationCount.value = 0;
    awardedSlotsCount.value = 0;
    activeFormSection.value = 'details';
    showLocationMap.value = false;
    customizeRubric.value = false;
    selectedTargetPresetKey.value = '';
    selectedEligibilityOptions.value = [];
    customEligibilityText.value = '';
    coverageLevel.value = 'city';
    coverageRegionCode.value = '';
    coverageProvinceCode.value = '';
    coverageCity.value = '';
    coverageProvinceOptions.value = [];
    coverageCityOptions.value = [];
    coverageOptionsError.value = '';
    programProvinceOptions.value = [];
    programCityOptions.value = [];
    programLocationOptionsError.value = '';
    imageFile.value = null;
    imagePreviewUrl.value = '';
    useProviderLogoSelected.value = false;
    formError.value = '';
    providerLocationMessage.value = '';
    selectedCommitmentOption.value = 'provider_briefing';
    customCommitmentText.value = '';
    applyProviderProfileDefaults();

    if (imageInputElement.value) {
        imageInputElement.value.value = '';
    }
}

function saveLocalDraft() {
    if (isEditMode.value || !autosaveReady.value) {
        return;
    }

    const savedAt = new Date().toISOString();
    const form = {
        ...scholarshipForm.value,
        termsAccepted: false,
        imageUrl: '/uploads/scholarship-default.jpg',
    };

    try {
        window.localStorage.setItem(createDraftStorageKey, JSON.stringify({ savedAt, form }));
        draftSavedAt.value = savedAt;
    } catch (error) {
        draftSavedAt.value = '';
    }
}

function restoreLocalDraft() {
    if (isEditMode.value) {
        return;
    }

    try {
        const storedDraft = JSON.parse(window.localStorage.getItem(createDraftStorageKey) || 'null');

        if (!storedDraft?.form || typeof storedDraft.form !== 'object') {
            return;
        }

        scholarshipForm.value = {
            ...emptyScholarshipForm(),
            ...storedDraft.form,
            termsAccepted: false,
            imageUrl: '/uploads/scholarship-default.jpg',
        };
        if (!hasText(scholarshipForm.value.locationCity) && hasText(scholarshipForm.value.locationAddress)) {
            Object.assign(scholarshipForm.value, splitProgramAddress(scholarshipForm.value.locationAddress));
        }
        syncProgramAddress({ clearCoordinates: false });
        loadProgramLocationHierarchy();
        draftSavedAt.value = storedDraft.savedAt || '';
        selectedTargetPresetKey.value = inferTargetFormKey(scholarshipForm.value.eligibleEducationLevels);
        syncEligibilityOptions();
        syncCommitmentEditor();
    } catch (error) {
        window.localStorage.removeItem(createDraftStorageKey);
    }
}

function clearLocalDraft() {
    window.localStorage.removeItem(createDraftStorageKey);
    draftSavedAt.value = '';
}

function handleImageFile(event) {
    const file = event.target.files?.[0] ?? null;

    imageFile.value = file;
    useProviderLogoSelected.value = !file
        && !isEditMode.value
        && Boolean(providerProgramDefaults.value.logoUrl);

    if (imagePreviewUrl.value) {
        URL.revokeObjectURL(imagePreviewUrl.value);
    }

    imagePreviewUrl.value = file ? URL.createObjectURL(file) : '';
}

function useProviderLogo() {
    if (!providerProgramDefaults.value.logoUrl) {
        return;
    }

    imageFile.value = null;
    useProviderLogoSelected.value = true;
    scholarshipForm.value.imageUrl = providerProgramDefaults.value.logoUrl;

    if (imagePreviewUrl.value) {
        URL.revokeObjectURL(imagePreviewUrl.value);
        imagePreviewUrl.value = '';
    }

    if (imageInputElement.value) {
        imageInputElement.value.value = '';
    }
}

async function loadFormData() {
    isLoading.value = true;
    errorMessage.value = '';

    try {
        const profileResponse = await window.axios.get('/provider/profile/data');

        user.value = profileResponse.data.user;

        if (scholarshipId.value) {
            const scholarshipResponse = await window.axios.get(`/provider/scholarships/${scholarshipId.value}`);

            fillScholarshipForm(scholarshipResponse.data.scholarship);
        } else {
            restoreLocalDraft();
            applyProviderProfileDefaults();
        }
    } catch (error) {
        errorMessage.value = error.response?.data?.message ?? 'Unable to load scholarship form.';
    } finally {
        autosaveReady.value = true;
        isLoading.value = false;
    }
}

async function saveScholarship(options = {}) {
    const isStepSave = options.mode === 'step';
    const targetSection = options.targetSection ?? null;
    formError.value = '';

    if (!hasText(scholarshipForm.value.title)) {
        await focusFormField('details', 'scholarship-title');
        formError.value = 'Add a scholarship title before saving.';
        return;
    }

    if (!isStepSave && termsRequiredForSave.value && !hasText(scholarshipForm.value.description)) {
        await focusFormField('details', 'scholarship-description');
        formError.value = 'Add a clear scholarship description before continuing.';
        return;
    }

    if (!isStepSave && reviewSubmissionSelected.value && missingProgramReadinessItems.value.length > 0) {
        const firstMissingItem = missingProgramReadinessItems.value[0];
        const fieldId = readinessFocusTarget(firstMissingItem);

        if (fieldId) {
            await focusFormField(firstMissingItem.section, fieldId);
        } else {
            await openFormSection(firstMissingItem.section);
        }

        formError.value = `${firstMissingItem.label} is incomplete. ${firstMissingItem.help}`;
        return;
    }

    if (
        !isStepSave
        && termsRequiredForSave.value
        && scholarshipForm.value.applicationQuestions.some((question) => !hasText(question.prompt))
    ) {
        await openFormSection('application');
        formError.value = 'Complete or remove each applicant question before submitting this program.';
        return;
    }

    if (!isStepSave && termsRequiredForSave.value && !scholarshipForm.value.termsAccepted) {
        await openFormSection('review');
        formError.value = 'Accept the provider scholarship terms before submitting or updating this program.';
        return;
    }

    if (
        !isStepSave
        && termsRequiredForSave.value
        && (
            scholarshipForm.value.reviewRubric.some((criterion) => !hasText(criterion.label))
            || rubricWeightTotal.value !== 100
        )
    ) {
        customizeRubric.value = true;
        await focusFormField('selection', `rubric-label-${scholarshipForm.value.reviewRubric[0]?.key}`);
        formError.value = 'Add a label for every review criterion and make the weights total 100%.';
        return;
    }

    const importantSave = isStepSave ? null : {
        pending_review: {
            title: 'Submit this program for review?',
            message: 'The program will be sent to the administrator for approval before applicants can see it.',
            confirmLabel: 'Submit for review',
        },
        closed: {
            title: 'Close this program?',
            message: 'Applicants will no longer be able to submit new applications for this program.',
            confirmLabel: 'Close program',
            tone: 'danger',
        },
        published: isEditMode.value ? {
            title: 'Save changes to this published program?',
            message: 'Material changes may return the program to administrator review before it is published again.',
            confirmLabel: 'Save changes',
        } : null,
    }[scholarshipForm.value.status];

    if (importantSave && !await requestConfirmation(importantSave)) {
        return;
    }

    isSaving.value = true;

    const payload = new FormData();
    const fields = {
        title: scholarshipForm.value.title,
        category: scholarshipForm.value.category || '',
        program_cycle: scholarshipForm.value.programCycle || '',
        description: scholarshipForm.value.description,
        provider_objectives: JSON.stringify(scholarshipForm.value.providerObjectives),
        provider_objective_notes: scholarshipForm.value.providerObjectiveNotes || '',
        eligibility: scholarshipForm.value.eligibility,
        eligibility_conditions: JSON.stringify(eligibilityConditionPayload()),
        eligible_education_levels: scholarshipForm.value.eligibleEducationLevels.join('\n'),
        eligible_courses: canonicalizeProgramPathList(scholarshipForm.value.eligibleCourses),
        eligible_school_types: scholarshipForm.value.eligibleSchoolTypes.join('\n'),
        eligible_year_levels: scholarshipForm.value.eligibleYearLevels,
        eligible_locations: scholarshipForm.value.eligibleLocations,
        income_requirement: scholarshipForm.value.incomeRequirement || 'Any',
        exclude_current_scholarship_recipients: scholarshipForm.value.excludeCurrentScholarshipRecipients ? '1' : '0',
        location_name: scholarshipForm.value.locationName || '',
        location_address: scholarshipForm.value.locationAddress || '',
        latitude: scholarshipForm.value.latitude || '',
        longitude: scholarshipForm.value.longitude || '',
        requirements: isProfileReviewOnly.value ? '' : allDocumentRequirements.value.join('\n'),
        optional_requirements: isProfileReviewOnly.value ? '' : allOptionalDocumentRequirements.value.join('\n'),
        post_qualification_requirements: postQualificationRequirementItems.value.join('\n'),
        handoff_mode: scholarshipForm.value.handoffMode || '',
        handoff_instructions: scholarshipForm.value.handoffInstructions || '',
        handoff_deadline: scholarshipForm.value.handoffDeadline || '',
        handoff_location_name: scholarshipForm.value.handoffLocationName || '',
        handoff_location_address: scholarshipForm.value.handoffLocationAddress || '',
        handoff_url: scholarshipForm.value.handoffUrl || '',
        review_rubric: JSON.stringify(scholarshipForm.value.reviewRubric),
        application_questions: JSON.stringify(scholarshipForm.value.applicationQuestions),
        benefits: JSON.stringify(scholarshipForm.value.benefits),
        award_amount: cashGrantAmount(scholarshipForm.value.benefits),
        minimum_gwa: academicRequirementNeedsValue.value ? scholarshipForm.value.minimumGwa || '' : '',
        minimum_grade_scale: scholarshipForm.value.minimumGradeScale || '',
        slots_available: scholarshipForm.value.slotsAvailable || '',
        application_limit: scholarshipForm.value.applicationLimit || '',
        application_mode: scholarshipForm.value.applicationMode || '',
        selection_stages: JSON.stringify(scholarshipForm.value.selectionStages),
        renewal_policy: scholarshipForm.value.renewalPolicy || '',
        return_service_contract: scholarshipForm.value.returnServiceContract || '',
        other_contract_terms: scholarshipForm.value.otherContractTerms || '',
        recipient_agreement: JSON.stringify(scholarshipForm.value.recipientAgreement),
        contact_email: scholarshipForm.value.contactEmail || '',
        contact_number: scholarshipForm.value.contactNumber || '',
        application_opens_at: scholarshipForm.value.applicationOpensAt || '',
        expected_results_at: scholarshipForm.value.expectedResultsAt || '',
        support_starts_at: scholarshipForm.value.supportStartsAt || '',
        support_ends_at: scholarshipForm.value.supportEndsAt || '',
        official_program_url: scholarshipForm.value.officialProgramUrl || '',
        contact_person: scholarshipForm.value.contactPerson || '',
        contact_department: scholarshipForm.value.contactDepartment || '',
        deadline: scholarshipForm.value.deadline || '',
        status: isStepSave ? 'draft' : scholarshipForm.value.status,
        use_provider_logo: useProviderLogoSelected.value ? '1' : '0',
        terms_accepted: scholarshipForm.value.termsAccepted ? '1' : '',
    };

    Object.entries(fields).forEach(([key, value]) => {
        payload.append(key, value);
    });

    if (imageFile.value) {
        payload.append('image_file', imageFile.value);
    }

    const wasEditMode = isEditMode.value;

    if (wasEditMode) {
        payload.append('_method', 'PUT');
    }

    try {
        const response = wasEditMode
            ? await window.axios.post(`/provider/scholarships/${scholarshipId.value}`, payload)
            : await window.axios.post('/provider/scholarships', payload);

        if (isStepSave) {
            autosaveReady.value = false;
            scholarshipId.value = String(response.data.scholarship.id);
            clearLocalDraft();
            fillScholarshipForm(response.data.scholarship);
            autosaveReady.value = true;

            if (targetSection) {
                await openFormSection(targetSection, { replaceUrl: !wasEditMode });
            }
        } else if (wasEditMode) {
            fillScholarshipForm(response.data.scholarship);
        } else {
            autosaveReady.value = false;
            clearLocalDraft();
            resetScholarshipForm();
            autosaveReady.value = true;
        }

        return true;
    } catch (error) {
        const validationErrors = error.response?.data?.errors ?? {};
        const firstValidationMessage = Object.values(validationErrors).flat()[0];

        formError.value = firstValidationMessage
            ?? error.response?.data?.message
            ?? 'Unable to save this scholarship right now.';

        return false;
    } finally {
        isSaving.value = false;
    }
}

watch(scholarshipForm, () => {
    if (!autosaveReady.value || isEditMode.value || isSaving.value) {
        return;
    }

    window.clearTimeout(autosaveTimer);
    autosaveTimer = window.setTimeout(saveLocalDraft, 600);
}, { deep: true });

onMounted(() => {
    window.addEventListener('popstate', handleProgramStepHistory);
    loadFormData();
});
onBeforeUnmount(() => {
    window.clearTimeout(autosaveTimer);
    window.removeEventListener('popstate', handleProgramStepHistory);

    if (imagePreviewUrl.value) {
        URL.revokeObjectURL(imagePreviewUrl.value);
    }
});
</script>

<template>
    <main class="provider-shell">
        <ProviderSidebar />

        <ConfirmationDialog
            v-bind="confirmation"
            @confirm="confirmConfirmation"
            @cancel="cancelConfirmation"
        />
        <AlertDialog
            :open="Boolean(formError)"
            title="Complete this section"
            :message="formError"
            button-label="Review field"
            @close="formError = ''"
        />

        <section class="provider-page">
            <div class="provider-container provider-container-narrow">
                <TaskPageHeader
                    theme="provider"
                    :eyebrow="isEditMode ? 'Program configuration' : 'New program'"
                    :title="isEditMode ? 'Edit program' : 'Create scholarship program'"
                    :description="isEditMode ? 'Update one setup section at a time. Applicant records are managed in a separate workspace.' : 'Complete one section at a time, then review before submitting.'"
                    icon="fa-solid fa-pen-to-square"
                    secondary-href="/provider/programs"
                    secondary-label="Back to programs"
                >
                    <template #meta>
                        <span v-if="isEditMode">{{ scholarshipForm.title || 'Untitled program' }}</span>
                        <span>Section {{ activeFormSectionIndex + 1 }} of {{ formSections.length }}</span>
                        <span>{{ completedProgramReadinessCount }} of {{ programReadinessItems.length }} checks ready</span>
                    </template>
                </TaskPageHeader>

                <div v-if="isLoading" class="mt-6 rounded-lg border border-slate-200 bg-white p-6 text-sm text-slate-500 shadow-sm">
                    Loading scholarship form...
                </div>

                <div v-else-if="errorMessage" class="mt-6 rounded-lg border border-rose-200 bg-rose-50 p-6 text-sm text-rose-700 shadow-sm">
                    {{ errorMessage }}
                </div>

                <div v-else class="mt-5 space-y-4">
                    <div
                        v-if="!canPostScholarships"
                        class="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900 shadow-sm"
                    >
                        <p class="font-bold">
                            Provider verification required
                        </p>
                        <p class="mt-1">Admin approval is required before programs can be created or updated.</p>
                    </div>

                    <div
                        v-if="!isEditMode && draftSavedAt"
                        class="flex flex-col gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm sm:flex-row sm:items-center sm:justify-between"
                    >
                        <p class="font-semibold text-emerald-900">
                            <i class="fa-solid fa-cloud-arrow-up mr-2" aria-hidden="true"></i>
                            Draft recovered and saved automatically on this device.
                        </p>
                        <button type="button" class="text-xs font-bold text-emerald-900 underline" @click="clearLocalDraft">
                            Clear saved copy
                        </button>
                    </div>

                    <form
                        ref="scholarshipFormElement"
                        class="provider-program-form scroll-mt-4 space-y-4"
                        novalidate
                        @submit.prevent="saveScholarship()"
                    >
                        <div class="rounded-lg border border-slate-200 bg-white p-2 shadow-sm">
                            <label class="block sm:hidden">
                                <span class="sr-only">Program setup section</span>
                                <select
                                    :value="activeFormSection"
                                    class="w-full rounded-md border border-slate-300 bg-white px-3 py-2.5 text-sm font-bold text-slate-800 outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-100"
                                    @change="navigateFromFormSection($event.target.value)"
                                >
                                    <option
                                        v-for="(section, index) in formSections"
                                        :key="section.id"
                                        :value="section.id"
                                        :disabled="!isEditMode && section.id !== activeFormSection"
                                    >
                                        {{ index + 1 }}. {{ section.label }}
                                    </option>
                                </select>
                            </label>
                            <nav class="hidden gap-1 sm:grid sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7" aria-label="Program form sections">
                                <button
                                    v-for="(section, index) in formSections"
                                    :key="section.id"
                                    type="button"
                                    :disabled="!isEditMode && section.id !== activeFormSection"
                                    :aria-current="activeFormSection === section.id ? 'page' : undefined"
                                    :class="[
                                        'flex min-w-0 items-center gap-2 rounded-md px-3 py-2.5 text-left text-xs font-bold transition',
                                        activeFormSection === section.id
                                            ? 'bg-slate-950 text-white shadow-sm'
                                            : 'text-slate-500 hover:bg-slate-100 hover:text-slate-900 disabled:cursor-not-allowed disabled:opacity-40',
                                    ]"
                                    @click="navigateFromFormSection(section.id)"
                                >
                                    <span :class="['grid h-6 w-6 shrink-0 place-items-center rounded text-[10px]', activeFormSection === section.id ? 'bg-white/10 text-amber-300' : 'bg-slate-100 text-slate-500']">{{ index + 1 }}</span>
                                    <span class="truncate">{{ section.label }}</span>
                                </button>
                            </nav>
                        </div>

                        <div class="min-w-0 overflow-hidden rounded-lg border border-slate-200 bg-white">
                            <div class="border-b border-slate-200 px-5 py-4 sm:px-7">
                                <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">Section {{ activeFormSectionIndex + 1 }} of {{ formSections.length }}</p>
                                <h3 class="mt-1 text-xl font-bold text-slate-950">{{ activeFormSectionMeta.label }}</h3>
                                <p class="mt-1 max-w-2xl text-sm leading-5 text-slate-600">{{ activeFormSectionMeta.help }}</p>

                                <nav
                                    v-if="activeFormSubsectionTabs.length"
                                    class="mt-4 flex gap-1 overflow-x-auto rounded-lg border border-slate-200 bg-slate-100 p-1"
                                    :aria-label="`${activeFormSectionMeta.label} sections`"
                                >
                                    <button
                                        v-for="subsection in activeFormSubsectionTabs"
                                        :key="subsection.id"
                                        type="button"
                                        :class="[
                                            'inline-flex min-w-max flex-1 items-center justify-center gap-2 rounded-md px-3 py-2 text-xs font-bold transition',
                                            activeFormSubsection[activeFormSection] === subsection.id
                                                ? 'bg-white text-slate-950 shadow-sm ring-1 ring-slate-200'
                                                : 'text-slate-500 hover:bg-white/70 hover:text-slate-800',
                                        ]"
                                        @click="openFormSubsection(subsection.id)"
                                    >
                                        <i :class="[subsection.icon, activeFormSubsection[activeFormSection] === subsection.id ? 'text-amber-700' : 'text-slate-400']" aria-hidden="true"></i>
                                        {{ subsection.label }}
                                    </button>
                                </nav>
                            </div>

                            <div class="p-5 sm:p-7">

                        <div
                            v-show="['details', 'support', 'logistics', 'review'].includes(activeFormSection)
                                || (activeFormSection === 'eligibility' && activeFormSubsection.eligibility === 'requirements')
                                || (activeFormSection === 'application' && activeFormSubsection.application === 'files')"
                            :class="['grid gap-6', sectionCardClass]"
                        >
                            <div v-show="activeFormSection === 'details'" class="space-y-5">
                                <div>
                                    <h4 class="text-base font-bold text-slate-950">Program identity</h4>
                                </div>

                                <div :class="fieldStackClass">
                                    <label :class="labelClass" for="scholarship-title">
                                        Scholarship title
                                        <span :class="requiredHintClass">Required</span>
                                    </label>
                                    <input
                                        id="scholarship-title"
                                        v-model="scholarshipForm.title"
                                        type="text"
                                        placeholder="Scholarship title"
                                        :class="inputClass"
                                    >
                                </div>

                                <div :class="[fieldCardClass, 'grid gap-3 rounded-md border border-slate-200 bg-white p-4 sm:grid-cols-[4rem_minmax(0,1fr)] sm:items-center']">
                                    <img
                                        :src="scholarshipImagePreview"
                                        alt="Scholarship program preview"
                                        class="h-14 w-14 rounded-md bg-white object-contain p-2 ring-1 ring-slate-200"
                                    >
                                    <div class="min-w-0">
                                        <label :class="labelClass" for="scholarship-image">
                                            Program logo
                                            <span :class="requiredHintClass">Required</span>
                                        </label>
                                        <input
                                            id="scholarship-image"
                                            ref="imageInputElement"
                                            type="file"
                                            accept="image/jpeg,image/png,image/webp"
                                            class="w-full min-w-0 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 file:mr-2 file:rounded file:border-0 file:bg-slate-900 file:px-2.5 file:py-1.5 file:text-xs file:font-bold file:text-white hover:file:bg-slate-800"
                                            @change="handleImageFile"
                                        >
                                        <div class="mt-2 flex flex-wrap items-center gap-2">
                                            <p class="text-xs leading-5 text-slate-500">Upload a JPG, PNG, or WebP up to 4MB, or reuse the provider logo.</p>
                                            <span v-if="useProviderLogoSelected" class="rounded bg-emerald-100 px-2 py-1 text-[10px] font-bold uppercase text-emerald-800">
                                                Using provider logo
                                            </span>
                                            <button
                                                v-else-if="providerProgramDefaults.logoUrl"
                                                type="button"
                                                class="text-xs font-bold text-slate-800 underline decoration-slate-300 underline-offset-2 hover:text-amber-700"
                                                @click="useProviderLogo"
                                            >
                                                Use provider logo
                                            </button>
                                            <a v-else href="/provider/profile/details" class="text-xs font-bold text-slate-800 underline decoration-slate-300 underline-offset-2 hover:text-amber-700">
                                                Add provider logo
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div v-show="activeFormSection === 'eligibility' && activeFormSubsection.eligibility === 'requirements'" id="scholarship-eligibility" :class="fieldStackClass">
                                <div class="grid gap-4 rounded-lg border border-slate-200 bg-white p-4 md:grid-cols-[minmax(0,1fr)_20rem] md:items-center">
                                    <div class="flex min-w-0 items-start gap-3">
                                        <span class="grid h-10 w-10 shrink-0 place-items-center rounded-md bg-slate-100 text-slate-700">
                                            <i :class="activeTargetForm.icon" aria-hidden="true"></i>
                                        </span>
                                        <div>
                                            <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">1. Starting point</p>
                                            <p class="mt-1 text-sm font-bold text-slate-950">Choose the closest learner group</p>
                                            <p class="mt-1 text-xs text-slate-500">The portal fills common rules that you can adjust.</p>
                                        </div>
                                    </div>
                                    <div :class="fieldStackClass">
                                        <label class="sr-only" for="target-applicant-preset">Applicant group template</label>
                                        <select
                                            id="target-applicant-preset"
                                            :value="selectedTargetPresetKey"
                                            :class="inputClass"
                                            @change="applyTargetApplicantPresetByKey"
                                        >
                                            <option value="">Choose an applicant group</option>
                                            <option
                                                v-if="selectedTargetPresetKey && !targetApplicantPresets.some((preset) => preset.key === selectedTargetPresetKey)"
                                                :value="selectedTargetPresetKey"
                                            >
                                                Custom or mixed applicant group
                                            </option>
                                            <option v-for="preset in targetApplicantPresets" :key="preset.key" :value="preset.key">
                                                {{ preset.label }}
                                            </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="mt-5" :class="labelClass">
                                    2. Required conditions
                                    <span :class="requiredHintClass">Select all that apply</span>
                                </div>

                                <div class="mt-3 grid gap-2 md:grid-cols-2" role="group" aria-label="Eligibility criteria">
                                    <label
                                        v-for="option in eligibilityOptions"
                                        :key="option.key"
                                        :class="[
                                            'flex cursor-pointer items-center gap-3 rounded-md border px-3 py-3 transition',
                                            selectedEligibilityOptions.includes(option.key)
                                                ? 'border-slate-900 bg-slate-50 ring-1 ring-slate-900/10'
                                                : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/70',
                                        ]"
                                    >
                                        <input
                                            v-model="selectedEligibilityOptions"
                                            type="checkbox"
                                            :value="option.key"
                                            class="mt-0.5 h-4 w-4 shrink-0 rounded border-slate-300 text-slate-900 focus:ring-amber-400"
                                            @change="applyEligibilityOption(option.key)"
                                        >
                                        <span class="flex min-w-0 flex-1 items-center justify-between gap-3">
                                            <span class="text-sm font-bold text-slate-900">{{ option.label }}</span>
                                            <span class="shrink-0 rounded-md bg-slate-100 px-2 py-1 text-[10px] font-bold uppercase tracking-[0.08em] text-slate-600">
                                                {{ eligibilityVerificationLabel(option.verificationType) }}
                                            </span>
                                        </span>
                                    </label>

                                    <label
                                        :class="[
                                            'flex cursor-pointer items-center gap-3 rounded-md border px-3 py-3 transition',
                                            selectedEligibilityOptions.includes(customEligibilityOption)
                                                ? 'border-amber-400 bg-amber-50/60 ring-1 ring-amber-200'
                                                : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/70',
                                        ]"
                                    >
                                        <input
                                            v-model="selectedEligibilityOptions"
                                            type="checkbox"
                                            :value="customEligibilityOption"
                                            class="mt-0.5 h-4 w-4 shrink-0 rounded border-slate-300 text-slate-900 focus:ring-amber-400"
                                            @change="applyEligibilityOption(customEligibilityOption)"
                                        >
                                        <span class="flex min-w-0 flex-1 items-center justify-between gap-3">
                                            <span class="text-sm font-bold text-slate-900">Custom condition</span>
                                            <span class="shrink-0 rounded-md bg-amber-100 px-2 py-1 text-[10px] font-bold uppercase tracking-[0.08em] text-amber-900">Optional</span>
                                        </span>
                                    </label>
                                </div>

                                <textarea
                                    v-if="selectedEligibilityOptions.includes(customEligibilityOption)"
                                    id="scholarship-custom-eligibility"
                                    v-model="customEligibilityText"
                                    rows="3"
                                    placeholder="Write the additional eligibility condition"
                                    :class="[inputClass, 'mt-3']"
                                    @input="updateEligibilitySummary"
                                ></textarea>
                                <div v-if="selectedEligibilityOptions.includes(customEligibilityOption)" class="mt-3 grid gap-3 rounded-md border border-slate-200 bg-slate-50 p-3 md:grid-cols-[15rem_minmax(0,1fr)] md:items-center">
                                    <div>
                                        <label :class="labelClass" for="scholarship-custom-eligibility-verification">How this is checked</label>
                                        <select id="scholarship-custom-eligibility-verification" v-model="scholarshipForm.customEligibilityVerification" :class="inputClass">
                                            <option v-for="option in eligibilityVerificationOptions" :key="option.value" :value="option.value">
                                                {{ option.label }}
                                            </option>
                                        </select>
                                    </div>
                                    <p class="text-xs leading-5 text-slate-500">
                                        {{ eligibilityVerificationOptions.find((option) => option.value === scholarshipForm.customEligibilityVerification)?.help }}
                                    </p>
                                </div>

                                <div v-if="eligibilityRuleIssues.length" class="mt-4 rounded-md border border-amber-300 bg-amber-50 p-3.5">
                                    <div class="flex items-start gap-3">
                                        <span class="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-amber-200 text-xs text-amber-900">
                                            <i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i>
                                        </span>
                                        <div>
                                            <p class="text-sm font-bold text-amber-950">Resolve these eligibility settings before submission</p>
                                            <ul class="mt-2 space-y-1.5">
                                                <li v-for="issue in eligibilityRuleIssues" :key="issue" class="flex items-start gap-2 text-xs leading-5 text-amber-900">
                                                    <span class="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-amber-700"></span>
                                                    <span>{{ issue }}</span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div :class="formGridClass">
                                <div v-show="activeFormSection === 'details'" :class="basicFieldStackClass">
                                    <label :class="labelClass" for="scholarship-category">
                                        Category
                                        <span :class="requiredHintClass">Required</span>
                                    </label>
                                    <select id="scholarship-category" v-model="scholarshipForm.category" :class="inputClass">
                                        <option value="">
                                            Select category
                                        </option>
                                        <option
                                            v-for="option in categoryOptions"
                                            :key="option"
                                            :value="option"
                                        >
                                            {{ option }}
                                        </option>
                                    </select>
                                </div>

                                <div v-show="activeFormSection === 'details'" :class="basicFieldStackClass">
                                    <label :class="labelClass" for="scholarship-program-cycle">
                                        Program cycle
                                        <span :class="requiredHintClass">Required</span>
                                    </label>
                                    <input
                                        id="scholarship-program-cycle"
                                        v-model="scholarshipForm.programCycle"
                                        type="text"
                                        maxlength="100"
                                        placeholder="Example: SY 2026-2027 or 2026 intake"
                                        :class="inputClass"
                                    >
                                </div>

                                <div v-show="activeFormSection === 'details'" :class="[fieldStackClass, 'md:col-span-2']">
                                    <label :class="labelClass" for="scholarship-description">
                                        Description
                                        <span :class="requiredHintClass">Required</span>
                                    </label>
                                    <textarea
                                        id="scholarship-description"
                                        v-model="scholarshipForm.description"
                                        rows="4"
                                        placeholder="Describe the scholarship program"
                                        :class="inputClass"
                                    ></textarea>
                                </div>

                                <section v-show="activeFormSection === 'details'" class="md:col-span-2 rounded-lg border border-slate-200 bg-white p-4 sm:p-5">
                                    <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                                        <div class="flex items-start gap-3">
                                            <span class="grid h-10 w-10 shrink-0 place-items-center rounded-md bg-amber-100 text-amber-800">
                                                <i class="fa-solid fa-bullseye" aria-hidden="true"></i>
                                            </span>
                                            <div>
                                                <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">Optional purpose</p>
                                                <h4 class="mt-1 text-sm font-bold text-slate-950">Explain why your organization offers this scholarship</h4>
                                            </div>
                                        </div>
                                        <button
                                            type="button"
                                            class="shrink-0 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-50"
                                            @click="showProviderPurpose = !showProviderPurpose"
                                        >
                                            {{ showProviderPurpose ? 'Hide purpose' : (scholarshipForm.providerObjectives.length || scholarshipForm.providerObjectiveNotes ? 'Review purpose' : 'Add purpose') }}
                                        </button>
                                    </div>

                                    <div v-if="showProviderPurpose" class="mt-4 border-t border-slate-200 pt-4">
                                        <div class="grid gap-2 sm:grid-cols-2">
                                            <label
                                                v-for="option in providerObjectiveOptions"
                                                :key="option.value"
                                                :class="[
                                                    'flex cursor-pointer items-start gap-3 rounded-md border p-3 transition',
                                                    scholarshipForm.providerObjectives.includes(option.value)
                                                        ? 'border-amber-400 bg-amber-50'
                                                        : 'border-slate-200 bg-slate-50 hover:border-slate-300',
                                                ]"
                                            >
                                                <input
                                                    v-model="scholarshipForm.providerObjectives"
                                                    type="checkbox"
                                                    :value="option.value"
                                                    class="mt-1 h-4 w-4 rounded border-slate-300 text-slate-950 focus:ring-amber-400"
                                                >
                                                <span class="min-w-0">
                                                    <span class="block text-sm font-bold text-slate-950">{{ option.label }}</span>
                                                    <span class="mt-0.5 block text-xs leading-5 text-slate-500">{{ option.detail }}</span>
                                                </span>
                                            </label>
                                        </div>

                                        <div class="mt-4">
                                            <label :class="labelClass" for="scholarship-provider-objective-notes">Short explanation</label>
                                            <textarea
                                                id="scholarship-provider-objective-notes"
                                                v-model="scholarshipForm.providerObjectiveNotes"
                                                rows="3"
                                                maxlength="1500"
                                                placeholder="How does this scholarship support your organization's purpose?"
                                                :class="inputClass"
                                            ></textarea>
                                        </div>
                                    </div>
                                </section>

                                <div v-show="activeFormSection === 'support'" class="md:col-span-2">
                                    <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">Support package</p>
                                    <h4 class="mt-1 text-base font-bold text-slate-950">What selected applicants will receive</h4>
                                </div>

                                <ProgramBenefitsEditor
                                    v-show="activeFormSection === 'support'"
                                    v-model="scholarshipForm.benefits"
                                />

                                <div v-show="activeFormSection === 'eligibility' && activeFormSubsection.eligibility === 'requirements'" :class="basicFieldStackClass">
                                    <label :class="labelClass" for="scholarship-grade-scale">
                                        Academic basis
                                        <span :class="optionalHintClass">Optional</span>
                                    </label>
                                    <select
                                        id="scholarship-grade-scale"
                                        v-model="scholarshipForm.minimumGradeScale"
                                        :class="inputClass"
                                        @change="handleGradeScaleChange"
                                    >
                                        <option
                                            v-for="option in gradeScaleOptions"
                                            :key="option.value || 'none'"
                                            :value="option.value"
                                        >
                                            {{ option.label }}
                                        </option>
                                    </select>
                                    <p class="mt-2 text-xs leading-5 text-slate-500">
                                        {{ selectedGradeScaleOption.help }}
                                    </p>
                                </div>

                                <div v-if="activeFormSection === 'eligibility' && activeFormSubsection.eligibility === 'requirements' && academicRequirementNeedsValue" :class="basicFieldStackClass">
                                    <label :class="labelClass" for="scholarship-minimum-gwa">
                                        {{ selectedGradeScaleOption.inputLabel }}
                                        <span :class="requiredHintClass">Required</span>
                                    </label>
                                    <input
                                        id="scholarship-minimum-gwa"
                                        v-model="scholarshipForm.minimumGwa"
                                        type="number"
                                        min="0"
                                        :max="academicRequirementInputMax"
                                        :step="academicRequirementInputStep"
                                        :placeholder="selectedGradeScaleOption.placeholder"
                                        :class="inputClass"
                                    >
                                    <p class="mt-2 text-xs leading-5 text-slate-500">
                                        {{ activeTargetForm.averageHelp }}
                                    </p>
                                </div>

                                <div v-else-if="activeFormSection === 'eligibility' && activeFormSubsection.eligibility === 'requirements'" :class="basicFieldStackClass">
                                    <p class="text-sm font-semibold text-slate-500">
                                        Academic cutoff
                                    </p>
                                    <p class="mt-2 text-sm font-bold text-slate-950">
                                        {{ academicRequirementSummary }}
                                    </p>
                                    <p class="mt-2 text-xs leading-5 text-slate-500">
                                        Add extra details in the eligibility section if reviewers need context.
                                    </p>
                                </div>

                                <div v-show="activeFormSection === 'support'" class="grid gap-4 rounded-lg border border-slate-200 bg-white p-4 md:col-span-2 md:grid-cols-[minmax(0,1fr)_minmax(0,28rem)] md:items-center">
                                    <div class="flex min-w-0 items-start gap-3">
                                        <span class="grid h-10 w-10 shrink-0 place-items-center rounded-md bg-slate-100 text-slate-700">
                                            <i class="fa-solid fa-users" aria-hidden="true"></i>
                                        </span>
                                        <div>
                                            <p class="text-sm font-bold text-slate-950">Program capacity</p>
                                            <p class="mt-1 text-xs leading-5 text-slate-500">Limit applications separately from the recipients who will receive support.</p>
                                            <p v-if="existingApplicationCount > 0" class="mt-1 text-xs font-semibold text-amber-800">
                                                {{ existingApplicationCount }} application{{ existingApplicationCount === 1 ? '' : 's' }} received · {{ awardedSlotsCount }} recipient slot{{ awardedSlotsCount === 1 ? '' : 's' }} occupied
                                            </p>
                                        </div>
                                    </div>
                                    <div class="grid gap-4 sm:grid-cols-2">
                                        <div :class="basicFieldStackClass">
                                            <label :class="labelClass" for="scholarship-slots">
                                                Recipient slots
                                                <span :class="optionalHintClass">Optional</span>
                                            </label>
                                            <input
                                                id="scholarship-slots"
                                                v-model="scholarshipForm.slotsAvailable"
                                                type="number"
                                                :min="minimumAwardSlots"
                                                step="1"
                                                placeholder="No limit"
                                                :class="inputClass"
                                            >
                                        </div>
                                        <div :class="basicFieldStackClass">
                                            <label :class="labelClass" for="scholarship-application-limit">
                                                Application limit
                                                <span :class="optionalHintClass">Optional</span>
                                            </label>
                                            <input
                                                id="scholarship-application-limit"
                                                v-model="scholarshipForm.applicationLimit"
                                                type="number"
                                                :min="minimumApplicationLimit"
                                                step="1"
                                                placeholder="No limit"
                                                :class="inputClass"
                                            >
                                        </div>
                                    </div>
                                </div>

                                <div
                                    id="scholarship-mode"
                                    v-show="activeFormSection === 'application' && activeFormSubsection.application === 'files'"
                                    class="md:col-span-2"
                                    tabindex="-1"
                                >
                                    <div class="flex flex-wrap items-end justify-between gap-2">
                                        <div>
                                            <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">Pre-screening method</p>
                                            <h4 class="mt-1 text-base font-bold text-slate-950">Choose what applicants submit first</h4>
                                        </div>
                                        <span :class="requiredHintClass">Required</span>
                                    </div>
                                    <div class="mt-4 grid gap-2 lg:grid-cols-3">
                                        <label
                                            v-for="option in applicationModeOptions"
                                            :key="option.value"
                                            :class="[
                                                'flex cursor-pointer items-start gap-3 rounded-lg border p-4 transition',
                                                scholarshipForm.applicationMode === option.value
                                                    ? 'border-slate-950 bg-slate-950 text-white shadow-sm'
                                                    : 'border-slate-200 bg-white text-slate-950 hover:border-slate-400',
                                            ]"
                                        >
                                            <input v-model="scholarshipForm.applicationMode" type="radio" :value="option.value" class="sr-only">
                                            <span :class="['grid h-9 w-9 shrink-0 place-items-center rounded-md', scholarshipForm.applicationMode === option.value ? 'bg-white/10 text-amber-300' : 'bg-slate-100 text-slate-600']">
                                                <i :class="option.value === 'provider_review' ? 'fa-solid fa-id-card' : option.value === 'onsite' ? 'fa-solid fa-building-circle-check' : 'fa-solid fa-folder-open'" aria-hidden="true"></i>
                                            </span>
                                            <span>
                                                <span class="block text-sm font-bold">{{ option.label }}</span>
                                                <span :class="['mt-1 block text-xs leading-5', scholarshipForm.applicationMode === option.value ? 'text-slate-300' : 'text-slate-500']">
                                                    {{ applicationModeDetail(option.value) }}
                                                </span>
                                            </span>
                                        </label>
                                    </div>
                                </div>

                                <div v-show="activeFormSection === 'logistics'" class="md:col-span-2">
                                    <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">Application timeline</p>
                                    <h4 class="mt-1 text-base font-bold text-slate-950">Portal pre-screening dates</h4>
                                    <p class="mt-1 text-xs leading-5 text-slate-500">Set when applications open, when submissions close, and when applicants should expect the initial result.</p>

                                    <div class="mt-4 grid gap-3 lg:grid-cols-3">
                                        <div class="rounded-lg border border-slate-200 bg-white p-4">
                                            <div class="mb-3 flex items-center gap-2">
                                                <span class="grid h-8 w-8 place-items-center rounded-md bg-slate-100 text-slate-600">
                                                    <i class="fa-solid fa-door-open text-xs" aria-hidden="true"></i>
                                                </span>
                                                <div>
                                                    <p class="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">Opens</p>
                                                    <p class="text-xs font-semibold text-slate-600">Optional</p>
                                                </div>
                                            </div>
                                            <label class="sr-only" for="scholarship-application-opens">Pre-screening opens</label>
                                            <input
                                                id="scholarship-application-opens"
                                                v-model="scholarshipForm.applicationOpensAt"
                                                type="date"
                                                :max="scholarshipForm.deadline || undefined"
                                                :class="inputClass"
                                            >
                                            <p class="mt-2 text-xs leading-5 text-slate-500">Leave blank to open when the program is published.</p>
                                        </div>

                                        <div class="rounded-lg border border-amber-200 bg-amber-50/50 p-4">
                                            <div class="mb-3 flex items-center gap-2">
                                                <span class="grid h-8 w-8 place-items-center rounded-md bg-amber-100 text-amber-800">
                                                    <i class="fa-solid fa-calendar-xmark text-xs" aria-hidden="true"></i>
                                                </span>
                                                <div>
                                                    <p class="text-[10px] font-bold uppercase tracking-[0.12em] text-amber-800">Deadline</p>
                                                    <p class="text-xs font-semibold text-slate-700">Required</p>
                                                </div>
                                            </div>
                                            <label class="sr-only" for="scholarship-deadline">Pre-screening deadline</label>
                                            <input
                                                id="scholarship-deadline"
                                                v-model="scholarshipForm.deadline"
                                                type="date"
                                                :min="todayDate"
                                                :class="inputClass"
                                            >
                                            <p class="mt-2 text-xs leading-5 text-slate-500">Applicants cannot submit after this date.</p>
                                        </div>

                                        <div class="rounded-lg border border-slate-200 bg-white p-4">
                                            <div class="mb-3 flex items-center gap-2">
                                                <span class="grid h-8 w-8 place-items-center rounded-md bg-slate-100 text-slate-600">
                                                    <i class="fa-solid fa-flag-checkered text-xs" aria-hidden="true"></i>
                                                </span>
                                                <div>
                                                    <p class="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">Initial result</p>
                                                    <p class="text-xs font-semibold text-slate-600">Optional estimate</p>
                                                </div>
                                            </div>
                                            <label class="sr-only" for="scholarship-expected-results">Expected initial results</label>
                                            <input
                                                id="scholarship-expected-results"
                                                v-model="scholarshipForm.expectedResultsAt"
                                                type="date"
                                                :min="scholarshipForm.deadline || undefined"
                                                :class="inputClass"
                                            >
                                            <p class="mt-2 text-xs leading-5 text-slate-500">Later activity schedules are announced separately.</p>
                                        </div>
                                    </div>

                                    <div class="mt-5 rounded-lg border border-slate-200 bg-slate-50 p-4 sm:p-5">
                                        <div class="flex flex-wrap items-start justify-between gap-3">
                                            <div>
                                                <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">Recipient support period</p>
                                                <h4 class="mt-1 text-base font-bold text-slate-950">When the scholarship benefits run</h4>
                                                <p class="mt-1 text-xs leading-5 text-slate-500">These dates describe the support itself, not the application period.</p>
                                            </div>
                                            <span :class="requiredHintClass">Required for review</span>
                                        </div>

                                        <div class="mt-4 grid gap-3 sm:grid-cols-2">
                                            <div class="rounded-lg border border-slate-200 bg-white p-4">
                                                <label :class="labelClass" for="scholarship-support-starts">Support starts</label>
                                                <input
                                                    id="scholarship-support-starts"
                                                    v-model="scholarshipForm.supportStartsAt"
                                                    type="date"
                                                    :class="inputClass"
                                                >
                                                <p class="mt-2 text-xs leading-5 text-slate-500">Expected first day recipients can begin receiving the listed support.</p>
                                            </div>

                                            <div class="rounded-lg border border-slate-200 bg-white p-4">
                                                <label :class="labelClass" for="scholarship-support-ends">Support ends</label>
                                                <input
                                                    id="scholarship-support-ends"
                                                    v-model="scholarshipForm.supportEndsAt"
                                                    type="date"
                                                    :min="scholarshipForm.supportStartsAt || undefined"
                                                    :class="inputClass"
                                                >
                                                <p class="mt-2 text-xs leading-5 text-slate-500">Expected final day covered by this program cycle.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>

                            <section v-show="['selection', 'logistics'].includes(activeFormSection)" class="flex flex-col gap-6">
                                <div id="scholarship-selection-stages" v-show="activeFormSection === 'selection' && activeFormSubsection.selection === 'flow'" :class="sectionCardClass">
                                    <div class="flex items-start justify-between gap-4">
                                        <div>
                                            <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">Selection process</p>
                                            <p class="mt-1 text-base font-bold text-slate-950">Set the steps before the final decision</p>
                                        </div>
                                        <span class="w-fit rounded-md bg-slate-100 px-2.5 py-1.5 text-xs font-bold text-slate-600">
                                            {{ scholarshipForm.selectionStages.length }} stages
                                        </span>
                                    </div>

                                    <div v-if="selectionPlanLocked" class="mt-4 flex items-start gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs leading-5 text-slate-600">
                                        <i class="fa-solid fa-lock mt-1 text-slate-500" aria-hidden="true"></i>
                                        <p>This order is locked because {{ existingApplicationCount }} applicant{{ existingApplicationCount === 1 ? '' : 's' }} already {{ existingApplicationCount === 1 ? 'uses' : 'use' }} it.</p>
                                    </div>

                                    <div class="mt-4 overflow-hidden rounded-lg border border-slate-200 bg-white">
                                        <div class="flex items-center justify-between gap-3 border-b border-slate-200 bg-slate-50 px-4 py-2.5">
                                            <p class="text-xs font-bold uppercase tracking-[0.12em] text-slate-500">Stage order</p>
                                            <p v-if="!selectionPlanLocked" class="text-[11px] text-slate-400">Use arrows to reorder.</p>
                                        </div>
                                        <div class="flex items-center gap-3 border-b border-slate-200 bg-slate-50 px-4 py-3">
                                            <span class="grid h-8 w-8 place-items-center rounded-md bg-slate-950 text-xs font-bold text-white">1</span>
                                            <div class="min-w-0 flex-1">
                                                <p class="text-sm font-bold text-slate-950">Pre-screening review</p>
                                                <p class="text-xs text-slate-500">Check eligibility, profile, scoring, and submitted files.</p>
                                            </div>
                                            <span class="rounded bg-white px-2 py-1 text-[10px] font-bold uppercase tracking-[0.12em] text-slate-500 ring-1 ring-slate-200">Portal</span>
                                        </div>

                                        <div class="divide-y divide-slate-200">
                                            <div
                                                v-for="(stageValue, index) in scholarshipForm.selectionStages.filter((stage) => !['screening', 'decision'].includes(stage))"
                                                :key="stageValue"
                                                class="flex items-start gap-3 px-4 py-3"
                                            >
                                                <span class="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-amber-100 text-xs font-bold text-amber-800">{{ index + 2 }}</span>
                                                <span class="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-slate-100 text-slate-700">
                                                    <i :class="selectionStageOptions.find((stage) => stage.value === stageValue)?.icon" aria-hidden="true"></i>
                                                </span>
                                                <div class="min-w-0 flex-1">
                                                    <p class="text-sm font-bold text-slate-950">{{ selectionStageOptions.find((stage) => stage.value === stageValue)?.label }}</p>
                                                    <p class="mt-0.5 text-xs leading-5 text-slate-500">{{ selectionStageOptions.find((stage) => stage.value === stageValue)?.description }}</p>
                                                </div>
                                                <div v-if="!selectionPlanLocked" class="flex shrink-0 items-center gap-1">
                                                    <button type="button" class="grid h-8 w-8 place-items-center rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-30" :disabled="index === 0" title="Move earlier" @click="moveSelectionStage(stageValue, -1)">
                                                        <i class="fa-solid fa-arrow-up" aria-hidden="true"></i>
                                                    </button>
                                                    <button type="button" class="grid h-8 w-8 place-items-center rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-30" :disabled="index === scholarshipForm.selectionStages.filter((stage) => !['screening', 'decision'].includes(stage)).length - 1" title="Move later" @click="moveSelectionStage(stageValue, 1)">
                                                        <i class="fa-solid fa-arrow-down" aria-hidden="true"></i>
                                                    </button>
                                                    <button v-if="['exam', 'interview'].includes(stageValue)" type="button" class="grid h-8 w-8 place-items-center rounded-md border border-rose-200 text-rose-600 hover:bg-rose-50" title="Remove stage" @click="toggleSelectionStage(stageValue)">
                                                        <i class="fa-solid fa-xmark" aria-hidden="true"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="flex items-center gap-3 border-t border-slate-200 bg-slate-50 px-4 py-3">
                                            <span class="grid h-8 w-8 place-items-center rounded-md bg-slate-950 text-xs font-bold text-white">{{ scholarshipForm.selectionStages.length }}</span>
                                            <div class="min-w-0 flex-1">
                                                <p class="text-sm font-bold text-slate-950">Final decision</p>
                                                <p class="text-xs text-slate-500">Selected, waitlisted, or not selected</p>
                                            </div>
                                            <span class="rounded bg-white px-2 py-1 text-[10px] font-bold uppercase tracking-[0.12em] text-slate-500 ring-1 ring-slate-200">Final</span>
                                        </div>

                                        <div
                                            v-if="!selectionPlanLocked && configurableStageOptions.filter((stage) => !stage.required && !scholarshipForm.selectionStages.includes(stage.value)).length"
                                            class="border-t border-slate-200 bg-white px-4 py-3"
                                        >
                                            <div class="flex flex-wrap items-center gap-2">
                                                <span class="mr-1 text-xs font-bold text-slate-500">Add optional stage</span>
                                                <button
                                                    v-for="stage in configurableStageOptions.filter((item) => !item.required && !scholarshipForm.selectionStages.includes(item.value))"
                                                    :key="stage.value"
                                                    type="button"
                                                    class="inline-flex items-center gap-2 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:border-slate-950 hover:text-slate-950"
                                                    @click="toggleSelectionStage(stage.value)"
                                                >
                                                    <i :class="stage.icon" aria-hidden="true"></i>
                                                    {{ stage.label }}
                                                    <i class="fa-solid fa-plus text-[10px]" aria-hidden="true"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mt-4 flex flex-col gap-3 border-t border-slate-200 pt-4 sm:flex-row sm:items-center sm:justify-between">
                                        <p class="text-xs leading-5 text-slate-500">
                                            Schedule the {{ schedulableSelectionStageLabel }} from Activities after saving.
                                        </p>
                                        <a
                                            v-if="isEditMode && hasSchedulableSelectionStage"
                                            :href="`/provider/programs/${scholarshipId}/applications/activities`"
                                            class="inline-flex shrink-0 items-center justify-center gap-2 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-100"
                                        >
                                            Open Activities
                                            <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
                                        </a>
                                        <span v-else class="shrink-0 text-xs font-bold text-slate-400">Available after saving</span>
                                    </div>
                                </div>

                                <div v-show="activeFormSection === 'logistics'" :class="[sectionCardClass, 'grid items-stretch gap-4 lg:grid-cols-2']">
                                    <div class="flex flex-col gap-3 lg:col-span-2 sm:flex-row sm:items-start sm:justify-between">
                                        <div>
                                            <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">Public contact</p>
                                            <p class="mt-1 text-base font-bold text-slate-950">
                                                Where applicants can ask questions
                                                <span :class="requiredHintClass">Email or number required</span>
                                            </p>
                                            <p class="mt-1 text-xs leading-5 text-slate-500">
                                                New programs use the public contact and website saved in your provider profile. You can still change them for this program.
                                            </p>
                                        </div>
                                        <button
                                            v-if="hasProviderPublicContact"
                                            type="button"
                                            class="inline-flex shrink-0 items-center justify-center gap-2 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-100"
                                            @click="useProviderPublicContact()"
                                        >
                                            <i class="fa-solid fa-building" aria-hidden="true"></i>
                                            Use provider profile
                                        </button>
                                    </div>

                                    <div :class="fieldStackClass">
                                        <label :class="labelClass" for="scholarship-contact-person">
                                            Contact person
                                            <span :class="optionalHintClass">Optional</span>
                                        </label>
                                        <input
                                            id="scholarship-contact-person"
                                            v-model="scholarshipForm.contactPerson"
                                            type="text"
                                            maxlength="150"
                                            placeholder="Name of the program contact"
                                            :class="inputClass"
                                        >
                                    </div>

                                    <div :class="fieldStackClass">
                                        <label :class="labelClass" for="scholarship-contact-department">
                                            Office or department
                                            <span :class="optionalHintClass">Optional</span>
                                        </label>
                                        <input
                                            id="scholarship-contact-department"
                                            v-model="scholarshipForm.contactDepartment"
                                            type="text"
                                            maxlength="150"
                                            placeholder="Example: Scholarship Office"
                                            :class="inputClass"
                                        >
                                    </div>

                                    <div :class="fieldStackClass">
                                        <label :class="labelClass" for="scholarship-contact-email">Contact email</label>
                                        <input
                                            id="scholarship-contact-email"
                                            v-model="scholarshipForm.contactEmail"
                                            type="email"
                                            placeholder="scholarship.office@example.com"
                                            :class="inputClass"
                                        >
                                    </div>

                                    <div :class="fieldStackClass">
                                        <label :class="labelClass" for="scholarship-contact-number">Contact number</label>
                                        <input
                                            id="scholarship-contact-number"
                                            :value="scholarshipForm.contactNumber"
                                            type="tel"
                                            inputmode="tel"
                                            maxlength="20"
                                            placeholder="0917 123 4567"
                                            :class="inputClass"
                                            @input="scholarshipForm.contactNumber = limitPhoneNumber($event.target.value)"
                                        >
                                    </div>

                                    <div :class="[fieldStackClass, 'lg:col-span-2']">
                                        <label :class="labelClass" for="scholarship-official-url">
                                            Official program page
                                            <span :class="optionalHintClass">Optional</span>
                                        </label>
                                        <input
                                            id="scholarship-official-url"
                                            v-model="scholarshipForm.officialProgramUrl"
                                            type="url"
                                            maxlength="2048"
                                            placeholder="https://provider.example.org/scholarships/program"
                                            :class="inputClass"
                                        >
                                        <p class="mt-2 text-xs leading-5 text-slate-500">
                                            Applicants can use this public page to confirm the official announcement.
                                        </p>
                                    </div>

                                </div>
                            </section>

                            <section v-show="activeFormSection === 'eligibility' && activeFormSubsection.eligibility === 'matching'" :class="sectionCardClass">
                                <div class="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                                    <div class="flex min-w-0 items-start gap-3">
                                        <span class="grid h-10 w-10 shrink-0 place-items-center rounded-md bg-slate-100 text-slate-700">
                                            <i class="fa-solid fa-sliders" aria-hidden="true"></i>
                                        </span>
                                        <div>
                                            <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">Matching restrictions</p>
                                            <h4 class="mt-1 text-base font-bold text-slate-950">Rules used to match applicants</h4>
                                            <p class="mt-1 max-w-2xl text-xs leading-5 text-slate-500">Leave an item open when it should not restrict who can match this program.</p>
                                        </div>
                                    </div>
                                    <button
                                        type="button"
                                        class="shrink-0 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-100"
                                        @click="applyActiveTargetDefaults"
                                    >
                                        Use suggested defaults
                                    </button>
                                </div>

                                <div class="mt-4 rounded-md border border-slate-200 bg-white p-3">
                                    <p class="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-500">Current matching setup</p>
                                    <div class="mt-2 flex flex-wrap gap-2">
                                        <span
                                            v-for="summary in finderRuleSummary"
                                            :key="summary"
                                            class="rounded-md bg-slate-100 px-2.5 py-1.5 text-xs font-semibold text-slate-700"
                                        >
                                            {{ summary }}
                                        </span>
                                    </div>
                                </div>

                                <div class="mt-4 grid items-start gap-4 lg:grid-cols-2">
                                    <div class="rounded-md border border-slate-200 bg-white p-4 lg:col-span-2">
                                        <p class="text-[10px] font-bold uppercase tracking-[0.12em] text-amber-700">Applicant group</p>
                                        <p class="mt-1 text-sm font-bold text-slate-950">{{ activeTargetForm.title }}</p>
                                        <p class="mt-1 max-w-2xl text-xs leading-5 text-slate-500">
                                            {{ activeTargetForm.guidance }}
                                        </p>
                                    </div>

                                    <button
                                        type="button"
                                        class="flex w-full items-center justify-between gap-4 rounded-md border border-slate-200 bg-white p-4 text-left transition hover:border-slate-300 lg:col-span-2"
                                        :aria-expanded="showCoreMatchingRules"
                                        @click="showCoreMatchingRules = !showCoreMatchingRules"
                                    >
                                        <span class="flex min-w-0 items-center gap-3">
                                            <span class="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-slate-100 text-slate-700">
                                                <i class="fa-solid fa-graduation-cap" aria-hidden="true"></i>
                                            </span>
                                            <span class="min-w-0">
                                                <span class="block text-sm font-bold text-slate-950">Learner and school rules</span>
                                                <span class="mt-1 block truncate text-xs text-slate-500">{{ finderRuleSummary.slice(0, 2).join(' · ') }}</span>
                                            </span>
                                        </span>
                                        <i :class="['fa-solid shrink-0 text-slate-400', showCoreMatchingRules ? 'fa-chevron-up' : 'fa-chevron-down']" aria-hidden="true"></i>
                                    </button>

                                    <div v-if="showCoreMatchingRules" class="grid gap-4 lg:col-span-2 lg:grid-cols-2">
                                    <div id="scholarship-education-levels" :class="[fieldStackClass, 'rounded-md border border-slate-200 bg-white p-4 lg:col-span-2']">
                                        <div class="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                                            <div>
                                                <p class="text-sm font-bold text-slate-900">Education levels</p>
                                                <p class="mt-1 text-xs text-slate-500">Select every learner level that may apply.</p>
                                            </div>
                                            <div class="flex items-center gap-2">
                                                <span class="text-xs font-semibold text-slate-500">
                                                    {{ scholarshipForm.eligibleEducationLevels.length ? `${scholarshipForm.eligibleEducationLevels.length} selected` : 'Open to all' }}
                                                </span>
                                                <button type="button" class="text-xs font-bold text-slate-700 hover:text-slate-950" @click="selectAllOptions('eligibleEducationLevels', educationLevelOptions)">
                                                    Select all
                                                </button>
                                                <span class="text-slate-300" aria-hidden="true">|</span>
                                                <button type="button" class="text-xs font-bold text-slate-700 hover:text-slate-950" @click="scholarshipForm.eligibleEducationLevels = []">
                                                    Open to all
                                                </button>
                                            </div>
                                        </div>
                                        <div class="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                                            <label
                                                v-for="option in educationLevelOptions"
                                                :key="option.value"
                                                :class="[
                                                    'flex cursor-pointer items-center gap-2.5 rounded-md border px-3 py-2.5 text-xs font-semibold transition',
                                                    scholarshipForm.eligibleEducationLevels.includes(option.value)
                                                        ? 'border-slate-400 bg-slate-50 text-slate-950'
                                                        : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300',
                                                ]"
                                            >
                                                <input
                                                    v-model="scholarshipForm.eligibleEducationLevels"
                                                    type="checkbox"
                                                    :value="option.value"
                                                    class="h-4 w-4 rounded border-slate-300 text-slate-950 focus:ring-amber-400"
                                                >
                                                {{ option.label }}
                                            </label>
                                        </div>
                                    </div>

                                    <div id="scholarship-school-types" :class="[fieldStackClass, 'rounded-md border border-slate-200 bg-white p-4 lg:col-span-2']">
                                        <div class="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                                            <div>
                                                <p class="text-sm font-bold text-slate-900">School types</p>
                                                <p class="mt-1 text-xs text-slate-500">Leave this open when any school type is accepted.</p>
                                            </div>
                                            <div class="flex items-center gap-2">
                                                <span class="text-xs font-semibold text-slate-500">
                                                    {{ scholarshipForm.eligibleSchoolTypes.length ? `${scholarshipForm.eligibleSchoolTypes.length} selected` : 'Open to all' }}
                                                </span>
                                                <button type="button" class="text-xs font-bold text-slate-700 hover:text-slate-950" @click="selectAllOptions('eligibleSchoolTypes', targetSchoolTypeOptions)">
                                                    Select all
                                                </button>
                                                <span class="text-slate-300" aria-hidden="true">|</span>
                                                <button type="button" class="text-xs font-bold text-slate-700 hover:text-slate-950" @click="scholarshipForm.eligibleSchoolTypes = []">
                                                    Open to all
                                                </button>
                                            </div>
                                        </div>
                                        <div class="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                                            <label
                                                v-for="option in targetSchoolTypeOptions"
                                                :key="option.value"
                                                :class="[
                                                    'flex cursor-pointer items-center gap-2.5 rounded-md border px-3 py-2.5 text-xs font-semibold transition',
                                                    scholarshipForm.eligibleSchoolTypes.includes(option.value)
                                                        ? 'border-slate-400 bg-slate-50 text-slate-950'
                                                        : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300',
                                                ]"
                                            >
                                                <input
                                                    v-model="scholarshipForm.eligibleSchoolTypes"
                                                    type="checkbox"
                                                    :value="option.value"
                                                    class="h-4 w-4 rounded border-slate-300 text-slate-950 focus:ring-amber-400"
                                                >
                                                {{ option.label }}
                                            </label>
                                        </div>
                                        <div
                                            v-if="hiddenSelectedSchoolTypeLabels.length"
                                            class="mt-3 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs leading-5 text-amber-900"
                                        >
                                            <p class="font-bold">
                                                Hidden selections from another target form
                                            </p>
                                            <p class="mt-1">
                                                {{ hiddenSelectedSchoolTypeLabels.join(', ') }}
                                            </p>
                                            <button
                                                type="button"
                                                class="mt-2 font-bold text-amber-950 underline"
                                                @click="clearHiddenSchoolTypes"
                                            >
                                                Remove hidden school types
                                            </button>
                                        </div>
                                    </div>
                                    </div>

                                    <button
                                        type="button"
                                        class="flex w-full items-center justify-between gap-4 rounded-md border border-slate-200 bg-white p-4 text-left transition hover:border-slate-300 lg:col-span-2"
                                        :aria-expanded="showAdditionalMatchingRules"
                                        @click="showAdditionalMatchingRules = !showAdditionalMatchingRules"
                                    >
                                        <span class="flex min-w-0 items-center gap-3">
                                            <span class="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-amber-100 text-amber-800">
                                                <i class="fa-solid fa-filter" aria-hidden="true"></i>
                                            </span>
                                            <span>
                                                <span class="block text-sm font-bold text-slate-950">Additional restrictions</span>
                                                <span class="mt-1 block text-xs text-slate-500">{{ additionalRestrictionCount ? `${additionalRestrictionCount} active` : 'No additional restrictions' }}</span>
                                            </span>
                                        </span>
                                        <i :class="['fa-solid shrink-0 text-slate-400', showAdditionalMatchingRules ? 'fa-chevron-up' : 'fa-chevron-down']" aria-hidden="true"></i>
                                    </button>

                                    <div v-if="showAdditionalMatchingRules" class="grid gap-4 lg:col-span-2 lg:grid-cols-2">

                                    <div v-if="activeTargetForm.showProgramPath" :class="[fieldStackClass, 'rounded-md border border-slate-200 bg-white p-4 lg:col-span-2']">
                                        <div class="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                                            <div>
                                                <p class="block text-sm font-bold text-slate-900">
                                                    {{ activeTargetForm.programPathLabel }}
                                                </p>
                                                <p class="mt-1 text-xs text-slate-500">{{ activeTargetForm.programPathHelp }}</p>
                                            </div>
                                            <span class="text-xs font-semibold text-slate-500">
                                                {{ selectedProgramPaths.length ? `${selectedProgramPaths.length} selected` : 'Open to all' }}
                                            </span>
                                        </div>
                                        <div id="scholarship-courses" class="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3" role="group" :aria-label="activeTargetForm.programPathLabel">
                                            <label
                                                v-for="option in programPathSelectOptions"
                                                :key="option"
                                                :class="[
                                                    'flex cursor-pointer items-center gap-2.5 rounded-md border px-3 py-2.5 text-xs font-semibold transition',
                                                    isProgramPathSelected(option)
                                                        ? 'border-slate-400 bg-slate-50 text-slate-950'
                                                        : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300',
                                                ]"
                                            >
                                                <input
                                                    type="checkbox"
                                                    :checked="isProgramPathSelected(option)"
                                                    class="h-4 w-4 rounded border-slate-300 text-slate-950 focus:ring-amber-400"
                                                    @change="toggleEligibleProgramPath(option)"
                                                >
                                                {{ option }}
                                            </label>
                                        </div>
                                        <div class="mt-3 flex flex-col gap-2 sm:flex-row">
                                            <input
                                                v-model="customProgramPath"
                                                type="text"
                                                :placeholder="`Enter another ${activeTargetForm.programPathLabel.toLowerCase()}`"
                                                :class="inputClass"
                                                @keyup.enter.prevent="addCustomProgramPath"
                                            >
                                            <button
                                                type="button"
                                                class="shrink-0 rounded-md bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800"
                                                @click="addCustomProgramPath"
                                            >
                                                Add
                                            </button>
                                        </div>
                                        <div v-if="customSelectedProgramPaths.length" class="mt-3 flex flex-wrap gap-2">
                                            <button
                                                v-for="path in customSelectedProgramPaths"
                                                :key="path"
                                                type="button"
                                                class="inline-flex items-center gap-2 rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-left text-xs font-semibold text-slate-700 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-700"
                                                :title="`Remove ${path}`"
                                                @click="removeEligibleProgramPath(path)"
                                            >
                                                <span>{{ path }}</span>
                                                <i class="fa-solid fa-xmark text-[10px]" aria-hidden="true"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <div v-else :class="[fieldStackClass, 'rounded-md border border-slate-200 bg-white p-4 lg:col-span-2']">
                                        <p class="text-sm font-bold text-slate-900">
                                            {{ activeTargetForm.programPathLabel }}
                                        </p>
                                        <p class="mt-2 text-xs leading-5 text-slate-500">
                                            {{ activeTargetForm.programPathHelp }}
                                        </p>
                                        <button
                                            type="button"
                                            class="mt-3 self-start rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-white"
                                            @click="scholarshipForm.eligibleCourses = canonicalizeProgramPathList(activeTargetForm.programPathTemplate)"
                                        >
                                            Mark as not applicable
                                        </button>
                                    </div>

                                    <div :class="[fieldStackClass, 'rounded-md border border-slate-200 bg-white p-4 lg:col-span-2']">
                                        <div class="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                                            <div>
                                                <p class="block text-sm font-bold text-slate-900">
                                                    {{ activeTargetForm.levelLabel }}
                                                </p>
                                                <p class="mt-1 text-xs text-slate-500">Select every grade or year level that may apply.</p>
                                            </div>
                                            <span class="text-xs font-semibold text-slate-500">
                                                {{ selectedGradeLevels.length ? `${selectedGradeLevels.length} selected` : 'Open to all' }}
                                            </span>
                                        </div>
                                        <div id="scholarship-years" class="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3" role="group" :aria-label="activeTargetForm.levelLabel">
                                            <label
                                                v-for="level in gradeLevelSelectOptions"
                                                :key="level"
                                                :class="[
                                                    'flex cursor-pointer items-center gap-2.5 rounded-md border px-3 py-2.5 text-xs font-semibold transition',
                                                    isGradeLevelSelected(level)
                                                        ? 'border-slate-400 bg-slate-50 text-slate-950'
                                                        : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300',
                                                ]"
                                            >
                                                <input
                                                    type="checkbox"
                                                    :checked="isGradeLevelSelected(level)"
                                                    class="h-4 w-4 rounded border-slate-300 text-slate-950 focus:ring-amber-400"
                                                    @change="toggleEligibleGradeLevel(level)"
                                                >
                                                {{ level }}
                                            </label>
                                        </div>
                                    </div>

                                    <div id="scholarship-eligible-locations" :class="[fieldStackClass, 'rounded-md border border-slate-200 bg-white p-4 lg:col-span-2']">
                                        <div class="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                                            <div>
                                                <p class="text-sm font-bold text-slate-900">Eligible locations</p>
                                                <p class="mt-1 text-xs text-slate-500">Choose a region first. Province and city options are limited to that region.</p>
                                            </div>
                                            <button type="button" class="self-start text-xs font-bold text-slate-700 hover:text-slate-950 sm:self-auto" @click="setNationwideCoverage">
                                                Set nationwide
                                            </button>
                                        </div>

                                        <div class="mt-3 grid items-end gap-3 md:grid-cols-2 xl:grid-cols-4">
                                            <label>
                                                <span :class="labelClass">Coverage level</span>
                                                <select v-model="coverageLevel" :class="inputClass" @change="handleCoverageLevelChange">
                                                    <option v-for="option in coverageLevelOptions" :key="option.value" :value="option.value">{{ option.label }}</option>
                                                </select>
                                            </label>
                                            <label>
                                                <span :class="labelClass">Region</span>
                                                <select v-model="coverageRegionCode" :class="inputClass" @change="handleCoverageRegionChange">
                                                    <option value="">Select region</option>
                                                    <option v-for="region in philippineRegionOptions" :key="region.code" :value="region.code">{{ region.label }}</option>
                                                </select>
                                            </label>
                                            <label v-if="coverageLevel !== 'region'">
                                                <span :class="labelClass">Province</span>
                                                <select
                                                    v-model="coverageProvinceCode"
                                                    :class="inputClass"
                                                    :disabled="!coverageRegionCode || isLoadingCoverageProvinces"
                                                    @change="handleCoverageProvinceChange"
                                                >
                                                    <option value="">{{ isLoadingCoverageProvinces ? 'Loading provinces...' : 'Select province' }}</option>
                                                    <option v-for="province in coverageProvinceOptions" :key="province.code" :value="province.code">{{ province.label }}</option>
                                                </select>
                                            </label>
                                            <label v-if="coverageLevel === 'city'">
                                                <span :class="labelClass">City / municipality</span>
                                                <select v-model="coverageCity" :class="inputClass" :disabled="!coverageProvinceCode || isLoadingCoverageCities">
                                                    <option value="">{{ isLoadingCoverageCities ? 'Loading cities...' : 'Select city or municipality' }}</option>
                                                    <option v-for="city in coverageCityOptions" :key="city.code" :value="city.value">{{ city.label }}</option>
                                                </select>
                                            </label>
                                        </div>

                                        <button type="button" class="mt-3 w-fit rounded-md bg-slate-900 px-4 py-2.5 text-xs font-bold text-white transition hover:bg-slate-800" @click="addEligibleLocation">
                                            <i class="fa-solid fa-plus mr-1.5" aria-hidden="true"></i>
                                            Add coverage
                                        </button>

                                        <p v-if="coverageOptionsError" class="mt-2 text-xs font-semibold text-rose-600">{{ coverageOptionsError }}</p>

                                        <div v-if="selectedEligibleLocations.length" class="mt-3 flex flex-wrap gap-2">
                                            <button
                                                v-for="location in selectedEligibleLocations"
                                                :key="location"
                                                type="button"
                                                class="inline-flex items-center gap-2 rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-left text-xs font-semibold text-slate-700 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-700"
                                                :title="`Remove ${location}`"
                                                @click="removeEligibleLocation(location)"
                                            >
                                                <i class="fa-solid fa-location-dot text-amber-600" aria-hidden="true"></i>
                                                <span>{{ location }}</span>
                                                <i class="fa-solid fa-xmark text-[10px]" aria-hidden="true"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <div :class="[fieldStackClass, 'rounded-md border border-slate-200 bg-white p-4 lg:col-span-2']">
                                        <div class="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                                            <div>
                                                <label class="block text-sm font-bold text-slate-900" for="scholarship-income">Income requirement</label>
                                                <p class="mt-1 text-xs text-slate-500">Choose a limit only when household income affects matching.</p>
                                            </div>
                                            <span class="text-xs font-semibold text-slate-500">{{ scholarshipForm.incomeRequirement || 'Any income' }}</span>
                                        </div>
                                        <select id="scholarship-income" v-model="scholarshipForm.incomeRequirement" :class="[inputClass, 'mt-3']">
                                            <option
                                                v-for="option in incomeOptions"
                                                :key="option"
                                                :value="option"
                                            >
                                                {{ option }}
                                            </option>
                                        </select>
                                    </div>

                                    <label
                                        :class="[
                                            'flex cursor-pointer items-start gap-3 rounded-md border p-4 transition lg:col-span-2',
                                            scholarshipForm.excludeCurrentScholarshipRecipients
                                                ? 'border-amber-400 bg-amber-50'
                                                : 'border-slate-200 bg-white hover:border-slate-300',
                                        ]"
                                    >
                                        <input
                                            v-model="scholarshipForm.excludeCurrentScholarshipRecipients"
                                            type="checkbox"
                                            class="mt-0.5 h-4 w-4 rounded border-slate-300 text-slate-950 focus:ring-amber-400"
                                        >
                                        <span>
                                            <span class="block text-sm font-bold text-slate-950">Do not accept applicants currently receiving another scholarship</span>
                                            <span class="mt-1 block text-xs leading-5 text-slate-600">The portal checks active awards recorded in the platform and scholarship support declared from outside it. Pending applications, completed scholarships, and terminated benefits are not blocked.</span>
                                        </span>
                                    </label>

                                    </div>
                                </div>
                            </section>

                            <fieldset v-show="activeFormSection === 'logistics'" :class="['mt-6', sectionCardClass]">
                                <div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                                    <div>
                                        <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">Program location</p>
                                        <p class="mt-1 text-sm font-semibold text-slate-700">
                                            Main office or service location
                                            <span :class="requiredHintClass">Address and pin required</span>
                                        </p>
                                        <p class="mt-1 text-xs leading-5 text-slate-500">
                                            Select the general area used by the portal map. Add the street details for applicants, then use Google Maps when exact street-level checking is needed.
                                        </p>
                                    </div>

                                    <div class="flex flex-wrap items-center gap-2">
                                        <button
                                            v-if="hasProviderAddress"
                                            type="button"
                                            class="rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-100"
                                            @click="useProviderAddress()"
                                        >
                                            <i class="fa-solid fa-building mr-1.5" aria-hidden="true"></i>
                                            Use provider address
                                        </button>
                                        <button
                                            id="scholarship-map-toggle"
                                            type="button"
                                            class="rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-100"
                                            @click="openLocationMap"
                                        >
                                            <i class="fa-solid fa-map-location-dot mr-1.5" aria-hidden="true"></i>
                                            {{ scholarshipForm.latitude ? 'Review map pin' : 'Set map pin' }}
                                        </button>
                                    </div>
                                </div>

                                <div class="mt-4 space-y-4">
                                    <div :class="fieldStackClass">
                                        <label :class="labelClass" for="scholarship-location-name">
                                            Location name
                                            <span :class="requiredHintClass">Required</span>
                                        </label>
                                        <input
                                            id="scholarship-location-name"
                                            v-model="scholarshipForm.locationName"
                                            type="text"
                                            placeholder="Example: City Scholarship Office"
                                            :class="inputClass"
                                        >
                                    </div>

                                    <div class="grid items-start gap-4 md:grid-cols-2 xl:grid-cols-4">
                                        <div :class="fieldStackClass">
                                            <label :class="labelClass" for="scholarship-location-region">
                                                Region
                                                <span :class="requiredHintClass">Required</span>
                                            </label>
                                            <select
                                                id="scholarship-location-region"
                                                v-model="scholarshipForm.locationRegion"
                                                :class="inputClass"
                                                @change="handleProgramRegionChange"
                                            >
                                                <option value="">Select region</option>
                                                <option v-if="scholarshipForm.locationRegion && !findPhilippineRegion(scholarshipForm.locationRegion)" :value="scholarshipForm.locationRegion">{{ scholarshipForm.locationRegion }}</option>
                                                <option v-for="region in philippineRegionOptions" :key="region.code" :value="region.value">{{ region.label }}</option>
                                            </select>
                                        </div>

                                        <div :class="fieldStackClass">
                                            <label :class="labelClass" for="scholarship-location-province">
                                                Province
                                                <span :class="requiredHintClass">Required</span>
                                            </label>
                                            <select
                                                id="scholarship-location-province"
                                                v-model="scholarshipForm.locationProvince"
                                                :disabled="!scholarshipForm.locationRegion || isLoadingProgramProvinces"
                                                :class="[inputClass, 'disabled:bg-slate-100 disabled:text-slate-500']"
                                                @change="handleProgramProvinceChange"
                                            >
                                                <option value="">{{ isLoadingProgramProvinces ? 'Loading provinces...' : 'Select province' }}</option>
                                                <option v-if="scholarshipForm.locationProvince && !findLocationOption(programProvinceOptions, scholarshipForm.locationProvince)" :value="scholarshipForm.locationProvince">{{ scholarshipForm.locationProvince }}</option>
                                                <option v-for="province in programProvinceOptions" :key="province.code" :value="province.value">{{ province.label }}</option>
                                            </select>
                                        </div>

                                        <div :class="fieldStackClass">
                                            <label :class="labelClass" for="scholarship-location-city">
                                                City / municipality
                                                <span :class="requiredHintClass">Required</span>
                                            </label>
                                            <select
                                                id="scholarship-location-city"
                                                v-model="scholarshipForm.locationCity"
                                                :disabled="!scholarshipForm.locationProvince || isLoadingProgramCities"
                                                :class="[inputClass, 'disabled:bg-slate-100 disabled:text-slate-500']"
                                                @change="handleProgramAddressChange"
                                            >
                                                <option value="">{{ isLoadingProgramCities ? 'Loading cities...' : 'Select city or municipality' }}</option>
                                                <option v-if="scholarshipForm.locationCity && !findLocationOption(programCityOptions, scholarshipForm.locationCity)" :value="scholarshipForm.locationCity">{{ scholarshipForm.locationCity }}</option>
                                                <option v-for="city in programCityOptions" :key="city.code" :value="city.value">{{ city.label }}</option>
                                            </select>
                                        </div>

                                        <div :class="fieldStackClass">
                                            <label :class="labelClass" for="scholarship-location-barangay">
                                                Barangay
                                                <span :class="optionalHintClass">Optional</span>
                                            </label>
                                            <input
                                                id="scholarship-location-barangay"
                                                v-model="scholarshipForm.locationBarangay"
                                                type="text"
                                                maxlength="255"
                                                placeholder="Barangay"
                                                :class="inputClass"
                                                @input="handleProgramDetailAddressChange"
                                            >
                                        </div>
                                    </div>

                                    <div :class="fieldStackClass">
                                        <label :class="labelClass" for="scholarship-location-address-line">
                                            Street / building address
                                            <span :class="optionalHintClass">Optional</span>
                                        </label>
                                        <input
                                            id="scholarship-location-address-line"
                                            v-model="scholarshipForm.locationAddressLine"
                                            type="text"
                                            maxlength="500"
                                            placeholder="Building, house number, and street"
                                            :class="inputClass"
                                            @input="handleProgramDetailAddressChange"
                                        >
                                        <p class="mt-2 text-xs leading-5 text-slate-500">
                                            Leaflet uses only the city, province, and region. Open Google Maps from the map modal to check the complete address more accurately.
                                        </p>
                                    </div>

                                    <p v-if="programLocationOptionsError" class="text-xs font-semibold text-rose-600">
                                        {{ programLocationOptionsError }}
                                    </p>

                                    <div class="rounded-md border border-slate-200 bg-white px-3 py-2.5 text-xs leading-5 text-slate-600">
                                        <span class="font-bold text-slate-800">Saved public address:</span>
                                        {{ scholarshipForm.locationAddress || 'Complete the location fields above.' }}
                                    </div>
                                </div>

                                <p v-if="providerLocationMessage" class="mt-3 text-xs font-semibold text-slate-700">
                                    {{ providerLocationMessage }}
                                </p>
                                <p v-else-if="scholarshipForm.latitude" class="mt-3 flex items-center gap-2 text-xs font-semibold text-emerald-700">
                                    <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                                    A map pin is set for this program.
                                </p>
                            </fieldset>

                            <fieldset
                                v-show="activeFormSection === 'application'"
                                :class="[activeFormSubsection.application === 'files' ? 'mt-6' : '', sectionCardClass]"
                            >
                                <div v-show="activeFormSubsection.application === 'files'">
                                <div class="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                                    <div>
                                        <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">Portal pre-screening</p>
                                        <h4 class="mt-1 text-base font-bold text-slate-950">Files submitted with the application</h4>
                                        <p class="mt-1 max-w-3xl text-xs leading-5 text-slate-500">
                                            {{ isProfileReviewOnly
                                                ? 'Applicants submit their profile and matching details without uploading program-specific files.'
                                                : 'Choose only the files needed to make the initial qualification decision.' }}
                                        </p>
                                    </div>
                                    <div v-if="!isProfileReviewOnly" class="flex shrink-0 items-center gap-2 text-xs font-bold">
                                        <span class="rounded-md bg-slate-950 px-2.5 py-1.5 text-white">{{ selectedRequirementCount }} required</span>
                                        <span class="rounded-md bg-amber-100 px-2.5 py-1.5 text-amber-900">{{ selectedOptionalRequirementCount }} supporting</span>
                                    </div>
                                </div>

                                <div v-if="isProfileReviewOnly" class="mt-4 flex items-start gap-3 rounded-lg border border-slate-200 bg-slate-50 p-4 text-sm leading-6 text-slate-700">
                                    <span class="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-white text-slate-700 shadow-sm">
                                        <i class="fa-solid fa-id-card" aria-hidden="true"></i>
                                    </span>
                                    <div>
                                        <p class="font-bold text-slate-950">Profile review selected</p>
                                        <p class="mt-0.5 text-xs leading-5">Applicants will not be asked for program files at this stage. Add any originals or provider forms below under formal application handoff.</p>
                                    </div>
                                </div>

                                <template v-else>
                                <button
                                    type="button"
                                    class="mt-4 flex w-full items-center justify-between gap-4 rounded-md border border-slate-200 bg-white p-4 text-left transition hover:border-slate-300"
                                    :aria-expanded="showDocumentChecklist"
                                    @click="showDocumentChecklist = !showDocumentChecklist"
                                >
                                    <span class="flex min-w-0 items-center gap-3">
                                        <span class="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-slate-100 text-slate-700">
                                            <i class="fa-solid fa-folder-open" aria-hidden="true"></i>
                                        </span>
                                        <span>
                                            <span class="block text-sm font-bold text-slate-950">Document checklist</span>
                                            <span class="mt-1 block text-xs text-slate-500">{{ selectedRequirementCount }} required · {{ selectedOptionalRequirementCount }} supporting</span>
                                        </span>
                                    </span>
                                    <span class="flex shrink-0 items-center gap-2 text-xs font-bold text-slate-600">
                                        {{ showDocumentChecklist ? 'Hide' : 'Review' }}
                                        <i :class="['fa-solid text-slate-400', showDocumentChecklist ? 'fa-chevron-up' : 'fa-chevron-down']" aria-hidden="true"></i>
                                    </span>
                                </button>

                                <div v-if="showDocumentChecklist">
                                <div class="mt-4 flex flex-wrap gap-2 border-t border-slate-200 pt-4">
                                    <button
                                        type="button"
                                        class="rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-bold text-slate-600 transition hover:bg-slate-100"
                                        @click="selectCommonRequirements"
                                    >
                                        Use common set
                                    </button>
                                    <button
                                        type="button"
                                        class="rounded-md border border-rose-200 bg-white px-3 py-1.5 text-xs font-bold text-rose-700 transition hover:bg-rose-50"
                                        @click="clearRequirements"
                                    >
                                        Clear all
                                    </button>
                                </div>

                                <div class="mt-4 overflow-hidden rounded-lg border border-slate-200 bg-white">
                                    <div
                                        v-for="requirement in documentRequirementOptions"
                                        :key="requirement"
                                        class="grid gap-3 border-b border-slate-200 p-3 last:border-b-0 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center"
                                    >
                                        <div class="flex min-w-0 items-center gap-3">
                                            <span :class="[
                                                'grid h-8 w-8 shrink-0 place-items-center rounded-md text-xs',
                                                isRequirementSelected(requirement)
                                                    ? 'bg-slate-950 text-white'
                                                    : isOptionalRequirementSelected(requirement)
                                                        ? 'bg-amber-100 text-amber-800'
                                                        : 'bg-slate-100 text-slate-400',
                                            ]">
                                                <i class="fa-solid fa-file-lines" aria-hidden="true"></i>
                                            </span>
                                            <div class="min-w-0">
                                                <p class="truncate text-sm font-semibold text-slate-900">{{ requirement }}</p>
                                                <p class="mt-0.5 text-[11px] font-semibold text-slate-400">
                                                    {{ isRequirementSelected(requirement) ? 'Needed before submission' : isOptionalRequirementSelected(requirement) ? 'May support the review' : 'Not requested' }}
                                                </p>
                                            </div>
                                        </div>
                                        <div class="grid grid-cols-3 overflow-hidden rounded-md border border-slate-200 bg-white text-[11px] font-bold sm:w-[17rem]">
                                            <button
                                                type="button"
                                                :class="['px-2 py-2 transition', isRequirementSelected(requirement) ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100']"
                                                @click="setRequirementLevel(requirement, 'required')"
                                            >
                                                Required
                                            </button>
                                            <button
                                                type="button"
                                                :class="['border-x border-slate-200 px-2 py-2 transition', isOptionalRequirementSelected(requirement) ? 'bg-amber-100 text-amber-900' : 'text-slate-600 hover:bg-slate-100']"
                                                @click="setRequirementLevel(requirement, 'optional')"
                                            >
                                                Supporting
                                            </button>
                                            <button
                                                type="button"
                                                :class="['px-2 py-2 transition', !isRequirementSelected(requirement) && !isOptionalRequirementSelected(requirement) ? 'bg-slate-100 text-slate-900' : 'text-slate-600 hover:bg-slate-100']"
                                                @click="setRequirementLevel(requirement, 'none')"
                                            >
                                                Not used
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="mt-4 grid gap-4">
                                    <div :class="fieldCardClass">
                                        <label :class="labelClass" for="scholarship-custom-requirements">Other required documents</label>
                                        <textarea
                                            id="scholarship-custom-requirements"
                                            v-model="scholarshipForm.customRequirements"
                                            rows="3"
                                            maxlength="2000"
                                            placeholder="One required document per line"
                                            :class="inputClass"
                                        ></textarea>
                                        <p class="mt-2 text-xs leading-5 text-slate-500">Applicants upload these before pre-screening can be submitted.</p>
                                    </div>
                                    <div :class="fieldCardClass">
                                        <label :class="labelClass" for="scholarship-custom-optional-requirements">Other supporting documents</label>
                                        <textarea
                                            id="scholarship-custom-optional-requirements"
                                            v-model="scholarshipForm.customOptionalRequirements"
                                            rows="3"
                                            maxlength="2000"
                                            placeholder="One optional supporting document per line"
                                            :class="inputClass"
                                        ></textarea>
                                        <p class="mt-2 text-xs leading-5 text-slate-500">These may strengthen or clarify an application but never block submission.</p>
                                    </div>
                                </div>
                                </div>
                                </template>
                                </div>

                                <section v-show="activeFormSubsection.application === 'questions'">
                                    <div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                                        <div>
                                            <div class="flex flex-wrap items-center gap-2">
                                                <p class="text-base font-bold text-slate-950">Short applicant questions</p>
                                                <span class="rounded bg-slate-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.12em] text-slate-500">Optional</span>
                                            </div>
                                            <p class="mt-1 max-w-3xl text-xs leading-5 text-slate-500">
                                                Ask only for program-specific context that is not already in the applicant profile or document list. Applicants answer before submission.
                                            </p>
                                        </div>
                                        <button
                                            type="button"
                                            class="inline-flex w-fit shrink-0 items-center gap-2 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
                                            :disabled="scholarshipForm.applicationQuestions.length >= 5"
                                            @click="addApplicationQuestion"
                                        >
                                            <i class="fa-solid fa-plus" aria-hidden="true"></i>
                                            Add question
                                        </button>
                                    </div>

                                    <div v-if="scholarshipForm.applicationQuestions.length" class="mt-4 divide-y divide-slate-200 overflow-hidden rounded-md border border-slate-200 bg-white">
                                        <article
                                            v-for="(question, index) in scholarshipForm.applicationQuestions"
                                            :key="question.id"
                                            class="grid gap-3 p-4 md:grid-cols-[2rem_minmax(0,1fr)_auto] md:items-start"
                                        >
                                            <span class="grid h-8 w-8 place-items-center rounded-md bg-slate-950 text-xs font-bold text-white">{{ index + 1 }}</span>
                                            <div>
                                                <label :for="`application-question-${index}`" class="sr-only">Applicant question {{ index + 1 }}</label>
                                                <input
                                                    :id="`application-question-${index}`"
                                                    v-model="question.prompt"
                                                    type="text"
                                                    maxlength="300"
                                                    placeholder="Example: Briefly explain why this support would help your studies."
                                                    :class="inputClass"
                                                >
                                                <label class="mt-2 inline-flex cursor-pointer items-center gap-2 text-xs font-semibold text-slate-600">
                                                    <input v-model="question.required" type="checkbox" class="h-4 w-4 rounded border-slate-300 text-slate-900 focus:ring-slate-900">
                                                    Applicant must answer
                                                </label>
                                            </div>
                                            <button
                                                type="button"
                                                class="inline-flex h-10 w-fit items-center justify-center gap-2 rounded-md border border-rose-200 bg-white px-3 text-xs font-bold text-rose-700 transition hover:bg-rose-50"
                                                @click="removeApplicationQuestion(index)"
                                            >
                                                <i class="fa-solid fa-trash-can" aria-hidden="true"></i>
                                                Remove
                                            </button>
                                        </article>
                                    </div>
                                    <div v-else class="mt-4 rounded-md border border-dashed border-slate-300 bg-slate-50 px-4 py-3 text-xs leading-5 text-slate-500">
                                        No extra questions. The standard applicant profile and selected files will be used for review.
                                    </div>
                                    <p class="mt-2 text-right text-[11px] font-semibold text-slate-400">{{ scholarshipForm.applicationQuestions.length }} of 5 questions</p>
                                </section>

                                <section v-show="activeFormSubsection.application === 'handoff'" class="overflow-hidden rounded-lg border border-slate-200 bg-white">
                                    <div class="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 bg-slate-50 p-4 sm:p-5">
                                        <div class="flex items-start gap-3">
                                            <span class="grid h-10 w-10 shrink-0 place-items-center rounded-md bg-amber-100 text-amber-800">
                                                <i class="fa-solid fa-arrow-right-to-bracket" aria-hidden="true"></i>
                                            </span>
                                            <div>
                                                <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">After pre-screening</p>
                                                <h4 class="mt-1 text-base font-bold text-slate-950">Formal application</h4>
                                                <p class="mt-1 max-w-2xl text-xs leading-5 text-slate-500">
                                                    Tell qualified applicants how to continue with your organization and what documents to prepare.
                                                </p>
                                            </div>
                                        </div>
                                        <span class="rounded-md bg-white px-3 py-1.5 text-xs font-bold text-slate-600 ring-1 ring-slate-200">
                                            Shown after qualification
                                        </span>
                                    </div>

                                    <div class="space-y-4 p-4 sm:p-5">
                                        <div>
                                            <label :class="labelClass">
                                                How applicants continue
                                                <span :class="requiredHintClass">Required</span>
                                            </label>
                                            <p class="mb-3 text-xs leading-5 text-slate-500">Choose the method your organization uses for the formal application.</p>
                                            <div id="scholarship-handoff-mode" class="grid gap-2 md:grid-cols-3" role="radiogroup" aria-label="Formal application continuation method" tabindex="-1">
                                                <label
                                                    v-for="option in handoffModeOptions"
                                                    :key="option.value"
                                                    :class="[
                                                        'flex cursor-pointer items-start gap-3 rounded-md border p-3 transition',
                                                        scholarshipForm.handoffMode === option.value
                                                            ? 'border-amber-400 bg-amber-50 text-slate-950'
                                                            : 'border-slate-200 bg-white text-slate-800 hover:border-slate-400',
                                                    ]"
                                                >
                                                    <input v-model="scholarshipForm.handoffMode" type="radio" :value="option.value" class="sr-only">
                                                    <span :class="['grid h-8 w-8 shrink-0 place-items-center rounded-md', scholarshipForm.handoffMode === option.value ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-600']">
                                                        <i :class="option.icon" aria-hidden="true"></i>
                                                    </span>
                                                    <span>
                                                        <span class="block text-sm font-bold">{{ option.label }}</span>
                                                        <span class="mt-1 block text-xs leading-5 text-slate-500">{{ option.detail }}</span>
                                                    </span>
                                                </label>
                                            </div>
                                        </div>

                                        <div class="rounded-md border border-slate-200 bg-slate-50 p-4">
                                            <div class="space-y-4">
                                                <div :class="fieldStackClass">
                                                    <label :class="labelClass" for="scholarship-handoff-deadline">Formal application deadline</label>
                                                    <input
                                                        id="scholarship-handoff-deadline"
                                                        v-model="scholarshipForm.handoffDeadline"
                                                        type="date"
                                                        :min="scholarshipForm.deadline || todayDate"
                                                        :class="inputClass"
                                                    >
                                                    <p class="mt-2 text-xs leading-5 text-slate-500">Optional when each applicant receives a separate deadline.</p>
                                                </div>

                                                <div :class="fieldCardClass">
                                                <template v-if="scholarshipForm.handoffMode === 'onsite'">
                                                    <div class="flex flex-wrap items-center justify-between gap-2">
                                                        <label :class="labelClass">
                                                            Where applicants should go
                                                            <span :class="requiredHintClass">Required</span>
                                                        </label>
                                                        <div class="flex flex-wrap gap-2">
                                                            <button
                                                                v-if="hasProviderAddress"
                                                                type="button"
                                                                class="rounded-md bg-white px-2.5 py-1.5 text-[11px] font-bold text-sky-700 ring-1 ring-slate-200 hover:bg-sky-50"
                                                                @click="useProviderAddressForHandoff"
                                                            >
                                                                Use provider address
                                                            </button>
                                                            <button type="button" class="rounded-md bg-white px-2.5 py-1.5 text-[11px] font-bold text-sky-700 ring-1 ring-slate-200 hover:bg-sky-50" @click="useProgramLocationForHandoff">
                                                                Use program address
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <div class="space-y-3">
                                                        <div>
                                                            <label class="sr-only" for="scholarship-handoff-location-name">Office or venue</label>
                                                            <input
                                                                id="scholarship-handoff-location-name"
                                                                v-model="scholarshipForm.handoffLocationName"
                                                                type="text"
                                                                maxlength="255"
                                                                placeholder="Office or venue"
                                                                :class="inputClass"
                                                            >
                                                        </div>
                                                        <div>
                                                            <label class="sr-only" for="scholarship-handoff-location-address">Complete address</label>
                                                            <input
                                                                id="scholarship-handoff-location-address"
                                                                v-model="scholarshipForm.handoffLocationAddress"
                                                                type="text"
                                                                maxlength="500"
                                                                placeholder="Street, barangay, city, and province"
                                                                :class="inputClass"
                                                            >
                                                        </div>
                                                    </div>
                                                </template>

                                                <template v-else-if="scholarshipForm.handoffMode === 'online'">
                                                    <label :class="labelClass" for="scholarship-handoff-url">
                                                        Official continuation link
                                                        <span :class="requiredHintClass">Required</span>
                                                    </label>
                                                    <input
                                                        id="scholarship-handoff-url"
                                                        v-model="scholarshipForm.handoffUrl"
                                                        type="url"
                                                        maxlength="2048"
                                                        placeholder="https://provider.example.org/formal-application"
                                                        :class="inputClass"
                                                    >
                                                    <p class="mt-2 text-xs leading-5 text-slate-500">Use a provider-controlled application or scheduling page.</p>
                                                </template>

                                                <template v-else>
                                                    <label :class="labelClass">How applicants receive the next step</label>
                                                    <div class="flex items-start gap-3 rounded-md border border-slate-200 bg-white p-3">
                                                        <span class="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-white text-slate-700 ring-1 ring-slate-200">
                                                            <i class="fa-solid fa-address-card" aria-hidden="true"></i>
                                                        </span>
                                                        <p class="text-xs leading-5 text-slate-600">Your team contacts qualified applicants using the official email or phone number listed in this program.</p>
                                                    </div>
                                                </template>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="space-y-3">
                                            <div :class="[fieldStackClass, 'rounded-md border border-slate-200 bg-slate-50 p-4']">
                                                <label :class="labelClass" for="scholarship-handoff-instructions">
                                                    Instructions for qualified applicants
                                                    <span :class="requiredHintClass">Required</span>
                                                </label>
                                                <textarea
                                                    id="scholarship-handoff-instructions"
                                                    v-model="scholarshipForm.handoffInstructions"
                                                    rows="4"
                                                    maxlength="3000"
                                                    placeholder="Explain the first action, who to contact, and what the applicant should expect"
                                                    :class="inputClass"
                                                ></textarea>
                                                <p class="mt-2 text-xs leading-5 text-slate-500">Activity schedules are announced separately.</p>
                                            </div>

                                            <div :class="[fieldStackClass, 'rounded-md border border-slate-200 bg-slate-50 p-4']">
                                                <label :class="labelClass" for="scholarship-post-qualification-requirements">
                                                    Documents to bring or submit
                                                    <span :class="requiredHintClass">Required</span>
                                                </label>
                                                <textarea
                                                    id="scholarship-post-qualification-requirements"
                                                    v-model="scholarshipForm.postQualificationRequirements"
                                                    rows="4"
                                                    maxlength="5000"
                                                    placeholder="One document per line"
                                                    :class="inputClass"
                                                ></textarea>
                                                <p class="mt-2 text-xs leading-5 text-slate-500">List original or provider-specific documents requested after portal qualification.</p>
                                            </div>
                                        </div>
                                    </div>
                                </section>

                                <section v-show="activeFormSubsection.application === 'expectations'" class="overflow-hidden rounded-lg border border-slate-200 bg-white">
                                    <div class="border-b border-slate-200 bg-slate-50 p-4 sm:p-5">
                                        <div class="flex items-start gap-3">
                                            <span class="grid h-10 w-10 shrink-0 place-items-center rounded-md bg-white text-amber-700 ring-1 ring-slate-200">
                                                <i class="fa-solid fa-handshake" aria-hidden="true"></i>
                                            </span>
                                            <div>
                                                <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">Recipient terms</p>
                                                <p class="mt-1 text-base font-bold text-slate-950">Set clear expectations before applicants continue</p>
                                                <p class="mt-1 max-w-3xl text-xs leading-5 text-slate-500">
                                                    Explain what recipients must do, how long it applies, what happens if it is not completed, and how exceptions are handled.
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="border-b border-slate-200 p-4 sm:p-5">
                                        <div class="max-w-3xl">
                                            <label :class="labelClass" for="scholarship-commitment-option">
                                                Expected recipient contribution
                                                <span :class="requiredHintClass">Required</span>
                                            </label>
                                            <select
                                                id="scholarship-commitment-option"
                                                v-model="selectedCommitmentOption"
                                                :class="inputClass"
                                                @change="applySelectedCommitment"
                                            >
                                                <option v-for="option in commitmentOptions" :key="option.value" :value="option.value">
                                                    {{ option.label }}
                                                </option>
                                            </select>
                                            <p class="mt-2 text-xs leading-5 text-slate-500">Choose the closest option. Select a custom preview when your requirement does not fit the presets.</p>
                                        </div>
                                    </div>

                                    <div class="p-4 sm:p-5">
                                        <div v-if="selectedCommitmentOption === 'provider_briefing'" class="flex items-start gap-3 rounded-md border border-amber-200 bg-amber-50 px-4 py-3">
                                            <span class="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-white/70 text-amber-700"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i></span>
                                            <div>
                                                <p class="text-sm font-bold text-amber-950">Add the terms before publishing</p>
                                                <p class="mt-1 text-xs leading-5 text-amber-900">Applicants and administrators need to review the expected contribution before the program can be assessed fairly.</p>
                                            </div>
                                        </div>

                                        <div v-else-if="selectedCommitmentOption === 'none'" class="flex items-start gap-3 rounded-md border border-emerald-200 bg-emerald-50 px-4 py-3">
                                            <span class="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-white/70 text-emerald-700"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></span>
                                            <div>
                                                <p class="text-sm font-bold text-emerald-950">No contribution expected from recipients</p>
                                                <p class="mt-1 text-xs leading-5 text-emerald-900">Applicants will see that no service, activity, report, or other commitment is required in return for the support.</p>
                                            </div>
                                        </div>

                                        <template v-else>
                                            <div class="rounded-md border border-slate-200 bg-slate-50 p-4">
                                                <div class="flex items-start gap-3">
                                                    <span class="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-white text-slate-700 ring-1 ring-slate-200"><i class="fa-solid fa-eye" aria-hidden="true"></i></span>
                                                    <div class="min-w-0 flex-1">
                                                        <label :class="labelClass" for="scholarship-agreement-responsibilities">
                                                            Exact recipient responsibilities
                                                            <span :class="requiredHintClass">Required</span>
                                                        </label>
                                                        <textarea
                                                            id="scholarship-agreement-responsibilities"
                                                            v-model="scholarshipForm.recipientAgreement.responsibilities"
                                                            rows="4"
                                                            maxlength="2000"
                                                            placeholder="List every action the recipient must complete, including attendance, grade maintenance, reports, or service duties."
                                                            :class="inputClass"
                                                            @input="applyCustomCommitment"
                                                        ></textarea>
                                                        <p class="mt-1.5 text-xs leading-5 text-slate-500">Use definite terms. Avoid wording such as “may be required” or “the provider will explain later.”</p>
                                                    </div>
                                                </div>
                                            </div>

                                            <button
                                                type="button"
                                                class="mt-4 flex w-full items-center justify-between gap-4 rounded-md border border-slate-200 bg-white p-4 text-left transition hover:border-slate-300"
                                                :aria-expanded="showRecipientReleaseDetails"
                                                @click="showRecipientReleaseDetails = !showRecipientReleaseDetails"
                                            >
                                                <span>
                                                    <span class="block text-sm font-bold text-slate-950">Release and proof details</span>
                                                    <span class="mt-1 block text-xs text-slate-500">Proof, benefit release conditions, and duration</span>
                                                </span>
                                                <span :class="['shrink-0 rounded-md px-2.5 py-1.5 text-xs font-bold', recipientReleaseDetailsReady ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-900']">
                                                    {{ recipientReleaseDetailsReady ? 'Complete' : 'Needs details' }}
                                                </span>
                                            </button>

                                            <div v-if="showRecipientReleaseDetails" class="mt-3 overflow-hidden rounded-md border border-slate-200 bg-white">
                                                <div class="grid gap-3 border-b border-slate-200 p-4 sm:grid-cols-[2rem_minmax(0,1fr)]">
                                                    <span class="grid h-8 w-8 place-items-center rounded-md bg-slate-100 text-xs font-bold text-slate-700">1</span>
                                                    <div :class="fieldStackClass">
                                                        <label :class="labelClass" for="scholarship-agreement-evidence">
                                                            Proof the recipient must submit
                                                            <span :class="requiredHintClass">Required</span>
                                                        </label>
                                                        <textarea
                                                            id="scholarship-agreement-evidence"
                                                            v-model="scholarshipForm.recipientAgreement.required_evidence"
                                                            rows="3"
                                                            maxlength="1500"
                                                            placeholder="Example: Official report card each semester and signed attendance confirmation after orientation."
                                                            :class="inputClass"
                                                        ></textarea>
                                                    </div>
                                                </div>
                                                <div class="grid gap-3 border-b border-slate-200 p-4 sm:grid-cols-[2rem_minmax(0,1fr)]">
                                                    <span class="grid h-8 w-8 place-items-center rounded-md bg-slate-100 text-xs font-bold text-slate-700">2</span>
                                                    <div :class="fieldStackClass">
                                                        <label :class="labelClass" for="scholarship-agreement-release-conditions">
                                                            Conditions for receiving the benefits
                                                            <span :class="requiredHintClass">Required</span>
                                                        </label>
                                                        <textarea
                                                            id="scholarship-agreement-release-conditions"
                                                            v-model="scholarshipForm.recipientAgreement.release_conditions"
                                                            rows="3"
                                                            maxlength="1500"
                                                            placeholder="Explain when support is released and what must be verified before each release."
                                                            :class="inputClass"
                                                        ></textarea>
                                                    </div>
                                                </div>
                                                <div class="grid gap-3 p-4 sm:grid-cols-[2rem_minmax(0,1fr)]">
                                                    <span class="grid h-8 w-8 place-items-center rounded-md bg-slate-100 text-xs font-bold text-slate-700">3</span>
                                                    <div :class="fieldStackClass">
                                                        <label :class="labelClass" for="scholarship-agreement-duration">
                                                            How long the expectation applies
                                                            <span :class="requiredHintClass">Required</span>
                                                        </label>
                                                        <textarea
                                                            id="scholarship-agreement-duration"
                                                            v-model="scholarshipForm.recipientAgreement.duration"
                                                            rows="3"
                                                            maxlength="500"
                                                            placeholder="Example: One activity before the end of the current school year."
                                                            :class="inputClass"
                                                        ></textarea>
                                                    </div>
                                                </div>
                                            </div>

                                            <button
                                                type="button"
                                                class="mt-3 flex w-full items-center justify-between gap-4 rounded-md border border-slate-200 bg-white p-4 text-left transition hover:border-slate-300"
                                                :aria-expanded="showRecipientExceptionDetails"
                                                @click="showRecipientExceptionDetails = !showRecipientExceptionDetails"
                                            >
                                                <span>
                                                    <span class="block text-sm font-bold text-slate-950">Exceptions and consequences</span>
                                                    <span class="mt-1 block text-xs text-slate-500">Non-compliance, adjustments, and withdrawal</span>
                                                </span>
                                                <span :class="['shrink-0 rounded-md px-2.5 py-1.5 text-xs font-bold', recipientExceptionDetailsReady ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-900']">
                                                    {{ recipientExceptionDetailsReady ? 'Complete' : 'Needs details' }}
                                                </span>
                                            </button>

                                            <div v-if="showRecipientExceptionDetails" class="mt-3 overflow-hidden rounded-md border border-slate-200 bg-white">
                                                <div class="grid gap-3 border-b border-slate-200 p-4 sm:grid-cols-[2rem_minmax(0,1fr)]">
                                                    <span class="grid h-8 w-8 place-items-center rounded-md bg-slate-100 text-xs font-bold text-slate-700">4</span>
                                                    <div :class="fieldStackClass">
                                                        <label :class="labelClass" for="scholarship-agreement-consequence">
                                                            What happens if it is not completed
                                                            <span :class="requiredHintClass">Required</span>
                                                        </label>
                                                        <textarea
                                                            id="scholarship-agreement-consequence"
                                                            v-model="scholarshipForm.recipientAgreement.noncompliance_consequence"
                                                            rows="3"
                                                            maxlength="1000"
                                                            placeholder="Explain what may happen and whether the provider reviews the circumstances first."
                                                            :class="inputClass"
                                                        ></textarea>
                                                    </div>
                                                </div>
                                                <div class="grid gap-3 p-4 sm:grid-cols-[2rem_minmax(0,1fr)]">
                                                    <span class="grid h-8 w-8 place-items-center rounded-md bg-slate-100 text-xs font-bold text-slate-700">5</span>
                                                    <div :class="fieldStackClass">
                                                        <label :class="labelClass" for="scholarship-agreement-exit">
                                                            Exception, adjustment, or withdrawal process
                                                            <span :class="requiredHintClass">Required</span>
                                                        </label>
                                                        <textarea
                                                            id="scholarship-agreement-exit"
                                                            v-model="scholarshipForm.recipientAgreement.exit_or_exception_process"
                                                            rows="3"
                                                            maxlength="1000"
                                                            placeholder="Explain who the recipient contacts if illness, transfer, withdrawal, or another circumstance prevents completion."
                                                            :class="inputClass"
                                                        ></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </template>

                                        <div v-if="selectedCommitmentOption === 'none'" class="mt-4 overflow-hidden rounded-md border border-slate-200 bg-white p-4">
                                            <label :class="labelClass" for="scholarship-agreement-release-conditions-none">
                                                Conditions for receiving the benefits
                                                <span :class="requiredHintClass">Required</span>
                                            </label>
                                            <textarea
                                                id="scholarship-agreement-release-conditions-none"
                                                v-model="scholarshipForm.recipientAgreement.release_conditions"
                                                rows="3"
                                                maxlength="1500"
                                                placeholder="Explain when support is released and what identity, enrollment, or receipt verification is required."
                                                :class="inputClass"
                                            ></textarea>
                                            <p class="mt-1.5 text-xs leading-5 text-slate-500">This does not create a recipient contribution. It only explains how the listed support is released.</p>
                                        </div>
                                    </div>
                                </section>
                            </fieldset>

                            <fieldset v-show="activeFormSection === 'selection' && activeFormSubsection.selection === 'scoring'" :class="sectionCardClass">
                                <div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                                    <div>
                                        <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">Review scoring</p>
                                        <p class="mt-1 text-base font-bold text-slate-950">Set a 100% review rubric</p>
                                    </div>
                                    <div class="flex flex-wrap items-center gap-2">
                                        <span :class="['rounded-md px-3 py-2 text-xs font-bold', rubricWeightTotal === 100 ? 'bg-slate-950 text-white' : 'bg-amber-100 text-amber-800']">
                                            {{ rubricWeightTotal === 100 ? 'Ready' : 'Needs adjustment' }} · {{ rubricWeightTotal }}%
                                        </span>
                                        <button
                                            type="button"
                                            class="rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-100"
                                            @click="customizeRubric = !customizeRubric"
                                        >
                                            {{ customizeRubric ? 'Finish editing' : 'Edit rubric' }}
                                        </button>
                                    </div>
                                </div>

                                <div v-if="!customizeRubric" class="mt-4 overflow-hidden rounded-lg border border-slate-200 bg-white">
                                    <div
                                        v-for="(criterion, index) in scholarshipForm.reviewRubric"
                                        :key="criterion.key"
                                        class="grid gap-2 border-b border-slate-200 px-4 py-3 last:border-b-0 sm:grid-cols-[2rem_minmax(0,1fr)_auto] sm:items-center"
                                    >
                                        <span class="grid h-7 w-7 place-items-center rounded-md bg-slate-100 text-[11px] font-bold text-slate-600">{{ index + 1 }}</span>
                                        <div class="min-w-0">
                                            <p class="text-sm font-bold text-slate-950">{{ criterion.label || 'Unnamed criterion' }}</p>
                                        </div>
                                        <span class="w-fit rounded-md bg-amber-100 px-2.5 py-1 text-xs font-bold text-amber-900">{{ criterion.weight }}%</span>
                                    </div>
                                </div>

                                <div v-if="customizeRubric" class="mt-4">
                                    <div class="mb-3 flex flex-wrap items-center gap-2">
                                        <button
                                            type="button"
                                            class="rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-100"
                                            @click="resetReviewRubric"
                                        >
                                            Restore defaults
                                        </button>
                                        <button
                                            type="button"
                                            :disabled="scholarshipForm.reviewRubric.length >= 6"
                                            class="rounded-md bg-slate-950 px-3 py-2 text-xs font-bold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-50"
                                            @click="addReviewCriterion"
                                        >
                                            <i class="fa-solid fa-plus mr-1" aria-hidden="true"></i>
                                            Add criterion
                                        </button>
                                    </div>
                                    <div class="overflow-hidden rounded-lg border border-slate-200 bg-white">
                                    <div
                                        v-for="(criterion, index) in scholarshipForm.reviewRubric"
                                        :key="criterion.key"
                                        class="grid gap-3 border-b border-slate-200 p-4 last:border-b-0 lg:grid-cols-[2rem_minmax(0,1fr)_7rem_auto]"
                                    >
                                        <span class="grid h-8 w-8 place-items-center rounded-md bg-slate-100 text-xs font-bold text-slate-600">{{ index + 1 }}</span>
                                        <div class="min-w-0">
                                            <label :class="labelClass" :for="`rubric-label-${criterion.key}`">
                                                Criterion
                                            </label>
                                            <input
                                                :id="`rubric-label-${criterion.key}`"
                                                v-model="criterion.label"
                                                type="text"
                                                maxlength="100"
                                                placeholder="Example: Community involvement"
                                                :class="inputClass"
                                            >
                                            <textarea
                                                v-model="criterion.guidance"
                                                rows="2"
                                                maxlength="300"
                                                placeholder="Briefly explain what reviewers should check."
                                                :class="['mt-2', inputClass]"
                                            ></textarea>
                                        </div>
                                        <div>
                                            <label :class="labelClass" :for="`rubric-weight-${criterion.key}`">
                                                Weight %
                                            </label>
                                            <input
                                                :id="`rubric-weight-${criterion.key}`"
                                                v-model.number="criterion.weight"
                                                type="number"
                                                min="1"
                                                max="100"
                                                :class="inputClass"
                                            >
                                        </div>
                                        <button
                                            type="button"
                                            :disabled="scholarshipForm.reviewRubric.length === 1"
                                            class="grid h-10 w-10 place-items-center self-start rounded-md border border-rose-200 bg-rose-50 text-rose-700 transition hover:bg-rose-100 disabled:cursor-not-allowed disabled:opacity-40 lg:mt-7"
                                            title="Remove criterion"
                                            @click="removeReviewCriterion(index)"
                                        >
                                            <i class="fa-solid fa-trash-can" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                    </div>
                                </div>

                                <p v-if="customizeRubric && rubricWeightTotal !== 100" class="mt-3 text-xs font-semibold text-amber-800">
                                    Adjust the weights until they total exactly 100%.
                                </p>
                            </fieldset>

                        <section v-show="activeFormSection === 'review'" :class="['mt-6', sectionCardClass]">
                            <div class="mb-4 flex items-center justify-between gap-3">
                                <div>
                                    <p class="text-xs font-bold uppercase tracking-[0.18em] text-amber-700">Final check</p>
                                    <h4 class="mt-1 text-base font-bold text-slate-950">Review before sending</h4>
                                </div>
                                <span :class="['w-fit shrink-0 rounded-md px-3 py-1.5 text-xs font-bold', missingProgramReadinessItems.length ? 'bg-amber-100 text-amber-900' : 'bg-slate-950 text-white']">
                                    {{ missingProgramReadinessItems.length ? `${missingProgramReadinessItems.length} to finish` : 'Ready for review' }}
                                </span>
                            </div>

                            <div class="overflow-hidden rounded-lg border border-slate-200 bg-white">
                                <div class="flex items-start gap-4 p-4 sm:p-5">
                                    <img
                                        :src="scholarshipImagePreview"
                                        alt="Program logo"
                                        class="h-12 w-12 shrink-0 rounded-md bg-white object-contain p-1.5 ring-1 ring-slate-200"
                                    >
                                    <div class="min-w-0 flex-1">
                                        <p class="text-[10px] font-bold uppercase tracking-[0.14em] text-amber-700">{{ scholarshipForm.category || 'Scholarship program' }}</p>
                                        <h4 class="mt-1 truncate text-lg font-bold text-slate-950">{{ scholarshipForm.title || 'Untitled scholarship' }}</h4>
                                        <p class="mt-1 line-clamp-2 text-sm leading-5 text-slate-500">{{ scholarshipForm.description || 'Add a clear program description.' }}</p>
                                    </div>
                                </div>
                                <dl class="grid grid-cols-2 border-t border-slate-200 bg-slate-50 sm:grid-cols-4">
                                    <div class="border-r border-slate-200 p-3">
                                        <dt class="text-[10px] font-bold uppercase tracking-wider text-slate-400">Deadline</dt>
                                        <dd class="mt-1 text-xs font-bold text-slate-800">{{ formatPreviewDate(scholarshipForm.deadline) }}</dd>
                                    </div>
                                    <div class="border-r border-slate-200 p-3">
                                        <dt class="text-[10px] font-bold uppercase tracking-wider text-slate-400">Support</dt>
                                        <dd class="mt-1 text-xs font-bold text-slate-800">{{ scholarshipForm.benefits.length }} benefit{{ scholarshipForm.benefits.length === 1 ? '' : 's' }}</dd>
                                    </div>
                                    <div class="border-r border-t border-slate-200 p-3 sm:border-t-0">
                                        <dt class="text-[10px] font-bold uppercase tracking-wider text-slate-400">Application</dt>
                                        <dd class="mt-1 text-xs font-bold text-slate-800">{{ applicationModeLabel(scholarshipForm.applicationMode) }}</dd>
                                    </div>
                                    <div class="border-t border-slate-200 p-3 sm:border-t-0">
                                        <dt class="text-[10px] font-bold uppercase tracking-wider text-slate-400">Selection</dt>
                                        <dd class="mt-1 text-xs font-bold text-slate-800">{{ scholarshipForm.selectionStages.length }} stages</dd>
                                    </div>
                                </dl>
                                <button
                                    type="button"
                                    class="flex w-full items-center justify-between gap-3 border-t border-slate-200 px-4 py-3 text-left text-xs font-bold text-slate-700 transition hover:bg-slate-50"
                                    :aria-expanded="showProgramReviewSummary"
                                    @click="showProgramReviewSummary = !showProgramReviewSummary"
                                >
                                    <span>{{ showProgramReviewSummary ? 'Hide applicant-facing summary' : 'Review applicant-facing summary' }}</span>
                                    <i :class="['fa-solid text-slate-400', showProgramReviewSummary ? 'fa-chevron-up' : 'fa-chevron-down']" aria-hidden="true"></i>
                                </button>
                            </div>

                            <div v-if="showProgramReviewSummary" class="mt-4 overflow-hidden rounded-lg border border-slate-200 bg-slate-50">
                                <div class="border-b border-slate-200 bg-white p-4 sm:p-5">
                                    <div class="flex min-w-0 items-start gap-4">
                                        <img
                                            :src="scholarshipImagePreview"
                                            alt="Program logo"
                                            class="h-14 w-14 shrink-0 rounded-md bg-white object-contain p-2 ring-1 ring-slate-200"
                                        >
                                        <div class="min-w-0">
                                            <p class="text-xs font-bold uppercase tracking-wider text-amber-700">
                                                {{ scholarshipForm.category || 'Scholarship program' }}
                                            </p>
                                            <h4 class="mt-1 font-display text-xl font-bold leading-tight text-slate-950">
                                                {{ scholarshipForm.title || 'Untitled scholarship' }}
                                            </h4>
                                            <p class="mt-2 line-clamp-3 text-sm leading-6 text-slate-600">
                                                {{ scholarshipForm.description || 'Add a clear program description.' }}
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <div
                                    v-if="providerObjectiveDetails(scholarshipForm.providerObjectives).length || scholarshipForm.providerObjectiveNotes"
                                    class="border-t border-slate-200 bg-amber-50/60 p-4 sm:p-5"
                                >
                                    <p class="text-xs font-bold uppercase tracking-wider text-amber-800">Why the provider offers this program</p>
                                    <div v-if="providerObjectiveDetails(scholarshipForm.providerObjectives).length" class="mt-2 flex flex-wrap gap-2">
                                        <span
                                            v-for="objective in providerObjectiveDetails(scholarshipForm.providerObjectives)"
                                            :key="objective.value"
                                            class="rounded-md bg-white px-2.5 py-1 text-xs font-bold text-slate-700 ring-1 ring-slate-200"
                                        >
                                            {{ objective.label }}
                                        </span>
                                    </div>
                                    <p v-if="scholarshipForm.providerObjectiveNotes" class="mt-2 text-sm leading-6 text-slate-600">{{ scholarshipForm.providerObjectiveNotes }}</p>
                                </div>

                                <dl class="grid grid-cols-2 border-b border-slate-200 bg-white sm:grid-cols-4">
                                    <div class="border-r border-slate-200 p-3 last:border-r-0 sm:p-4">
                                        <dt class="text-[10px] font-bold uppercase tracking-wider text-slate-400">Cycle</dt>
                                        <dd class="mt-1 text-sm font-bold text-slate-800">{{ scholarshipForm.programCycle || 'Not specified' }}</dd>
                                    </div>
                                    <div class="border-r border-slate-200 p-3 last:border-r-0 sm:p-4">
                                        <dt class="text-[10px] font-bold uppercase tracking-wider text-slate-400">Opens</dt>
                                        <dd class="mt-1 text-sm font-bold text-slate-800">{{ formatPreviewDate(scholarshipForm.applicationOpensAt, 'On publication') }}</dd>
                                    </div>
                                    <div class="border-r border-t border-slate-200 p-3 last:border-r-0 sm:border-t-0 sm:p-4">
                                        <dt class="text-[10px] font-bold uppercase tracking-wider text-slate-400">Deadline</dt>
                                        <dd class="mt-1 text-sm font-bold text-slate-800">{{ formatPreviewDate(scholarshipForm.deadline) }}</dd>
                                    </div>
                                    <div class="border-t border-slate-200 p-3 sm:border-t-0 sm:p-4">
                                        <dt class="text-[10px] font-bold uppercase tracking-wider text-slate-400">Initial results</dt>
                                        <dd class="mt-1 text-sm font-bold text-slate-800">{{ formatPreviewDate(scholarshipForm.expectedResultsAt) }}</dd>
                                    </div>
                                </dl>

                                <div class="grid border-b border-slate-200 bg-slate-50 sm:grid-cols-2">
                                    <div class="border-b border-slate-200 p-3 sm:border-r sm:border-b-0 sm:p-4">
                                        <p class="text-[10px] font-bold uppercase tracking-wider text-amber-700">Support starts</p>
                                        <p class="mt-1 text-sm font-bold text-slate-800">{{ formatPreviewDate(scholarshipForm.supportStartsAt) }}</p>
                                    </div>
                                    <div class="p-3 sm:p-4">
                                        <p class="text-[10px] font-bold uppercase tracking-wider text-amber-700">Support ends</p>
                                        <p class="mt-1 text-sm font-bold text-slate-800">{{ formatPreviewDate(scholarshipForm.supportEndsAt) }}</p>
                                    </div>
                                </div>

                                <div class="grid gap-4 p-4 sm:grid-cols-2 sm:p-5">
                                    <div>
                                        <p class="text-xs font-bold uppercase tracking-wider text-slate-500">Benefits</p>
                                        <div v-if="scholarshipForm.benefits.length" class="mt-2 grid gap-2">
                                            <div
                                                v-for="benefit in scholarshipForm.benefits.slice(0, 3)"
                                                :key="benefit.type"
                                                class="rounded-md bg-white px-3 py-2 text-sm ring-1 ring-slate-200"
                                            >
                                                <span class="font-bold text-slate-900">{{ benefit.title }}</span>
                                                <span v-if="benefit.duration" class="ml-1 text-slate-500">| {{ benefit.duration }}</span>
                                            </div>
                                            <p v-if="scholarshipForm.benefits.length > 3" class="text-xs font-semibold text-slate-500">
                                                +{{ scholarshipForm.benefits.length - 3 }} more benefit{{ scholarshipForm.benefits.length - 3 === 1 ? '' : 's' }}
                                            </p>
                                        </div>
                                        <p v-else class="mt-2 text-sm text-slate-500">No benefits added yet.</p>
                                    </div>

                                    <div>
                                        <p class="text-xs font-bold uppercase tracking-wider text-slate-500">Who can apply</p>
                                        <p class="mt-2 whitespace-pre-line text-sm leading-6 text-slate-700">
                                            {{ scholarshipForm.eligibility || 'Add an eligibility summary.' }}
                                        </p>
                                        <p class="mt-3 text-xs font-semibold text-slate-500">
                                            {{ applicationModeLabel(scholarshipForm.applicationMode) }}
                                        </p>
                                    </div>
                                </div>

                                <div class="grid gap-4 border-t border-slate-200 bg-white p-4 sm:grid-cols-2 sm:p-5">
                                    <div>
                                        <p class="text-xs font-bold uppercase tracking-wider text-slate-500">Required before submission</p>
                                        <p class="mt-2 text-sm font-semibold text-slate-800">
                                            {{ isProfileReviewOnly ? 'Profile review only' : `${selectedRequirementCount} required document${selectedRequirementCount === 1 ? '' : 's'}` }}
                                        </p>
                                        <p class="mt-1 line-clamp-2 text-xs leading-5 text-slate-500">{{ isProfileReviewOnly ? 'No program files are collected during initial submission.' : (allDocumentRequirements.join(', ') || 'No required documents selected.') }}</p>
                                        <p v-if="scholarshipForm.applicationQuestions.length" class="mt-2 text-xs font-semibold text-slate-700">
                                            {{ scholarshipForm.applicationQuestions.length }} short applicant question{{ scholarshipForm.applicationQuestions.length === 1 ? '' : 's' }}
                                        </p>
                                    </div>
                                    <div>
                                        <p class="text-xs font-bold uppercase tracking-wider text-slate-500">Optional supporting files</p>
                                        <p class="mt-2 text-sm font-semibold text-slate-800">
                                            {{ selectedOptionalRequirementCount }} supporting document{{ selectedOptionalRequirementCount === 1 ? '' : 's' }}
                                        </p>
                                        <p class="mt-1 line-clamp-2 text-xs leading-5 text-slate-500">{{ allOptionalDocumentRequirements.join(', ') || 'No optional supporting files selected.' }}</p>
                                    </div>
                                </div>

                                <div
                                    v-if="scholarshipForm.contactPerson || scholarshipForm.contactDepartment || scholarshipForm.contactEmail || scholarshipForm.contactNumber || scholarshipForm.officialProgramUrl"
                                    class="border-t border-slate-200 bg-white px-4 py-3 text-xs leading-5 text-slate-600 sm:px-5"
                                >
                                    <span class="font-bold text-slate-900">
                                        {{ scholarshipForm.contactDepartment || scholarshipForm.contactPerson || 'Program contact' }}
                                    </span>
                                    <span v-if="scholarshipForm.contactDepartment && scholarshipForm.contactPerson"> | {{ scholarshipForm.contactPerson }}</span>
                                    <span v-if="scholarshipForm.contactEmail"> | {{ scholarshipForm.contactEmail }}</span>
                                    <span v-if="scholarshipForm.contactNumber"> | {{ scholarshipForm.contactNumber }}</span>
                                    <a
                                        v-if="officialProgramPreviewUrl"
                                        :href="officialProgramPreviewUrl"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        class="ml-2 font-bold text-slate-900 underline decoration-amber-400 underline-offset-2"
                                    >Official page</a>
                                </div>
                            </div>

                            <div class="mt-4 overflow-hidden rounded-lg border border-slate-200 bg-white">
                                <div class="flex flex-col gap-3 border-b border-slate-200 bg-slate-50 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
                                    <div>
                                        <p class="text-sm font-bold text-slate-950">Submission readiness</p>
                                        <p class="mt-0.5 text-xs text-slate-500">{{ completedProgramReadinessCount }} of {{ programReadinessItems.length }} required areas are complete.</p>
                                    </div>
                                    <span :class="['w-fit rounded-md px-2.5 py-1.5 text-xs font-bold', missingProgramReadinessItems.length ? 'bg-amber-100 text-amber-900' : 'bg-slate-950 text-white']">
                                        {{ missingProgramReadinessItems.length ? `${missingProgramReadinessItems.length} to finish` : 'Ready for review' }}
                                    </span>
                                </div>

                                <div v-if="missingProgramReadinessItems.length" class="divide-y divide-slate-200">
                                    <button
                                        v-for="item in missingProgramReadinessItems"
                                        :key="item.label"
                                        type="button"
                                        class="flex w-full items-center gap-3 px-4 py-3 text-left transition hover:bg-slate-50"
                                        @click="focusFormField(item.section, readinessFocusTarget(item))"
                                    >
                                        <span class="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-amber-100 text-xs text-amber-800">
                                            <i class="fa-solid fa-exclamation" aria-hidden="true"></i>
                                        </span>
                                        <span class="min-w-0 flex-1">
                                            <span class="block text-sm font-bold text-slate-950">{{ item.label }}</span>
                                            <span class="mt-0.5 block truncate text-xs text-slate-500">{{ item.help }}</span>
                                        </span>
                                        <i class="fa-solid fa-arrow-right mt-2 text-xs text-slate-400" aria-hidden="true"></i>
                                    </button>
                                </div>
                                <div v-else class="flex items-center gap-3 px-4 py-4 text-sm text-slate-700">
                                    <span class="grid h-9 w-9 place-items-center rounded-md bg-slate-950 text-white">
                                        <i class="fa-solid fa-check" aria-hidden="true"></i>
                                    </span>
                                    <div>
                                        <p class="font-bold text-slate-950">Program information is complete</p>
                                        <p class="mt-0.5 text-xs text-slate-500">You can submit it for admin review using the action below.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="mt-4 overflow-hidden rounded-lg border border-slate-200 bg-white">
                                <div class="border-b border-slate-200 bg-slate-50 px-4 py-3">
                                    <p class="text-sm font-bold text-slate-950">Save choice</p>
                                    <p class="mt-0.5 text-xs text-slate-500">Keep working or send the completed program to the admin.</p>
                                </div>
                                <div class="divide-y divide-slate-200">
                                    <label
                                        v-for="option in statusOptions"
                                        :key="option.value"
                                        :class="[
                                            'flex items-center gap-3 px-4 py-3 transition',
                                            option.value === 'rejected' ? 'cursor-not-allowed bg-slate-50 opacity-60' : 'cursor-pointer hover:bg-slate-50',
                                            scholarshipForm.status === option.value ? 'border-l-4 border-l-amber-500 bg-amber-50/50' : 'border-l-4 border-l-transparent',
                                        ]"
                                    >
                                        <input
                                            v-model="scholarshipForm.status"
                                            type="radio"
                                            name="scholarship-status"
                                            :value="option.value"
                                            :disabled="option.value === 'rejected'"
                                            class="sr-only"
                                        >
                                        <span :class="['grid h-9 w-9 shrink-0 place-items-center rounded-md', scholarshipForm.status === option.value ? 'bg-slate-950 text-white' : 'bg-slate-100 text-slate-600']">
                                            <i :class="option.value === 'draft' ? 'fa-solid fa-file-pen' : option.value === 'closed' ? 'fa-solid fa-lock' : option.value === 'published' ? 'fa-solid fa-eye' : 'fa-solid fa-paper-plane'" aria-hidden="true"></i>
                                        </span>
                                        <span class="min-w-0 flex-1">
                                            <span class="block text-sm font-bold text-slate-950">{{ option.label }}</span>
                                            <span class="mt-0.5 block text-xs text-slate-500">{{ option.help }}</span>
                                        </span>
                                        <i v-if="scholarshipForm.status === option.value" class="fa-solid fa-circle-check text-emerald-600" aria-hidden="true"></i>
                                    </label>
                                </div>
                            </div>
                        </section>

                        <div v-show="activeFormSection === 'review'" class="mt-4 rounded-lg border border-slate-200 bg-white p-4">
                            <div class="mb-3">
                                <p class="text-xs font-bold uppercase tracking-[0.14em] text-amber-700">Confirmation</p>
                                <p class="mt-1 text-sm font-bold text-slate-950">
                                    {{ termsRequiredForSave ? 'Confirm the provider terms before continuing' : 'Save and continue later' }}
                                </p>
                            </div>
                            <TermsAgreement
                                v-if="termsRequiredForSave"
                                v-model="scholarshipForm.termsAccepted"
                                context="scholarship"
                            />
                            <p v-else class="rounded-md border border-slate-200 bg-slate-50 px-4 py-3 text-sm leading-6 text-slate-600">
                                Save this draft now and finish it later. Terms are required only for admin review.
                            </p>
                        </div>
                            </div>

                            <div class="sticky bottom-0 z-20 border-t border-slate-200 bg-white/95 p-4 backdrop-blur">
                                <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                                    <div class="min-w-0">
                                        <p class="text-xs font-semibold text-slate-500">
                                            {{ stepNavigationSaves ? 'Your draft saves when you continue.' : 'Final changes save from Review & submit.' }}
                                        </p>
                                    </div>

                                    <div class="flex shrink-0 flex-wrap justify-end gap-2">
                                        <button
                                            type="button"
                                            :disabled="activeFormSectionIndex === 0 || isSaving"
                                            class="rounded-md border border-slate-300 px-3.5 py-2.5 text-sm font-semibold text-slate-700 transition hover:border-slate-400 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
                                            @click="goToPreviousFormSection"
                                        >
                                            Back
                                        </button>
                                        <button
                                            v-if="activeFormSectionIndex < formSections.length - 1"
                                            type="button"
                                            :disabled="isSaving || !canPostScholarships"
                                            class="rounded-md bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-40"
                                            @click="goToNextFormSection"
                                        >
                                            {{ stepNavigationSaves ? 'Save & continue:' : 'Next:' }} {{ formSections[activeFormSectionIndex + 1]?.label }}
                                        </button>
                                        <button
                                            v-if="activeFormSection === 'review'"
                                            type="submit"
                                            :disabled="isSaving || !canPostScholarships"
                                            class="rounded-md bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-70"
                                        >
                                            {{ submitButtonLabel }}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </section>

        <LocationMapModal
            :open="showLocationMap"
            eyebrow="Program location"
            title="Set the program map pin"
            :address="scholarshipFormMapAddress"
            :google-maps-query="scholarshipGoogleMapsAddress"
            :latitude="scholarshipForm.latitude"
            :longitude="scholarshipForm.longitude"
            :marker-text="scholarshipForm.locationName || 'Program location'"
            :location-message="providerLocationMessage"
            :auto-geocode-delay="900"
            picker
            @resolved="handleScholarshipLocationResolved"
            @picked="handleScholarshipLocationPicked"
            @error="handleScholarshipLocationError"
            @close="closeLocationMap"
        />

    </main>
</template>

<script setup>
import StaffTableIdentity from '../../../components/StaffTableIdentity.vue';
import AdminEmptyState from '../components/AdminEmptyState.vue';

defineProps({
    accounts: {
        type: Array,
        default: () => [],
    },
    loading: {
        type: Boolean,
        default: false,
    },
    showIssue: {
        type: Boolean,
        default: false,
    },
    emptyTitle: {
        type: String,
        default: 'No matching accounts',
    },
    recordLink: { type: Function, default: (href) => href },
});

function roleLabel(role) {
    return {
        applicant: 'Applicant',
        provider: 'Provider',
        admin: 'Administrator',
    }[role] ?? 'Account';
}

function roleIcon(role) {
    return {
        applicant: 'fa-solid fa-user-graduate',
        provider: 'fa-solid fa-building-columns',
        admin: 'fa-solid fa-user-shield',
    }[role] ?? 'fa-solid fa-user';
}

function primaryIssue(account) {
    if (account.account_status === 'suspended') return 'Suspended';
    return signInLabel(account, 'No issue');
}

function signInLabel(account, readyLabel = 'Email verified') {
    if (!account.email_verified && account.must_reset_password) return 'Email and password reset pending';
    if (!account.email_verified) return 'Email unverified';
    if (account.must_reset_password) return 'Password reset due';
    return readyLabel;
}

function issueClass(account) {
    if (account.account_status === 'suspended') return 'bg-rose-100 text-rose-800';
    if (!account.email_verified || account.must_reset_password) return 'bg-amber-100 text-amber-900';
    return 'bg-slate-100 text-slate-700';
}
</script>

<template>
    <div v-if="loading" class="px-6 py-14 text-center text-sm font-semibold text-slate-500">
        Loading accounts...
    </div>

    <table v-else-if="accounts.length" class="portal-data-table table-fixed min-w-[56rem]">
        <colgroup><col><col class="w-24"><col class="w-40"><col class="w-28"><col class="w-36"><col class="w-20"></colgroup>
        <thead class="bg-slate-50 text-[10px] font-bold uppercase tracking-[0.15em] text-slate-500">
            <tr>
                <th scope="col" class="border-b border-slate-200 px-5 py-3">Account</th>
                <th scope="col" class="border-b border-slate-200 px-4 py-3">Role</th>
                <th v-if="showIssue" scope="col" class="border-b border-slate-200 px-4 py-3">Needs attention</th>
                <th v-else scope="col" class="border-b border-slate-200 px-4 py-3">Sign-in checks</th>
                <th scope="col" class="border-b border-slate-200 px-4 py-3">Access</th>
                <th scope="col" class="border-b border-slate-200 px-4 py-3">Created</th>
                <th scope="col" class="border-b border-slate-200 px-5 py-3 text-right">Open</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-slate-200 bg-white">
            <tr v-for="account in accounts" :key="account.id" class="align-middle hover:bg-slate-50/70">
                <td class="px-5 py-3.5">
                    <div class="flex min-w-0 items-center gap-3">
                        <StaffTableIdentity :kind="account.role" :src="account.avatar_url" :icon="roleIcon(account.role)" class="h-10 w-10" />
                        <span class="min-w-0">
                            <span class="block break-words text-sm font-bold text-slate-950">{{ account.name }}</span>
                            <span class="mt-0.5 block text-xs text-slate-500 [overflow-wrap:anywhere]">{{ account.email }}</span>
                        </span>
                    </div>
                </td>
                <td class="px-4 py-3.5 text-sm font-semibold text-slate-700">{{ roleLabel(account.role) }}</td>
                <td v-if="showIssue" class="px-4 py-3.5">
                    <span :class="['inline-flex px-2 py-1 text-[10px] font-bold uppercase tracking-wide', issueClass(account)]">{{ primaryIssue(account) }}</span>
                </td>
                <td v-else class="px-4 py-3.5">
                    <span :class="['inline-flex px-2 py-1 text-[10px] font-bold uppercase tracking-wide', account.email_verified && !account.must_reset_password ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-900']">
                        {{ signInLabel(account) }}
                    </span>
                </td>
                <td class="px-4 py-3.5">
                    <span :class="['inline-flex px-2 py-1 text-[10px] font-bold uppercase tracking-wide', account.account_status === 'suspended' ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800']">
                        {{ account.account_status === 'suspended' ? 'Suspended' : 'Active' }}
                    </span>
                </td>
                <td class="px-4 py-3.5 text-sm text-slate-600">{{ account.created_at }}</td>
                <td class="px-5 py-3.5 text-right">
                    <a :href="recordLink(`/admin/workspaces/accounts/${account.id}`)" class="staff-row-action h-10 w-10" :aria-label="`Open ${account.name}`" title="Open account">
                        <i class="fa-solid fa-arrow-right text-xs" aria-hidden="true"></i>
                    </a>
                </td>
            </tr>
        </tbody>
    </table>

    <AdminEmptyState
        v-else
        :title="emptyTitle"
        description="Try another search or filter."
        icon="fa-solid fa-user-check"
    />
</template>

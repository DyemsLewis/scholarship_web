<script setup>
import { staffQueueReturn } from '../../../support/staffQueueState.js';
import { computed, onMounted, ref } from 'vue';
import AdminWorkspaceHeader from '../components/AdminWorkspaceHeader.vue';
import AdminWorkspacePage from '../components/AdminWorkspacePage.vue';
import AdminDialog from '../components/AdminDialog.vue';
import AdminLoadState from '../components/AdminLoadState.vue';
import { useAdminResource } from '../../../composables/useAdminResource.js';
import { showPortalToast } from '../../../support/portalToast';

const accountId = (window.portalPathname?.() ?? window.location.pathname).match(/\/admin\/workspaces\/accounts\/(\d+)$/)?.[1];
const resource = useAdminResource(async ({ signal }) => {
    const response = await window.axios.get(`/admin/workspaces/accounts/${accountId}/data`, { signal });
    if (!response.data.user) throw new Error('Missing account.');
    return response.data;
}, { failureMessage: 'The account record could not be loaded.' });
const { isLoading: loading, errorMessage } = resource;
const actionBusy = ref('');
const actionError = ref('');
const account = ref(null);
const roleContext = ref({ label: 'Records', count: 0 });
const statusDialogOpen = ref(false);
const suspensionReason = ref('');

const roleLabel = computed(() => ({
    applicant: 'Applicant',
    provider: 'Scholarship provider',
    admin: 'Administrator',
}[account.value?.role] ?? 'Portal account'));
const isSuspended = computed(() => account.value?.account_status === 'suspended');
const signInState = computed(() => {
    if (isSuspended.value) return 'Access suspended';
    if (!account.value?.email_verified) return 'Email verification needed';
    if (account.value?.must_reset_password) return 'Password reset required';
    return 'Ready to sign in';
});

function roleIcon(role) {
    return {
        applicant: 'fa-solid fa-user-graduate',
        provider: 'fa-solid fa-building-columns',
        admin: 'fa-solid fa-user-shield',
    }[role] ?? 'fa-solid fa-user';
}

function firstError(error, fallback) {
    return Object.values(error.response?.data?.errors ?? {})[0]?.[0]
        ?? error.response?.data?.message
        ?? fallback;
}

async function loadAccount() {
    const payload = await resource.load();
    if (payload) {
        account.value = payload.user;
        roleContext.value = payload.role_context ?? { label: 'Records', count: 0 };
    }
}

async function runAction(key, request, successTitle) {
    if (actionBusy.value || loading.value || errorMessage.value || !account.value) return;
    actionBusy.value = key;
    actionError.value = '';

    try {
        const response = await request();
        account.value = { ...account.value, ...response.data.user };
        showPortalToast({ title: successTitle, message: response.data.message });
    } catch (error) {
        actionError.value = firstError(error, 'The account action could not be completed.');
    } finally {
        actionBusy.value = '';
    }
}

function resendVerification() {
    runAction(
        'verification',
        () => window.axios.post(`/admin/users/${account.value.id}/verification-email`),
        'Verification sent',
    );
}

function requirePasswordReset() {
    runAction(
        'password',
        () => window.axios.post(`/admin/users/${account.value.id}/force-password-reset`),
        'Password reset required',
    );
}

function openStatusDialog() {
    if (actionBusy.value || loading.value || errorMessage.value || !account.value) return;
    suspensionReason.value = '';
    actionError.value = '';
    statusDialogOpen.value = true;
}

function closeStatusDialog() {
    if (!actionBusy.value) statusDialogOpen.value = false;
}

async function updateStatus() {
    if (actionBusy.value || loading.value || errorMessage.value || !account.value) return;
    if (!isSuspended.value && suspensionReason.value.trim().length < 5) {
        actionError.value = 'Add a short reason for suspending this account.';
        return;
    }

    await runAction(
        'status',
        () => window.axios.patch(`/admin/users/${account.value.id}/status`, {
            account_status: isSuspended.value ? 'active' : 'suspended',
            suspension_reason: isSuspended.value ? null : suspensionReason.value.trim(),
        }),
        isSuspended.value ? 'Account reactivated' : 'Account suspended',
    );

    if (!actionError.value) statusDialogOpen.value = false;
}

onMounted(loadAccount);
const backToQueue = staffQueueReturn(window, 'accounts', '/admin/workspaces/accounts/directory');
</script>

<template>
    <AdminWorkspacePage workspace="account_manager">
        <a :href="backToQueue" class="mb-3 inline-flex items-center gap-2 text-sm font-bold text-slate-600 hover:text-slate-950"><i class="fa-solid fa-arrow-left text-xs" aria-hidden="true"></i>Back to accounts</a>

        <AdminWorkspaceHeader
            eyebrow="Account access"
            title="Manage account"
            description="Review identity and use only the access action needed."
            icon="fa-solid fa-user-gear"
        >
            <template v-if="account" #actions>
                <span :class="['px-3 py-2 text-[10px] font-bold uppercase tracking-wide', isSuspended ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800']">{{ isSuspended ? 'Suspended' : 'Active' }}</span>
            </template>
        </AdminWorkspaceHeader>

        <section v-if="loading || errorMessage" class="admin-panel mt-4 overflow-hidden"><AdminLoadState :loading="loading" :error="errorMessage" loading-message="Loading account record..." error-title="Account unavailable" @retry="loadAccount" /></section>

        <template v-else-if="account">
            <section class="admin-panel mt-4 overflow-hidden">
                <div class="flex items-center gap-4 border-b border-slate-200 px-6 py-5">
                    <span class="relative grid h-14 w-14 shrink-0 place-items-center overflow-hidden border border-slate-200 bg-slate-100 text-lg text-slate-600">
                        <i :class="roleIcon(account.role)" aria-hidden="true"></i>
                        <img v-if="account.avatar_url" :src="account.avatar_url" alt="" :class="['absolute inset-0 h-full w-full bg-white', account.role === 'provider' ? 'object-contain p-1' : 'object-cover']" @error="$event.currentTarget.remove()">
                    </span>
                    <div class="min-w-0">
                        <p class="text-[10px] font-bold uppercase tracking-[0.16em] text-amber-700">{{ roleLabel }}</p>
                        <h2 class="break-words text-lg font-black text-slate-950">{{ account.name }}</h2>
                        <p class="mt-1 text-sm text-slate-500 [overflow-wrap:anywhere]">{{ account.email }} · @{{ account.username }}</p>
                    </div>
                </div>
                <dl class="grid grid-cols-4 divide-x divide-slate-200">
                    <div class="px-5 py-4"><dt class="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">Sign-in state</dt><dd class="mt-1 text-sm font-bold text-slate-950">{{ signInState }}</dd></div>
                    <div class="px-5 py-4"><dt class="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">Contact number</dt><dd class="mt-1 text-sm font-bold text-slate-950">{{ account.contact_number || 'Not provided' }}</dd></div>
                    <div class="px-5 py-4"><dt class="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">Created</dt><dd class="mt-1 text-sm font-bold text-slate-950">{{ account.created_at }}</dd></div>
                    <div class="px-5 py-4"><dt class="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">{{ roleContext.label }}</dt><dd class="mt-1 text-sm font-bold text-slate-950">{{ roleContext.count }}<span v-if="roleContext.secondary_label" class="ml-2 text-xs font-semibold text-slate-500">{{ roleContext.secondary_count }} {{ roleContext.secondary_label.toLowerCase() }}</span></dd></div>
                </dl>
            </section>

            <section class="admin-panel mt-4 overflow-hidden">
                <header class="border-b border-slate-200 px-6 py-4">
                    <div class="flex items-center gap-3"><span class="grid h-9 w-9 shrink-0 place-items-center bg-slate-100 text-slate-600"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i></span><div><h2 class="text-base font-black text-slate-950">Sign-in controls</h2><p class="mt-0.5 text-sm text-slate-500">Use only the action needed for this account.</p></div></div>
                </header>

                <p v-if="actionError && !statusDialogOpen" class="border-b border-rose-200 bg-rose-50 px-6 py-3 text-sm font-semibold text-rose-800" role="alert">{{ actionError }}</p>

                <div class="divide-y divide-slate-200">
                    <div class="flex items-center justify-between gap-6 px-6 py-5">
                        <div class="flex items-center gap-3"><span class="grid h-9 w-9 shrink-0 place-items-center bg-slate-100 text-slate-500"><i class="fa-regular fa-envelope" aria-hidden="true"></i></span><div><h3 class="text-sm font-bold text-slate-950">Email verification</h3><p class="mt-1 text-sm text-slate-500">{{ account.email_verified ? 'The email address is verified.' : 'Send a new verification link.' }}</p></div></div>
                        <span v-if="account.email_verified" class="text-xs font-bold text-emerald-700">Verified</span>
                        <button v-else type="button" :disabled="Boolean(actionBusy)" class="inline-flex h-10 items-center border border-slate-300 bg-white px-4 text-sm font-bold text-slate-700 hover:border-slate-950 disabled:opacity-40" @click="resendVerification">{{ actionBusy === 'verification' ? 'Sending...' : 'Resend verification' }}</button>
                    </div>
                    <div class="flex items-center justify-between gap-6 px-6 py-5">
                        <div class="flex items-center gap-3"><span class="grid h-9 w-9 shrink-0 place-items-center bg-slate-100 text-slate-500"><i class="fa-solid fa-key" aria-hidden="true"></i></span><div><h3 class="text-sm font-bold text-slate-950">Password access</h3><p class="mt-1 text-sm text-slate-500">Require a password change before the next sign-in.</p></div></div>
                        <button type="button" :disabled="Boolean(actionBusy) || account.must_reset_password" class="inline-flex h-10 items-center border border-slate-300 bg-white px-4 text-sm font-bold text-slate-700 hover:border-slate-950 disabled:opacity-40" @click="requirePasswordReset">{{ account.must_reset_password ? 'Reset already required' : actionBusy === 'password' ? 'Preparing...' : 'Require password reset' }}</button>
                    </div>
                    <div class="flex items-center justify-between gap-6 px-6 py-5">
                        <div class="flex items-center gap-3"><span class="grid h-9 w-9 shrink-0 place-items-center bg-slate-100 text-slate-500"><i class="fa-solid fa-user-lock" aria-hidden="true"></i></span><div><h3 class="text-sm font-bold text-slate-950">Account status</h3><p class="mt-1 text-sm text-slate-500">{{ isSuspended ? 'Restore sign-in access when the issue is resolved.' : 'Suspend access when an account should no longer sign in.' }}</p></div></div>
                        <button type="button" :disabled="Boolean(actionBusy)" :class="['inline-flex h-10 items-center border px-4 text-sm font-bold disabled:opacity-40', isSuspended ? 'border-slate-950 bg-slate-950 text-white' : 'border-rose-300 bg-white text-rose-700']" @click="openStatusDialog">{{ isSuspended ? 'Reactivate account' : 'Suspend account' }}</button>
                    </div>
                </div>
            </section>
        </template>
    </AdminWorkspacePage>

    <AdminDialog
        :open="statusDialogOpen"
        :confirmation-only="isSuspended"
        title-id="status-dialog-title"
        :title="isSuspended ? 'Reactivate this account?' : 'Suspend this account?'"
        :description="isSuspended ? 'The user will be able to sign in again.' : 'The user will lose sign-in access immediately.'"
        eyebrow="Account access"
        icon="fa-solid fa-user-lock"
        :confirm-label="isSuspended ? 'Reactivate' : 'Suspend'"
        :busy="Boolean(actionBusy)"
        :error="actionError"
        :danger="!isSuspended"
        @confirm="updateStatus"
        @cancel="closeStatusDialog"
    >
        <label v-if="!isSuspended" class="block"><span class="text-sm font-bold text-slate-800">Reason</span><textarea v-model="suspensionReason" rows="3" maxlength="1000" class="mt-2 w-full rounded-sm border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-slate-950" placeholder="Briefly explain why access is being suspended."></textarea></label>
    </AdminDialog>
</template>

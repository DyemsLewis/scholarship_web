<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue';
import ApplicantPageHeader from '../components/ApplicantPageHeader.vue';
import ApplicantSidebar from '../components/ApplicantSidebar.vue';
import ScholarshipPreparationReturn from '../components/ScholarshipPreparationReturn.vue';
import FilePreviewModal from '../components/FilePreviewModal.vue';
import ConfirmationDialog from '../components/ConfirmationDialog.vue';
import PrivacyNoticeCard from '../components/PrivacyNoticeCard.vue';
import TermsAgreement from '../components/TermsAgreement.vue';
import { useConfirmationDialog } from '../composables/useConfirmationDialog';
import { labelFromKey } from '../support/display';
import { preparationQuery, withPreparationContext } from '../support/scholarshipPreparationContext';

const isLoading = ref(true);
const preparationParams = preparationQuery(window.location.search);
const preparationContext = ref(null);
const contextualHref = (href) => withPreparationContext(href, preparationContext.value?.scholarship_id, preparationContext.value?.return_section);
const uploadingPreparedName = ref('');
const errorMessage = ref('');
const applications = ref([]);
const preparedDocuments = ref([]);
const documentOptions = ref([]);
const preparedDocumentTermsAccepted = ref(false);
const updatingPreparedId = ref(null);
const removingPreparedId = ref(null);
const preparedFilesBusy = computed(() => Boolean(uploadingPreparedName.value) || updatingPreparedId.value !== null || removingPreparedId.value !== null);
const { confirmation, requestConfirmation, confirmConfirmation, cancelConfirmation } = useConfirmationDialog();
const previewDocument = ref(null);
const documentsPerPage = 7;
const documentsPage = ref(1);
const applicationsPerPage = 3;
const applicationsPage = ref(1);
const statusBadgeBase = 'student-badge min-w-[7.5rem] justify-center text-center';
const preparedRowColumns = 'lg:grid-cols-[minmax(0,1fr)_9rem_14rem]';
const applicationRowColumns = 'md:grid-cols-[minmax(0,1fr)_9rem] xl:grid-cols-[minmax(0,1fr)_9rem_12rem_9rem]';
const requestedDocumentView = new URLSearchParams(window.location.search).get('view');
const documentView = ['prepared', 'applications'].includes(requestedDocumentView)
    ? requestedDocumentView
    : 'prepared';
const documentPageContent = {
    prepared: {
        eyebrow: 'Prepared files',
        title: 'Manage reusable documents',
        description: 'Upload common files once so they are ready when an application requests them.',
        actionHref: '#upload-document',
        actionLabel: 'Prepare files',
        secondaryHref: '/dashboard/documents?view=applications',
        secondaryLabel: 'Application files',
    },
    applications: {
        eyebrow: 'Application files',
        title: 'Track submitted requirements',
        description: 'Check document readiness and open the related application when a file needs attention.',
        actionHref: '/dashboard/applications?view=action',
        actionLabel: 'Needs my action',
        secondaryHref: '/dashboard/documents?view=prepared',
        secondaryLabel: 'Prepared files',
    },
}[documentView];
const documentDescriptions = {
    'Latest report card or grades': 'Your latest available school grades or report card.',
    'Certificate of enrollment': 'Current proof that you are enrolled in school.',
    'Recent school ID': 'A clear copy or photo of your most recent school ID.',
    'Proof of identity': 'A birth certificate or valid government-issued ID supporting your official name and date of birth.',
    'Proof of residence': 'A residency certificate or recent utility bill supporting your saved city, province, and region.',
    'Proof of no current scholarship': 'A certificate, clearance, or signed declaration accepted by the provider confirming that you do not currently receive another scholarship.',
    'Proof of income': 'A recent income certificate, payslip, or similar household income proof.',
    'Certificate of indigency': 'A current certificate issued by your barangay or local office.',
    'Birth certificate': 'A clear copy of your birth certificate.',
    'Parent or guardian valid ID': 'Useful when a parent or guardian manages a younger applicant.',
    'Transcript of records': 'Your official transcript or latest certificate of grades for college-level applications.',
    'Good moral certificate': 'A current certificate of good moral character issued by your school.',
    'Barangay certificate of residency': 'Proof of your current residence issued by your barangay.',
    'Government-issued ID': 'A clear copy of your valid government-issued identification.',
    'Recent 2x2 ID photo': 'A recent, clear 2x2 identification photo with a plain background.',
    'Admission or acceptance letter': 'Proof that a school, college, university, or training institution accepted you.',
};
const applicationsWithRequirements = computed(() => applications.value.map((application) => ({
    ...application,
    required_documents: documentRequirements(application.scholarship?.requirements),
})));
const preparedDocumentNames = computed(() => new Set(preparedDocuments.value.map((document) => document.document_name)));
const preparedDocumentsByName = computed(() => new Map(
    preparedDocuments.value.map((document) => [document.document_name, document]),
));
const commonDocumentRows = computed(() => documentOptions.value.map((name) => ({
    name,
    description: documentDescriptions[name] ?? 'A reusable document commonly requested by scholarship providers.',
    document: preparedDocumentsByName.value.get(name) ?? null,
})));
const documentTotalPages = computed(() => pageCount(commonDocumentRows.value.length, documentsPerPage));
const paginatedDocumentRows = computed(() => paginateItems(commonDocumentRows.value, documentsPage.value, documentsPerPage));
const otherPreparedDocuments = computed(() => preparedDocuments.value
    .filter((document) => !documentOptions.value.includes(document.document_name)));
const commonDocumentReadyCount = computed(() => documentOptions.value
    .filter((option) => preparedDocumentNames.value.has(option))
    .length);
const applicationTotalPages = computed(() => pageCount(applicationsWithRequirements.value.length, applicationsPerPage));
const paginatedApplications = computed(() => paginateItems(applicationsWithRequirements.value, applicationsPage.value, applicationsPerPage));
function documentRequirements(requirements) {
    if (!requirements) {
        return [];
    }

    return String(requirements)
        .split(/\r\n|\r|\n|,/)
        .map((requirement) => requirement.trim())
        .filter(Boolean);
}

function pageCount(total, perPage) {
    return Math.max(1, Math.ceil(Number(total || 0) / perPage));
}

function clampPage(page, totalPages) {
    return Math.min(Math.max(Number(page) || 1, 1), totalPages);
}

function paginateItems(items, page, perPage) {
    const currentPage = clampPage(page, pageCount(items.length, perPage));
    const start = (currentPage - 1) * perPage;

    return items.slice(start, start + perPage);
}

function setApplicationsPage(page) {
    applicationsPage.value = clampPage(page, applicationTotalPages.value);
}

function setDocumentsPage(page) {
    documentsPage.value = clampPage(page, documentTotalPages.value);
}

function clampPagination() {
    documentsPage.value = clampPage(documentsPage.value, documentTotalPages.value);
    applicationsPage.value = clampPage(applicationsPage.value, applicationTotalPages.value);
}

function readinessClass(percent) {
    const value = Number(percent ?? 0);

    if (value >= 100) {
        return 'bg-emerald-100 text-emerald-800';
    }

    if (value >= 50) {
        return 'bg-amber-100 text-amber-800';
    }

    return 'bg-slate-100 text-slate-700';
}

function preparedDocumentStatus(document) {
    return document
        ? {
            label: 'Ready',
            icon: 'fa-solid fa-circle-check',
            className: 'student-badge-positive',
        }
        : {
            label: 'Not uploaded',
            icon: 'fa-regular fa-circle',
            className: '',
        };
}

function applicationStatus(status) {
    const normalized = status || 'submitted';

    if (['selected', 'accepted', 'recipient', 'completed'].includes(normalized)) {
        return { label: labelFromKey(normalized), icon: 'fa-solid fa-circle-check', className: 'student-badge-positive' };
    }

    if (['not_selected', 'rejected', 'cancelled', 'withdrawn'].includes(normalized)) {
        return { label: labelFromKey(normalized), icon: 'fa-solid fa-circle-xmark', className: 'student-badge-negative' };
    }

    if (['qualified', 'shortlisted', 'waitlisted'].includes(normalized)) {
        return { label: labelFromKey(normalized), icon: 'fa-solid fa-hourglass-half', className: 'student-badge-attention' };
    }

    return { label: labelFromKey(normalized), icon: 'fa-regular fa-clock', className: '' };
}

function readinessBarClass(percent) {
    const value = Number(percent ?? 0);

    if (value >= 100) {
        return 'bg-emerald-500';
    }

    if (value >= 50) {
        return 'bg-amber-500';
    }

    return 'bg-slate-500';
}

function readinessWidth(percent) {
    return `${Math.min(Math.max(Number(percent) || 0, 0), 100)}%`;
}

function documentReuseCount(document) {
    return applicationsWithRequirements.value
        .filter((application) => application.required_documents.includes(document.document_name))
        .length;
}

function documentReuseLabel(document) {
    const count = documentReuseCount(document);

    if (count === 0) {
        return 'Reusable when a program asks for it';
    }

    return `Reusable for ${count} submitted application${count === 1 ? '' : 's'}`;
}

function formatFileSize(size) {
    if (!size) {
        return 'Unknown size';
    }

    if (size < 1024 * 1024) {
        return `${Math.round(size / 1024)} KB`;
    }

    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function fileExtension(filename) {
    const extension = String(filename || '').split('.').pop();

    if (!extension || extension === filename) {
        return 'FILE';
    }

    return extension.slice(0, 4).toUpperCase();
}

function openDocumentPreview(document) {
    previewDocument.value = document;
}

function closeDocumentPreview() {
    previewDocument.value = null;
}

async function loadDocuments() {
    isLoading.value = true;
    errorMessage.value = '';

    try {
        const response = await window.axios.get('/dashboard/documents/data', { params: preparationParams });

        applications.value = response.data.applications;
        preparationContext.value = response.data.preparation_context ?? null;
        preparedDocuments.value = response.data.prepared_documents ?? [];
        documentOptions.value = response.data.document_options ?? [];
        clampPagination();
    } catch (error) {
        errorMessage.value = error.response?.data?.message ?? 'Unable to load documents.';
    } finally {
        isLoading.value = false;
    }
}

async function uploadPreparedDocument(documentName, event) {
    const file = event.target.files?.[0] ?? null;

    if (!file) {
        return;
    }

    if (!preparedDocumentTermsAccepted.value) {
        errorMessage.value = 'Please accept the document upload terms before saving.';
        event.target.value = '';
        return;
    }

    uploadingPreparedName.value = documentName;
    errorMessage.value = '';

    const payload = new FormData();
    payload.append('document_name', documentName);
    payload.append('document_file', file);
    payload.append('terms_accepted', '1');

    try {
        await window.axios.post('/dashboard/student-documents', payload, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });

        await loadDocuments();
    } catch (handledError) {
        void handledError;
    } finally {
        uploadingPreparedName.value = '';
        event.target.value = '';
    }
}

async function updatePreparedDocument(document, event) {
    const file = event.target.files?.[0] ?? null;

    if (!file) {
        return;
    }

    if (!preparedDocumentTermsAccepted.value) {
        errorMessage.value = 'Please accept the document upload terms before updating.';
        event.target.value = '';
        return;
    }

    updatingPreparedId.value = document.id;
    errorMessage.value = '';

    const payload = new FormData();
    payload.append('document_name', document.document_name);
    payload.append('document_file', file);
    payload.append('terms_accepted', '1');

    try {
        await window.axios.post('/dashboard/student-documents', payload, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });

        await loadDocuments();
    } catch (handledError) {
        void handledError;
    } finally {
        updatingPreparedId.value = null;
        event.target.value = '';
    }
}

async function deletePreparedDocument(document) {
    const canRemove = () => !isLoading.value && !preparedFilesBusy.value && preparedDocuments.value.includes(document);
    if (confirmation.open || !canRemove()) return;

    const confirmed = await requestConfirmation({
        title: 'Remove file from My Documents?',
        message: `"${document.original_name || document.document_name}" will no longer be available to reuse. Copies already submitted with applications will stay attached.`,
        confirmLabel: 'Remove file',
        cancelLabel: 'Keep file',
        tone: 'danger',
    });
    if (!confirmed || !canRemove()) return;

    removingPreparedId.value = document.id;
    errorMessage.value = '';

    try {
        await window.axios.delete(`/dashboard/student-documents/${document.id}`);

        await loadDocuments();
    } catch (handledError) {
        void handledError;
    } finally {
        removingPreparedId.value = null;
    }
}

onMounted(loadDocuments);
onBeforeUnmount(cancelConfirmation);
</script>

<template>
    <main class="student-shell">
        <ApplicantSidebar />

        <ConfirmationDialog
            data-document-removal-confirmation
            v-bind="confirmation"
            @confirm="confirmConfirmation"
            @cancel="cancelConfirmation"
        />

        <FilePreviewModal
            :file="previewDocument"
            :title="previewDocument?.document_name || previewDocument?.original_name || 'Prepared document'"
            context="Applicant document library"
            @close="closeDocumentPreview"
        />

        <section class="student-page">
            <div class="student-container">
                <ApplicantPageHeader
                    :eyebrow="documentPageContent.eyebrow"
                    :title="documentPageContent.title"
                    :description="documentPageContent.description"
                    icon="fa-solid fa-folder-open"
                    :action-href="documentPageContent.actionHref"
                    :action-label="documentPageContent.actionLabel"
                    :secondary-href="contextualHref(documentPageContent.secondaryHref)"
                    :secondary-label="documentPageContent.secondaryLabel"
                />

                <ScholarshipPreparationReturn v-if="!isLoading" :context="preparationContext" :busy="preparedFilesBusy" class="my-4" />

                <PrivacyNoticeCard context="documents" compact />

                <div v-if="isLoading" class="student-card mt-5 p-6 text-sm text-slate-500">
                    Loading documents...
                </div>

                <div v-else class="mt-5 space-y-5">
                    <div v-if="errorMessage" class="flex items-start gap-3 rounded-md border border-rose-200 bg-rose-50 p-4 text-sm font-semibold text-rose-700">
                        <i class="fa-solid fa-circle-exclamation mt-0.5" aria-hidden="true"></i>
                        <p>{{ errorMessage }}</p>
                    </div>
                    <section v-if="documentView === 'prepared'" class="student-card overflow-hidden">
                        <header class="flex flex-col gap-3 border-b border-slate-200 p-5 sm:flex-row sm:items-center sm:justify-between">
                            <div class="flex items-center gap-3">
                                <span class="student-section-mark shrink-0">
                                    <i class="fa-solid fa-folder-open text-sm" aria-hidden="true"></i>
                                </span>
                                <div class="min-w-0">
                                    <p class="student-kicker">Reusable files</p>
                                    <h2 class="mt-1 text-xl font-bold text-slate-950">Common documents</h2>
                                    <p class="mt-1 max-w-2xl text-xs leading-5 text-slate-600">Upload only what a scholarship requests. You do not need every document below.</p>
                                </div>
                            </div>
                            <p class="shrink-0 text-sm font-semibold text-slate-600" data-library-saved-count>
                                {{ commonDocumentReadyCount }} common {{ commonDocumentReadyCount === 1 ? 'file' : 'files' }} saved
                            </p>
                        </header>

                        <div id="upload-document" class="scroll-mt-5 border-b border-slate-200 px-5 py-4">
                            <TermsAgreement
                                v-model="preparedDocumentTermsAccepted"
                                context="document"
                            />
                            <p id="prepared-upload-consent" :class="['mt-2 text-xs leading-5', preparedDocumentTermsAccepted ? 'text-slate-600' : 'font-semibold text-amber-800']" role="status" aria-live="polite">{{ preparedDocumentTermsAccepted ? 'Upload and Replace are enabled for this visit.' : 'Accept the upload terms above to enable Upload and Replace.' }}</p>
                            <p id="prepared-upload-formats" class="mt-1 text-xs text-slate-500">PDF, JPG, PNG, DOC or DOCX, up to 5 MB.</p>
                        </div>

                        <div class="divide-y divide-slate-200">
                            <article
                                v-for="row in paginatedDocumentRows"
                                :key="row.name"
                                class="grid gap-4 px-5 py-4 lg:items-center"
                                :class="preparedRowColumns"
                                data-library-document-row
                            >
                                <div class="flex min-w-0 items-start gap-3">
                                    <span :class="['grid h-11 w-11 shrink-0 place-items-center rounded-md text-sm', row.document ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-500']">
                                        <i :class="row.document ? 'fa-solid fa-file-circle-check' : 'fa-regular fa-file-lines'" aria-hidden="true"></i>
                                    </span>
                                    <div class="min-w-0">
                                        <h3 class="text-sm font-bold text-slate-950">{{ row.name }}</h3>
                                        <p class="mt-1 text-xs leading-5 text-slate-500">{{ row.description }}</p>
                                        <div v-if="row.document" class="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-xs text-slate-500">
                                            <span class="max-w-xs truncate">{{ row.document.original_name }}</span>
                                            <span>{{ formatFileSize(row.document.size) }}</span>
                                            <span class="font-semibold text-slate-700">{{ documentReuseLabel(row.document) }}</span>
                                        </div>
                                    </div>
                                </div>

                                <div class="lg:text-center" data-document-status>
                                    <span :class="[statusBadgeBase, preparedDocumentStatus(row.document).className]">
                                        <i :class="preparedDocumentStatus(row.document).icon" aria-hidden="true"></i>
                                        {{ preparedDocumentStatus(row.document).label }}
                                    </span>
                                </div>

                                <div class="flex shrink-0 flex-wrap items-center gap-2 lg:justify-end" data-document-actions>
                                    <button
                                        v-if="row.document"
                                        type="button"
                                        class="student-button student-button-secondary student-button-compact"
                                        @click="openDocumentPreview(row.document)"
                                    >
                                        <i class="fa-solid fa-eye" aria-hidden="true"></i>
                                        View
                                    </button>
                                    <label
                                        :class="[
                                            'student-button student-button-compact cursor-pointer focus-within:ring-2 focus-within:ring-amber-400 focus-within:ring-offset-2',
                                            row.document ? 'student-button-secondary' : 'student-button-primary',
                                            !preparedDocumentTermsAccepted || uploadingPreparedName === row.name || updatingPreparedId === row.document?.id ? 'pointer-events-none opacity-60' : '',
                                        ]"
                                    >
                                        <input
                                            type="file"
                                            accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                                            class="sr-only"
                                            aria-describedby="prepared-upload-consent prepared-upload-formats"
                                            :disabled="!preparedDocumentTermsAccepted || uploadingPreparedName === row.name || updatingPreparedId === row.document?.id"
                                            @change="row.document ? updatePreparedDocument(row.document, $event) : uploadPreparedDocument(row.name, $event)"
                                        >
                                        <i :class="[
                                            uploadingPreparedName === row.name || updatingPreparedId === row.document?.id ? 'fa-solid fa-spinner fa-spin' : (row.document ? 'fa-solid fa-rotate' : 'fa-solid fa-upload'),
                                        ]" aria-hidden="true"></i>
                                        {{ uploadingPreparedName === row.name || updatingPreparedId === row.document?.id ? 'Saving...' : (row.document ? 'Replace' : 'Upload') }}
                                    </label>
                                    <button
                                        v-if="row.document"
                                        type="button"
                                        :disabled="preparedFilesBusy"
                                        class="student-button student-button-danger student-button-compact student-button-icon"
                                        :aria-label="`Remove ${row.name}`"
                                        @click="deletePreparedDocument(row.document)"
                                    >
                                        <i :class="[removingPreparedId === row.document.id ? 'fa-solid fa-spinner fa-spin' : 'fa-solid fa-trash-can', 'text-xs']" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </article>
                        </div>

                        <footer v-if="documentTotalPages > 1" class="flex items-center justify-between border-t border-slate-200 bg-slate-50 px-5 py-3">
                            <button
                                type="button"
                                :disabled="documentsPage <= 1"
                                class="inline-flex items-center gap-2 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
                                @click="setDocumentsPage(documentsPage - 1)"
                            >
                                <i class="fa-solid fa-chevron-left text-[10px]" aria-hidden="true"></i>
                                Previous
                            </button>
                            <span class="text-xs font-bold text-slate-500">Page {{ documentsPage }} of {{ documentTotalPages }}</span>
                            <button
                                type="button"
                                :disabled="documentsPage >= documentTotalPages"
                                class="inline-flex items-center gap-2 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
                                @click="setDocumentsPage(documentsPage + 1)"
                            >
                                Next
                                <i class="fa-solid fa-chevron-right text-[10px]" aria-hidden="true"></i>
                            </button>
                        </footer>

                        <div v-if="otherPreparedDocuments.length" class="border-t border-slate-200">
                            <div class="bg-slate-50 px-5 py-3">
                                <h3 class="text-sm font-bold text-slate-900">Other saved files</h3>
                                <p class="mt-1 text-xs text-slate-500">Existing files that are not part of the common list remain available here.</p>
                            </div>
                            <div class="divide-y divide-slate-200">
                                <article
                                    v-for="document in otherPreparedDocuments"
                                    :key="document.id"
                                    class="grid gap-4 px-5 py-4 lg:items-center"
                                    :class="preparedRowColumns"
                                    data-library-document-row
                                >
                                    <div class="flex min-w-0 items-start gap-3">
                                        <span class="grid h-10 w-10 shrink-0 place-items-center rounded-md bg-slate-100 text-[11px] font-black text-slate-600">
                                            {{ fileExtension(document.original_name) }}
                                        </span>
                                        <div class="min-w-0">
                                            <p class="truncate text-sm font-bold text-slate-950">{{ document.document_name }}</p>
                                            <p class="mt-1 truncate text-xs text-slate-500">{{ document.original_name }}</p>
                                        </div>
                                    </div>
                                    <div class="lg:text-center" data-document-status>
                                        <span :class="[statusBadgeBase, preparedDocumentStatus(document).className]">
                                            <i :class="preparedDocumentStatus(document).icon" aria-hidden="true"></i>
                                            {{ preparedDocumentStatus(document).label }}
                                        </span>
                                    </div>
                                    <div class="flex flex-wrap items-center gap-2 lg:justify-end" data-document-actions>
                                        <button type="button" class="student-button student-button-secondary student-button-compact" @click="openDocumentPreview(document)">
                                            <i class="fa-solid fa-eye" aria-hidden="true"></i>
                                            View
                                        </button>
                                        <label :class="['student-button student-button-secondary student-button-compact cursor-pointer focus-within:ring-2 focus-within:ring-amber-400 focus-within:ring-offset-2', !preparedDocumentTermsAccepted || updatingPreparedId === document.id ? 'pointer-events-none opacity-60' : '']">
                                            <input type="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" class="sr-only" aria-describedby="prepared-upload-consent prepared-upload-formats" :disabled="!preparedDocumentTermsAccepted || updatingPreparedId === document.id" @change="updatePreparedDocument(document, $event)">
                                            <i :class="[updatingPreparedId === document.id ? 'fa-solid fa-spinner fa-spin' : 'fa-solid fa-rotate', 'text-xs']" aria-hidden="true"></i>
                                            Replace
                                        </label>
                                        <button type="button" :disabled="preparedFilesBusy" class="student-button student-button-danger student-button-compact student-button-icon" :aria-label="`Remove ${document.document_name}`" @click="deletePreparedDocument(document)">
                                            <i :class="[removingPreparedId === document.id ? 'fa-solid fa-spinner fa-spin' : 'fa-solid fa-trash-can', 'text-xs']" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                </article>
                            </div>
                        </div>
                    </section>

                    <section v-if="documentView === 'applications'" class="student-card overflow-hidden">
                        <header class="flex flex-col gap-3 border-b border-slate-200 p-5 sm:flex-row sm:items-center sm:justify-between">
                            <div class="flex items-center gap-3">
                                <span class="student-section-mark shrink-0">
                                    <i class="fa-solid fa-file-circle-check text-sm" aria-hidden="true"></i>
                                </span>
                                <div class="min-w-0">
                                    <p class="student-kicker">Submitted applications</p>
                                    <h2 class="mt-1 text-xl font-bold text-slate-950">Application documents</h2>
                                </div>
                            </div>
                            <p class="text-sm font-semibold text-slate-500">
                                {{ applications.length }} application{{ applications.length === 1 ? '' : 's' }}
                            </p>
                        </header>

                        <div v-if="applications.length === 0" class="flex flex-col items-start gap-4 p-6 sm:flex-row sm:items-center sm:justify-between">
                            <div class="flex items-start gap-3">
                                <span class="grid h-11 w-11 shrink-0 place-items-center rounded-md bg-slate-100 text-slate-500">
                                    <i class="fa-solid fa-briefcase" aria-hidden="true"></i>
                                </span>
                                <div>
                                    <h3 class="text-sm font-bold text-slate-950">No application files to track yet</h3>
                                    <p class="mt-1 text-sm text-slate-500">Submitted application files will appear here.</p>
                                </div>
                            </div>
                            <a
                                href="/dashboard/scholarships"
                                class="inline-flex shrink-0 items-center gap-2 rounded-md bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800"
                            >
                                Browse scholarships
                                <i class="fa-solid fa-arrow-right text-xs" aria-hidden="true"></i>
                            </a>
                        </div>

                        <div v-else class="divide-y divide-slate-200">
                            <article
                                v-for="application in paginatedApplications"
                                :key="application.id"
                                class="grid gap-4 p-5 md:items-center"
                                :class="applicationRowColumns"
                                data-library-application-row
                            >
                                <div class="flex min-w-0 gap-3">
                                    <img
                                        :src="application.scholarship?.image_url || '/uploads/scholarship-default.jpg'"
                                        :alt="application.scholarship?.title || 'Scholarship'"
                                        class="h-12 w-12 shrink-0 rounded-md bg-white object-contain p-1.5 ring-1 ring-slate-200"
                                    >
                                    <div class="min-w-0">
                                        <p class="max-w-full truncate text-xs font-bold text-slate-500">
                                            {{ application.scholarship?.provider?.name || 'Scholarship Provider' }}
                                        </p>
                                        <h3 class="mt-1 truncate text-base font-bold text-slate-950">
                                            {{ application.scholarship?.title || 'Scholarship application' }}
                                        </h3>
                                        <p class="mt-1 text-xs text-slate-500">Submitted {{ application.submitted_at || 'recently' }}</p>
                                    </div>
                                </div>

                                <div class="md:text-center" data-document-status>
                                    <span :class="[statusBadgeBase, applicationStatus(application.status).className]">
                                        <i :class="applicationStatus(application.status).icon" aria-hidden="true"></i>
                                        {{ applicationStatus(application.status).label }}
                                    </span>
                                </div>

                                <div class="min-w-0">
                                    <div class="flex items-center justify-between gap-3 text-xs">
                                        <span class="font-bold text-slate-700">Required files uploaded</span>
                                        <span :class="['rounded px-2 py-1 font-bold', readinessClass(application.document_readiness?.uploaded_percent)]">
                                            {{ application.document_readiness?.uploaded_percent ?? 0 }}%
                                        </span>
                                    </div>
                                    <div class="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-200">
                                        <div
                                            :class="['h-full rounded-full', readinessBarClass(application.document_readiness?.uploaded_percent)]"
                                            :style="{ width: readinessWidth(application.document_readiness?.uploaded_percent) }"
                                        ></div>
                                    </div>
                                    <p class="mt-2 text-xs text-slate-500">
                                        {{ application.document_readiness?.uploaded ?? 0 }} of {{ application.document_readiness?.required ?? application.required_documents.length }} uploaded
                                        <span v-if="application.document_readiness?.accepted"> - {{ application.document_readiness.accepted }} accepted</span>
                                    </p>
                                </div>

                                <a
                                    :href="application.detail_url || `/dashboard/applications/${application.id}`"
                                    class="student-button student-button-secondary w-full"
                                    data-document-actions
                                >
                                    <i class="fa-solid fa-eye text-xs" aria-hidden="true"></i>
                                    View details
                                </a>
                            </article>
                        </div>

                        <footer v-if="applicationTotalPages > 1" class="flex items-center justify-between border-t border-slate-200 bg-slate-50 px-5 py-3">
                            <button
                                type="button"
                                :disabled="applicationsPage <= 1"
                                class="inline-flex items-center gap-2 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
                                @click="setApplicationsPage(applicationsPage - 1)"
                            >
                                <i class="fa-solid fa-chevron-left text-[10px]" aria-hidden="true"></i>
                                Previous
                            </button>
                            <span class="text-xs font-bold text-slate-500">Page {{ applicationsPage }} of {{ applicationTotalPages }}</span>
                            <button
                                type="button"
                                :disabled="applicationsPage >= applicationTotalPages"
                                class="inline-flex items-center gap-2 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
                                @click="setApplicationsPage(applicationsPage + 1)"
                            >
                                Next
                                <i class="fa-solid fa-chevron-right text-[10px]" aria-hidden="true"></i>
                            </button>
                        </footer>
                    </section>
                </div>

            </div>
        </section>

    </main>
</template>

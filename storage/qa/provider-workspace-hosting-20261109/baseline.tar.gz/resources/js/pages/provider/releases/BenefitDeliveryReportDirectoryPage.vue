<script setup>
import StaffTableIdentity from '../../../components/StaffTableIdentity.vue';
import { onBeforeUnmount, onMounted, ref, watch } from 'vue';
import ProviderSidebar from '../ProviderSidebar.vue';
import StaffTableLoadError from '../../../components/StaffTableLoadError.vue';
import BenefitDeliveryReportDialog from '../../../components/benefit-delivery/BenefitDeliveryReportDialog.vue';
import { concernError } from '../../../support/agreementConcerns.js';
import { deliveryClass } from '../../../support/benefitDeliveryReports.js';

const rows = ref([]), legacy = ref([]), programs = ref([]), pagination = ref({}), legacyPagination = ref({});
const status = ref(new URLSearchParams(window.location.search).get('status') === 'all' ? 'all' : 'open'), program = ref(''), search = ref(''), selected = ref(null), loading = ref(false), opening = ref(false), error = ref(''), message = ref('');
const selectionError = ref('');
let timer, version = 0, openVersion = 0;
let requestedPages = [1, 1];
async function load(page = 1, legacyPage = 1) {
    clearTimeout(timer);
    requestedPages = [page, legacyPage];
    selectionError.value = '';
    const token = ++version; loading.value = true; error.value = '';
    try {
        const { data } = await window.axios.get('/provider/workspaces/releases/delivery-reports/data', { params: { page, legacy_page: legacyPage, status: status.value, program_id: program.value || undefined, search: search.value.trim() || undefined }, portalToast: false });
        if (token !== version) return;
        rows.value = data.reports.data; pagination.value = data.reports; legacy.value = data.legacy_reports?.data || []; legacyPagination.value = data.legacy_reports || {}; programs.value = data.programs;
    } catch (failure) { if (token === version) error.value = concernError(failure); }
    finally { if (token === version) loading.value = false; }
}
async function show(row, importing = false) {
    if (opening.value || loading.value || error.value) return;
    const token = ++openVersion; opening.value = true; selectionError.value = '';
    try { const { data } = importing ? await window.axios.post(row.import_url, {}, { portalToast: false }) : await window.axios.get(row.read_url, { portalToast: false }); if (token === openVersion) selected.value = data.report; }
    catch (failure) { if (token === openVersion) selectionError.value = concernError(failure); }
    finally { if (token === openVersion) opening.value = false; }
}
async function changed(data) { message.value = data.message || ''; await load(pagination.value.current_page || 1, legacyPagination.value.current_page || 1); }
watch([status, program], () => { clearTimeout(timer); load(); }, { flush: 'sync' });
watch(search, () => { version++; loading.value = true; error.value = ''; clearTimeout(timer); timer = setTimeout(() => load(), 300); }, { flush: 'sync' });
onMounted(load);
onBeforeUnmount(() => { version++; openVersion++; clearTimeout(timer); });
</script>

<template>
    <main class="student-shell"><ProviderSidebar /><section class="student-page" aria-labelledby="delivery-queue-title"><div class="provider-monitoring-workspace mx-auto max-w-[94rem]">
        <header class="flex items-center justify-between gap-6 border border-slate-200 border-t-2 border-t-slate-950 bg-white px-7 py-5 shadow-sm"><div class="flex items-start gap-4"><span class="grid h-12 w-12 shrink-0 place-items-center bg-slate-950 text-amber-300"><i class="fa-solid fa-hand-holding-heart" aria-hidden="true"></i></span><div><p class="text-xs font-bold uppercase tracking-[0.18em] text-amber-700">Benefit releases</p><h1 id="delivery-queue-title" class="mt-1 font-display text-2xl font-bold text-slate-950">Delivery reports</h1><p class="mt-2 text-sm text-slate-600">Plan corrections, share delivery proof, and wait for applicant confirmation.</p></div></div><a href="/provider/workspaces/releases" class="inline-flex min-h-10 shrink-0 items-center gap-2 border border-slate-300 px-4 text-sm font-bold text-slate-700">Benefit releases<i class="fa-solid fa-arrow-right text-xs" aria-hidden="true"></i></a></header>
        <p v-if="message" role="status" class="mt-4 border border-slate-200 bg-white px-5 py-3 text-sm text-slate-700">{{ message }}</p>
        <section class="mt-4 border border-slate-200 bg-white shadow-sm" aria-label="Benefit delivery queue">
            <div class="grid grid-cols-[minmax(0,1fr)_16rem_14rem] gap-3 border-b border-slate-200 p-4"><label><span class="mb-1.5 block text-xs font-bold text-slate-600">Find an applicant</span><input v-model="search" type="search" maxlength="160" placeholder="Applicant name" class="h-11 w-full border border-slate-300 px-3 text-sm"></label><label><span class="mb-1.5 block text-xs font-bold text-slate-600">Program</span><select v-model="program" class="h-11 w-full border border-slate-300 bg-white px-3 text-sm"><option value="">All assigned programs</option><option v-for="item in programs" :key="item.id" :value="item.id">{{ item.title }}</option></select></label><label><span class="mb-1.5 block text-xs font-bold text-slate-600">Status</span><select v-model="status" class="h-11 w-full border border-slate-300 bg-white px-3 text-sm"><option value="open">Open reports</option><option value="awaiting_provider">Awaiting provider</option><option value="awaiting_recipient">Awaiting applicant</option><option value="closed">Applicant-confirmed resolution</option><option value="all">All reports</option></select></label></div>
            <p v-if="selectionError" role="alert" class="border-b border-amber-200 bg-amber-50 px-5 py-3 text-sm text-amber-950">{{ selectionError }}</p>
            <StaffTableLoadError v-if="error && !loading" :message="error" @retry="load(...requestedPages)" />
            <div class="staff-table-viewport" :aria-busy="loading || opening"><p v-if="loading" role="status" class="py-20 text-center text-sm text-slate-500">Loading delivery reports...</p><div v-else-if="!rows.length && !error" class="px-6 py-20 text-center"><span class="mx-auto grid h-10 w-10 place-items-center bg-slate-100 text-slate-500"><i class="fa-regular fa-folder-open" aria-hidden="true"></i></span><h2 class="mt-3 text-base font-bold">No matching delivery reports</h2><p class="mt-2 text-sm text-slate-500">Applicant reports about assigned benefits will appear here. Normal release recording stays in Benefit releases.</p></div>
                <table v-else-if="!error" class="w-full min-w-[60rem] table-fixed text-left"><colgroup><col><col class="w-44"><col class="w-48"><col class="w-28"></colgroup><thead class="border-b border-slate-200 bg-slate-50 text-xs font-bold uppercase tracking-[0.14em] text-slate-600"><tr><th class="px-5 py-3">Applicant and benefit</th><th class="px-5 py-3">Follow-up</th><th class="px-5 py-3">Status</th><th class="px-5 py-3 text-right">Action</th></tr></thead><tbody class="divide-y divide-slate-200"><tr v-for="row in rows" :key="row.id" class="hover:bg-slate-50"><td class="px-5 py-4"><div class="flex items-center gap-3"><StaffTableIdentity :src="row.applicant.photo_url" class="h-11 w-11" /><div class="min-w-0"><p class="break-words text-sm font-bold">{{ row.applicant.name }}</p><p class="mt-1 break-words text-xs text-slate-600">{{ row.subject }}</p><p class="mt-1 break-words text-xs text-slate-500">{{ row.program.title }}<span v-if="row.benefit_period"> / {{ row.benefit_period }}</span></p></div></div></td><td class="px-5 py-4 text-xs leading-5 text-slate-600">{{ row.follow_up_on || 'No correction date recorded' }}</td><td class="px-5 py-4"><span :class="['inline-flex border px-2.5 py-1 text-xs font-bold', deliveryClass(row.status)]">{{ row.status_label }}</span></td><td class="px-5 py-4 text-right"><button type="button" :disabled="opening" class="staff-row-action h-9 w-9" :aria-label="'Open delivery report for ' + row.applicant.name" @click="show(row)" title="Open delivery report"><i class="fa-solid fa-arrow-right text-xs" aria-hidden="true"></i></button></td></tr></tbody></table>
            </div><footer class="flex items-center justify-between border-t border-slate-200 bg-slate-50 px-5 py-3 text-xs"><span>{{ pagination.total || 0 }} report(s)<span v-if="opening" role="status"> &middot; Opening...</span></span><div class="flex gap-2"><button v-for="direction in [-1, 1]" :key="direction" type="button" :disabled="loading || Boolean(error) || (direction < 0 ? pagination.current_page <= 1 : pagination.current_page >= pagination.last_page)" class="min-h-9 border border-slate-300 bg-white px-3 font-bold disabled:opacity-40" @click="load(pagination.current_page + direction)">{{ direction < 0 ? 'Previous' : 'Next' }}</button></div></footer>
        </section>
        <section v-if="legacy.length && !loading && !error" class="mt-4 border border-slate-200 bg-white"><h2 class="border-b border-slate-200 px-5 py-4 text-base font-bold">Earlier receipt issues</h2><div v-for="row in legacy" :key="row.id" class="flex items-center justify-between gap-5 border-b border-slate-200 px-5 py-4"><div><p class="text-sm font-bold">{{ row.applicant_name }}</p><p class="mt-1 text-xs text-slate-500">{{ row.title }} / Continue using applicant-confirmed resolution.</p></div><button type="button" :disabled="opening" class="min-h-10 border border-slate-300 px-4 text-xs font-bold" @click="show(row, true)">Open receipt issue</button></div><footer v-if="legacyPagination.last_page > 1" class="flex justify-end gap-2 px-5 py-3"><button v-for="direction in [-1, 1]" :key="direction" :disabled="loading || Boolean(error) || (direction < 0 ? legacyPagination.current_page <= 1 : legacyPagination.current_page >= legacyPagination.last_page)" class="border px-3 py-2 text-xs disabled:opacity-40" @click="load(pagination.current_page, legacyPagination.current_page + direction)">{{ direction < 0 ? 'Previous' : 'Next' }}</button></footer></section>
        <BenefitDeliveryReportDialog :open="!!selected" :record="selected" provider @close="selected = null; load(pagination.current_page || 1, legacyPagination.current_page || 1)" @changed="changed" />
    </div></section></main>
</template>

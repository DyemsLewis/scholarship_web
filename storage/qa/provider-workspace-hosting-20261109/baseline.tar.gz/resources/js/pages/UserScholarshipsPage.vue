<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue';
import ApplicantPageHeader from '../components/ApplicantPageHeader.vue';
import ApplicantSidebar from '../components/ApplicantSidebar.vue';
import { labelFromKey } from '../support/display';
import { eligibilityOverview } from '../support/applicantEligibility';
import { programPathListMatches } from '../support/learnerProgramPaths';

const isLoading = ref(true);
const errorMessage = ref('');
const savingId = ref(null);
const user = ref(null);
const scholarships = ref([]);
const search = ref('');
const selectedProviderType = ref('all');
const selectedCategory = ref('all');
const selectedIncome = ref('all');
const selectedEducationLevel = ref('all');
const selectedSchoolType = ref('all');
const deadlineFilter = ref('all');
const maxGwa = ref('');
const minimumMatch = ref('');
const courseFilter = ref('');
const yearFilter = ref('');
const locationFilter = ref('');
const savedOnly = ref(false);
const showAdvancedFilters = ref(false);
const previewScholarship = ref(null);
const showComparisonModal = ref(false);
const comparisonStep = ref('select');
const comparisonSelection = ref([]);
const requestedScholarshipView = new URLSearchParams(window.location.search).get('view');
const scholarshipView = ['find', 'saved', 'compare'].includes(requestedScholarshipView)
    ? requestedScholarshipView
    : 'find';
const scholarshipPageContent = {
    find: {
        eyebrow: 'Scholarships',
        title: 'Find programs that fit',
        description: 'Search approved scholarships using the criteria that matter to you.',
    },
    saved: {
        eyebrow: 'Saved scholarships',
        title: 'Review programs saved for later',
        description: 'Keep your shortlist focused before comparing or starting an application.',
    },
    compare: {
        eyebrow: 'Scholarship comparison',
        title: 'Compare two eligible programs',
        description: 'Review benefits, deadlines, eligibility, and recipient expectations side by side.',
    },
}[scholarshipView];
const benefitIcons = {
    cash_grant: 'fa-solid fa-peso-sign',
    tuition_coverage: 'fa-solid fa-graduation-cap',
    allowance: 'fa-solid fa-wallet',
    school_supplies: 'fa-solid fa-book-open',
    device_support: 'fa-solid fa-laptop',
    transportation: 'fa-solid fa-bus',
    accommodation: 'fa-solid fa-house',
    training: 'fa-solid fa-certificate',
    mentorship: 'fa-solid fa-people-group',
    fee_waiver: 'fa-solid fa-receipt',
    other: 'fa-solid fa-gift',
};

const providerTypes = computed(() => [
    'all',
    ...new Set(scholarships.value.map((scholarship) => scholarship.provider?.type).filter(Boolean)),
]);
const categories = computed(() => [
    'all',
    ...new Set(scholarships.value.map((scholarship) => scholarship.category).filter(Boolean)),
]);
const incomeRequirements = computed(() => [
    'all',
    ...new Set(scholarships.value.map((scholarship) => scholarship.income_requirement).filter(Boolean)),
]);
const educationLevels = computed(() => [
    'all',
    ...new Set(scholarships.value
        .flatMap((scholarship) => splitOptions(scholarship.eligible_education_levels))
        .filter(Boolean)),
]);
const schoolTypes = computed(() => [
    'all',
    ...new Set(scholarships.value
        .flatMap((scholarship) => splitOptions(scholarship.eligible_school_types))
        .filter(Boolean)),
]);
const activeFilterCount = computed(() => [
    search.value.trim(),
    selectedProviderType.value !== 'all',
    selectedCategory.value !== 'all',
    selectedIncome.value !== 'all',
    selectedEducationLevel.value !== 'all',
    selectedSchoolType.value !== 'all',
    deadlineFilter.value !== 'all',
    maxGwa.value,
    minimumMatch.value,
    courseFilter.value.trim(),
    yearFilter.value.trim(),
    locationFilter.value.trim(),
    savedOnly.value,
].filter(Boolean).length);
const filteredScholarships = computed(() => scholarships.value
    .filter((scholarship) => {
        const keyword = search.value.trim().toLowerCase();
        const matchScore = Number(scholarship.eligibility_match?.score ?? 0);
        const locationText = [scholarship.eligible_locations, scholarship.location_name, scholarship.location_address].filter(Boolean).join(' ');
        const matchesSearch = !keyword || [
            scholarship.title,
            scholarship.description,
            scholarship.provider?.name,
            scholarship.category,
            scholarship.eligibility,
            scholarship.eligible_education_levels,
            scholarship.eligible_courses,
            scholarship.eligible_school_types,
            scholarship.eligible_year_levels,
            scholarship.income_requirement,
            scholarship.requirements,
            scholarship.application_mode,
            scholarship.renewal_policy,
            scholarship.return_service_contract,
            scholarship.other_contract_terms,
            scholarship.contact_email,
            scholarship.contact_number,
        ].filter(Boolean).some((value) => String(value).toLowerCase().includes(keyword)) || locationSearchMatches(locationText, search.value);
        const matchesProvider = selectedProviderType.value === 'all' || scholarship.provider?.type === selectedProviderType.value;
        const matchesCategory = selectedCategory.value === 'all' || scholarship.category === selectedCategory.value;
        const matchesGwa = matchesAcademicRequirement(scholarship, maxGwa.value);
        const matchesMinimum = !minimumMatch.value || matchScore >= Number(minimumMatch.value);
        const matchesCourse = programPathListMatches(scholarship.eligible_courses, courseFilter.value);
        const matchesYear = textMatches(scholarship.eligible_year_levels, yearFilter.value);
        const matchesEducationLevel = selectedEducationLevel.value === 'all' || textMatches(scholarship.eligible_education_levels, selectedEducationLevel.value);
        const matchesSchoolType = selectedSchoolType.value === 'all' || textMatches(scholarship.eligible_school_types, selectedSchoolType.value);
        const matchesLocation = locationMatches(locationText, locationFilter.value);
        const matchesIncome = selectedIncome.value === 'all' || textMatches(scholarship.income_requirement, selectedIncome.value);
        const matchesSaved = !savedOnly.value || scholarship.is_saved;
        const matchesDeadline = deadlineMatches(scholarship);

        return matchesSearch
            && matchesProvider
            && matchesCategory
            && matchesGwa
            && matchesMinimum
            && matchesEducationLevel
            && matchesSchoolType
            && matchesCourse
            && matchesYear
            && matchesLocation
            && matchesIncome
            && matchesSaved
            && matchesDeadline;
    })
    .sort((first, second) => {
        const scoreDifference = Number(second.eligibility_match?.score ?? 0) - Number(first.eligibility_match?.score ?? 0);

        return scoreDifference || deadlineValue(first) - deadlineValue(second);
    }));
const eligibleScholarships = computed(() => scholarships.value
    .filter((scholarship) => scholarship.eligibility_match?.is_eligible === true)
    .sort((first, second) => {
        const scoreDifference = Number(second.eligibility_match?.score ?? 0) - Number(first.eligibility_match?.score ?? 0);

        return scoreDifference || deadlineValue(first) - deadlineValue(second);
    }));
const selectedComparisonScholarships = computed(() => comparisonSelection.value
    .map((id) => scholarships.value.find((scholarship) => scholarship.id === id))
    .filter(Boolean));
const canStartComparison = computed(() => selectedComparisonScholarships.value.length === 2);
const comparisonRows = [
    { key: 'match', label: 'Profile match', icon: 'fa-solid fa-gauge-high' },
    { key: 'benefits', label: 'Benefits', icon: 'fa-solid fa-gift' },
    { key: 'deadline', label: 'Application dates', icon: 'fa-regular fa-calendar' },
    { key: 'support_period', label: 'Support period', icon: 'fa-solid fa-calendar-days' },
    { key: 'target', label: 'Eligible learners', icon: 'fa-solid fa-user-graduate' },
    { key: 'academic', label: 'Academic rule', icon: 'fa-solid fa-chart-line' },
    { key: 'documents', label: 'Document readiness', icon: 'fa-solid fa-folder-open' },
    { key: 'location', label: 'Coverage and distance', icon: 'fa-solid fa-location-dot' },
    { key: 'slots', label: 'Available slots', icon: 'fa-solid fa-users' },
    { key: 'process', label: 'Selection process', icon: 'fa-solid fa-list-check' },
];

function formatAmount(amount) {
    if (amount === null || amount === undefined || amount === '') {
        return 'Amount not set';
    }

    return new Intl.NumberFormat('en-PH', {
        style: 'currency',
        currency: 'PHP',
        maximumFractionDigits: 2,
    }).format(Number(amount));
}

function primaryBenefit(scholarship) {
    return Array.isArray(scholarship?.benefits)
        ? scholarship.benefits[0] ?? null
        : null;
}

function primaryBenefitTitle(scholarship) {
    return primaryBenefit(scholarship)?.title
        || scholarship?.benefit_summary
        || 'Benefits available';
}

function primaryBenefitDetails(scholarship) {
    const benefit = primaryBenefit(scholarship);

    if (!benefit) {
        return 'Open the program to review all benefits.';
    }

    return benefitDetailLine(benefit);
}

function benefitDetailLine(benefit) {
    const details = [
        benefit.amount !== null && benefit.amount !== undefined && benefit.amount !== ''
            ? formatAmount(benefit.amount)
            : null,
        benefit.coverage_label,
        benefit.frequency_label,
        benefit.duration,
    ].filter(Boolean);

    return details.length
        ? details.join(' / ')
        : benefit.type_label || 'Included with this program';
}

function previewBenefitItems(scholarship) {
    return Array.isArray(scholarship?.benefits)
        ? scholarship.benefits.slice(0, 4)
        : [];
}

function hiddenPreviewBenefitCount(scholarship) {
    return Math.max((scholarship?.benefits?.length ?? 0) - 4, 0);
}

function remainingBenefitCount(scholarship) {
    return Math.max((scholarship?.benefits?.length ?? 0) - 1, 0);
}

function comparisonBenefitSummary(scholarship) {
    const benefits = Array.isArray(scholarship?.benefits) ? scholarship.benefits : [];

    if (benefits.length === 0) {
        return scholarship?.benefit_summary || formatAmount(scholarship?.award_amount);
    }

    const summary = benefits
        .slice(0, 2)
        .map((benefit) => `${benefit.title}: ${benefitDetailLine(benefit)}`)
        .join(' / ');

    return `${summary}${benefits.length > 2 ? ` / +${benefits.length - 2} more` : ''}`;
}

function comparisonValue(scholarship, key) {
    if (key === 'match') {
        return `${scholarship.eligibility_match?.score ?? 0}% - ${scholarship.eligibility_match?.label || 'Eligible'}`;
    }

    if (key === 'benefits') return comparisonBenefitSummary(scholarship);
    if (key === 'deadline') {
        const opening = scholarship.application_opens_at ? `Opens ${scholarship.application_opens_at}` : 'Open now';

        return `${opening} / ${deadlineLabel(scholarship)}`;
    }
    if (key === 'support_period') {
        return scholarship.support_starts_at && scholarship.support_ends_at
            ? `${scholarship.support_starts_at} - ${scholarship.support_ends_at}`
            : 'Not fully announced';
    }
    if (key === 'target') return targetApplicantLabel(scholarship);
    if (key === 'academic') return academicRequirementLabel(scholarship);
    if (key === 'documents') return `${requirementSummary(scholarship)}. ${documentReadinessHint(scholarship)}`;
    if (key === 'location') {
        return `${coverageLabel(scholarship)}${scholarship.distance_label ? ` / ${scholarship.distance_label}` : ''}`;
    }
    if (key === 'slots') {
        return scholarship.slots_available !== null && scholarship.slots_available !== undefined
            ? `${scholarship.slots_available} slot${Number(scholarship.slots_available) === 1 ? '' : 's'}`
            : 'Not specified';
    }
    if (key === 'process') return selectionProcessLabel(scholarship);

    return 'Not specified';
}

function benefitIcon(benefit) {
    return benefitIcons[benefit?.type] || benefitIcons.other;
}

function primaryBenefitIcon(scholarship) {
    return benefitIcon(primaryBenefit(scholarship));
}

function inferGradeScale(value) {
    if (value === null || value === undefined || value === '') {
        return '';
    }

    return Number(value) <= 5 ? 'grade_point' : 'percentage';
}

function academicRequirementLabel(scholarship) {
    if (scholarship?.minimum_grade_label) {
        return scholarship.minimum_grade_label;
    }

    if (!scholarship?.minimum_gwa) {
        return 'Not listed yet';
    }

    return inferGradeScale(scholarship.minimum_gwa) === 'grade_point'
        ? `Maximum GWA/GPA ${scholarship.minimum_gwa}`
        : `Minimum average ${scholarship.minimum_gwa}%`;
}

function matchesAcademicRequirement(scholarship, studentValue) {
    if (!studentValue || !scholarship.minimum_gwa) {
        return true;
    }

    const requiredScale = scholarship.minimum_grade_scale || inferGradeScale(scholarship.minimum_gwa);

    if (!['percentage', 'grade_point'].includes(requiredScale)) {
        return true;
    }

    const studentScale = inferGradeScale(studentValue);

    if (studentScale !== requiredScale) {
        return false;
    }

    const studentNumber = Number(studentValue);
    const requiredNumber = Number(scholarship.minimum_gwa);

    return requiredScale === 'grade_point'
        ? studentNumber <= requiredNumber
        : studentNumber >= requiredNumber;
}

function providerTypeLabel(type) {
    return String(type ?? 'Provider')
        .replace(/_/g, ' ')
        .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function splitOptions(value) {
    if (!value) {
        return [];
    }

    return String(value)
        .split(/\r?\n|,/)
        .map((option) => option.trim())
        .filter(Boolean);
}

function targetApplicantLabel(scholarship) {
    const levels = splitOptions(scholarship.eligible_education_levels);

    if (levels.length === 0 || levels.length >= 7) {
        return 'All learners';
    }

    if (levels.includes('preschool') && levels.includes('elementary') && levels.length === 2) {
        return 'Preschool / Elementary';
    }

    return levels.slice(0, 2).map(labelFromKey).join(', ') + (levels.length > 2 ? ` +${levels.length - 2}` : '');
}

function optionSummary(value, fallback) {
    const options = splitOptions(value);

    if (options.length === 0) {
        return fallback;
    }

    return options.slice(0, 3).map(labelFromKey).join(', ')
        + (options.length > 3 ? ` +${options.length - 3}` : '');
}

function documentRequirements(requirements) {
    if (!requirements) {
        return [];
    }

    return String(requirements)
        .split(/\r?\n|,/)
        .map((requirement) => requirement.trim())
        .filter(Boolean);
}

function requirementSummary(scholarship) {
    const count = documentRequirements(scholarship?.requirements).length;
    const readiness = documentReadinessLabel(scholarship);

    if (count === 0) {
        return readiness;
    }

    return `${count} required / ${readiness}`;
}

function selectionProcessLabel(scholarship) {
    const stages = Array.isArray(scholarship?.selection_stages)
        ? scholarship.selection_stages
        : [];

    if (stages.length === 0) {
        return 'Provider review';
    }

    return stages.slice(0, 4).map(labelFromKey).join(', ')
        + (stages.length > 4 ? ` +${stages.length - 4}` : '');
}

function applicationModeLabel(mode) {
    return {
        online: 'Portal review',
        onsite: 'Portal review with in-person verification',
        hybrid: 'Portal review with in-person verification',
        provider_review: 'Profile review only',
    }[mode] ?? labelFromKey(mode || 'not specified');
}

function applicationModeDescription(mode) {
    return {
        online: 'Profile and required files are reviewed in the portal.',
        onsite: 'Files are uploaded first; original documents may be checked in person later.',
        hybrid: 'Files are uploaded first; original documents may be checked in person later.',
        provider_review: 'The initial review uses the applicant profile and does not require program files.',
    }[mode] ?? 'The provider reviews the portal submission before its formal process.';
}

function matchClass(score) {
    if (Number(score) >= 80) {
        return 'bg-emerald-100 text-emerald-800';
    }

    if (Number(score) >= 50) {
        return 'bg-amber-100 text-amber-800';
    }

    return 'bg-rose-100 text-rose-800';
}

const localTodayDate = new Date(Date.now() - new Date().getTimezoneOffset() * 60_000)
    .toISOString()
    .slice(0, 10);

function canStartApplication(scholarship) {
    if (!user.value?.is_profile_verified) {
        return false;
    }

    if (scholarship?.can_start_application !== undefined) {
        return Boolean(scholarship.can_start_application);
    }

    return scholarship?.eligibility_match?.is_eligible !== false;
}

function isUpcomingProgram(scholarship) {
    return Boolean(
        scholarship?.application_opens_date
        && scholarship.application_opens_date > localTodayDate,
    );
}

function applicationBlockedLabel(scholarship) {
    if (scholarship?.application_limit_reached) {
        return 'This scholarship has reached its application limit.';
    }

    if (!user.value?.is_profile_verified) {
        return 'Your applicant profile must be verified before you can apply. Review Supporting Evidence in your profile.';
    }

    const blockers = scholarship?.eligibility_match?.blocking_criteria ?? [];
    const labels = blockers
        .map((criterion) => criterion.label)
        .filter(Boolean)
        .slice(0, 2);

    return labels.length
        ? `Required rules not met: ${labels.join(', ')}`
        : 'Complete your profile or review eligibility first.';
}

function applicationBlockedActionLabel(scholarship) {
    if (isUpcomingProgram(scholarship)) {
        return `Opens ${scholarship.application_opens_at}`;
    }

    if (scholarship?.application_limit_reached) {
        return 'Applications full';
    }

    if (!user.value?.is_profile_verified) {
        return 'Verify profile first';
    }

    return scholarship?.eligibility_match?.is_eligible === false
        ? 'Required rules not met'
        : 'Complete profile first';
}

function scholarshipSnapshot(scholarship) {
    return [
        { label: 'Benefits', value: scholarship.benefit_summary || formatAmount(scholarship.award_amount) },
        { label: 'For', value: targetApplicantLabel(scholarship) },
        { label: 'Academic', value: academicRequirementLabel(scholarship) },
        { label: 'Documents', value: documentReadinessLabel(scholarship) },
    ];
}

function scholarshipLogo(scholarship) {
    return scholarship?.logo_url || '/uploads/scholarship-default.jpg';
}

function handleScholarshipImageError(event) {
    event.target.src = '/uploads/scholarship-default.jpg';
}

function compactDeadlineLabel(scholarship) {
    if (isUpcomingProgram(scholarship)) {
        return `Opens ${scholarship.application_opens_at}`;
    }

    const days = deadlineDays(scholarship);

    if (days === null) {
        return 'No deadline';
    }

    if (days < 0) {
        return 'Closed';
    }

    if (days === 0) {
        return 'Due today';
    }

    if (days === 1) {
        return 'Tomorrow';
    }

    if (days <= 30) {
        return `${days} days left`;
    }

    return scholarship.deadline;
}

function coverageLabel(scholarship) {
    const coverage = scholarship?.eligible_locations || scholarship?.location_name || scholarship?.location_address;

    if (!coverage) {
        return 'Coverage not listed';
    }

    return String(coverage)
        .split(/\r?\n/)
        .map((item) => item.trim())
        .filter(Boolean)
        .join(', ');
}

function availableSlotsLabel(scholarship) {
    const slots = scholarship?.slots_available;

    if (slots === null || slots === undefined || slots === '') {
        return 'Not specified';
    }

    return `${slots} planned`;
}

function documentReadinessLabel(scholarship) {
    const readiness = scholarship?.prepared_documents;
    const required = Number(readiness?.required ?? 0);
    const uploaded = Number(readiness?.uploaded ?? 0);

    if (required === 0) {
        return 'No required documents listed';
    }

    return `${uploaded} of ${required} ready`;
}

function documentReadinessHint(scholarship) {
    const readiness = scholarship?.prepared_documents;
    const required = Number(readiness?.required ?? 0);
    const uploaded = Number(readiness?.uploaded ?? 0);

    if (required === 0) {
        return 'Provider has not listed document requirements yet.';
    }

    if (uploaded >= required) {
        return 'Your prepared documents cover this program.';
    }

    const missing = (readiness?.missing ?? []).slice(0, 2);

    return missing.length
        ? `Missing: ${missing.join(', ')}${(readiness?.missing ?? []).length > 2 ? '...' : ''}`
        : 'Upload matching documents before applying.';
}

function documentReadinessWidth(scholarship) {
    const percent = Number(scholarship?.prepared_documents?.percent ?? 0);

    return `${Math.min(Math.max(percent, 0), 100)}%`;
}

function deadlineLabel(scholarship) {
    const days = deadlineDays(scholarship);

    if (days === null) {
        return 'No deadline listed';
    }

    if (days < 0) {
        return 'Deadline passed';
    }

    if (days === 0) {
        return 'Due today';
    }

    if (days === 1) {
        return 'Due tomorrow';
    }

    return `${scholarship.deadline} (${days} days left)`;
}

function deadlineClass(scholarship) {
    const days = deadlineDays(scholarship);

    if (days === null) {
        return 'bg-slate-100 text-slate-700';
    }

    if (days <= 7) {
        return 'bg-rose-100 text-rose-800';
    }

    if (days <= 30) {
        return 'bg-amber-100 text-amber-800';
    }

    return 'bg-emerald-100 text-emerald-800';
}

function textMatches(value, filter) {
    const needle = String(filter ?? '').trim().toLowerCase();

    if (!needle) {
        return true;
    }

    const haystack = String(value ?? '').toLowerCase();

    return haystack === '' || haystack.includes(needle) || needle.includes(haystack);
}

function normalizeLocation(value) {
    return String(value ?? '')
        .toLowerCase()
        .replace(/[.;:]/g, '')
        .replace(/\s+/g, ' ')
        .trim();
}

function isOpenPhilippineLocation(value) {
    const normalized = normalizeLocation(value);

    if (!normalized) {
        return false;
    }

    return [
        'all locations',
        'any location',
        'all regions',
        'any region',
        'nationwide',
        'philippines',
        'the philippines',
        'republic of the philippines',
        'nationwide philippines',
        'philippines nationwide',
        'anywhere in the philippines',
        'within the philippines',
        'all over the philippines',
        'all philippines',
    ].includes(normalized)
        || normalized.includes('open to all')
        || normalized.includes('no restriction')
        || (normalized.includes('nationwide') && !normalized.includes('not nationwide'));
}

function locationMatches(value, filter) {
    const needle = normalizeLocation(filter);
    const haystack = normalizeLocation(value);

    if (!needle) {
        return true;
    }

    if (!haystack || isOpenPhilippineLocation(haystack)) {
        return true;
    }

    if (isOpenPhilippineLocation(needle) && isOpenPhilippineLocation(haystack)) {
        return true;
    }

    return haystack.includes(needle) || needle.includes(haystack);
}

function locationSearchMatches(value, filter) {
    const needle = normalizeLocation(filter);
    const haystack = normalizeLocation(value);

    if (!needle || !haystack) {
        return false;
    }

    if (isOpenPhilippineLocation(needle) && isOpenPhilippineLocation(haystack)) {
        return true;
    }

    return haystack.includes(needle) || needle.includes(haystack);
}

function deadlineValue(scholarship) {
    const parsed = Date.parse(scholarship.deadline ?? '');

    return Number.isNaN(parsed) ? Number.POSITIVE_INFINITY : parsed;
}

function deadlineDays(scholarship) {
    const due = deadlineValue(scholarship);

    if (!Number.isFinite(due)) {
        return null;
    }

    const today = new Date();
    const startOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();

    return Math.ceil((due - startOfToday) / 86400000);
}

function deadlineMatches(scholarship) {
    const days = deadlineDays(scholarship);

    if (deadlineFilter.value === 'no_deadline') {
        return days === null;
    }

    if (deadlineFilter.value === 'next_7_days') {
        return days !== null && days >= 0 && days <= 7;
    }

    if (deadlineFilter.value === 'next_30_days') {
        return days !== null && days >= 0 && days <= 30;
    }

    return true;
}

function resetFilters() {
    search.value = '';
    selectedProviderType.value = 'all';
    selectedCategory.value = 'all';
    selectedIncome.value = 'all';
    selectedEducationLevel.value = 'all';
    selectedSchoolType.value = 'all';
    deadlineFilter.value = 'all';
    maxGwa.value = '';
    minimumMatch.value = '';
    courseFilter.value = '';
    yearFilter.value = '';
    locationFilter.value = '';
    savedOnly.value = scholarshipView === 'saved';
}

async function toggleSave(scholarship) {
    savingId.value = scholarship.id;
    errorMessage.value = '';

    try {
        const response = scholarship.is_saved
            ? await window.axios.delete(`/dashboard/scholarships/${scholarship.id}/save`)
            : await window.axios.post(`/dashboard/scholarships/${scholarship.id}/save`);

        scholarships.value = scholarships.value.map((item) => (item.id === scholarship.id ? response.data.scholarship : item));
    } catch (handledError) {
        void handledError;
    } finally {
        savingId.value = null;
    }
}

async function loadScholarships() {
    isLoading.value = true;
    errorMessage.value = '';

    try {
        const response = await window.axios.get('/dashboard/scholarships/data');

        user.value = response.data.user;
        scholarships.value = response.data.scholarships;
    } catch (error) {
        errorMessage.value = error.response?.data?.message ?? 'Unable to load scholarships.';
    } finally {
        isLoading.value = false;
    }
}

function openScholarshipPreview(scholarship) {
    previewScholarship.value = scholarship;
}

function closeScholarshipPreview() {
    previewScholarship.value = null;
}

function openComparisonModal() {
    comparisonSelection.value = [];
    comparisonStep.value = 'select';
    showComparisonModal.value = true;
}

function closeComparisonModal() {
    showComparisonModal.value = false;
    comparisonStep.value = 'select';
    comparisonSelection.value = [];
}

function isComparisonSelected(scholarshipId) {
    return comparisonSelection.value.includes(scholarshipId);
}

function toggleComparisonSelection(scholarshipId) {
    if (isComparisonSelected(scholarshipId)) {
        comparisonSelection.value = comparisonSelection.value.filter((id) => id !== scholarshipId);
        return;
    }

    if (comparisonSelection.value.length < 2) {
        comparisonSelection.value = [...comparisonSelection.value, scholarshipId];
    }
}

function showComparison() {
    if (canStartComparison.value) {
        comparisonStep.value = 'compare';
    }
}

function returnToComparisonSelection() {
    if (comparisonStep.value === 'compare') {
        comparisonStep.value = 'select';
        return;
    }

    closeComparisonModal();
}

function handlePreviewKeydown(event) {
    if (event.key !== 'Escape') return;

    if (showComparisonModal.value) {
        closeComparisonModal();
        return;
    }

    if (previewScholarship.value) {
        closeScholarshipPreview();
    }
}

onMounted(async () => {
    window.addEventListener('keydown', handlePreviewKeydown);
    savedOnly.value = scholarshipView === 'saved';
    await loadScholarships();

    if (scholarshipView === 'compare' && !errorMessage.value) {
        openComparisonModal();
    }
});

onBeforeUnmount(() => {
    window.removeEventListener('keydown', handlePreviewKeydown);
});
</script>

<template>
    <main class="student-shell">
        <ApplicantSidebar />

        <section class="student-page">
            <div class="student-container">
                <ApplicantPageHeader
                    :eyebrow="scholarshipPageContent.eyebrow"
                    :title="scholarshipPageContent.title"
                    :description="scholarshipPageContent.description"
                    icon="fa-solid fa-magnifying-glass-chart"
                />

                <div v-if="isLoading" class="student-card mt-6 p-6 text-sm text-slate-500">
                    Loading scholarships...
                </div>

                <div v-else-if="errorMessage" class="mt-6 rounded-lg border border-rose-200 bg-rose-50 p-6 text-sm text-rose-700 shadow-sm">
                    {{ errorMessage }}
                </div>

                <section v-else class="mt-6 space-y-5">
                    <section class="student-card overflow-hidden">
                        <div class="flex flex-col gap-3 bg-slate-950 p-4 text-white lg:flex-row lg:items-center lg:justify-between">
                            <div>
                                <h3 class="font-display text-lg font-bold">Search and filter</h3>
                            </div>
                            <div class="flex flex-wrap gap-2">
                                <button
                                    type="button"
                                    class="inline-flex items-center gap-2 rounded-md border border-amber-300/40 bg-amber-300 px-3 py-2 text-xs font-bold text-slate-950 transition hover:bg-amber-200"
                                    @click="openComparisonModal"
                                >
                                    <i class="fa-solid fa-code-compare" aria-hidden="true"></i>
                                    Compare scholarships
                                </button>
                                <p class="rounded-md bg-white/10 px-3 py-2 text-xs font-bold text-slate-200">
                                    {{ filteredScholarships.length }} program{{ filteredScholarships.length === 1 ? '' : 's' }} matched
                                </p>
                            </div>
                        </div>

                        <div class="grid gap-3 p-4 md:grid-cols-2 xl:grid-cols-[minmax(14rem,2fr)_auto_minmax(10rem,1fr)_minmax(10rem,1fr)_auto_auto] xl:items-center">
                            <input
                                v-model="search"
                                type="search"
                                placeholder="Search program or provider"
                                class="rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-amber-500 focus:ring-3 focus:ring-amber-100"
                            >

                            <label v-if="scholarshipView !== 'saved'" class="flex items-center justify-between gap-3 rounded-md border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm font-semibold text-slate-700">
                                <span>Saved only</span>
                                <input
                                    v-model="savedOnly"
                                    type="checkbox"
                                    class="h-4 w-4 rounded border-slate-300 text-amber-600 focus:ring-amber-200"
                                >
                            </label>

                            <select v-model="selectedCategory" class="rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition focus:border-amber-500 focus:ring-3 focus:ring-amber-100">
                                <option v-for="category in categories" :key="category" :value="category">
                                    {{ category === 'all' ? 'All categories' : category }}
                                </option>
                            </select>

                            <select v-model="selectedProviderType" class="rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition focus:border-amber-500 focus:ring-3 focus:ring-amber-100">
                                <option v-for="type in providerTypes" :key="type" :value="type">
                                    {{ type === 'all' ? 'All provider types' : providerTypeLabel(type) }}
                                </option>
                            </select>

                            <button
                                type="button"
                                class="rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm font-bold text-slate-700 transition hover:bg-slate-100"
                                @click="showAdvancedFilters = !showAdvancedFilters"
                            >
                                {{ showAdvancedFilters ? 'Hide advanced' : 'Show advanced' }}
                            </button>

                            <div v-if="showAdvancedFilters" class="grid gap-3 border-t border-slate-200 pt-3 md:col-span-2 md:grid-cols-2 xl:col-span-6 xl:grid-cols-4">
                                <select v-model="selectedEducationLevel" class="rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition focus:border-amber-500 focus:ring-3 focus:ring-amber-100">
                                    <option v-for="level in educationLevels" :key="level" :value="level">
                                        {{ level === 'all' ? 'All education levels' : labelFromKey(level) }}
                                    </option>
                                </select>
                                <select v-model="selectedSchoolType" class="rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition focus:border-amber-500 focus:ring-3 focus:ring-amber-100">
                                    <option v-for="type in schoolTypes" :key="type" :value="type">
                                        {{ type === 'all' ? 'All school types' : labelFromKey(type) }}
                                    </option>
                                </select>
                                <input v-model="maxGwa" type="number" min="0" max="100" step="0.01" placeholder="My grade value, e.g. 85 or 2.00" class="rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-amber-500 focus:ring-3 focus:ring-amber-100">
                                <input v-model="minimumMatch" type="number" min="0" max="100" step="1" placeholder="Minimum match %" class="rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-amber-500 focus:ring-3 focus:ring-amber-100">
                                <input v-model="courseFilter" type="search" placeholder="Track / strand / course" class="rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-amber-500 focus:ring-3 focus:ring-amber-100">
                                <input v-model="yearFilter" type="search" placeholder="Grade / year level" class="rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-amber-500 focus:ring-3 focus:ring-amber-100">
                                <input v-model="locationFilter" type="search" placeholder="City, province, or region" class="rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-amber-500 focus:ring-3 focus:ring-amber-100">
                                <select v-model="selectedIncome" class="rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition focus:border-amber-500 focus:ring-3 focus:ring-amber-100">
                                    <option v-for="income in incomeRequirements" :key="income" :value="income">
                                        {{ income === 'all' ? 'All income rules' : income }}
                                    </option>
                                </select>
                                <select v-model="deadlineFilter" class="rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition focus:border-amber-500 focus:ring-3 focus:ring-amber-100">
                                    <option value="all">All deadlines</option>
                                    <option value="next_7_days">Due in 7 days</option>
                                    <option value="next_30_days">Due in 30 days</option>
                                    <option value="no_deadline">No deadline</option>
                                </select>
                            </div>

                            <button type="button" class="rounded-md bg-slate-900 px-3.5 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800" @click="resetFilters">
                                Reset filters
                            </button>
                        </div>
                    </section>

                    <section class="space-y-4">
                        <div v-if="scholarships.length === 0" class="student-card p-6">
                            <div class="rounded-lg border border-dashed border-slate-300 bg-slate-50 p-6">
                                <p class="text-sm font-bold text-slate-900">
                                    No published scholarships yet
                                </p>
                                <p class="mt-1 text-sm leading-6 text-slate-500">
                                    Once providers publish programs, they will show up here with match and document readiness hints.
                                </p>
                                <a
                                    href="/dashboard/profile"
                                    class="mt-4 inline-flex rounded-md bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800"
                                >
                                    Review profile while waiting
                                </a>
                            </div>
                        </div>

                        <div v-else-if="filteredScholarships.length === 0" class="student-card p-6">
                            <div class="rounded-lg border border-dashed border-slate-300 bg-slate-50 p-6">
                                <p class="text-sm font-bold text-slate-900">
                                    {{ scholarshipView === 'saved' ? 'No saved scholarships yet' : 'No scholarships match your filters' }}
                                </p>
                                <p class="mt-1 text-sm leading-6 text-slate-500">
                                    {{ scholarshipView === 'saved' ? 'Save scholarships from the finder to build a shortlist here.' : 'Try removing one filter or searching with a broader course, location, or category.' }}
                                </p>
                                <button
                                    type="button"
                                    class="mt-4 rounded-md bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800"
                                    @click="resetFilters"
                                >
                                    Reset filters
                                </button>
                            </div>
                        </div>

                        <div v-else class="grid items-stretch gap-4">
                            <article
                                v-for="scholarship in filteredScholarships"
                                :key="scholarship.id"
                                class="group flex h-full flex-col overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm transition hover:border-slate-400 hover:shadow-md"
                            >
                                <div class="scholarship-card-head relative overflow-hidden p-4 text-white">
                                    <div class="relative z-10 flex items-center justify-between gap-3">
                                        <p class="truncate text-xs font-bold uppercase tracking-[0.16em] text-amber-300">
                                            {{ scholarship.category || 'Scholarship opportunity' }}
                                        </p>
                                        <div class="flex shrink-0 items-center gap-2">
                                            <button
                                                type="button"
                                                :disabled="savingId === scholarship.id"
                                                :aria-label="scholarship.is_saved ? `Remove ${scholarship.title} from saved programs` : `Save ${scholarship.title}`"
                                                :title="scholarship.is_saved ? 'Remove from saved programs' : 'Save program'"
                                                class="inline-flex h-9 w-9 items-center justify-center rounded-md border border-white/20 bg-white/10 text-sm text-white transition hover:bg-white/20 disabled:cursor-not-allowed disabled:opacity-60"
                                                @click="toggleSave(scholarship)"
                                            >
                                                <i :class="[scholarship.is_saved ? 'fa-solid' : 'fa-regular', savingId === scholarship.id ? 'fa-spinner fa-spin' : 'fa-bookmark']"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <div class="relative z-10 mt-3 flex min-w-0 items-center gap-3">
                                        <img
                                            :src="scholarshipLogo(scholarship)"
                                            data-scholarship-logo
                                            :alt="scholarship.title"
                                            class="h-13 w-13 shrink-0 rounded-md bg-white object-contain p-1.5 shadow-sm ring-1 ring-white/20"
                                            @error="handleScholarshipImageError"
                                        >
                                        <div class="min-w-0 flex-1">
                                            <h3 class="line-clamp-2 font-display text-lg font-bold leading-snug text-white">
                                                {{ scholarship.title }}
                                            </h3>
                                            <a
                                                v-if="scholarship.provider?.id"
                                                :href="`/dashboard/providers/${scholarship.provider.id}`"
                                                class="mt-1 block truncate text-sm font-semibold text-slate-300 transition hover:text-amber-200"
                                            >
                                                {{ scholarship.provider.name || 'Scholarship Provider' }}
                                            </a>
                                            <p v-else class="mt-1 truncate text-sm font-semibold text-slate-300">Scholarship Provider</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="flex flex-1 flex-col p-4">
                                    <div class="flex flex-wrap items-center gap-2">
                                        <p v-if="isUpcomingProgram(scholarship)" class="rounded-md bg-sky-100 px-2.5 py-1 text-xs font-bold text-sky-800">
                                            <i class="fa-regular fa-clock mr-1"></i>
                                            Upcoming
                                        </p>
                                        <p class="rounded-md bg-amber-100 px-2.5 py-1 text-xs font-bold text-amber-900">
                                            {{ scholarship.eligibility_match?.score ?? 0 }}% profile match
                                        </p>
                                        <p class="rounded-md bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-700">
                                            <i class="fa-regular fa-calendar mr-1"></i>
                                            {{ compactDeadlineLabel(scholarship) }}
                                        </p>
                                    </div>

                                    <p
                                        v-if="scholarship.description"
                                        class="mt-3 line-clamp-2 max-w-5xl text-sm leading-6 text-slate-600"
                                    >
                                        {{ scholarship.description }}
                                    </p>

                                    <div class="mt-4 grid gap-px overflow-hidden rounded-md border border-slate-200 bg-slate-200 sm:grid-cols-2 xl:grid-cols-4">
                                        <div class="flex min-w-0 items-start gap-2.5 bg-slate-50 p-3">
                                            <i class="fa-solid fa-user-graduate mt-1 w-4 shrink-0 text-center text-amber-700" aria-hidden="true"></i>
                                            <div class="min-w-0">
                                                <p class="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">Eligible learners</p>
                                                <p class="mt-1 truncate text-sm font-bold text-slate-900">{{ targetApplicantLabel(scholarship) }}</p>
                                            </div>
                                        </div>
                                        <div class="flex min-w-0 items-start gap-2.5 bg-slate-50 p-3">
                                            <i class="fa-solid fa-chart-line mt-1 w-4 shrink-0 text-center text-amber-700" aria-hidden="true"></i>
                                            <div class="min-w-0">
                                                <p class="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">Academic rule</p>
                                                <p class="mt-1 truncate text-sm font-bold text-slate-900">{{ academicRequirementLabel(scholarship) }}</p>
                                            </div>
                                        </div>
                                        <div class="flex min-w-0 items-start gap-2.5 bg-slate-50 p-3">
                                            <i class="fa-solid fa-location-dot mt-1 w-4 shrink-0 text-center text-amber-700" aria-hidden="true"></i>
                                            <div class="min-w-0">
                                                <p class="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">Coverage</p>
                                                <p :title="coverageLabel(scholarship)" class="mt-1 truncate text-sm font-bold text-slate-900">{{ coverageLabel(scholarship) }}</p>
                                            </div>
                                        </div>
                                        <div class="flex min-w-0 items-start gap-2.5 bg-slate-50 p-3">
                                            <i class="fa-solid fa-users mt-1 w-4 shrink-0 text-center text-amber-700" aria-hidden="true"></i>
                                            <div class="min-w-0">
                                                <p class="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">Planned recipients</p>
                                                <p class="mt-1 truncate text-sm font-bold text-slate-900">{{ availableSlotsLabel(scholarship) }}</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mt-4 flex items-center gap-3 rounded-md border border-amber-200 bg-amber-50 p-3.5">
                                        <span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-amber-200 text-amber-900">
                                            <i :class="[primaryBenefitIcon(scholarship), 'text-sm']"></i>
                                        </span>
                                        <div class="min-w-0 flex-1">
                                            <div class="flex items-center justify-between gap-2">
                                                <p class="text-[10px] font-bold uppercase tracking-[0.14em] text-amber-800">
                                                    Benefits
                                                </p>
                                                <span
                                                    v-if="remainingBenefitCount(scholarship)"
                                                    class="shrink-0 rounded-md bg-white px-2 py-0.5 text-[11px] font-bold text-amber-900 ring-1 ring-amber-200"
                                                >
                                                    +{{ remainingBenefitCount(scholarship) }} more
                                                </span>
                                            </div>
                                            <p class="mt-1 line-clamp-1 text-sm font-bold text-slate-950">
                                                {{ primaryBenefitTitle(scholarship) }}
                                            </p>
                                            <p class="mt-1 line-clamp-1 text-xs font-semibold text-slate-600">
                                                {{ primaryBenefitDetails(scholarship) }}
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <div class="mt-auto grid grid-cols-2 gap-2 border-t border-slate-100 p-3">
                                    <a
                                        :href="`/dashboard/scholarships/${scholarship.id}`"
                                        class="rounded-md border border-slate-300 bg-white px-3 py-2.5 text-center text-sm font-bold text-slate-700 transition hover:bg-slate-100"
                                    >
                                        View details
                                    </a>
                                    <a
                                        v-if="scholarship.has_applied"
                                        href="/dashboard/applications"
                                        class="rounded-md bg-slate-200 px-3 py-2.5 text-center text-sm font-bold text-slate-600"
                                    >
                                        Application
                                    </a>
                                    <a
                                        v-else-if="canStartApplication(scholarship)"
                                        :href="`/dashboard/applications/start/${scholarship.id}`"
                                        class="rounded-md bg-slate-900 px-3 py-2.5 text-center text-sm font-bold text-white transition hover:bg-slate-800"
                                    >
                                        Apply
                                    </a>
                                    <span
                                        v-else
                                        :title="applicationBlockedLabel(scholarship)"
                                        class="rounded-md bg-slate-200 px-3 py-2.5 text-center text-sm font-bold text-slate-600"
                                    >
                                        {{ applicationBlockedActionLabel(scholarship) }}
                                    </span>
                                </div>
                            </article>
                        </div>
                    </section>
                </section>

            </div>
        </section>
    </main>

    <Teleport to="body">
        <div
            v-if="previewScholarship"
            class="fixed inset-0 z-[100] overflow-y-auto bg-slate-950/70 p-4 backdrop-blur-sm"
            role="dialog"
            aria-modal="true"
            aria-labelledby="scholarship-preview-title"
            @click.self="closeScholarshipPreview"
        >
            <div class="flex min-h-full items-center justify-center" @click.self="closeScholarshipPreview">
                <section class="flex max-h-[calc(100vh-2rem)] w-full max-w-3xl flex-col overflow-hidden rounded-lg border border-slate-200 bg-white shadow-2xl">
                    <header class="scholarship-card-head relative shrink-0 overflow-hidden p-5 text-white">
                        <div class="relative z-10 flex items-start justify-between gap-4">
                            <div class="min-w-0">
                                <p class="truncate text-xs font-bold uppercase tracking-[0.16em] text-amber-300">
                                    {{ previewScholarship.category || 'Scholarship opportunity' }}
                                </p>
                                <div class="mt-3 flex min-w-0 items-center gap-3">
                                    <img
                                        :src="scholarshipLogo(previewScholarship)"
                                        data-scholarship-logo
                                        :alt="previewScholarship.title"
                                        class="h-14 w-14 shrink-0 rounded-md bg-white object-contain p-1.5 shadow-sm"
                                        @error="handleScholarshipImageError"
                                    >
                                    <div class="min-w-0">
                                        <h2 id="scholarship-preview-title" class="font-display text-xl font-bold leading-snug text-white sm:text-2xl">
                                            {{ previewScholarship.title }}
                                        </h2>
                                        <p class="mt-1 truncate text-sm font-semibold text-slate-300">
                                            {{ previewScholarship.provider?.name || 'Scholarship Provider' }}
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <button
                                type="button"
                                aria-label="Close scholarship preview"
                                class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-md border border-white/20 bg-white/10 text-white transition hover:bg-white/20"
                                @click="closeScholarshipPreview"
                            >
                                <i class="fa-solid fa-xmark"></i>
                            </button>
                        </div>
                    </header>

                    <div class="overflow-y-auto p-5">
                        <div class="flex flex-wrap gap-2">
                            <span class="rounded-md bg-amber-100 px-2.5 py-1 text-xs font-bold text-amber-900">
                                {{ previewScholarship.eligibility_match?.score ?? 0 }}% profile match
                            </span>
                            <span class="rounded-md bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-700">
                                <i class="fa-regular fa-calendar mr-1"></i>
                                {{ compactDeadlineLabel(previewScholarship) }}
                            </span>
                            <span v-if="previewScholarship.distance_label" class="rounded-md bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-700">
                                <i class="fa-solid fa-location-dot mr-1"></i>
                                {{ previewScholarship.distance_label }}
                            </span>
                        </div>

                        <p class="mt-4 text-sm leading-6 text-slate-600">
                            {{ previewScholarship.description || 'Open the full scholarship page to review the complete program information.' }}
                        </p>

                        <div class="mt-4 flex items-start gap-3 rounded-md border border-amber-200 bg-amber-50 p-3">
                            <span class="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-amber-200 text-xs text-amber-900">
                                <i class="fa-solid fa-calendar-days" aria-hidden="true"></i>
                            </span>
                            <div>
                                <p class="text-xs font-bold uppercase tracking-[0.12em] text-amber-800">Recipient support period</p>
                                <p class="mt-1 text-sm font-bold text-slate-950">
                                    {{ previewScholarship.support_starts_at && previewScholarship.support_ends_at ? `${previewScholarship.support_starts_at} - ${previewScholarship.support_ends_at}` : 'Exact dates not yet announced' }}
                                </p>
                                <p class="mt-1 text-xs leading-5 text-slate-600">This is separate from the application deadline shown above.</p>
                            </div>
                        </div>

                        <div :class="['mt-4 flex items-start gap-3 rounded-md border p-3', previewScholarship.eligibility_match?.is_eligible === false ? 'border-rose-200 bg-rose-50' : 'border-slate-200 bg-slate-50']">
                            <span :class="['grid h-8 w-8 shrink-0 place-items-center rounded-md text-xs', previewScholarship.eligibility_match?.is_eligible === false ? 'bg-rose-100 text-rose-700' : 'bg-slate-950 text-amber-300']">
                                <i :class="eligibilityOverview(previewScholarship.eligibility_match).state === 'ready' ? 'fa-solid fa-check' : 'fa-solid fa-circle-info'" aria-hidden="true"></i>
                            </span>
                            <div>
                                <p class="text-xs font-bold uppercase tracking-[0.12em] text-slate-500">{{ eligibilityOverview(previewScholarship.eligibility_match).label }}</p>
                                <p class="mt-1 text-sm leading-6 text-slate-700">
                                    {{ eligibilityOverview(previewScholarship.eligibility_match).description }} Profile verification and application availability still apply.
                                </p>
                            </div>
                        </div>

                        <section class="mt-5">
                            <h3 class="text-sm font-bold text-slate-950">
                                Program snapshot
                            </h3>
                            <dl class="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                                <div class="rounded-md border border-slate-200 bg-slate-50 p-3">
                                    <dt class="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-400">
                                        Intended for
                                    </dt>
                                    <dd class="mt-1 text-sm font-bold text-slate-900">
                                        {{ targetApplicantLabel(previewScholarship) }}
                                    </dd>
                                </div>
                                <div class="rounded-md border border-slate-200 bg-slate-50 p-3">
                                    <dt class="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-400">
                                        Academic
                                    </dt>
                                    <dd class="mt-1 text-sm font-bold text-slate-900">
                                        {{ academicRequirementLabel(previewScholarship) }}
                                    </dd>
                                </div>
                                <div class="rounded-md border border-slate-200 bg-slate-50 p-3">
                                    <dt class="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-400">
                                        Available slots
                                    </dt>
                                    <dd class="mt-1 text-sm font-bold text-slate-900">
                                        {{ previewScholarship.slots_available !== null && previewScholarship.slots_available !== undefined ? `${previewScholarship.slots_available} slots` : 'Not specified' }}
                                    </dd>
                                </div>
                                <div class="rounded-md border border-slate-200 bg-slate-50 p-3">
                                    <dt class="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-400">
                                        Application
                                    </dt>
                                    <dd class="mt-1 text-sm font-bold text-slate-900">
                                        {{ applicationModeLabel(previewScholarship.application_mode) }}
                                    </dd>
                                    <p class="mt-1 text-xs leading-5 text-slate-500">{{ applicationModeDescription(previewScholarship.application_mode) }}</p>
                                </div>
                            </dl>
                        </section>

                        <section class="mt-5">
                            <div class="flex items-center justify-between gap-3">
                                <h3 class="text-sm font-bold text-slate-950">
                                    Benefits and support
                                </h3>
                                <span class="text-xs font-semibold text-slate-500">
                                    {{ previewScholarship.benefits?.length ?? 0 }} listed
                                </span>
                            </div>
                            <div v-if="previewBenefitItems(previewScholarship).length" class="mt-3 grid gap-2 sm:grid-cols-2">
                                <article
                                    v-for="benefit in previewBenefitItems(previewScholarship)"
                                    :key="`${benefit.type}-${benefit.title}`"
                                    class="flex items-start gap-3 rounded-md border border-amber-100 bg-amber-50 p-3"
                                >
                                    <span class="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-amber-200 text-amber-900">
                                        <i :class="[benefitIcon(benefit), 'text-xs']"></i>
                                    </span>
                                    <div class="min-w-0">
                                        <p class="text-sm font-bold text-slate-950">
                                            {{ benefit.title }}
                                        </p>
                                        <p class="mt-1 text-xs font-semibold leading-5 text-slate-600">
                                            {{ benefitDetailLine(benefit) }}
                                        </p>
                                    </div>
                                </article>
                            </div>
                            <div v-else class="mt-3 rounded-md border border-amber-100 bg-amber-50 p-3">
                                <p class="text-sm font-bold text-slate-950">
                                    {{ primaryBenefitTitle(previewScholarship) }}
                                </p>
                                <p class="mt-1 text-xs font-semibold text-slate-600">
                                    {{ primaryBenefitDetails(previewScholarship) }}
                                </p>
                            </div>
                            <p v-if="hiddenPreviewBenefitCount(previewScholarship)" class="mt-2 text-xs font-semibold text-amber-800">
                                +{{ hiddenPreviewBenefitCount(previewScholarship) }} additional benefit{{ hiddenPreviewBenefitCount(previewScholarship) === 1 ? '' : 's' }} shown on the full page
                            </p>
                        </section>

                        <section class="mt-5">
                            <h3 class="text-sm font-bold text-slate-950">
                                Eligibility and application
                            </h3>
                            <dl class="mt-3 divide-y divide-slate-200 overflow-hidden rounded-md border border-slate-200">
                                <div class="grid gap-1 px-3 py-2.5 sm:grid-cols-[10rem_1fr] sm:gap-4">
                                    <dt class="text-xs font-bold text-slate-500">School type</dt>
                                    <dd class="text-sm font-semibold text-slate-900">
                                        {{ optionSummary(previewScholarship.eligible_school_types, 'Any school type') }}
                                    </dd>
                                </div>
                                <div class="grid gap-1 px-3 py-2.5 sm:grid-cols-[10rem_1fr] sm:gap-4">
                                    <dt class="text-xs font-bold text-slate-500">Course or track</dt>
                                    <dd class="text-sm font-semibold text-slate-900">
                                        {{ optionSummary(previewScholarship.eligible_courses, 'Any course or track') }}
                                    </dd>
                                </div>
                                <div class="grid gap-1 px-3 py-2.5 sm:grid-cols-[10rem_1fr] sm:gap-4">
                                    <dt class="text-xs font-bold text-slate-500">Year or grade</dt>
                                    <dd class="text-sm font-semibold text-slate-900">
                                        {{ optionSummary(previewScholarship.eligible_year_levels, 'Any year or grade') }}
                                    </dd>
                                </div>
                                <div class="grid gap-1 px-3 py-2.5 sm:grid-cols-[10rem_1fr] sm:gap-4">
                                    <dt class="text-xs font-bold text-slate-500">Location coverage</dt>
                                    <dd class="text-sm font-semibold text-slate-900">
                                        {{ coverageLabel(previewScholarship) }}
                                    </dd>
                                </div>
                                <div class="grid gap-1 px-3 py-2.5 sm:grid-cols-[10rem_1fr] sm:gap-4">
                                    <dt class="text-xs font-bold text-slate-500">Program location</dt>
                                    <dd class="text-sm font-semibold text-slate-900">
                                        {{ previewScholarship.location_address || previewScholarship.location_name || 'Not specified' }}
                                    </dd>
                                </div>
                                <div class="grid gap-1 px-3 py-2.5 sm:grid-cols-[10rem_1fr] sm:gap-4">
                                    <dt class="text-xs font-bold text-slate-500">Selection process</dt>
                                    <dd class="text-sm font-semibold text-slate-900">
                                        {{ selectionProcessLabel(previewScholarship) }}
                                    </dd>
                                </div>
                                <div class="grid gap-1 px-3 py-2.5 sm:grid-cols-[10rem_1fr] sm:gap-4">
                                    <dt class="text-xs font-bold text-slate-500">Documents</dt>
                                    <dd class="text-sm font-semibold text-slate-900">
                                        {{ requirementSummary(previewScholarship) }}
                                    </dd>
                                </div>
                            </dl>
                        </section>

                        <p
                            v-if="!previewScholarship.has_applied && !canStartApplication(previewScholarship)"
                            class="mt-4 rounded-md bg-slate-100 px-3 py-2 text-xs font-semibold leading-5 text-slate-600"
                        >
                            {{ applicationBlockedLabel(previewScholarship) }}
                        </p>
                    </div>

                    <footer class="flex shrink-0 flex-col-reverse gap-2 border-t border-slate-200 bg-slate-50 p-4 sm:flex-row sm:justify-end">
                        <button
                            type="button"
                            class="rounded-md border border-slate-300 bg-white px-4 py-2.5 text-sm font-bold text-slate-700 transition hover:bg-slate-100"
                            @click="closeScholarshipPreview"
                        >
                            Close
                        </button>
                        <a
                            :href="`/dashboard/scholarships/${previewScholarship.id}`"
                            class="rounded-md bg-slate-900 px-4 py-2.5 text-center text-sm font-bold text-white transition hover:bg-slate-800"
                        >
                            More details
                            <i class="fa-solid fa-arrow-right ml-2 text-xs"></i>
                        </a>
                    </footer>
                </section>
            </div>
        </div>
    </Teleport>

    <Teleport to="body">
        <div
            v-if="showComparisonModal"
            class="fixed inset-0 z-[70] overflow-y-auto bg-slate-950/75 px-3 py-5 sm:px-5"
            @click.self="closeComparisonModal"
        >
            <div class="flex min-h-full items-center justify-center" @click.self="closeComparisonModal">
                <section
                    role="dialog"
                    aria-modal="true"
                    aria-labelledby="scholarship-comparison-title"
                    class="flex max-h-[92vh] w-full max-w-6xl flex-col overflow-hidden rounded-lg bg-white shadow-2xl"
                >
                    <header class="shrink-0 bg-slate-950 px-5 py-4 text-white sm:px-6">
                        <div class="flex items-start justify-between gap-4">
                            <div>
                                <p class="text-[10px] font-bold uppercase tracking-[0.18em] text-amber-300">
                                    Scholarship comparison
                                </p>
                                <h2 id="scholarship-comparison-title" class="mt-1 font-display text-2xl font-bold">
                                    {{ comparisonStep === 'select' ? 'Choose two eligible programs' : 'Compare your options' }}
                                </h2>
                                <p class="mt-1 max-w-3xl text-sm leading-6 text-slate-300">
                                    {{ comparisonStep === 'select'
                                        ? 'Only scholarships that match your required eligibility criteria are shown.'
                                        : 'Use this summary as a guide, then open the full program before applying.' }}
                                </p>
                            </div>
                            <button
                                type="button"
                                aria-label="Close scholarship comparison"
                                class="grid h-9 w-9 shrink-0 place-items-center rounded-md border border-white/20 bg-white/10 text-white transition hover:bg-white/20"
                                @click="closeComparisonModal"
                            >
                                <i class="fa-solid fa-xmark" aria-hidden="true"></i>
                            </button>
                        </div>
                    </header>

                    <div v-if="comparisonStep === 'select'" class="min-h-0 flex-1 overflow-y-auto p-5 sm:p-6">
                        <div class="flex flex-col gap-2 rounded-md border border-slate-200 bg-slate-50 p-4 sm:flex-row sm:items-center sm:justify-between">
                            <div>
                                <p class="text-sm font-bold text-slate-950">
                                    {{ comparisonSelection.length }} of 2 selected
                                </p>
                                <p class="mt-1 text-xs leading-5 text-slate-500">
                                    Select the two programs you want to place side by side.
                                </p>
                            </div>
                            <span class="w-fit rounded-md bg-emerald-100 px-3 py-1.5 text-xs font-bold text-emerald-800">
                                {{ eligibleScholarships.length }} eligible program{{ eligibleScholarships.length === 1 ? '' : 's' }}
                            </span>
                        </div>

                        <div v-if="eligibleScholarships.length >= 2" class="mt-4 grid gap-3 md:grid-cols-2">
                            <button
                                v-for="scholarship in eligibleScholarships"
                                :key="scholarship.id"
                                type="button"
                                :disabled="comparisonSelection.length === 2 && !isComparisonSelected(scholarship.id)"
                                :class="[
                                    'flex min-h-32 items-start gap-3 rounded-md border p-4 text-left transition disabled:cursor-not-allowed disabled:opacity-45',
                                    isComparisonSelected(scholarship.id)
                                        ? 'border-slate-950 bg-slate-950 text-white shadow-sm'
                                        : 'border-slate-200 bg-white text-slate-950 hover:border-slate-400 hover:bg-slate-50',
                                ]"
                                @click="toggleComparisonSelection(scholarship.id)"
                            >
                                <img
                                    :src="scholarshipLogo(scholarship)"
                                    data-scholarship-logo
                                    :alt="scholarship.title"
                                    class="h-12 w-12 shrink-0 rounded-md bg-white object-contain p-1.5 ring-1 ring-slate-200"
                                    @error="handleScholarshipImageError"
                                >
                                <span class="min-w-0 flex-1">
                                    <span class="flex items-start justify-between gap-3">
                                        <span class="line-clamp-2 text-sm font-bold leading-5">{{ scholarship.title }}</span>
                                        <span :class="['grid h-5 w-5 shrink-0 place-items-center rounded border text-[10px]', isComparisonSelected(scholarship.id) ? 'border-amber-300 bg-amber-300 text-slate-950' : 'border-slate-300 bg-white text-transparent']">
                                            <i class="fa-solid fa-check" aria-hidden="true"></i>
                                        </span>
                                    </span>
                                    <span :class="['mt-1 block truncate text-xs', isComparisonSelected(scholarship.id) ? 'text-slate-300' : 'text-slate-500']">
                                        {{ scholarship.provider?.name || 'Scholarship provider' }}
                                    </span>
                                    <span class="mt-3 flex flex-wrap gap-2">
                                        <span :class="['rounded px-2 py-1 text-[10px] font-bold', isComparisonSelected(scholarship.id) ? 'bg-white/10 text-amber-300' : 'bg-emerald-100 text-emerald-800']">
                                            {{ scholarship.eligibility_match?.score ?? 0 }}% profile match
                                        </span>
                                        <span :class="['rounded px-2 py-1 text-[10px] font-bold', isComparisonSelected(scholarship.id) ? 'bg-white/10 text-slate-200' : 'bg-slate-100 text-slate-600']">
                                            {{ compactDeadlineLabel(scholarship) }}
                                        </span>
                                    </span>
                                </span>
                            </button>
                        </div>

                        <div v-else class="mt-4 rounded-md border border-dashed border-slate-300 bg-slate-50 p-6 text-center">
                            <span class="mx-auto grid h-11 w-11 place-items-center rounded-md bg-slate-200 text-slate-600">
                                <i class="fa-solid fa-code-compare" aria-hidden="true"></i>
                            </span>
                            <p class="mt-3 text-sm font-bold text-slate-950">Two eligible programs are needed</p>
                            <p class="mt-1 text-sm leading-6 text-slate-500">
                                Complete your profile or wait for more matching scholarships before using comparison.
                            </p>
                        </div>
                    </div>

                    <div v-else class="min-h-0 flex-1 overflow-y-auto p-4 sm:p-6">
                        <div class="overflow-hidden rounded-md border border-slate-200">
                            <div class="grid grid-cols-2 gap-px bg-slate-200 sm:grid-cols-[10rem_repeat(2,minmax(0,1fr))]">
                                <div class="hidden bg-slate-50 p-4 sm:block"></div>
                                <article
                                    v-for="scholarship in selectedComparisonScholarships"
                                    :key="`heading-${scholarship.id}`"
                                    class="bg-white p-4"
                                >
                                    <div class="flex items-center gap-3">
                                        <img
                                            :src="scholarshipLogo(scholarship)"
                                            data-scholarship-logo
                                            :alt="scholarship.title"
                                            class="h-11 w-11 shrink-0 rounded-md bg-white object-contain p-1 ring-1 ring-slate-200"
                                            @error="handleScholarshipImageError"
                                        >
                                        <div class="min-w-0">
                                            <h3 class="line-clamp-2 text-sm font-bold leading-5 text-slate-950">{{ scholarship.title }}</h3>
                                            <p class="mt-0.5 truncate text-[11px] text-slate-500">{{ scholarship.provider?.name || 'Scholarship provider' }}</p>
                                        </div>
                                    </div>
                                    <a :href="`/dashboard/scholarships/${scholarship.id}`" class="mt-3 inline-flex items-center gap-1 text-xs font-bold text-slate-700 hover:text-slate-950">
                                        View full details <i class="fa-solid fa-arrow-right text-[9px]" aria-hidden="true"></i>
                                    </a>
                                </article>

                                <template v-for="row in comparisonRows" :key="row.key">
                                    <div class="col-span-2 flex items-center gap-2 bg-slate-50 px-4 py-2.5 text-xs font-bold text-slate-700 sm:col-span-1 sm:items-start sm:py-4">
                                        <i :class="[row.icon, 'mt-0.5 text-amber-700']" aria-hidden="true"></i>
                                        {{ row.label }}
                                    </div>
                                    <div
                                        v-for="scholarship in selectedComparisonScholarships"
                                        :key="`${row.key}-${scholarship.id}`"
                                        class="bg-white p-4 text-xs font-semibold leading-5 text-slate-700 sm:text-sm sm:leading-6"
                                    >
                                        {{ comparisonValue(scholarship, row.key) }}
                                    </div>
                                </template>
                            </div>
                        </div>
                    </div>

                    <footer class="flex shrink-0 flex-col-reverse gap-2 border-t border-slate-200 bg-slate-50 p-4 sm:flex-row sm:items-center sm:justify-between">
                        <button
                            type="button"
                            class="rounded-md border border-slate-300 bg-white px-4 py-2.5 text-sm font-bold text-slate-700 transition hover:bg-slate-100"
                            @click="returnToComparisonSelection"
                        >
                            {{ comparisonStep === 'compare' ? 'Choose different programs' : 'Cancel' }}
                        </button>
                        <button
                            v-if="comparisonStep === 'select'"
                            type="button"
                            :disabled="!canStartComparison"
                            class="rounded-md bg-slate-950 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-40"
                            @click="showComparison"
                        >
                            Compare selected
                            <i class="fa-solid fa-arrow-right ml-2 text-xs" aria-hidden="true"></i>
                        </button>
                        <p v-else class="text-xs font-semibold text-slate-500">
                            Eligibility does not guarantee final provider approval.
                        </p>
                    </footer>
                </section>
            </div>
        </div>
    </Teleport>
</template>

<style scoped>
.scholarship-card-head {
    background:
        radial-gradient(circle at 92% -20%, rgba(252, 211, 77, 0.28), transparent 38%),
        linear-gradient(120deg, #081426 0%, #10243d 100%);
}
</style>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import ApplicantPageHeader from '../components/ApplicantPageHeader.vue';
import ApplicantSidebar from '../components/ApplicantSidebar.vue';
import ConfirmationDialog from '../components/ConfirmationDialog.vue';
import EligibilityConditionList from '../components/EligibilityConditionList.vue';
import FilePreviewModal from '../components/FilePreviewModal.vue';
import PrivacyNoticeCard from '../components/PrivacyNoticeCard.vue';
import RecipientAgreementPanel from '../components/RecipientAgreementPanel.vue';
import ScholarshipBenefitsPanel from '../components/ScholarshipBenefitsPanel.vue';
import TermsAgreement from '../components/TermsAgreement.vue';
import { labelFromKey } from '../support/display';
import { eligibilityCriterionPresentation, eligibilityOverview } from '../support/applicantEligibility';
import { showPortalToast } from '../support/portalToast';
import { progressStateLabel, selectionPlanFor } from '../support/selectionPlan';
import { useConfirmationDialog } from '../composables/useConfirmationDialog';
import { hasUnsentApplicationAnswers, withPreparationContext } from '../support/scholarshipPreparationContext';

const isLoading = ref(true);
const isSubmitting = ref(false);
const isUploadingDocument = ref(false);
const errorMessage = ref('');
const user = ref(null);
const stats = ref({
    available_scholarships: 0,
    applications: 0,
    saved: 0,
});
const scholarships = ref([]);
const applications = ref([]);
const preparedDocuments = ref([]);
const profileReadiness = ref({
    complete: false,
    completed: 0,
    total: 0,
    percent: 0,
    missing: [],
});
const currentStep = ref(0);
const activeWorkspace = ref('applications');
const selectedScholarshipId = ref('');
const documentChecklist = ref([]);
const applicationAnswers = ref({});
const notes = ref('');
const applicationTermsAccepted = ref(false);
const documentTermsAccepted = ref(false);
const documentFileInput = ref(null);
const activeUploadRequirement = ref('');
const previewDocument = ref(null);
const { confirmation, requestConfirmation, confirmConfirmation, cancelConfirmation } = useConfirmationDialog();
let allowApplicationNavigation = false;
let pendingApplicationNavigation = false;
const hasUnsentAnswers = computed(() => Boolean(selectedScholarshipId.value)
    && hasUnsentApplicationAnswers(applicationAnswers.value, notes.value, applicationTermsAccepted.value));
const applicationBusy = computed(() => isSubmitting.value || isUploadingDocument.value);
const applicationUrlParams = new URLSearchParams(window.location.search);
const requestedScholarshipId = document.getElementById('app')?.dataset.scholarshipId
    || applicationUrlParams.get('scholarship');
const requestedApplicationView = applicationUrlParams.get('view');
const applicationView = ['active', 'action', 'completed'].includes(requestedApplicationView)
    ? requestedApplicationView
    : 'active';
const applicationViewContent = {
    active: {
        eyebrow: 'Active applications',
        title: 'Follow your applications and support',
        description: 'See applications in progress and scholarships with ongoing recipient support.',
        sectionTitle: 'Active applications and scholarships',
        emptyTitle: 'No active applications',
        emptyText: 'Browse scholarships when you are ready to begin a new pre-screening application.',
    },
    action: {
        eyebrow: 'Needs my action',
        title: 'Complete your pending tasks',
        description: 'Corrections, agreements, schedules, and monitoring requirements that need your response.',
        sectionTitle: 'Waiting for your response',
        emptyTitle: 'You have no pending tasks',
        emptyText: 'Nothing currently requires your response. Provider updates will appear here when action is needed.',
    },
    completed: {
        eyebrow: 'Completed applications',
        title: 'Review recorded outcomes',
        description: 'Open completed, declined, withdrawn, or awarded application records.',
        sectionTitle: 'Application history',
        emptyTitle: 'No completed applications',
        emptyText: 'Applications appear here after their selection workflow is closed.',
    },
}[applicationView];

const steps = [
    { label: 'Program', detail: 'Review the program', icon: 'fa-solid fa-graduation-cap' },
    { label: 'Eligibility', detail: 'Check the criteria', icon: 'fa-solid fa-user-check' },
    { label: 'Requirements', detail: 'Files and questions', icon: 'fa-solid fa-folder-open' },
    { label: 'Confirm', detail: 'Check and submit', icon: 'fa-solid fa-paper-plane' },
];
const applicationModeOptions = [
    { value: 'online', label: 'Portal review' },
    { value: 'onsite', label: 'Portal review with in-person verification' },
    { value: 'provider_review', label: 'Profile review only' },
];
const selectedScholarship = computed(() => scholarships.value.find((scholarship) => scholarship.id === Number(selectedScholarshipId.value)));
const preparationHref = (href) => withPreparationContext(href, selectedScholarship.value?.id);
const scholarshipRequirementsHref = computed(() => selectedScholarship.value ? `/dashboard/scholarships/${selectedScholarship.value.id}/application` : null);
const selectedRequirements = computed(() => selectedScholarship.value?.application_mode === 'provider_review'
    ? []
    : documentRequirements(selectedScholarship.value?.requirements));
const selectedOptionalRequirements = computed(() => selectedScholarship.value?.application_mode === 'provider_review'
    ? []
    : documentRequirements(selectedScholarship.value?.optional_requirements)
        .filter((requirement) => !selectedRequirements.value.includes(requirement)));
const selectedApplicationQuestions = computed(() => (
    Array.isArray(selectedScholarship.value?.application_questions)
        ? selectedScholarship.value.application_questions
        : []
).filter((question) => question?.id && question?.prompt));
const requiredApplicationQuestionsAnswered = computed(() => selectedApplicationQuestions.value
    .filter((question) => question.required)
    .every((question) => String(applicationAnswers.value[question.id] ?? '').trim() !== ''));
const answeredApplicationQuestionCount = computed(() => selectedApplicationQuestions.value
    .filter((question) => String(applicationAnswers.value[question.id] ?? '').trim() !== '')
    .length);
const appliedScholarshipIds = computed(() => new Set(applications.value.map((application) => application.scholarship?.id).filter(Boolean)));
const selectedAlreadyApplied = computed(() => selectedScholarship.value && appliedScholarshipIds.value.has(selectedScholarship.value.id));
const allDocumentsChecked = computed(() => selectedRequirements.value.every((requirement) => documentChecklist.value.includes(requirement)));
const canApply = computed(() => profileReadiness.value.complete && profileReadiness.value.verified === true);
const profileApplicationMessage = computed(() => !profileReadiness.value.complete
    ? 'Complete your student profile before applying.'
    : 'Your applicant profile must be verified before you can apply. Review Supporting Evidence in your profile.');
const selectedEligibilityConditions = computed(() => selectedScholarship.value?.eligibility_match?.condition_results ?? []);
const selectedIsEligible = computed(() => selectedScholarship.value?.eligibility_match?.is_eligible !== false);
const selectedEligibilityOverview = computed(() => eligibilityOverview(selectedScholarship.value?.eligibility_match));
const selectedCanStartApplication = computed(() => {
    if (!selectedScholarship.value) {
        return false;
    }

    if (selectedScholarship.value.can_start_application !== undefined) {
        return canApply.value && Boolean(selectedScholarship.value.can_start_application);
    }

    return canApply.value && selectedIsEligible.value && !selectedAlreadyApplied.value;
});
const selectedEligibilityMessage = computed(() => selectedEligibilityOverview.value.description);
const preparedDocumentsByName = computed(() => new Map(
    preparedDocuments.value.map((document) => [document.document_name, document]),
));
const selectedPreparedDocuments = computed(() => selectedRequirements.value
    .filter((requirement) => preparedDocumentsByName.value.has(requirement)));
const selectedPreparedOptionalDocuments = computed(() => selectedOptionalRequirements.value
    .filter((requirement) => preparedDocumentsByName.value.has(requirement)));
const selectedMissingPreparedDocuments = computed(() => selectedRequirements.value
    .filter((requirement) => !preparedDocumentsByName.value.has(requirement)));
const selectedDocumentReadiness = computed(() => selectedRequirements.value.length === 0
    ? 100
    : Math.round((selectedPreparedDocuments.value.length / selectedRequirements.value.length) * 100));
const selectedApplicationMode = computed(() => applicationModeLabel(selectedScholarship.value?.application_mode));
const selectedApplicationModeDescription = computed(() => applicationModeDescription(selectedScholarship.value?.application_mode));
const selectedNeedsOriginalVerification = computed(() => ['onsite', 'hybrid'].includes(selectedScholarship.value?.application_mode));
const selectedSelectionPlan = computed(() => selectionPlanFor(selectedScholarship.value));
const selectedEligibilityUrl = computed(() => selectedScholarship.value
    ? `/dashboard/scholarships/${selectedScholarship.value.id}/eligibility`
    : '/dashboard/scholarships');
const selectedEligibilityCriteria = computed(() => {
    const scholarship = selectedScholarship.value;

    if (!scholarship) {
        return [];
    }

    const checks = new Map((scholarship.eligibility_match?.criteria ?? [])
        .map((criterion) => [criterion.key, criterion]));
    const rules = [
        { key: 'education_level', label: 'Education level', value: scholarship.eligible_education_levels, icon: 'fa-solid fa-school' },
        { key: 'year_level', label: 'Grade / year level', value: scholarship.eligible_year_levels, icon: 'fa-solid fa-layer-group' },
        { key: 'course', label: 'Track, strand, or course', value: scholarship.eligible_courses, icon: 'fa-solid fa-book-open' },
        { key: 'school_type', label: 'School type', value: scholarship.eligible_school_types, icon: 'fa-solid fa-building-columns' },
        { key: 'location', label: 'Location coverage', value: scholarship.eligible_locations, icon: 'fa-solid fa-location-dot' },
        { key: 'income', label: 'Household income', value: scholarship.income_requirement, icon: 'fa-solid fa-wallet' },
        { key: 'academic', label: 'Academic requirement', value: academicRequirementLabel(scholarship), icon: 'fa-solid fa-chart-line', formatted: true },
        { key: 'current_scholarship_support', label: 'Other scholarship support', value: checks.get('current_scholarship_support')?.requirement, icon: 'fa-solid fa-hand-holding-heart' },
        { key: 'enrollment_status', label: 'Current enrollment', value: checks.get('enrollment_status')?.requirement, icon: 'fa-solid fa-user-graduate' },
    ];

    return rules.filter((rule) => checks.has(rule.key)).map((rule) => {
        const check = checks.get(rule.key);
        const presentation = eligibilityCriterionPresentation(check);

        return {
            ...rule,
            value: rule.formatted ? rule.value : eligibilityRuleLabel(rule.value, check),
            status: presentation.status,
            statusLabel: presentation.label,
            modeLabel: presentation.modeLabel,
            comparison: check?.comparison || check?.note || '',
        };
    });
});
const applicationQueue = computed(() => [...applications.value].sort((first, second) => {
    const firstNeedsCorrection = Number(first.correction_status === 'requested');
    const secondNeedsCorrection = Number(second.correction_status === 'requested');

    if (firstNeedsCorrection !== secondNeedsCorrection) {
        return secondNeedsCorrection - firstNeedsCorrection;
    }

    const firstActiveSchedule = Number(Boolean(!first.workflow?.is_closed && primarySchedule(first)?.status === 'scheduled'));
    const secondActiveSchedule = Number(Boolean(!second.workflow?.is_closed && primarySchedule(second)?.status === 'scheduled'));

    if (firstActiveSchedule !== secondActiveSchedule) {
        return secondActiveSchedule - firstActiveSchedule;
    }

    const stageRank = { screening: 5, formal_application: 4, exam: 3, interview: 2, decision: 1, complete: 0 };
    const firstRank = first.workflow?.is_closed ? -1 : (stageRank[first.workflow?.current_stage] ?? 0);
    const secondRank = second.workflow?.is_closed ? -1 : (stageRank[second.workflow?.current_stage] ?? 0);

    return secondRank - firstRank;
}));
const visibleApplicationQueue = computed(() => applicationQueue.value.filter((application) => {
    if (applicationView === 'action') {
        return applicationNeedsAction(application);
    }

    if (applicationView === 'completed') {
        return Boolean(application.workflow?.is_closed) && !applicationIsActive(application);
    }

    return applicationIsActive(application);
}));
const nextStepLabel = computed(() => steps[currentStep.value + 1]?.label
    ? `Continue to ${steps[currentStep.value + 1].label}`
    : 'Continue');
const canGoNext = computed(() => {
    if (!selectedScholarship.value) {
        return false;
    }

    if (!canApply.value) {
        return false;
    }

    if (currentStep.value === 0) {
        return true;
    }

    if (!selectedCanStartApplication.value) {
        return false;
    }

    if (currentStep.value === 2) {
        return allDocumentsChecked.value && requiredApplicationQuestionsAnswered.value;
    }

    return true;
});
const canSubmitApplication = computed(() => allDocumentsChecked.value
    && requiredApplicationQuestionsAnswered.value
    && selectedCanStartApplication.value
    && applicationTermsAccepted.value);

function canOpenWizardStep(index) {
    if (index === 0) {
        return true;
    }

    if (index === 1) {
        return canApply.value && Boolean(selectedScholarship.value);
    }

    if (!selectedCanStartApplication.value) {
        return false;
    }

    if (index === 2) {
        return true;
    }

    if (index === 3) {
        return allDocumentsChecked.value && requiredApplicationQuestionsAnswered.value;
    }

    return false;
}

function inferGradeScale(value) {
    if (value === null || value === undefined || value === '') {
        return '';
    }

    return Number(value) <= 5 ? 'grade_point' : 'percentage';
}

function academicRequirementLabel(scholarship) {
    if (scholarship?.minimum_grade_label) {
        return scholarship.minimum_grade_label;
    }

    if (!scholarship?.minimum_gwa) {
        return 'Not listed yet';
    }

    return inferGradeScale(scholarship.minimum_gwa) === 'grade_point'
        ? `Maximum GWA/GPA ${scholarship.minimum_gwa}`
        : `Minimum average ${scholarship.minimum_gwa}%`;
}

function goToWizardStep(index) {
    if (canOpenWizardStep(index)) {
        currentStep.value = index;
        errorMessage.value = '';
        return;
    }

    if (selectedScholarship.value?.application_limit_reached) {
        errorMessage.value = 'This scholarship has reached its application limit.';
        return;
    }

    if (!canApply.value) {
        errorMessage.value = profileApplicationMessage.value;
        return;
    }

    if (!selectedIsEligible.value) {
        errorMessage.value = selectedEligibilityMessage.value;
        return;
    }

    if (selectedAlreadyApplied.value) {
        errorMessage.value = 'You already submitted an application for this scholarship.';
        return;
    }

    errorMessage.value = 'Complete the current application step before moving forward.';
}

function openWorkspace(workspace) {
    activeWorkspace.value = workspace;
    errorMessage.value = '';
}

function formatAmount(amount) {
    if (amount === null || amount === undefined || amount === '') {
        return 'Amount not set';
    }

    return new Intl.NumberFormat('en-PH', {
        style: 'currency',
        currency: 'PHP',
        maximumFractionDigits: 2,
    }).format(Number(amount));
}

function statusLabel(status) {
    const labels = {
        approved: 'Qualified for formal application',
        waitlisted: 'Waitlisted alternate',
        withdrawn: 'Withdrawn',
        rejected: 'Not qualified',
        exam_qualified: 'Qualified for exam',
        exam_scheduled: 'Exam scheduled',
        exam_taken: 'Exam taken',
        exam_passed: 'Passed exam',
        exam_failed: 'Failed exam',
        interview_failed: 'Failed interview',
        distribution_scheduled: 'Distribution scheduled',
        disbursed: 'Distributed',
        benefits_terminated: 'Benefits stopped',
    };

    if (labels[status]) {
        return labels[status];
    }

    return String(status ?? 'submitted')
        .replace(/_/g, ' ')
        .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function applicationStatusLabel(application) {
    if (application?.status === 'benefits_terminated') {
        return statusLabel(application.status);
    }

    return application?.workflow?.final_outcome_label
        ?? application?.workflow?.current_stage_label
        ?? statusLabel(application?.status);
}

function applicationNextAction(application) {
    if (application?.correction_status === 'requested') {
        return 'Update the information requested by the provider';
    }

    return application?.workflow?.next_action?.label
        ?? application?.status_progress?.next_action
        ?? 'Open the application for the latest update.';
}

function applicationNextActionDetails(application) {
    if (application?.correction_status === 'requested') {
        return {
            actor_label: 'You',
            description: application?.correction_message
                || 'Review the provider request, update the affected details or files, then send your response.',
        };
    }

    return application?.workflow?.next_action
        ?? application?.status_progress?.next_action_details
        ?? {};
}

function applicationNeedsAction(application) {
    const nextAction = applicationNextActionDetails(application);
    const actorLabel = String(nextAction.actor_label ?? nextAction.actor ?? '').toLowerCase();

    return application?.correction_status === 'requested'
        || Boolean(application?.recipient_agreement?.can_respond || application?.requires_student_response)
        || Number(application?.recipient_monitoring?.pending_count ?? 0) > 0
        || actorLabel === 'you'
        || actorLabel.includes('applicant')
        || actorLabel.includes('recipient');
}

function applicationHasOngoingSupport(application) {
    const monitoring = application?.recipient_monitoring;
    const agreementStatus = String(application?.recipient_agreement?.status ?? '').toLowerCase();
    const supportStatus = String(monitoring?.support_status ?? '').toLowerCase();

    return Boolean(monitoring?.eligible)
        && agreementStatus !== 'declined'
        && ['active', 'renewed'].includes(supportStatus);
}

function applicationIsActive(application) {
    return !application?.workflow?.is_closed
        || Boolean(application?.recipient_agreement?.can_respond || application?.requires_student_response)
        || applicationHasOngoingSupport(application);
}

function applicationCardAction(application) {
    if (application?.correction_status === 'requested') {
        return {
            eyebrow: 'Your next step',
            title: 'Update the requested information',
            description: application?.correction_message || 'Review the provider request and submit the corrected information.',
            icon: 'fa-solid fa-pen-to-square',
        };
    }

    if (application?.recipient_agreement?.can_respond || application?.requires_student_response) {
        return {
            eyebrow: 'Agreement needed',
            title: 'Review your recipient agreement',
            description: 'Confirm the scholarship support and recipient responsibilities before continuing.',
            icon: 'fa-solid fa-file-signature',
        };
    }

    const pendingMonitoring = Number(application?.recipient_monitoring?.pending_count ?? 0);

    if (pendingMonitoring > 0) {
        return {
            eyebrow: 'Monitoring update',
            title: `${pendingMonitoring} requirement${pendingMonitoring === 1 ? '' : 's'} ready for submission`,
            description: 'Open Monitoring to submit the requested academic update.',
            icon: 'fa-solid fa-graduation-cap',
        };
    }

    if (applicationHasOngoingSupport(application)) {
        return {
            eyebrow: 'Recipient support',
            title: application?.recipient_monitoring?.support_status_label || 'Scholarship support is active',
            description: 'Review requirements, benefit releases, and provider notices in Monitoring.',
            icon: 'fa-solid fa-award',
        };
    }

    const nextAction = applicationNextActionDetails(application);
    const actor = String(nextAction.actor_label ?? nextAction.actor ?? '').toLowerCase();

    return {
        eyebrow: application?.workflow?.is_closed
            ? 'Final result'
            : (actor.includes('provider') ? 'Provider step' : 'Your next step'),
        title: applicationNextAction(application),
        description: nextAction.description || '',
        icon: application?.workflow?.is_closed ? 'fa-solid fa-flag-checkered' : 'fa-solid fa-arrow-right',
    };
}

function applicationActionUrl(application) {
    if (application?.recipient_monitoring?.eligible
        && (Number(application.recipient_monitoring.pending_count ?? 0) > 0 || applicationHasOngoingSupport(application))) {
        return `/dashboard/monitoring/${application.id}`;
    }

    const url = new URL(
        application?.detail_url || `/dashboard/applications/${application?.id}`,
        window.location.origin,
    );

    if (application?.recipient_agreement?.can_respond || application?.requires_student_response) {
        url.searchParams.set('action', 'agreement');
    } else if (!application?.workflow?.is_closed && primarySchedule(application)?.status === 'scheduled') {
        url.searchParams.set('section', 'schedule');
    } else if (application?.correction_status === 'requested') {
        url.searchParams.set('section', 'overview');
    }

    return `${url.pathname}${url.search}`;
}

function applicationStageLabel(application) {
    if (application?.recipient_agreement?.can_respond || application?.requires_student_response) {
        return 'Recipient agreement';
    }

    if (applicationHasOngoingSupport(application)) {
        return 'Recipient support';
    }

    return application?.workflow?.current_stage_label
        || application?.status_progress?.label
        || statusLabel(application?.status);
}

function applicationActionLabel(application) {
    if (application?.correction_status === 'requested') {
        return 'Review update';
    }

    if (application?.recipient_agreement?.can_respond || application?.requires_student_response) {
        return 'Review agreement';
    }

    if (Number(application?.recipient_monitoring?.pending_count ?? 0) > 0) {
        return 'Submit update';
    }

    if (applicationHasOngoingSupport(application)) {
        return 'Open support';
    }

    if (application?.workflow?.is_closed) {
        return 'View outcome';
    }

    if (primarySchedule(application)?.status === 'scheduled') {
        return 'Open schedule';
    }

    return 'Open application';
}

function statusClass(status) {
    if (['approved', 'awarded', 'disbursed', 'renewed', 'exam_passed'].includes(status)) {
        return 'bg-emerald-100 text-emerald-800';
    }

    if (['withdrawn', 'rejected', 'not_awarded', 'exam_failed', 'interview_failed', 'benefits_terminated'].includes(status)) {
        return 'bg-rose-100 text-rose-800';
    }

    if (['under_review', 'shortlisted', 'interview', 'exam_qualified', 'exam_scheduled', 'exam_taken', 'distribution_scheduled', 'waitlisted'].includes(status)) {
        return 'bg-slate-100 text-slate-700';
    }

    return 'bg-amber-100 text-amber-800';
}

function applicationSchedules(application) {
    return Array.isArray(application?.schedules) ? application.schedules : [];
}

function primarySchedule(application) {
    const schedules = applicationSchedules(application);
    const active = schedules.find((schedule) => schedule.status === 'scheduled');

    return active ?? schedules[schedules.length - 1] ?? null;
}

function scheduleTypeLabel(type) {
    return {
        exam: 'Scholarship exam',
        interview: 'Interview',
    }[type] ?? labelFromKey(type);
}

function scheduleTypeIcon(type) {
    return {
        exam: 'fa-solid fa-clipboard-check',
        interview: 'fa-solid fa-comments',
    }[type] ?? 'fa-solid fa-calendar-day';
}

function scheduleModeLabel(mode) {
    return {
        onsite: 'On-site',
        online: 'Online',
        hybrid: 'On-site and online',
        provider_managed: 'Provider-managed',
    }[mode] ?? labelFromKey(mode);
}

function schedulePreviewLabel(schedule) {
    if (schedule?.status === 'scheduled') {
        return 'Upcoming activity';
    }

    if (schedule?.status === 'completed') {
        return 'Latest completed activity';
    }

    return 'Latest schedule update';
}

function timelineStepClass(state) {
    if (state === 'complete') {
        return 'border-slate-900 bg-slate-900 text-white';
    }

    if (state === 'current') {
        return 'border-amber-300 bg-amber-50 text-slate-950';
    }

    if (['stopped', 'skipped'].includes(state)) {
        return 'border-rose-200 bg-rose-50 text-rose-700';
    }

    return 'border-slate-200 bg-white text-slate-500';
}

function applicationModeLabel(value) {
    const normalizedValue = value === 'hybrid' ? 'onsite' : value;

    return applicationModeOptions.find((option) => option.value === normalizedValue)?.label ?? labelFromKey(value || 'not_listed');
}

function applicationModeDescription(value) {
    return {
        online: 'Your profile and required files are reviewed through the portal.',
        onsite: 'Upload copies first and keep the originals ready. Do not bring them yet; the provider will send the date and location if an in-person check is needed.',
        hybrid: 'Upload copies first and keep the originals ready. Do not bring them yet; the provider will send the date and location if an in-person check is needed.',
        provider_review: 'The provider checks your profile first. No program files are required for this initial review.',
    }[value] ?? 'The provider will review your portal submission before its formal application process.';
}

function selectionStageDescription(stage) {
    return {
        screening: 'The provider checks your profile, eligibility, and submitted files.',
        formal_application: 'Follow the provider instructions and prepare any originals it requests.',
        exam: 'Applicants who pass the review receive the exam schedule and instructions.',
        interview: 'Applicants who reach this stage receive the interview schedule and instructions.',
        decision: 'The provider records whether you are selected, waitlisted, or not selected.',
    }[stage?.value] ?? stage?.detail ?? 'The provider will share instructions if you reach this stage.';
}

function criteriaLabel(value) {
    const items = Array.isArray(value)
        ? value
        : String(value ?? '').split(/\r?\n|,/);

    const labels = items
        .map((item) => String(item).trim())
        .filter(Boolean)
        .map(labelFromKey);

    return labels.length ? labels.join(', ') : 'No restriction';
}

function eligibilityRuleLabel(value, criterion) {
    if (eligibilityCriterionPresentation(criterion).status === 'info') {
        return 'Open to all';
    }

    return criteriaLabel(value);
}

function eligibilityCriterionCardClass(status) {
    return {
        pass: 'border-emerald-200 bg-emerald-50/50',
        fail: 'border-rose-300 bg-rose-50/60',
        missing: 'border-amber-300 bg-amber-50/60',
        preferred: 'border-amber-300 bg-amber-50/60',
        review: 'border-amber-300 bg-amber-50/60',
        info: 'border-sky-200 bg-sky-50/60',
    }[status] ?? 'border-slate-200 bg-white';
}

function eligibilityCriterionIconClass(status) {
    return {
        pass: 'bg-emerald-100 text-emerald-700',
        fail: 'bg-rose-100 text-rose-700',
        missing: 'bg-amber-100 text-amber-800',
        preferred: 'bg-amber-100 text-amber-800',
        review: 'bg-amber-100 text-amber-800',
        info: 'bg-sky-100 text-sky-700',
    }[status] ?? 'bg-slate-100 text-slate-700';
}

function eligibilityCriterionBadgeClass(status) {
    return {
        pass: 'bg-emerald-100 text-emerald-800',
        fail: 'bg-rose-100 text-rose-700',
        missing: 'bg-amber-100 text-amber-800',
        preferred: 'bg-amber-100 text-amber-800',
        review: 'bg-amber-100 text-amber-800',
        info: 'bg-sky-100 text-sky-800',
    }[status] ?? 'bg-slate-100 text-slate-600';
}

function documentRequirements(requirements) {
    if (!requirements) {
        return [];
    }

    return String(requirements)
        .split(/\r?\n|,/)
        .map((requirement) => requirement.trim())
        .filter(Boolean);
}

function preparedDocumentFor(requirement) {
    return preparedDocumentsByName.value.get(requirement) ?? null;
}

function formatFileSize(size) {
    const bytes = Number(size ?? 0);

    if (!bytes) {
        return 'Size unavailable';
    }

    if (bytes < 1024 * 1024) {
        return `${Math.max(1, Math.round(bytes / 1024))} KB`;
    }

    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function syncDocumentChecklist() {
    documentChecklist.value = [...selectedPreparedDocuments.value];
}

function nextStep() {
    if (currentStep.value < steps.length - 1 && canGoNext.value) {
        currentStep.value += 1;
    }
}

function previousStep() {
    if (currentStep.value > 0) {
        currentStep.value -= 1;
    }
}

function resetWizard() {
    selectedScholarshipId.value = '';
    documentChecklist.value = [];
    applicationAnswers.value = {};
    notes.value = '';
    applicationTermsAccepted.value = false;
    documentTermsAccepted.value = false;
    activeUploadRequirement.value = '';
    errorMessage.value = '';
    currentStep.value = 0;

    if (window.location.search) {
        window.history.replaceState({}, '', (window.portalPathname?.() ?? window.location.pathname));
    }
}

function openDocumentUpload(requirement) {
    errorMessage.value = '';

    if (!documentTermsAccepted.value) {
        showPortalToast({
            type: 'error',
            title: 'Terms required',
            message: 'Accept the document upload terms before choosing a file.',
        });
        return;
    }

    activeUploadRequirement.value = requirement;

    if (documentFileInput.value) {
        documentFileInput.value.value = '';
        documentFileInput.value.click();
    }
}

async function handleDocumentFileChange(event) {
    const file = event.target.files?.[0] ?? null;
    const requirement = activeUploadRequirement.value;

    if (!file || !requirement) {
        activeUploadRequirement.value = '';
        return;
    }

    if (file.size > 5 * 1024 * 1024) {
        errorMessage.value = 'Choose a file that is 5 MB or smaller.';
        event.target.value = '';
        activeUploadRequirement.value = '';
        return;
    }

    isUploadingDocument.value = true;
    errorMessage.value = '';

    const payload = new FormData();
    payload.append('document_name', requirement);
    payload.append('document_file', file);
    payload.append('terms_accepted', '1');

    try {
        const response = await window.axios.post('/dashboard/student-documents', payload, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
        const savedDocument = response.data.document;

        preparedDocuments.value = [
            savedDocument,
            ...preparedDocuments.value.filter((document) => document.document_name !== savedDocument.document_name),
        ];
        syncDocumentChecklist();
    } catch (handledError) {
        void handledError;
    } finally {
        isUploadingDocument.value = false;
        activeUploadRequirement.value = '';
        event.target.value = '';
    }
}

async function loadApplications() {
    isLoading.value = true;
    errorMessage.value = '';

    try {
        const response = await window.axios.get('/dashboard/applications/data');

        user.value = response.data.user;
        profileReadiness.value = response.data.profile_readiness ?? profileReadiness.value;
        stats.value = response.data.stats;
        scholarships.value = response.data.scholarships;
        applications.value = response.data.applications;
        preparedDocuments.value = response.data.prepared_documents ?? [];

        activeWorkspace.value = requestedScholarshipId ? 'new' : 'applications';

        if (requestedScholarshipId) {
            const requestedScholarship = scholarships.value.find((scholarship) => scholarship.id === Number(requestedScholarshipId));

            if (requestedScholarship) {
                selectedScholarshipId.value = String(requestedScholarship.id);
                documentChecklist.value = [];
                applicationAnswers.value = {};
                notes.value = '';
                currentStep.value = 0;

                if (appliedScholarshipIds.value.has(requestedScholarship.id)) {
                    errorMessage.value = 'You already submitted an application for this scholarship.';
                    currentStep.value = 0;
                } else if (!canApply.value) {
                    errorMessage.value = profileApplicationMessage.value;
                    currentStep.value = 0;
                } else if (requestedScholarship.eligibility_match?.is_eligible === false) {
                    errorMessage.value = selectedEligibilityMessage.value;
                    currentStep.value = 0;
                }
            } else {
                errorMessage.value = 'The selected scholarship was not found. Please choose a published scholarship from the scholarship page.';
            }
        }
    } catch (error) {
        errorMessage.value = error.response?.data?.message ?? 'Unable to load applications.';
    } finally {
        isLoading.value = false;
    }
}

async function submitApplication() {
    if (applicationBusy.value || confirmation.open) return;

    if (selectedScholarship.value?.application_limit_reached) {
        errorMessage.value = 'This scholarship has reached its application limit.';
        currentStep.value = 0;
        return;
    }

    if (!canApply.value) {
        errorMessage.value = profileApplicationMessage.value;
        return;
    }

    if (!selectedIsEligible.value) {
        errorMessage.value = selectedEligibilityMessage.value;
        return;
    }

    if (!selectedScholarship.value || !allDocumentsChecked.value) {
        return;
    }

    if (!requiredApplicationQuestionsAnswered.value) {
        errorMessage.value = 'Answer every required provider question before submitting.';
        currentStep.value = 2;
        return;
    }

    if (!applicationTermsAccepted.value) {
        errorMessage.value = 'Please accept the application terms before submitting.';
        return;
    }

    if (!canSubmitApplication.value) return;

    const scholarship = selectedScholarship.value;
    const confirmed = await requestConfirmation({
        title: 'Submit this application?',
        message: `Your application for "${scholarship.title}" will be sent to the provider for review. You cannot edit your answers after submitting.`,
        confirmLabel: 'Submit application',
        cancelLabel: 'Keep reviewing',
    });
    if (!confirmed || applicationBusy.value || selectedScholarship.value !== scholarship
        || !canSubmitApplication.value || !selectedIsEligible.value || scholarship.application_limit_reached) return;

    isSubmitting.value = true;
    errorMessage.value = '';

    try {
        await window.axios.post('/dashboard/applications', {
            scholarship_id: scholarship.id,
            document_checklist: documentChecklist.value,
            application_answers: selectedApplicationQuestions.value.map((question) => ({
                question_id: question.id,
                answer: String(applicationAnswers.value[question.id] ?? '').trim(),
            })),
            notes: notes.value,
            terms_accepted: applicationTermsAccepted.value ? '1' : '',
        });

        await loadApplications();
        resetWizard();
        activeWorkspace.value = 'applications';
    } catch (error) {
        if (error.response?.data?.profile_readiness) {
            profileReadiness.value = error.response.data.profile_readiness;
        }
        errorMessage.value = error.response?.data?.message ?? 'Unable to submit your application. Please try again.';
    } finally {
        isSubmitting.value = false;
    }
}

async function trackApplicationStart(scholarship) {
    if (!scholarship || appliedScholarshipIds.value.has(scholarship.id)) {
        return;
    }

    try {
        await window.axios.post(`/dashboard/scholarships/${scholarship.id}/application-start`);
    } catch {
        // Tracking must never interrupt the application wizard.
    }
}

function protectUnsentApplication(event) {
    if (!allowApplicationNavigation && (hasUnsentAnswers.value || applicationBusy.value)) {
        event.preventDefault();
        event.returnValue = '';
    }
}

async function handleApplicationNavigation(event) {
    if (allowApplicationNavigation || (!hasUnsentAnswers.value && !applicationBusy.value)
        || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const link = event.target?.closest?.('a[href]');
    if (!link || link.target === '_blank' || link.hasAttribute('download')) return;
    const destination = new URL(link.href, window.location.href);
    if (destination.pathname === (window.portalPathname?.() ?? window.location.pathname) && destination.search === window.location.search) return;
    event.preventDefault();
    if (applicationBusy.value) {
        showPortalToast({ type: 'warning', message: 'Wait for the current upload or submission to finish before leaving.' });
        return;
    }
    if (confirmation.open || pendingApplicationNavigation) return;
    pendingApplicationNavigation = true;
    const leave = await requestConfirmation({
        eyebrow: 'Unsent application answers', title: 'Leave this application form?',
        message: 'Your answers, notes, and confirmation are not saved until you submit. Uploaded files remain in My Documents, but unsent answers will be lost.',
        confirmLabel: 'Discard answers and leave', cancelLabel: 'Keep editing', tone: 'danger',
    });
    pendingApplicationNavigation = false;
    if (leave) {
        allowApplicationNavigation = true;
        window.location.assign(destination.href);
    }
}

onMounted(() => {
    window.addEventListener('beforeunload', protectUnsentApplication);
    document.addEventListener('click', handleApplicationNavigation);
    loadApplications();
});
onBeforeUnmount(() => {
    window.removeEventListener('beforeunload', protectUnsentApplication);
    document.removeEventListener('click', handleApplicationNavigation);
    cancelConfirmation();
});

watch(selectedScholarship, (scholarship) => {
    applicationAnswers.value = {};

    if (!scholarship) {
        documentChecklist.value = [];
        return;
    }

    syncDocumentChecklist();
    applicationTermsAccepted.value = false;
    trackApplicationStart(scholarship);
});
</script>

<template>
    <main class="student-shell">
        <ApplicantSidebar />

        <ConfirmationDialog v-bind="confirmation" @confirm="confirmConfirmation" @cancel="cancelConfirmation" />

        <FilePreviewModal
            :file="previewDocument"
            :title="previewDocument?.document_name || previewDocument?.original_name || 'Application file'"
            context="Prepared application file"
            @close="previewDocument = null"
        />

        <section class="student-page">
            <div class="student-container">
                <ApplicantPageHeader
                    :eyebrow="applicationViewContent.eyebrow"
                    :title="applicationViewContent.title"
                    :description="applicationViewContent.description"
                    icon="fa-solid fa-file-signature"
                    action-href="/dashboard/scholarships"
                    action-label="Browse scholarships"
                />

                <PrivacyNoticeCard context="applications" compact />

                <nav v-if="activeWorkspace === 'new'" class="student-card mt-5 grid gap-1.5 p-1.5 sm:grid-cols-2" aria-label="Application workspace">
                    <button
                        type="button"
                        :class="[
                            'flex min-h-14 items-center justify-between gap-3 rounded-md px-4 py-3 text-left transition',
                            activeWorkspace === 'applications'
                                ? 'bg-slate-900 text-white shadow-sm'
                                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-950',
                        ]"
                        :aria-pressed="activeWorkspace === 'applications'"
                        @click="openWorkspace('applications')"
                    >
                        <span class="flex items-center gap-3">
                            <i class="fa-solid fa-layer-group text-sm" aria-hidden="true"></i>
                            <span>
                                <span class="block text-sm font-bold">My applications</span>
                                <span class="mt-0.5 block text-xs opacity-70">Track status and schedules</span>
                            </span>
                        </span>
                        <span :class="['rounded-md px-2.5 py-1 text-xs font-bold', activeWorkspace === 'applications' ? 'bg-white/15 text-white' : 'bg-slate-100 text-slate-600']">
                            {{ applications.length }}
                        </span>
                    </button>
                    <button
                        type="button"
                        :class="[
                            'flex min-h-14 items-center justify-between gap-3 rounded-md px-4 py-3 text-left transition',
                            activeWorkspace === 'new'
                                ? 'bg-slate-900 text-white shadow-sm'
                                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-950',
                        ]"
                        :aria-pressed="activeWorkspace === 'new'"
                        @click="openWorkspace('new')"
                    >
                        <span class="flex items-center gap-3">
                            <i class="fa-solid fa-plus text-sm" aria-hidden="true"></i>
                            <span>
                                <span class="block text-sm font-bold">Start pre-screening</span>
                                <span class="mt-0.5 block text-xs opacity-70">Review, prepare, and submit</span>
                            </span>
                        </span>
                        <span v-if="selectedScholarship" :class="['h-2.5 w-2.5 rounded-full', activeWorkspace === 'new' ? 'bg-amber-300' : 'bg-amber-500']" title="Scholarship selected"></span>
                    </button>
                </nav>

                <div v-if="isLoading" class="student-card mt-6 p-6 text-sm text-slate-500">
                    Loading pre-screening form...
                </div>

                <div v-else class="mt-6 space-y-6">
                    <div v-if="errorMessage" class="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm font-semibold text-rose-700 shadow-sm">
                        {{ errorMessage }}
                    </div>

                    <template v-if="activeWorkspace === 'new'">
                    <div v-if="scholarshipRequirementsHref" data-application-preparation-handoff class="flex flex-wrap items-center justify-between gap-3 rounded-md border border-slate-300 bg-white px-5 py-4">
                        <div><p class="text-sm font-bold text-slate-950">{{ selectedScholarship.title }}</p><p class="mt-1 text-xs leading-5 text-slate-500">This scholarship is selected. Answers are not saved until you submit.</p></div>
                        <a :href="scholarshipRequirementsHref" class="inline-flex min-h-11 items-center gap-2 text-xs font-bold text-slate-700 hover:underline"><i class="fa-solid fa-arrow-left text-[10px]" aria-hidden="true"></i>Back to scholarship requirements</a>
                    </div>
                    <div v-if="!canApply" class="student-card border-amber-200 bg-amber-50/90 p-5">
                        <div class="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                            <div>
                                <p class="text-xs font-bold uppercase text-amber-700">
                                    {{ profileReadiness.complete ? 'Profile verification required' : 'Profile required' }}
                                </p>
                                <h3 class="mt-2 text-lg font-bold text-slate-950">
                                    {{ profileReadiness.complete ? 'Verify your profile before applying' : 'Complete your student profile before applying' }}
                                </h3>
                                <p v-if="!profileReadiness.complete" class="mt-2 text-sm leading-5 text-slate-700">
                                    Your profile is {{ profileReadiness.percent }}% complete. Missing:
                                    {{ profileReadiness.missing.slice(0, 4).map((field) => field.label).join(', ') }}{{ profileReadiness.missing.length > 4 ? ', and more' : '' }}.
                                </p>
                                <p v-else class="mt-2 text-sm leading-5 text-slate-700">
                                    {{ profileReadiness.verification_status === 'pending'
                                        ? 'Your supporting evidence is awaiting review. You can apply once your profile is verified.'
                                        : 'Upload or replace your required supporting evidence, then wait for an authorized reviewer to verify your profile.' }}
                                </p>
                            </div>
                            <a
                                :href="preparationHref(profileReadiness.complete ? '/dashboard/profile?section=verification' : '/dashboard/profile')"
                                class="inline-flex justify-center rounded-md bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800"
                            >
                                {{ profileReadiness.complete ? 'Review supporting evidence' : 'Complete profile' }}
                            </a>
                        </div>
                    </div>

                    <section class="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
                        <header class="bg-slate-950 px-5 py-4 text-white sm:px-6">
                            <div class="flex items-center gap-4">
                                <span class="grid h-11 w-11 shrink-0 place-items-center rounded-md bg-amber-400 text-slate-950">
                                    <i :class="steps[currentStep].icon" aria-hidden="true"></i>
                                </span>
                                <div class="min-w-0 flex-1">
                                    <p class="text-[11px] font-bold uppercase tracking-[0.16em] text-amber-300">Step {{ currentStep + 1 }} of {{ steps.length }}</p>
                                    <h3 class="mt-1 text-lg font-bold">{{ steps[currentStep].label }}</h3>
                                    <p class="mt-0.5 truncate text-xs text-slate-300">{{ selectedScholarship?.title || 'Select a scholarship to begin' }}</p>
                                </div>
                            </div>
                        </header>

                        <nav class="grid gap-2 border-b border-slate-200 bg-slate-50 p-3 sm:grid-cols-2 xl:grid-cols-4" aria-label="Pre-screening process">
                            <button
                                v-for="(step, index) in steps"
                                :key="step.label"
                                type="button"
                                :disabled="!canOpenWizardStep(index)"
                                :aria-current="currentStep === index ? 'step' : undefined"
                                :class="[
                                    'flex min-w-0 items-center gap-3 rounded-md border px-3 py-2.5 text-left transition disabled:cursor-not-allowed disabled:opacity-45',
                                    currentStep === index
                                        ? 'border-slate-900 bg-white text-slate-950 shadow-sm'
                                        : index < currentStep
                                            ? 'border-slate-200 bg-white text-slate-700'
                                            : 'border-transparent text-slate-500 hover:border-slate-200 hover:bg-white hover:text-slate-950',
                                ]"
                                @click="goToWizardStep(index)"
                            >
                                <span :class="['grid h-8 w-8 shrink-0 place-items-center rounded-md text-xs font-bold', currentStep === index ? 'bg-amber-400 text-slate-950' : index < currentStep ? 'bg-slate-900 text-white' : 'bg-slate-200 text-slate-500']">
                                    <i v-if="index < currentStep" class="fa-solid fa-check" aria-hidden="true"></i>
                                    <i v-else :class="step.icon" aria-hidden="true"></i>
                                </span>
                                <span class="min-w-0">
                                    <span class="block truncate text-sm font-bold">{{ step.label }}</span>
                                    <span class="mt-0.5 block truncate text-[11px] opacity-70">{{ step.detail }}</span>
                                </span>
                            </button>
                        </nav>

                        <div class="bg-white p-5 sm:p-6">
                            <div v-if="currentStep === 0 && !selectedScholarship">
                                <div class="grid min-h-64 place-items-center rounded-md border border-dashed border-slate-300 bg-slate-50 px-5 py-10 text-center">
                                    <div class="max-w-md">
                                        <span class="mx-auto grid h-12 w-12 place-items-center rounded-md bg-white text-amber-700 shadow-sm ring-1 ring-slate-200">
                                            <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                                        </span>
                                        <h3 class="mt-4 text-lg font-bold text-slate-950">Choose a scholarship first</h3>
                                        <p class="mt-2 text-sm leading-6 text-slate-600">Open Scholarships, review a program, and select Start pre-screening. Your chosen program will appear here automatically.</p>
                                        <a href="/dashboard/scholarships" class="mt-5 inline-flex items-center justify-center gap-2 rounded-md bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800">
                                            Browse scholarships
                                            <i class="fa-solid fa-arrow-right text-xs" aria-hidden="true"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <div v-else-if="currentStep === 0 && selectedScholarship" class="grid gap-5">
                                <section class="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
                                    <header class="relative flex flex-col gap-4 overflow-hidden bg-slate-950 p-4 text-white sm:flex-row sm:items-center sm:justify-between sm:p-5">
                                        <span class="pointer-events-none absolute -right-12 -top-16 h-40 w-40 rounded-full border-[24px] border-amber-300/10" aria-hidden="true"></span>
                                        <div class="flex min-w-0 items-start gap-4">
                                            <img :src="selectedScholarship.image_url" :alt="selectedScholarship.title" class="h-12 w-12 shrink-0 rounded-md bg-white object-contain p-1.5 ring-1 ring-white/20">
                                            <div class="min-w-0">
                                                <p class="text-[11px] font-bold uppercase tracking-[0.16em] text-amber-300">{{ selectedScholarship.provider?.name || 'Scholarship Provider' }}</p>
                                                <h3 class="mt-1 text-xl font-bold leading-tight text-white">{{ selectedScholarship.title }}</h3>
                                            </div>
                                        </div>
                                        <div class="relative flex w-full shrink-0 flex-row gap-2 sm:w-auto sm:items-center">
                                            <span :class="['rounded-md px-3 py-2 text-center text-xs font-bold ring-1', selectedEligibilityOverview.state === 'ready' ? 'bg-emerald-400/15 text-emerald-200 ring-emerald-300/25' : (selectedIsEligible ? 'bg-amber-400/15 text-amber-200 ring-amber-300/25' : 'bg-rose-400/15 text-rose-200 ring-rose-300/25')]">{{ selectedEligibilityOverview.label }}</span>
                                            <a :href="`/dashboard/scholarships/${selectedScholarship.id}`" class="inline-flex flex-1 items-center justify-center gap-2 rounded-md bg-white px-3 py-2 text-xs font-bold text-slate-900 transition hover:bg-amber-100 sm:flex-none">
                                                More details
                                                <i class="fa-solid fa-arrow-right text-[10px]" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </header>

                                    <div class="grid gap-4 p-4 sm:p-5">
                                        <section>
                                            <p class="student-kicker">Support package</p>
                                            <h4 class="mt-1 text-lg font-bold text-slate-950">What recipients receive</h4>
                                            <p class="mt-1 text-sm text-slate-500">Financial and non-cash support included by the provider.</p>
                                            <ScholarshipBenefitsPanel
                                                v-if="selectedScholarship.benefits?.length"
                                                class="mt-3"
                                                :benefits="selectedScholarship.benefits"
                                                uniform
                                                dense
                                            />
                                            <p v-else class="mt-4 rounded-md border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-700">{{ selectedScholarship.benefit_summary || formatAmount(selectedScholarship.award_amount) }}</p>
                                        </section>

                                        <dl class="grid gap-3 sm:grid-cols-3">
                                            <div class="flex items-start gap-3 rounded-md border border-slate-200 bg-slate-50 p-3"><span class="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-white text-xs text-slate-700 ring-1 ring-slate-200"><i class="fa-solid fa-calendar-plus" aria-hidden="true"></i></span><div><dt class="text-xs font-semibold text-slate-500">Application starts</dt><dd class="mt-1 text-sm font-bold text-slate-950">{{ selectedScholarship.application_opens_at || 'Open now' }}</dd></div></div>
                                            <div class="flex items-start gap-3 rounded-md border border-slate-200 bg-slate-50 p-3"><span class="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-white text-xs text-slate-700 ring-1 ring-slate-200"><i class="fa-solid fa-calendar-check" aria-hidden="true"></i></span><div><dt class="text-xs font-semibold text-slate-500">Deadline</dt><dd class="mt-1 text-sm font-bold text-slate-950">{{ selectedScholarship.deadline || 'No deadline listed' }}</dd></div></div>
                                            <div class="flex items-start gap-3 rounded-md border border-slate-200 bg-slate-50 p-3"><span class="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-white text-xs text-slate-700 ring-1 ring-slate-200"><i class="fa-solid fa-users" aria-hidden="true"></i></span><div><dt class="text-xs font-semibold text-slate-500">Application availability</dt><dd class="mt-1 text-sm font-bold text-slate-950">{{ selectedScholarship.application_limit_reached ? 'Applications full' : selectedScholarship.application_limit !== null && selectedScholarship.application_limit !== undefined ? `${selectedScholarship.application_slots_remaining} spaces left` : 'Open without a fixed limit' }}</dd></div></div>
                                        </dl>

                                    </div>
                                </section>
                            </div>

                            <div v-else-if="currentStep === 1 && selectedScholarship" class="grid gap-4">
                                <div v-if="selectedScholarship.application_limit_reached" class="flex items-start gap-3 rounded-md border border-amber-300 bg-amber-50 p-4 text-amber-950">
                                    <span class="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-amber-200"><i class="fa-solid fa-users-slash" aria-hidden="true"></i></span>
                                    <div><p class="font-bold">Applications are full</p><p class="mt-1 text-sm leading-5">The provider has received the maximum number of applications for this program.</p></div>
                                </div>
                                <section :class="['overflow-hidden rounded-lg border', selectedIsEligible ? 'border-slate-200 bg-white' : 'border-rose-200 bg-rose-50']">
                                    <header :class="['flex flex-col gap-4 border-b p-5 sm:flex-row sm:items-center sm:justify-between', selectedIsEligible ? 'border-slate-200 bg-slate-50' : 'border-white/80']">
                                        <div class="flex items-start gap-3">
                                            <span :class="['grid h-11 w-11 shrink-0 place-items-center rounded-md', selectedIsEligible ? 'bg-slate-950 text-amber-300' : 'bg-rose-600 text-white']"><i :class="selectedEligibilityOverview.state === 'ready' ? 'fa-solid fa-check' : 'fa-solid fa-circle-info'" aria-hidden="true"></i></span>
                                            <div>
                                                <p :class="['text-xs font-bold uppercase tracking-[0.14em]', selectedIsEligible ? 'text-amber-700' : 'text-rose-700']">DSS profile comparison</p>
                                                <h3 :class="['mt-1 text-xl font-bold', selectedIsEligible ? 'text-slate-950' : 'text-rose-950']">{{ selectedEligibilityOverview.title }}</h3>
                                                <p :class="['mt-1 text-sm leading-6', selectedIsEligible ? 'text-slate-600' : 'text-rose-800']">{{ selectedEligibilityMessage }}</p>
                                            </div>
                                        </div>
                                        <span :class="['w-fit shrink-0 rounded-md px-3 py-2 text-sm font-bold', selectedIsEligible ? 'bg-amber-100 text-amber-900' : 'bg-rose-100 text-rose-800']">{{ selectedEligibilityOverview.label }}</span>
                                    </header>

                                    <div class="border-b border-amber-200 bg-amber-50 p-4">
                                        <div class="flex items-start gap-3">
                                            <span class="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-amber-200 text-amber-900">
                                                <i class="fa-solid fa-file-circle-check" aria-hidden="true"></i>
                                            </span>
                                            <div>
                                                <p class="text-[10px] font-bold uppercase tracking-[0.14em] text-amber-800">Published conditions</p>
                                                <p class="mt-1 whitespace-pre-line text-sm font-semibold leading-6 text-slate-900">{{ selectedScholarship.eligibility || 'No separate written conditions were provided.' }}</p>
                                                <p class="mt-2 text-xs leading-5 text-amber-900">Required rules must be met. Preferred rules do not block applying. The provider checks your evidence and any additional conditions during pre-screening.</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div v-if="selectedEligibilityConditions.length" class="border-b border-slate-200 p-4">
                                        <div>
                                            <p class="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">Condition checks</p>
                                            <p class="mt-1 text-xs leading-5 text-slate-500">See which conditions are automatic and which the provider will review.</p>
                                        </div>
                                        <EligibilityConditionList class="mt-3" :conditions="selectedEligibilityConditions" />
                                    </div>

                                    <div class="flex flex-col gap-3 px-4 pt-4 sm:flex-row sm:items-end sm:justify-between">
                                        <div>
                                            <p class="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">Eligibility rules</p>
                                            <p class="mt-1 text-xs text-slate-500">The result of each rule matters, not a match percentage. Applying does not guarantee selection.</p>
                                        </div>
                                        <a :href="selectedEligibilityUrl" class="inline-flex w-fit shrink-0 items-center justify-center gap-2 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:border-slate-950 hover:text-slate-950">
                                            View full eligibility
                                            <i class="fa-solid fa-arrow-up-right-from-square text-[10px]" aria-hidden="true"></i>
                                        </a>
                                    </div>
                                    <dl class="grid gap-2 p-4 sm:grid-cols-2 lg:grid-cols-4">
                                        <div
                                            v-for="criterion in selectedEligibilityCriteria"
                                            :key="criterion.key"
                                            :class="[
                                                'flex h-full items-start gap-3 rounded-md border p-3',
                                                eligibilityCriterionCardClass(criterion.status),
                                            ]"
                                        >
                                            <span :class="['grid h-8 w-8 shrink-0 place-items-center rounded-md text-xs', eligibilityCriterionIconClass(criterion.status)]"><i :class="criterion.icon" aria-hidden="true"></i></span>
                                            <div class="flex min-w-0 flex-1 flex-col self-stretch">
                                                <dt class="text-[11px] font-semibold text-slate-500">{{ criterion.label }}<span v-if="criterion.modeLabel" class="mt-1 block text-[10px] font-bold uppercase tracking-wide">{{ criterion.modeLabel }}</span></dt>
                                                <dd class="mt-1 flex-1 text-sm font-bold leading-5 text-slate-900">{{ criterion.value }}</dd>
                                                <span :class="['mt-3 inline-flex w-fit rounded px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide', eligibilityCriterionBadgeClass(criterion.status)]">{{ criterion.statusLabel }}</span>
                                            </div>
                                        </div>
                                    </dl>
                                </section>

                                <div class="flex flex-col gap-3 rounded-lg border border-slate-200 bg-white p-4 sm:flex-row sm:items-center sm:justify-between">
                                    <div><p class="text-sm font-bold text-slate-900">Need to update your information?</p><p class="mt-1 text-xs leading-5 text-slate-500">Changes to your education, location, or household details may update this result.</p></div>
                                    <a :href="preparationHref('/dashboard/profile')" class="inline-flex w-full shrink-0 items-center justify-center gap-2 rounded-md border border-slate-300 px-3 py-2.5 text-sm font-bold text-slate-700 transition hover:bg-slate-50 sm:w-auto">Edit profile <i class="fa-solid fa-arrow-right text-xs" aria-hidden="true"></i></a>
                                </div>
                            </div>

                            <div v-else-if="currentStep === 2 && selectedScholarship" class="grid gap-5">
                                <input ref="documentFileInput" type="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" class="hidden" @change="handleDocumentFileChange">

                                <section class="overflow-hidden rounded-lg border border-slate-200 bg-white">
                                    <header class="flex flex-col gap-3 border-b border-slate-200 p-5 sm:flex-row sm:items-center sm:justify-between">
                                        <div>
                                            <p class="student-kicker">Required for this program</p>
                                            <h3 class="mt-1 text-xl font-bold text-slate-950">Prepare your application files</h3>
                                            <p class="mt-1 text-sm leading-6 text-slate-600">Upload one clear file for each required item.</p>
                                        </div>
                                        <span class="w-fit rounded-md bg-slate-100 px-3 py-2 text-xs font-bold text-slate-700">{{ selectedPreparedDocuments.length }} / {{ selectedRequirements.length }} ready</span>
                                    </header>

                                    <div v-if="selectedRequirements.length" class="divide-y divide-slate-200">
                                        <article v-for="requirement in selectedRequirements" :key="requirement" class="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                                            <div class="flex min-w-0 items-center gap-3">
                                                <span :class="['grid h-10 w-10 shrink-0 place-items-center rounded-md', preparedDocumentFor(requirement) ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-800']">
                                                    <i :class="preparedDocumentFor(requirement) ? 'fa-solid fa-check' : 'fa-regular fa-file'" aria-hidden="true"></i>
                                                </span>
                                                <div class="min-w-0">
                                                    <p class="font-bold text-slate-950">{{ requirement }}</p>
                                                    <p v-if="preparedDocumentFor(requirement)" class="mt-1 truncate text-xs text-slate-500">{{ preparedDocumentFor(requirement).original_name }} · {{ formatFileSize(preparedDocumentFor(requirement).size) }}</p>
                                                    <p v-else class="mt-1 text-xs font-semibold text-amber-700">No file uploaded</p>
                                                </div>
                                            </div>
                                            <div class="flex shrink-0 gap-2">
                                                <button v-if="preparedDocumentFor(requirement)?.view_url" type="button" class="rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-50" @click="previewDocument = preparedDocumentFor(requirement)">View</button>
                                                <button type="button" :disabled="isUploadingDocument" class="inline-flex items-center gap-2 rounded-md bg-slate-900 px-3 py-2 text-xs font-bold text-white transition hover:bg-slate-800 disabled:opacity-60" @click="openDocumentUpload(requirement)">
                                                    <i class="fa-solid fa-arrow-up-from-bracket" aria-hidden="true"></i>
                                                    {{ isUploadingDocument && activeUploadRequirement === requirement ? 'Uploading...' : preparedDocumentFor(requirement) ? 'Replace' : 'Upload' }}
                                                </button>
                                            </div>
                                        </article>
                                    </div>

                                    <div v-else class="flex items-start gap-3 p-5 text-sm leading-6 text-slate-600">
                                        <span class="grid h-10 w-10 shrink-0 place-items-center rounded-md bg-emerald-100 text-emerald-700"><i class="fa-solid fa-check" aria-hidden="true"></i></span>
                                        <div><p class="font-bold text-slate-950">No initial files required</p><p class="mt-1">This provider will begin with your completed applicant profile.</p></div>
                                    </div>

                                    <details v-if="selectedOptionalRequirements.length" class="border-t border-slate-200 bg-slate-50">
                                        <summary class="flex cursor-pointer list-none items-center justify-between gap-3 px-5 py-4 text-sm font-bold text-slate-700">
                                            <span>Optional supporting files · {{ selectedPreparedOptionalDocuments.length }} / {{ selectedOptionalRequirements.length }} prepared</span>
                                            <i class="fa-solid fa-chevron-down text-xs text-slate-400" aria-hidden="true"></i>
                                        </summary>
                                        <div class="divide-y divide-slate-200 border-t border-slate-200 bg-white">
                                            <article v-for="requirement in selectedOptionalRequirements" :key="`optional-${requirement}`" class="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                                                <div class="flex min-w-0 items-center gap-3">
                                                    <span class="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-slate-100 text-slate-600"><i :class="preparedDocumentFor(requirement) ? 'fa-solid fa-file-circle-check' : 'fa-regular fa-file'" aria-hidden="true"></i></span>
                                                    <div class="min-w-0"><p class="font-bold text-slate-900">{{ requirement }}</p><p class="mt-1 truncate text-xs text-slate-500">{{ preparedDocumentFor(requirement)?.original_name || 'Optional · upload only if useful' }}</p></div>
                                                </div>
                                                <div class="flex shrink-0 gap-2">
                                                    <button v-if="preparedDocumentFor(requirement)?.view_url" type="button" class="rounded-md border border-slate-300 px-3 py-2 text-xs font-bold text-slate-700" @click="previewDocument = preparedDocumentFor(requirement)">View</button>
                                                    <button type="button" :disabled="isUploadingDocument" class="rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-100 disabled:opacity-60" @click="openDocumentUpload(requirement)">{{ preparedDocumentFor(requirement) ? 'Replace' : 'Upload' }}</button>
                                                </div>
                                            </article>
                                        </div>
                                    </details>

                                    <details class="border-t border-slate-200">
                                        <summary class="flex cursor-pointer list-none items-center justify-between gap-3 px-5 py-4 text-sm font-bold text-slate-700"><span>Add a note to the provider <span class="font-normal text-slate-400">(optional)</span></span><i class="fa-solid fa-chevron-down text-xs text-slate-400" aria-hidden="true"></i></summary>
                                        <div class="border-t border-slate-200 p-4"><label for="application-notes" class="sr-only">Optional note to provider</label><textarea id="application-notes" v-model="notes" rows="3" maxlength="1000" placeholder="Share short context the provider should know" class="w-full rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-100"></textarea></div>
                                    </details>
                                </section>

                                <section v-if="selectedApplicationQuestions.length" class="overflow-hidden rounded-lg border border-slate-200 bg-white">
                                    <header class="flex flex-col gap-2 border-b border-slate-200 bg-slate-50 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
                                        <div>
                                            <p class="student-kicker">From the provider</p>
                                            <h3 class="mt-1 text-lg font-bold text-slate-950">Short application questions</h3>
                                            <p class="mt-1 text-xs leading-5 text-slate-500">Answer using brief, accurate information. These responses are shared only with this program's reviewers.</p>
                                        </div>
                                        <span class="w-fit rounded-md bg-white px-2.5 py-1.5 text-xs font-bold text-slate-600 ring-1 ring-slate-200">
                                            {{ answeredApplicationQuestionCount }} / {{ selectedApplicationQuestions.length }} answered
                                        </span>
                                    </header>
                                    <div class="divide-y divide-slate-200">
                                        <div v-for="(question, index) in selectedApplicationQuestions" :key="question.id" class="grid gap-3 p-4 sm:grid-cols-[2rem_minmax(0,1fr)] sm:p-5">
                                            <span class="grid h-8 w-8 place-items-center rounded-md bg-slate-950 text-xs font-bold text-white">{{ index + 1 }}</span>
                                            <div>
                                                <label :for="`application-answer-${question.id}`" class="text-sm font-bold leading-6 text-slate-900">
                                                    {{ question.prompt }}
                                                    <span v-if="question.required" class="ml-1 text-rose-600">*</span>
                                                    <span v-else class="ml-1 font-normal text-slate-400">(optional)</span>
                                                </label>
                                                <textarea
                                                    :id="`application-answer-${question.id}`"
                                                    v-model="applicationAnswers[question.id]"
                                                    rows="3"
                                                    maxlength="1500"
                                                    placeholder="Type a short answer"
                                                    class="mt-2 w-full rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-100"
                                                ></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </section>

                                <section class="overflow-hidden rounded-lg border border-slate-200 bg-white">
                                    <div v-if="selectedNeedsOriginalVerification" class="border-b border-amber-200 bg-amber-50 px-5 py-4 text-sm leading-6 text-amber-950">
                                        <p class="font-bold"><i class="fa-solid fa-file-shield mr-2 text-amber-700" aria-hidden="true"></i>Keep originals ready</p>
                                        <p class="mt-1 text-amber-900">Upload copies now. Bring originals only after the provider sends the date and location.</p>
                                    </div>

                                    <div class="flex flex-col gap-3 border-b border-slate-200 bg-slate-50 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
                                        <div class="min-w-0 flex-1">
                                            <div class="flex items-center justify-between gap-3">
                                                <p class="text-sm font-bold text-slate-900">File readiness</p>
                                                <span class="text-sm font-bold text-slate-700">{{ selectedDocumentReadiness }}%</span>
                                            </div>
                                            <div class="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-200"><div class="h-full rounded-full bg-amber-500 transition-all" :style="{ width: `${selectedDocumentReadiness}%` }"></div></div>
                                            <p class="mt-2 text-xs text-slate-500">{{ selectedMissingPreparedDocuments.length ? `${selectedMissingPreparedDocuments.length} required file${selectedMissingPreparedDocuments.length === 1 ? '' : 's'} still missing.` : 'All required files are ready.' }}</p>
                                        </div>
                                        <a :href="preparationHref('/dashboard/documents')" class="inline-flex w-full shrink-0 items-center justify-center gap-2 rounded-md border border-slate-300 bg-white px-3 py-2.5 text-sm font-bold text-slate-700 transition hover:bg-slate-100 sm:w-auto"><i class="fa-solid fa-folder-open" aria-hidden="true"></i>Open Documents</a>
                                    </div>

                                    <div class="p-5">
                                        <TermsAgreement v-model="documentTermsAccepted" context="document" />
                                    </div>
                                </section>
                            </div>

                            <div v-else-if="currentStep === 3 && selectedScholarship" class="grid gap-5">
                                <div class="grid gap-4">
                                    <section class="overflow-hidden rounded-lg border border-slate-200 bg-white">
                                        <header class="flex items-start gap-4 border-b border-slate-200 p-5">
                                            <img :src="selectedScholarship.image_url" :alt="selectedScholarship.title" class="h-12 w-12 shrink-0 rounded-md bg-slate-50 object-contain p-1.5 ring-1 ring-slate-200">
                                            <div class="min-w-0"><p class="text-[11px] font-bold uppercase tracking-[0.14em] text-amber-700">{{ selectedScholarship.provider?.name || 'Scholarship Provider' }}</p><h3 class="mt-1 text-xl font-bold text-slate-950">{{ selectedScholarship.title }}</h3><p class="mt-1 text-sm text-slate-500">{{ selectedApplicationMode }}</p></div>
                                        </header>

                                        <div class="divide-y divide-slate-200">
                                            <div class="flex items-start gap-3 p-4">
                                                <span class="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-emerald-100 text-emerald-700"><i class="fa-solid fa-check" aria-hidden="true"></i></span>
                                                <div><p class="text-xs font-semibold text-slate-500">Applicant profile</p><p class="mt-1 font-bold text-slate-950">{{ user?.name }}</p><p class="mt-1 text-xs text-slate-500">{{ user?.course_or_strand || 'Track not set' }} · {{ user?.year_level || 'Grade/year not set' }}</p></div>
                                            </div>
                                            <div class="flex items-start gap-3 p-4">
                                                <span class="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-emerald-100 text-emerald-700"><i class="fa-solid fa-check" aria-hidden="true"></i></span>
                                                <div><p class="text-xs font-semibold text-slate-500">Eligibility check</p><p class="mt-1 font-bold text-slate-950">{{ selectedEligibilityOverview.title }}</p><p class="mt-1 text-xs leading-5 text-slate-500">{{ selectedEligibilityMessage }} The provider still reviews your evidence and conditions.</p></div>
                                            </div>
                                            <div class="flex items-start gap-3 p-4">
                                                <span class="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-emerald-100 text-emerald-700"><i class="fa-solid fa-check" aria-hidden="true"></i></span>
                                                <div><p class="text-xs font-semibold text-slate-500">Application files</p><p class="mt-1 font-bold text-slate-950">{{ selectedRequirements.length ? `${documentChecklist.length} of ${selectedRequirements.length} required files attached` : 'No initial files required' }}</p><p v-if="selectedPreparedOptionalDocuments.length" class="mt-1 text-xs text-slate-500">{{ selectedPreparedOptionalDocuments.length }} optional supporting file{{ selectedPreparedOptionalDocuments.length === 1 ? '' : 's' }} included</p></div>
                                            </div>
                                            <div v-if="selectedApplicationQuestions.length" class="flex items-start gap-3 p-4">
                                                <span class="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-emerald-100 text-emerald-700"><i class="fa-solid fa-check" aria-hidden="true"></i></span>
                                                <div class="min-w-0 flex-1">
                                                    <p class="text-xs font-semibold text-slate-500">Provider questions</p>
                                                    <p class="mt-1 font-bold text-slate-950">{{ answeredApplicationQuestionCount }} of {{ selectedApplicationQuestions.length }} answered</p>
                                                    <details class="mt-2">
                                                        <summary class="cursor-pointer text-xs font-bold text-slate-600">Review answers</summary>
                                                        <dl class="mt-2 space-y-3 rounded-md bg-slate-50 p-3">
                                                            <div v-for="question in selectedApplicationQuestions" :key="`confirm-${question.id}`">
                                                                <dt class="text-xs font-semibold text-slate-500">{{ question.prompt }}</dt>
                                                                <dd class="mt-1 whitespace-pre-line text-sm leading-6 text-slate-700">{{ applicationAnswers[question.id] || 'No answer provided' }}</dd>
                                                            </div>
                                                        </dl>
                                                    </details>
                                                </div>
                                            </div>
                                            <div class="flex items-start gap-3 p-4">
                                                <span class="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-slate-100 text-slate-700"><i class="fa-regular fa-message" aria-hidden="true"></i></span>
                                                <div><p class="text-xs font-semibold text-slate-500">Note to provider</p><p class="mt-1 text-sm leading-6 text-slate-700">{{ notes || 'No note added.' }}</p></div>
                                            </div>
                                        </div>
                                    </section>

                                    <details class="group overflow-hidden rounded-lg border border-slate-200 bg-slate-50">
                                        <summary class="flex cursor-pointer list-none items-center justify-between gap-3 p-4 sm:p-5 [&::-webkit-details-marker]:hidden">
                                            <div><p class="student-kicker">After you submit</p><h3 class="mt-1 text-base font-bold text-slate-950">Provider selection flow</h3></div>
                                            <span class="flex items-center gap-3 text-xs font-bold text-slate-500">{{ selectedSelectionPlan.length }} stages <i class="fa-solid fa-chevron-down text-[10px] transition group-open:rotate-180" aria-hidden="true"></i></span>
                                        </summary>
                                        <ol class="grid gap-2 border-t border-slate-200 p-4 sm:grid-cols-2 sm:p-5">
                                            <li v-for="(stage, index) in selectedSelectionPlan" :key="stage.value" class="flex items-start gap-3 rounded-md border border-slate-200 bg-white px-4 py-3">
                                                <span class="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-slate-900 text-xs font-bold text-white">{{ index + 1 }}</span>
                                                <div>
                                                    <p class="text-sm font-bold text-slate-800">{{ stage.label }}</p>
                                                    <p class="mt-1 text-xs leading-5 text-slate-500">{{ selectionStageDescription(stage) }}</p>
                                                </div>
                                            </li>
                                        </ol>
                                    </details>

                                    <RecipientAgreementPanel :scholarship="selectedScholarship" />

                                    <section class="rounded-lg border border-amber-200 bg-amber-50/60 p-4 sm:p-5">
                                        <TermsAgreement v-model="applicationTermsAccepted" context="application" />
                                    </section>
                                </div>
                            </div>
                        </div>

                        <div class="border-t border-slate-200 bg-slate-50 px-5 py-4">
                            <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                                <button
                                    v-if="currentStep > 0"
                                    type="button"
                                    class="inline-flex w-full items-center justify-center gap-2 rounded-md border border-slate-300 px-4 py-2.5 text-sm font-bold text-slate-700 transition hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50 sm:w-auto"
                                    @click="previousStep"
                                >
                                    <i class="fa-solid fa-arrow-left text-xs" aria-hidden="true"></i>
                                    Back
                                </button>
                                <a
                                    v-else
                                    href="/dashboard/scholarships"
                                    class="inline-flex w-full items-center justify-center gap-2 rounded-md border border-slate-300 bg-white px-4 py-2.5 text-sm font-bold text-slate-700 transition hover:bg-slate-100 sm:w-auto"
                                >
                                    <i class="fa-solid fa-arrow-left text-xs" aria-hidden="true"></i>
                                    Scholarships
                                </a>

                                <div class="grid gap-2 sm:flex sm:justify-end">
                                    <button
                                        v-if="currentStep < steps.length - 1"
                                        type="button"
                                        :disabled="!canGoNext"
                                        class="inline-flex w-full items-center justify-center gap-2 rounded-md bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:bg-slate-400 sm:w-auto"
                                        @click="nextStep"
                                    >
                                        {{ nextStepLabel }}
                                        <i class="fa-solid fa-arrow-right text-xs" aria-hidden="true"></i>
                                    </button>
                                    <button
                                        v-else
                                        type="button"
                                        :disabled="applicationBusy || confirmation.open || !canSubmitApplication"
                                        class="inline-flex w-full items-center justify-center gap-2 rounded-md bg-slate-900 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:bg-slate-400 sm:w-auto"
                                        @click="submitApplication"
                                    >
                                        {{ isSubmitting ? 'Submitting...' : 'Submit application' }}
                                        <i class="fa-solid fa-paper-plane text-xs" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </section>

                    </template>

                    <section v-if="activeWorkspace === 'applications'" class="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
                        <div class="flex flex-col gap-4 border-b border-slate-200 bg-white p-5 sm:flex-row sm:items-center sm:justify-between">
                            <div>
                                <p class="student-kicker">What happens next</p>
                                <h3 class="mt-1 text-xl font-bold text-slate-950">
                                    {{ applicationViewContent.sectionTitle }}
                                </h3>
                            </div>
                            <div class="flex flex-wrap gap-2">
                                <span class="rounded-md bg-slate-100 px-3 py-2 text-xs font-bold text-slate-700">
                                    {{ visibleApplicationQueue.length }} record{{ visibleApplicationQueue.length === 1 ? '' : 's' }}
                                </span>
                            </div>
                        </div>

                        <div v-if="visibleApplicationQueue.length === 0" class="m-5 rounded-lg border border-dashed border-slate-300 bg-slate-50 p-6">
                            <p class="text-sm font-bold text-slate-900">
                                {{ applicationViewContent.emptyTitle }}
                            </p>
                            <p class="mt-1 text-sm leading-6 text-slate-500">
                                {{ applicationViewContent.emptyText }}
                            </p>
                            <div class="mt-4 flex flex-col gap-2 sm:flex-row">
                                <a
                                    href="/dashboard/scholarships"
                                    class="rounded-md bg-slate-900 px-4 py-2.5 text-center text-sm font-bold text-white transition hover:bg-slate-800"
                                >
                                    Browse scholarships
                                </a>
                                <a
                                    href="/dashboard/documents"
                                    class="rounded-md border border-slate-300 bg-white px-4 py-2.5 text-center text-sm font-bold text-slate-700 transition hover:bg-slate-100"
                                >
                                    Prepare documents
                                </a>
                            </div>
                        </div>

                        <div v-else class="grid gap-4 p-5">
                            <article
                                v-for="application in visibleApplicationQueue"
                                :key="application.id"
                                class="overflow-hidden rounded-lg border border-slate-200 border-t-4 border-t-slate-900 bg-white shadow-sm transition hover:border-slate-300 hover:shadow-md"
                            >
                                <div class="p-4 sm:p-5">
                                    <div class="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                                        <div class="flex min-w-0 gap-3.5">
                                            <img
                                                :src="application.scholarship?.image_url || '/uploads/scholarship-default.jpg'"
                                                :alt="application.scholarship?.title || 'Scholarship'"
                                                class="h-14 w-14 shrink-0 rounded-md bg-white object-contain p-1.5 ring-1 ring-slate-200"
                                            >
                                            <div class="min-w-0">
                                                <p class="truncate text-[10px] font-bold uppercase tracking-[0.14em] text-slate-400">
                                                    {{ application.scholarship?.provider?.name || 'Scholarship provider' }}
                                                </p>
                                                <h4 class="mt-1 truncate text-base font-bold text-slate-950">
                                                    {{ application.scholarship?.title || 'Scholarship' }}
                                                </h4>
                                                <p class="mt-1 text-xs text-slate-500">
                                                    Submitted {{ application.submitted_at || 'recently' }}
                                                </p>
                                            </div>
                                        </div>
                                        <div class="flex w-full flex-col gap-2 sm:w-auto sm:items-end">
                                            <div class="flex flex-wrap items-center gap-2 sm:justify-end">
                                                <span :class="['w-fit rounded-md px-2.5 py-1 text-xs font-bold uppercase', statusClass(application.status)]">
                                                    {{ applicationStatusLabel(application) }}
                                                </span>
                                                <span
                                                    v-if="application.correction_status === 'requested'"
                                                    class="w-fit rounded-md bg-amber-100 px-2.5 py-1 text-xs font-bold uppercase text-amber-800"
                                                >
                                                    Update requested
                                                </span>
                                                <span
                                                    v-else-if="application.correction_status === 'submitted'"
                                                    class="w-fit rounded-md bg-sky-100 px-2.5 py-1 text-xs font-bold uppercase text-sky-800"
                                                >
                                                    Correction sent
                                                </span>
                                            </div>
                                            <a
                                                :href="applicationActionUrl(application)"
                                                class="inline-flex w-full items-center justify-center gap-2 rounded-md bg-slate-950 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800 sm:w-auto"
                                            >
                                                {{ applicationActionLabel(application) }}
                                                <i class="fa-solid fa-arrow-right text-xs" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>

                                    <div v-if="applicationNeedsAction(application)" class="mt-4 border-t border-slate-200 pt-4">
                                        <div class="flex min-w-0 items-start gap-3">
                                            <span class="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-slate-100 text-slate-700">
                                                <i :class="applicationCardAction(application).icon" aria-hidden="true"></i>
                                            </span>
                                            <div class="min-w-0">
                                                <div class="flex flex-wrap items-center gap-2">
                                                    <p class="text-[10px] font-bold uppercase tracking-[0.14em] text-amber-700">
                                                        {{ applicationCardAction(application).eyebrow }}
                                                    </p>
                                                    <span :class="['rounded px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide', applicationNeedsAction(application) ? 'bg-amber-100 text-amber-800' : application.workflow?.is_closed ? 'bg-slate-100 text-slate-600' : 'bg-sky-100 text-sky-800']">
                                                        {{ applicationNeedsAction(application) ? 'Your action' : application.workflow?.is_closed ? 'Complete' : 'No action needed' }}
                                                    </span>
                                                </div>
                                                <p class="mt-1 text-sm font-bold text-slate-950">
                                                    {{ applicationCardAction(application).title }}
                                                </p>
                                                <p v-if="applicationCardAction(application).description" class="mt-1 line-clamp-2 text-xs leading-5 text-slate-500">
                                                    {{ applicationCardAction(application).description }}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <details v-if="application.status_progress?.steps?.length" class="group border-t border-slate-200 bg-slate-50">
                                    <summary class="flex cursor-pointer list-none items-center justify-between gap-4 px-4 py-3 text-xs text-slate-600 sm:px-5 [&::-webkit-details-marker]:hidden">
                                        <span class="min-w-0 truncate">
                                            <span class="font-semibold text-slate-500">Current stage:</span>
                                            <strong class="ml-1 text-slate-800">{{ applicationStageLabel(application) }}</strong>
                                        </span>
                                        <span class="inline-flex shrink-0 items-center gap-2 font-bold text-slate-700">
                                            Application process
                                            <i class="fa-solid fa-chevron-down text-[10px] text-slate-400 transition group-open:rotate-180" aria-hidden="true"></i>
                                        </span>
                                    </summary>
                                    <div class="overflow-x-auto border-t border-slate-200 bg-white">
                                        <ol class="flex min-w-max divide-x divide-slate-200">
                                            <li
                                                v-for="(step, index) in application.status_progress.steps"
                                                :key="step.key"
                                                :class="['flex min-w-[10rem] flex-1 items-center gap-2.5 px-3 py-3 text-xs', timelineStepClass(step.state)]"
                                            >
                                                <span :class="['grid h-7 w-7 shrink-0 place-items-center rounded-full text-[10px] font-bold', step.state === 'complete' ? 'bg-white/15 text-white' : step.state === 'current' ? 'bg-amber-400 text-slate-950' : 'bg-slate-100 text-slate-500']">
                                                    <i v-if="step.state === 'complete'" class="fa-solid fa-check" aria-hidden="true"></i>
                                                    <span v-else>{{ index + 1 }}</span>
                                                </span>
                                                <span class="min-w-0">
                                                    <span class="block truncate font-bold">{{ step.label }}</span>
                                                    <span class="mt-0.5 block text-[9px] font-semibold uppercase tracking-[0.08em] opacity-70">{{ progressStateLabel(step.state) }}</span>
                                                </span>
                                            </li>
                                        </ol>
                                    </div>
                                </details>
                            </article>
                        </div>
                    </section>
                </div>

            </div>
        </section>
    </main>
</template>

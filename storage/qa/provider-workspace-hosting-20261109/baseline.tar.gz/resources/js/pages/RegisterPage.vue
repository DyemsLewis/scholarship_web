<script setup>
import { computed, onBeforeUnmount, ref } from 'vue';
import AuthShell from '../components/AuthShell.vue';
import TermsAgreement from '../components/TermsAgreement.vue';
import ToastMessage from '../components/ToastMessage.vue';
import { limitPhoneNumber } from '../support/phoneNumber';

const formElement = ref(null);
const isProviderRegistration = (window.portalPathname?.() ?? window.location.pathname).startsWith('/provider/register');
const registrationRole = isProviderRegistration ? 'provider' : 'applicant';
const registrationStep = ref('details');
const registrationToken = ref('');
const verificationEmail = ref('');
const verificationCode = ref('');
const resendSeconds = ref(0);
const form = ref({
    firstName: '',
    lastName: '',
    middleInitial: '',
    email: '',
    username: '',
    number: '',
    password: '',
    passwordConfirmation: '',
    termsAccepted: false,
});

const labelClass = 'mb-2 block text-sm font-semibold text-slate-700';
const inputClass = 'w-full rounded-md border border-slate-300 bg-white px-3.5 py-2.5 text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-amber-500 focus:ring-3 focus:ring-amber-100';
const compactInputClass = 'w-full rounded-md border border-slate-300 bg-white px-3 py-2.5 text-center text-slate-900 uppercase outline-none transition placeholder:text-slate-400 focus:border-amber-500 focus:ring-3 focus:ring-amber-100';
const toggleButtonClass = 'absolute inset-y-0 right-2 my-auto h-9 rounded-md px-3 text-sm font-semibold text-slate-600 transition hover:bg-slate-100 hover:text-slate-900';
const primaryButtonClass = 'w-full rounded-md bg-slate-900 px-4 py-3 text-sm font-bold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-80';
const formSectionClass = 'rounded-md border border-slate-200 bg-white p-4 sm:p-5';

const isSubmitting = ref(false);
const isVerifying = ref(false);
const isResending = ref(false);
const showPassword = ref(false);
const toast = ref({
    show: false,
    type: 'success',
    title: '',
    message: '',
});

let toastTimer = null;
let resendTimer = null;

function showToast(type, title, message) {
    if (toastTimer) {
        window.clearTimeout(toastTimer);
    }

    toast.value = {
        show: true,
        type,
        title,
        message,
    };

    toastTimer = window.setTimeout(() => {
        toast.value.show = false;
    }, 3500);
}

function closeToast() {
    if (toastTimer) {
        window.clearTimeout(toastTimer);
    }

    toast.value.show = false;
}

const shellCopy = computed(() => {
    if (registrationStep.value === 'verification') {
        return {
            eyebrow: 'Email Verification',
            title: 'Check your email',
            description: `Enter the six-digit code sent to ${verificationEmail.value || 'your email'}.`,
            panelBadge: 'Secure Registration',
            panelTitle: 'Verify before account creation',
            panelText: 'Your account is created only after the email code is confirmed.',
            panelHighlights: [],
            panelNote: 'The code expires after 10 minutes.',
        };
    }

    if (isProviderRegistration) {
        return {
            eyebrow: 'Provider Registration',
            title: 'Create a representative account',
            description: 'Register the person who will manage the scholarship provider account.',
            panelBadge: 'Provider Access Desk',
            panelTitle: 'Start with the representative',
            panelText: 'Organization information is completed securely after the representative signs in.',
            panelHighlights: [
                'Create private login details for the representative.',
                'Verify the representative email before account creation.',
                'Complete the organization profile and verification proof after login.',
            ],
            panelNote: 'Publishing remains unavailable until the provider profile and organization proof are reviewed.',
        };
    }

    return {
        eyebrow: 'Scholarship Registration',
        title: 'Create your applicant profile',
        description: 'Set up your applicant account so you can continue scholarship activity after logging in.',
        panelBadge: 'Student Funding Desk',
        panelTitle: 'Start with an applicant profile',
        panelText: 'Applicant registration is for students preparing to use scholarship opportunities in the portal.',
        panelHighlights: [
            'Create a scholarship applicant account.',
            'Keep your basic profile details ready.',
            'Continue setup or browse the web after signing in.',
        ],
        panelNote: 'We verify your email before creating the applicant account.',
    };
});

function handleMiddleInitialInput(event) {
    form.value.middleInitial = event.target.value.replace(/[^a-zA-Z]/g, '').slice(0, 1).toUpperCase();
}

function handleNumberInput(event) {
    form.value.number = limitPhoneNumber(event.target.value);
}

function handleVerificationCodeInput(event) {
    verificationCode.value = event.target.value.replace(/\D/g, '').slice(0, 6);
}

function startResendCountdown(seconds) {
    if (resendTimer) {
        window.clearInterval(resendTimer);
    }

    resendSeconds.value = Number(seconds) || 0;

    if (resendSeconds.value <= 0) {
        return;
    }

    resendTimer = window.setInterval(() => {
        resendSeconds.value = Math.max(0, resendSeconds.value - 1);

        if (resendSeconds.value === 0) {
            window.clearInterval(resendTimer);
            resendTimer = null;
        }
    }, 1000);
}

function returnToDetails() {
    registrationStep.value = 'details';
    registrationToken.value = '';
    verificationCode.value = '';
    verificationEmail.value = '';
    startResendCountdown(0);
}

async function submitForm() {
    if (!formElement.value?.reportValidity()) {
        return;
    }

    const numberDigits = form.value.number.replace(/\D/g, '');

    if (numberDigits.length !== 11) {
        const message = 'Enter an 11-digit contact number.';
        showToast('error', 'Registration failed', message);
        formElement.value
            ?.querySelector('#number')
            ?.setCustomValidity(message);
        formElement.value?.reportValidity();
        return;
    }

    formElement.value?.querySelector('#number')?.setCustomValidity('');

    if (form.value.password !== form.value.passwordConfirmation) {
        const message = 'Passwords must match.';
        showToast('error', 'Registration failed', message);
        formElement.value
            ?.querySelector('#password-confirmation')
            ?.setCustomValidity(message);
        formElement.value?.reportValidity();
        return;
    }

    formElement.value?.querySelector('#password-confirmation')?.setCustomValidity('');

    if (!form.value.termsAccepted) {
        showToast('error', 'Registration failed', 'Please accept the Terms and Privacy Notice before creating an account.');
        return;
    }

    isSubmitting.value = true;

    const payload = {
        first_name: form.value.firstName,
        last_name: form.value.lastName,
        middle_initial: form.value.middleInitial,
        email: form.value.email,
        username: form.value.username,
        number: form.value.number,
        role: registrationRole,
        password: form.value.password,
        password_confirmation: form.value.passwordConfirmation,
        terms_accepted: form.value.termsAccepted ? '1' : '',
    };

    try {
        const response = await window.axios.post('/register', payload);
        registrationToken.value = response.data.registration_token;
        verificationEmail.value = response.data.email ?? form.value.email;
        verificationCode.value = '';
        registrationStep.value = 'verification';
        startResendCountdown(response.data.resend_after ?? 60);
        showToast('success', 'Code sent', response.data.message ?? 'Check your email for the verification code.');
    } catch (error) {
        const message = error.response?.data?.message ?? 'Registration failed. Check your details and try again.';
        showToast('error', 'Registration failed', message);
    } finally {
        isSubmitting.value = false;
    }
}

async function verifyRegistration() {
    if (!/^\d{6}$/.test(verificationCode.value)) {
        showToast('error', 'Verification failed', 'Enter the complete six-digit verification code.');
        return;
    }

    isVerifying.value = true;

    try {
        const response = await window.axios.post('/register/verify', {
            registration_token: registrationToken.value,
            code: verificationCode.value,
        });
        showToast('success', 'Account created', response.data.message);
        window.setTimeout(() => {
            window.location.href = response.data.redirect ?? '/login?registered=1&verified=1';
        }, 500);
    } catch (error) {
        const message = error.response?.data?.message ?? 'The verification code could not be confirmed.';
        showToast('error', 'Verification failed', message);

        if (error.response?.data?.restart_required) {
            returnToDetails();
        }
    } finally {
        isVerifying.value = false;
    }
}

async function resendVerificationCode() {
    if (resendSeconds.value > 0 || isResending.value) {
        return;
    }

    isResending.value = true;

    try {
        const response = await window.axios.post('/register/resend-code', {
            registration_token: registrationToken.value,
        });
        verificationCode.value = '';
        startResendCountdown(response.data.resend_after ?? 60);
        showToast('success', 'New code sent', response.data.message);
    } catch (error) {
        const message = error.response?.data?.message ?? 'Unable to resend the verification code.';
        showToast('error', 'Code not sent', message);

        if (error.response?.status === 429) {
            startResendCountdown(error.response?.data?.retry_after ?? 60);
        }

        if (error.response?.data?.restart_required) {
            returnToDetails();
        }
    } finally {
        isResending.value = false;
    }
}

onBeforeUnmount(() => {
    if (toastTimer) {
        window.clearTimeout(toastTimer);
    }

    if (resendTimer) {
        window.clearInterval(resendTimer);
    }
});
</script>

<template>
    <AuthShell
        :eyebrow="shellCopy.eyebrow"
        :title="shellCopy.title"
        :description="shellCopy.description"
        switch-href="/login"
        switch-label="Login"
        :panel-badge="shellCopy.panelBadge"
        :panel-title="shellCopy.panelTitle"
        :panel-text="shellCopy.panelText"
        :panel-highlights="shellCopy.panelHighlights"
        :panel-note="shellCopy.panelNote"
        :show-panel="false"
        :wide="isProviderRegistration && registrationStep === 'details'"
        background-image="/images/filipino-students-studying.jpg"
    >
        <ToastMessage
            :show="toast.show"
            :type="toast.type"
            :title="toast.title"
            :message="toast.message"
            @close="closeToast"
        />

        <form v-if="registrationStep === 'details'" ref="formElement" class="space-y-4" @submit.prevent="submitForm">
            <div class="flex items-center gap-3 text-xs font-bold">
                <span class="inline-flex items-center gap-2 text-slate-950">
                    <span class="grid h-6 w-6 place-items-center rounded-full bg-amber-400 text-[10px]">1</span>
                    Account details
                </span>
                <span class="h-px flex-1 bg-slate-200"></span>
                <span class="inline-flex items-center gap-2 text-slate-400">
                    <span class="grid h-6 w-6 place-items-center rounded-full border border-slate-300 bg-white text-[10px]">2</span>
                    Email verification
                </span>
            </div>

            <section :class="formSectionClass">
                <div class="flex items-start gap-3 border-b border-slate-200 pb-4">
                    <span class="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-slate-900 text-sm text-amber-300">
                        <i class="fa-solid fa-user" aria-hidden="true"></i>
                    </span>
                    <div>
                        <h2 class="font-bold text-slate-950">{{ isProviderRegistration ? 'Representative account' : 'Personal information' }}</h2>
                        <p class="mt-1 text-xs leading-5 text-slate-500">{{ isProviderRegistration ? 'Private details for the person who signs in and manages this provider account.' : 'Your basic contact details for the applicant account.' }}</p>
                    </div>
                </div>

                <div class="mt-4 grid gap-4 sm:grid-cols-[minmax(0,1fr)_5.5rem_minmax(0,1fr)] sm:items-end">
                    <div>
                        <label :class="labelClass" for="first-name">First name</label>
                        <input id="first-name" v-model="form.firstName" type="text" autocomplete="given-name" required placeholder="First name" :class="inputClass">
                    </div>
                    <div class="sm:mx-auto sm:w-[5.5rem]">
                        <label :class="[labelClass, 'sm:text-center']" for="middle-initial">M.I. <span class="text-xs font-normal text-slate-500">(optional)</span></label>
                        <input id="middle-initial" :value="form.middleInitial" aria-label="Middle initial (optional)" type="text" inputmode="text" maxlength="1" pattern="[A-Za-z]" placeholder="M" :class="compactInputClass" @input="handleMiddleInitialInput">
                    </div>
                    <div>
                        <label :class="labelClass" for="last-name">Last name</label>
                        <input id="last-name" v-model="form.lastName" type="text" autocomplete="family-name" required placeholder="Last name" :class="inputClass">
                    </div>
                </div>

                <div class="mt-4 grid gap-4 sm:grid-cols-2">
                    <div>
                        <label :class="labelClass" for="email">{{ isProviderRegistration ? 'Login email' : 'Email address' }}</label>
                        <input id="email" v-model="form.email" type="email" autocomplete="email" required placeholder="name@example.com" :class="inputClass">
                    </div>
                    <div>
                        <label :class="labelClass" for="number">{{ isProviderRegistration ? 'Representative phone' : 'Contact number' }}</label>
                        <input id="number" :value="form.number" type="tel" inputmode="numeric" autocomplete="tel" required maxlength="20" placeholder="09XX XXX XXXX" :class="inputClass" @input="(event) => { event.target.setCustomValidity(''); handleNumberInput(event); }">
                    </div>
                </div>

                <div v-if="isProviderRegistration" class="mt-4 flex items-start gap-3 border-t border-slate-200 pt-4 text-xs leading-5 text-slate-600">
                    <i class="fa-solid fa-circle-info mt-0.5 text-amber-700" aria-hidden="true"></i>
                    <p>After logging in, complete the organization name, type, address, description, public contacts, and verification proof from <span class="font-bold text-slate-900">Provider Profile</span>.</p>
                </div>
            </section>

            <section :class="formSectionClass">
                <div class="flex items-start gap-3 border-b border-slate-200 pb-4">
                    <span class="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-slate-900 text-sm text-amber-300">
                        <i class="fa-solid fa-key" aria-hidden="true"></i>
                    </span>
                    <div>
                        <h2 class="font-bold text-slate-950">Account security</h2>
                        <p class="mt-1 text-xs leading-5 text-slate-500">Choose a username and a password with at least eight characters.</p>
                    </div>
                </div>

                <div class="mt-4 grid gap-4 sm:grid-cols-2">
                    <div class="sm:col-span-2">
                        <label :class="labelClass" for="username">Username</label>
                        <input id="username" v-model="form.username" type="text" autocomplete="username" pattern="[A-Za-z0-9_.-]{4,}" required placeholder="Choose a username" :class="inputClass">
                    </div>
                    <div>
                        <label :class="labelClass" for="password">Password</label>
                        <div class="relative">
                            <input id="password" v-model="form.password" :type="showPassword ? 'text' : 'password'" autocomplete="new-password" required minlength="8" placeholder="At least 8 characters" :class="[inputClass, 'pr-16']">
                            <button type="button" :class="toggleButtonClass" @click="showPassword = !showPassword">{{ showPassword ? 'Hide' : 'Show' }}</button>
                        </div>
                    </div>
                    <div>
                        <label :class="labelClass" for="password-confirmation">Confirm password</label>
                        <input id="password-confirmation" v-model="form.passwordConfirmation" :type="showPassword ? 'text' : 'password'" autocomplete="new-password" required minlength="8" placeholder="Repeat password" :class="inputClass" @input="$event.target.setCustomValidity('')">
                    </div>
                </div>
            </section>

            <div class="rounded-md border border-slate-200 bg-slate-50 p-4">
                <TermsAgreement v-model="form.termsAccepted" context="account" />
                <button type="submit" :disabled="isSubmitting" :class="[primaryButtonClass, 'mt-4']">
                    {{ isSubmitting ? 'Sending code...' : 'Continue to email verification' }}
                </button>
            </div>
        </form>

        <form v-else class="space-y-5" @submit.prevent="verifyRegistration">
            <div class="flex items-center gap-3 text-xs font-bold">
                <span class="inline-flex items-center gap-2 text-slate-500">
                    <span class="grid h-6 w-6 place-items-center rounded-full bg-slate-900 text-[10px] text-white">
                        <i class="fa-solid fa-check" aria-hidden="true"></i>
                    </span>
                    Account details
                </span>
                <span class="h-px flex-1 bg-slate-300"></span>
                <span class="inline-flex items-center gap-2 text-slate-950">
                    <span class="grid h-6 w-6 place-items-center rounded-full bg-amber-400 text-[10px]">2</span>
                    Email verification
                </span>
            </div>

            <div class="rounded-md border border-slate-200 bg-white p-5 text-center">
                <span class="mx-auto grid h-11 w-11 place-items-center rounded-md bg-slate-900 text-amber-300">
                    <i class="fa-solid fa-envelope-open-text" aria-hidden="true"></i>
                </span>
                <p class="mt-3 text-sm font-bold text-slate-950">
                    Code sent to {{ verificationEmail }}
                </p>
                <p class="mt-1 text-xs leading-5 text-slate-500">
                    Enter the code to create your account. It expires after 10 minutes.
                </p>
            </div>

            <div>
                <label :class="labelClass" for="registration-code">
                    Six-digit verification code
                </label>
                <input
                    id="registration-code"
                    :value="verificationCode"
                    type="text"
                    inputmode="numeric"
                    autocomplete="one-time-code"
                    maxlength="6"
                    pattern="[0-9]{6}"
                    required
                    autofocus
                    placeholder="000000"
                    class="w-full rounded-md border border-slate-300 bg-white px-4 py-3 text-center text-2xl font-bold tracking-[0.45em] text-slate-950 outline-none transition placeholder:text-slate-300 focus:border-amber-500 focus:ring-3 focus:ring-amber-100"
                    @input="handleVerificationCodeInput"
                >
            </div>

            <button
                type="submit"
                :disabled="isVerifying || verificationCode.length !== 6"
                :class="primaryButtonClass"
            >
                {{ isVerifying ? 'Verifying...' : 'Verify and create account' }}
            </button>

            <div class="flex flex-col items-center justify-between gap-3 border-t border-slate-200 pt-4 text-sm sm:flex-row">
                <button
                    type="button"
                    class="font-semibold text-slate-600 transition hover:text-slate-950"
                    @click="returnToDetails"
                >
                    Change registration details
                </button>
                <button
                    type="button"
                    :disabled="resendSeconds > 0 || isResending"
                    class="font-bold text-slate-900 transition hover:text-amber-700 disabled:cursor-not-allowed disabled:text-slate-400"
                    @click="resendVerificationCode"
                >
                    {{ isResending ? 'Sending...' : resendSeconds > 0 ? `Resend code in ${resendSeconds}s` : 'Resend code' }}
                </button>
            </div>
        </form>

    </AuthShell>
</template>

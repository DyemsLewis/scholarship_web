<?php

namespace App\Models;

use App\Services\ApplicantEvidenceReviewService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StudentProfile extends Model
{
    protected static function booted(): void
    {
        static::updated(fn (self $profile) => app(ApplicantEvidenceReviewService::class)->invalidateClaims($profile));
    }

    protected $fillable = [
        'user_id',
        'first_name',
        'last_name',
        'suffix',
        'gender',
        'middle_initial',
        'contact_number',
        'account_managed_by',
        'citizenship_status',
        'education_level',
        'completed_qualification',
        'completed_qualification_school',
        'completed_qualification_year',
        'completed_qualification_details',
        'school',
        'school_type',
        'learner_reference_number',
        'course_or_strand',
        'year_level',
        'enrollment_status',
        'academic_year',
        'academic_term',
        'gwa',
        'grading_scale',
        'academic_result_source',
        'academic_result_extracted_at',
        'income_bracket',
        'household_size',
        'preferred_categories',
        'preferred_locations',
        'willing_to_relocate',
        'support_needs',
        'current_scholarship_status',
        'current_scholarship_details',
        'scholarship_goal',
        'achievements',
        'activities_and_responsibilities',
        'address',
        'barangay',
        'city',
        'province',
        'region',
        'latitude',
        'longitude',
        'birthdate',
        'guardian_name',
        'guardian_relationship',
        'guardian_contact',
        'guardian_email',
        'guardian_is_account_owner',
        'profile_photo_path',
        'profile_photo_original_name',
        'profile_photo_mime_type',
        'profile_photo_size',
        'profile_photo_updated_at',
        'profile_photo_review_status',
        'profile_photo_review_note',
        'profile_photo_reviewed_by',
        'profile_photo_reviewed_at',
        'profile_photo_review_application_id',
        'verification_status',
        'verification_notes',
        'verified_at',
        'verified_by',
    ];

    protected function casts(): array
    {
        return [
            'birthdate' => 'date',
            'completed_qualification_year' => 'integer',
            'gwa' => 'decimal:2',
            'academic_result_extracted_at' => 'datetime',
            'household_size' => 'integer',
            'latitude' => 'decimal:7',
            'longitude' => 'decimal:7',
            'guardian_is_account_owner' => 'boolean',
            'profile_photo_size' => 'integer',
            'profile_photo_updated_at' => 'datetime',
            'profile_photo_reviewed_at' => 'datetime',
            'verified_at' => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function verifier(): BelongsTo
    {
        return $this->belongsTo(User::class, 'verified_by');
    }
}

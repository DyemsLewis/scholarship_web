<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ScholarshipApplication extends Model
{
    protected $fillable = [
        'scholarship_id',
        'applicant_id',
        'status',
        'workflow_version',
        'application_state',
        'workflow_stage',
        'final_outcome',
        'submission_snapshot',
        'document_checklist',
        'optional_document_checklist',
        'eligibility_score',
        'eligibility_breakdown',
        'review_rubric_snapshot',
        'application_answers',
        'rubric_scores',
        'rubric_total_score',
        'rubric_scored_by',
        'rubric_scored_at',
        'notes',
        'review_notes',
        'correction_status',
        'correction_message',
        'correction_targets',
        'correction_response',
        'correction_requested_by',
        'correction_requested_at',
        'correction_responded_at',
        'correction_resolved_at',
        'withdrawal_reason',
        'withdrawn_by',
        'withdrawn_at',
        'waitlist_position',
        'waitlisted_at',
        'decision_reason',
        'awarded_amount',
        'outcome_notes',
        'outcome_at',
        'distribution_scheduled_for',
        'distribution_instructions',
        'dss_score',
        'dss_recommendation',
        'dss_breakdown',
        'reviewed_by',
        'assigned_reviewer_id',
        'reviewed_at',
        'submitted_at',
        'terms_accepted_at',
        'terms_version',
        'provider_contract_terms_snapshot',
        'provider_contract_terms_accepted_at',
        'provider_contract_terms_version',
        'provider_contract_acceptance_ip',
        'provider_contract_acceptance_user_agent',
        'student_response_status',
        'student_responded_at',
        'student_response_terms_accepted_at',
        'student_response_terms_version',
        'student_response_note',
    ];

    protected function casts(): array
    {
        return [
            'document_checklist' => 'array',
            'optional_document_checklist' => 'array',
            'workflow_version' => 'integer',
            'submission_snapshot' => 'array',
            'eligibility_score' => 'decimal:2',
            'eligibility_breakdown' => 'array',
            'review_rubric_snapshot' => 'array',
            'application_answers' => 'array',
            'rubric_scores' => 'array',
            'rubric_total_score' => 'decimal:2',
            'rubric_scored_at' => 'datetime',
            'correction_targets' => 'array',
            'correction_requested_at' => 'datetime',
            'correction_responded_at' => 'datetime',
            'correction_resolved_at' => 'datetime',
            'withdrawn_at' => 'datetime',
            'waitlist_position' => 'integer',
            'waitlisted_at' => 'datetime',
            'awarded_amount' => 'decimal:2',
            'outcome_at' => 'datetime',
            'distribution_scheduled_for' => 'date',
            'dss_score' => 'decimal:2',
            'dss_breakdown' => 'array',
            'reviewed_at' => 'datetime',
            'submitted_at' => 'datetime',
            'terms_accepted_at' => 'datetime',
            'provider_contract_terms_snapshot' => 'array',
            'provider_contract_terms_accepted_at' => 'datetime',
            'student_responded_at' => 'datetime',
            'student_response_terms_accepted_at' => 'datetime',
        ];
    }

    public function scholarship(): BelongsTo
    {
        return $this->belongsTo(Scholarship::class);
    }

    public function applicant(): BelongsTo
    {
        return $this->belongsTo(User::class, 'applicant_id');
    }

    public function documents(): HasMany
    {
        return $this->hasMany(ApplicationDocument::class);
    }

    public function reviewer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'reviewed_by');
    }

    public function assignedReviewer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_reviewer_id');
    }

    public function rubricScorer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'rubric_scored_by');
    }

    public function statusHistories(): HasMany
    {
        return $this->hasMany(ApplicationStatusHistory::class);
    }

    public function dssSnapshots(): HasMany
    {
        return $this->hasMany(DssCalculationSnapshot::class);
    }

    public function funnelEvents(): HasMany
    {
        return $this->hasMany(ScholarshipFunnelEvent::class);
    }

    public function schedules(): HasMany
    {
        return $this->hasMany(ApplicationSchedule::class);
    }

    public function stageProgresses(): HasMany
    {
        return $this->hasMany(ApplicationStageProgress::class)->orderBy('position');
    }

    public function stageAssignments(): HasMany
    {
        return $this->hasMany(ApplicationStageAssignment::class);
    }

    public function stageEvidence(): HasMany
    {
        return $this->hasMany(ApplicationStageEvidence::class);
    }

    public function stageAuditEvents(): HasMany
    {
        return $this->hasMany(ApplicationStageAuditEvent::class);
    }

    public function monitoringSubmissions(): HasMany
    {
        return $this->hasMany(RecipientMonitoringSubmission::class);
    }

    public function monitoringAdjustmentRequests(): HasMany
    {
        return $this->hasMany(RecipientMonitoringAdjustmentRequest::class);
    }

    public function monitoringInterventions(): HasMany
    {
        return $this->hasMany(RecipientMonitoringIntervention::class);
    }

    public function monitoringCases(): HasMany
    {
        return $this->hasMany(RecipientMonitoringCase::class);
    }

    public function benefitReleaseRecords(): HasMany
    {
        return $this->hasMany(RecipientBenefitReleaseRecord::class);
    }

    public function benefitEntitlements(): HasMany
    {
        return $this->hasMany(RecipientBenefitEntitlement::class);
    }

    public function benefitReceiptResponses(): HasMany
    {
        return $this->hasMany(RecipientBenefitReceiptResponse::class);
    }

    public function supportDecisions(): HasMany
    {
        return $this->hasMany(RecipientSupportDecision::class)
            ->orderByDesc('decided_at')
            ->orderByDesc('id');
    }

    public function recipientWithdrawalRequests(): HasMany
    {
        return $this->hasMany(RecipientWithdrawalRequest::class)->orderByDesc('id');
    }

    public function recipientAgreementCases(): HasMany
    {
        return $this->hasMany(RecipientAgreementCase::class)->orderByDesc('id');
    }

    public function monitoringOversightReviews(): HasMany
    {
        return $this->hasMany(RecipientMonitoringOversightReview::class)
            ->orderByDesc('reviewed_at')
            ->orderByDesc('id');
    }
}

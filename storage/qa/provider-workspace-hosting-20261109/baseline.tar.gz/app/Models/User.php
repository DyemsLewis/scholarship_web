<?php

namespace App\Models;

use App\Services\ApplicantEvidenceReviewService;
use App\Support\AcademicRequirement;
use App\Support\AdminWorkspace;
use App\Support\CoverImageCatalog;
use App\Support\EducationEligibilityPolicy;
use App\Support\ProviderWorkspace;
use Carbon\CarbonImmutable;
use Database\Factories\UserFactory;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable implements MustVerifyEmail
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    public const ADMIN_PERMISSIONS = [
        'manage_accounts',
        'manage_reviews',
        'manage_reports',
        'manage_billing',
        'view_finance',
        'view_logs',
        'export_data',
    ];

    public const PROVIDER_PERMISSIONS = [
        'manage_programs',
        'verify_applications',
        'manage_selection_activities',
        'record_final_decisions',
        'manage_recipients',
        'manage_monitoring',
        'manage_benefit_releases',
        'manage_reports',
        'manage_profile',
        'manage_team',
        'manage_billing',
    ];

    public const PROVIDER_GOVERNANCE_PERMISSIONS = [
        'manage_profile',
        'manage_team',
    ];

    /**
     * Legacy permissions remain readable so existing provider accounts keep
     * working while their roles are migrated to the focused workspaces.
     *
     * @var array<string, list<string>>
     */
    public const PROVIDER_LEGACY_PERMISSION_BUNDLES = [
        'review_applications' => [
            'verify_applications',
            'manage_selection_activities',
            'record_final_decisions',
            'manage_recipients',
            'manage_monitoring',
            'manage_benefit_releases',
        ],
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'parent_account_id',
        'email',
        'username',
        'role',
        'account_title',
        'permissions',
        'assigned_program_ids',
        'password',
        'account_status',
        'must_reset_password',
        'password_reset_required_at',
        'terms_accepted_at',
        'privacy_accepted_at',
        'terms_version',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'suspended_at' => 'datetime',
            'must_reset_password' => 'boolean',
            'password_reset_required_at' => 'datetime',
            'terms_accepted_at' => 'datetime',
            'privacy_accepted_at' => 'datetime',
            'permissions' => 'array',
            'assigned_program_ids' => 'array',
        ];
    }

    public function parentAccount(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_account_id');
    }

    public function managedAccounts(): HasMany
    {
        return $this->hasMany(self::class, 'parent_account_id');
    }

    public function studentProfile(): HasOne
    {
        return $this->hasOne(StudentProfile::class);
    }

    public function providerProfile(): HasOne
    {
        return $this->hasOne(ProviderProfile::class);
    }

    public function adminProfile(): HasOne
    {
        return $this->hasOne(AdminProfile::class);
    }

    public function notifications(): HasMany
    {
        return $this->hasMany(PortalNotification::class);
    }

    public function scholarshipBookmarks(): HasMany
    {
        return $this->hasMany(ScholarshipBookmark::class);
    }

    public function studentDocuments(): HasMany
    {
        return $this->hasMany(StudentDocument::class);
    }

    public function applicantVerificationDocuments(): HasMany
    {
        return $this->hasMany(ApplicantVerificationDocument::class, 'applicant_id');
    }

    public function applicantAcademicVerificationStatus(): string
    {
        if (! $this->isApplicant()) {
            return 'unsubmitted';
        }

        $hasAcademicRecord = $this->relationLoaded('applicantVerificationDocuments')
            ? $this->applicantVerificationDocuments->contains('document_type', 'academic_record')
            : $this->applicantVerificationDocuments()
                ->where('document_type', 'academic_record')
                ->exists();

        return $hasAcademicRecord
            ? ($this->studentProfile?->verification_status ?? 'pending')
            : 'unsubmitted';
    }

    public function scholarshipFunnelEvents(): HasMany
    {
        return $this->hasMany(ScholarshipFunnelEvent::class);
    }

    public function dssSnapshots(): HasMany
    {
        return $this->hasMany(DssCalculationSnapshot::class, 'applicant_id');
    }

    public function providerVerificationDocuments(): HasMany
    {
        return $this->hasMany(ProviderVerificationDocument::class, 'provider_id');
    }

    public function providerAssessments(): HasMany
    {
        return $this->hasMany(ProviderAssessment::class, 'provider_id');
    }

    public function providerServicePurchases(): HasMany
    {
        return $this->hasMany(ProviderServicePurchase::class, 'provider_id');
    }

    public function providerServiceRequests(): HasMany
    {
        return $this->hasMany(ProviderServiceRequest::class, 'provider_id');
    }

    public function providerScholarships(): HasMany
    {
        return $this->hasMany(Scholarship::class, 'provider_id');
    }

    public function initiatedProviderServicePurchases(): HasMany
    {
        return $this->hasMany(ProviderServicePurchase::class, 'created_by');
    }

    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }

    public function isProvider(): bool
    {
        return $this->role === 'provider';
    }

    public function isApplicant(): bool
    {
        return $this->role === 'applicant';
    }

    public function isManagedAccount(): bool
    {
        return $this->parent_account_id !== null;
    }

    public function hasPortalPermission(string $permission): bool
    {
        if (! $this->isAdmin() && ! $this->isProvider()) {
            return false;
        }

        if ($this->isAdmin() && ! $this->isManagedAccount()) {
            return true;
        }

        return in_array($permission, $this->effectivePortalPermissions(), true);
    }

    /** @param  iterable<string>  $permissions */
    public function hasAnyPortalPermission(iterable $permissions): bool
    {
        foreach ($permissions as $permission) {
            if ($this->hasPortalPermission($permission)) {
                return true;
            }
        }

        return false;
    }

    /** @return list<string> */
    public function effectivePortalPermissions(): array
    {
        if (! $this->isAdmin() && ! $this->isProvider()) {
            return [];
        }

        if ($this->isAdmin() && ! $this->isManagedAccount()) {
            return self::ADMIN_PERMISSIONS;
        }

        $permissions = collect(
            $this->isProvider() && ! $this->isManagedAccount() && empty($this->permissions)
                ? self::PROVIDER_GOVERNANCE_PERMISSIONS
                : ($this->permissions ?? []),
        );

        if ($this->isProvider()) {
            foreach (self::PROVIDER_LEGACY_PERMISSION_BUNDLES as $legacyPermission => $expandedPermissions) {
                if ($permissions->contains($legacyPermission)) {
                    $permissions = $permissions->merge($expandedPermissions);
                }
            }
        }

        return $permissions
            ->filter(fn ($permission): bool => is_string($permission))
            ->unique()
            ->values()
            ->all();
    }

    public function providerOperatingMode(): ?string
    {
        if (! $this->isProvider() || $this->isManagedAccount()) {
            return null;
        }

        return array_diff(self::PROVIDER_PERMISSIONS, $this->effectivePortalPermissions()) === []
            ? 'solo_operator'
            : 'governance';
    }

    public function providerOrganizationId(): int
    {
        return $this->isProvider() && $this->parent_account_id
            ? (int) $this->parent_account_id
            : (int) $this->id;
    }

    public function providerOrganizationOwner(): self
    {
        if (! $this->isProvider() || ! $this->parent_account_id) {
            return $this;
        }

        $owner = $this->relationLoaded('parentAccount')
            ? $this->parentAccount
            : $this->parentAccount()->with('providerProfile')->first();

        $owner?->loadMissing('providerProfile');

        return $owner ?? $this;
    }

    public function hasLimitedProviderProgramAccess(): bool
    {
        return $this->isProvider()
            && $this->isManagedAccount()
            && is_array($this->assigned_program_ids);
    }

    public function assignedProviderProgramIds(): array
    {
        return collect($this->assigned_program_ids ?? [])
            ->map(fn ($id) => (int) $id)
            ->filter(fn (int $id) => $id > 0)
            ->unique()
            ->values()
            ->all();
    }

    public function canAccessProviderProgram(Scholarship|int|null $program): bool
    {
        if (! $this->isProvider() || $program === null) {
            return false;
        }

        $programId = $program instanceof Scholarship ? (int) $program->id : (int) $program;
        $providerId = $program instanceof Scholarship ? (int) $program->provider_id : null;

        if ($providerId !== null && $providerId !== $this->providerOrganizationId()) {
            return false;
        }

        return ! $this->hasLimitedProviderProgramAccess()
            || in_array($programId, $this->assignedProviderProgramIds(), true);
    }

    public function isSuspended(): bool
    {
        return $this->account_status === 'suspended';
    }

    public function isActive(): bool
    {
        return ! $this->isSuspended();
    }

    public function getNameAttribute(): string
    {
        if ($this->isProvider() && $this->isManagedAccount() && $this->contactName()) {
            return $this->contactName();
        }

        if ($this->isProvider() && $this->provider_name) {
            return $this->provider_name;
        }

        if ($this->isAdmin() && $this->adminProfile?->display_name) {
            return $this->adminProfile->display_name;
        }

        return $this->contactName() ?: ($this->username ?: $this->email);
    }

    public function getFirstNameAttribute(): ?string
    {
        return $this->profileRecord()?->first_name;
    }

    public function getLastNameAttribute(): ?string
    {
        return $this->profileRecord()?->last_name;
    }

    public function getMiddleInitialAttribute(): ?string
    {
        return $this->profileRecord()?->middle_initial;
    }

    public function getSuffixAttribute(): ?string
    {
        return $this->studentProfile?->suffix;
    }

    public function getGenderAttribute(): ?string
    {
        return $this->studentProfile?->gender;
    }

    public function getContactNumberAttribute(): ?string
    {
        return $this->profileRecord()?->contact_number;
    }

    public function getProviderNameAttribute(): ?string
    {
        return $this->providerProfile?->provider_name;
    }

    public function getProviderTypeAttribute(): ?string
    {
        return $this->providerProfile?->provider_type;
    }

    public function getProviderWebsiteAttribute(): ?string
    {
        return $this->providerProfile?->provider_website;
    }

    public function getProviderAddressAttribute(): ?string
    {
        return $this->providerProfile?->provider_address;
    }

    public function getProviderDescriptionAttribute(): ?string
    {
        return $this->providerProfile?->provider_description;
    }

    public function getIsAdminAttribute(): bool
    {
        return $this->isAdmin();
    }

    public function publicPayload(): array
    {
        $birthdate = $this->studentProfile?->birthdate;
        $age = $birthdate?->age;
        $providerOwner = $this->isProvider() ? $this->providerOrganizationOwner() : null;
        $providerProfile = $providerOwner?->providerProfile ?? $this->providerProfile;
        $applicantVerificationStatus = $this->applicantAcademicVerificationStatus();

        return [
            'id' => $this->id,
            'parent_account_id' => $this->parent_account_id,
            'account_title' => $this->account_title,
            'permissions' => $this->isProvider()
                ? array_values(array_intersect(self::PROVIDER_PERMISSIONS, $this->effectivePortalPermissions()))
                : array_values($this->permissions ?? []),
            'is_managed_account' => $this->isManagedAccount(),
            'has_full_access' => ! $this->isManagedAccount()
                && ($this->isAdmin() || $this->providerOperatingMode() === 'solo_operator'),
            'is_organization_owner' => $this->isProvider() && ! $this->isManagedAccount(),
            'provider_operating_mode' => $this->providerOperatingMode(),
            'provider_workspace_url' => ProviderWorkspace::preferredPath($this),
            'admin_workspace_key' => $this->isAdmin() ? AdminWorkspace::key($this) : null,
            'admin_workspace_url' => $this->isAdmin() ? AdminWorkspace::preferredPath($this) : null,
            'name' => $this->name,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'middle_initial' => $this->middle_initial,
            'suffix' => $this->suffix,
            'gender' => $this->gender,
            'email' => $this->email,
            'email_verified' => $this->hasVerifiedEmail(),
            'email_verified_at' => $this->email_verified_at?->format('M d, Y h:i A'),
            'terms_accepted_at' => $this->terms_accepted_at?->format('M d, Y h:i A'),
            'privacy_accepted_at' => $this->privacy_accepted_at?->format('M d, Y h:i A'),
            'terms_version' => $this->terms_version,
            'username' => $this->username,
            'contact_number' => $this->contact_number,
            'account_status' => $this->account_status ?? 'active',
            'is_suspended' => $this->isSuspended(),
            'suspended_at' => $this->suspended_at?->format('M d, Y h:i A'),
            'suspension_reason' => $this->suspension_reason,
            'must_reset_password' => (bool) $this->must_reset_password,
            'password_reset_required_at' => $this->password_reset_required_at?->format('M d, Y h:i A'),
            'account_managed_by' => $this->studentProfile?->account_managed_by,
            'citizenship_status' => $this->studentProfile?->citizenship_status,
            'display_name' => $this->adminProfile?->display_name,
            'provider_name' => $providerProfile?->provider_name,
            'provider_type' => $providerProfile?->provider_type,
            'provider_website' => $providerProfile?->provider_website,
            'provider_address' => $providerProfile?->provider_address,
            'provider_latitude' => $providerProfile?->latitude,
            'provider_longitude' => $providerProfile?->longitude,
            'provider_description' => $providerProfile?->provider_description,
            'provider_mission' => $providerProfile?->mission,
            'provider_year_established' => $providerProfile?->year_established,
            'provider_service_area' => $providerProfile?->service_area,
            'provider_logo_path' => $providerProfile?->logo_path,
            'provider_logo_url' => filled($providerProfile?->logo_path)
                ? asset(ltrim($providerProfile->logo_path, '/'))
                : null,
            'provider_cover_source' => $providerProfile?->cover_image_source ?: 'default',
            'provider_cover_key' => $providerProfile?->cover_image_key,
            'provider_cover_url' => $this->isProvider()
                ? CoverImageCatalog::providerUrl($providerProfile)
                : null,
            'provider_contact_email' => $providerProfile?->provider_contact_email,
            'provider_contact_number' => $providerProfile?->provider_contact_number,
            'provider_contact_department' => $providerProfile?->contact_department,
            'provider_office_hours' => $providerProfile?->office_hours,
            'verification_status' => $providerProfile?->verification_status,
            'verification_notes' => $providerProfile?->verification_notes,
            'can_post_scholarships' => $this->isProvider()
                && $providerOwner?->isActive()
                && $providerOwner?->hasVerifiedEmail()
                && $providerOwner?->providerProfile?->isVerified(),
            'applicant_verification_status' => $applicantVerificationStatus,
            'applicant_verification_notes' => $this->studentProfile?->verification_notes,
            'applicant_verified_at' => $applicantVerificationStatus === 'approved'
                ? $this->studentProfile?->verified_at?->format('M d, Y')
                : null,
            'is_profile_verified' => $this->isApplicant() && $applicantVerificationStatus === 'approved',
            'evidence_review' => $this->isApplicant() ? app(ApplicantEvidenceReviewService::class)->summary($this) : null,
            'profile_evidence_requirements' => $this->isApplicant()
                ? ApplicantVerificationDocument::requirementsFor($this)
                : [],
            'education_level' => $this->studentProfile?->education_level,
            'completed_qualification' => $this->studentProfile?->completed_qualification,
            'completed_qualification_school' => $this->studentProfile?->completed_qualification_school,
            'completed_qualification_year' => $this->studentProfile?->completed_qualification_year,
            'completed_qualification_details' => $this->studentProfile?->completed_qualification_details,
            'school' => $this->studentProfile?->school,
            'school_type' => $this->studentProfile?->school_type,
            'learner_reference_number' => $this->studentProfile?->learner_reference_number,
            'course_or_strand' => $this->studentProfile?->course_or_strand,
            'year_level' => $this->studentProfile?->year_level,
            'enrollment_status' => $this->studentProfile?->enrollment_status,
            'academic_year' => $this->studentProfile?->academic_year,
            'academic_term' => $this->studentProfile?->academic_term,
            'gwa' => $this->studentProfile?->gwa,
            'grading_scale' => $this->studentProfile?->grading_scale,
            'academic_result_source' => $this->studentProfile?->academic_result_source,
            'academic_result_extracted_at' => $this->studentProfile?->academic_result_extracted_at?->format('M d, Y h:i A'),
            'income_bracket' => $this->studentProfile?->income_bracket,
            'household_size' => $this->studentProfile?->household_size,
            'preferred_categories' => $this->studentProfile?->preferred_categories,
            'preferred_locations' => $this->studentProfile?->preferred_locations,
            'willing_to_relocate' => $this->studentProfile?->willing_to_relocate,
            'support_needs' => $this->studentProfile?->support_needs,
            'current_scholarship_status' => $this->studentProfile?->current_scholarship_status,
            'current_scholarship_details' => $this->studentProfile?->current_scholarship_details,
            'scholarship_goal' => $this->studentProfile?->scholarship_goal,
            'achievements' => $this->studentProfile?->achievements,
            'activities_and_responsibilities' => $this->studentProfile?->activities_and_responsibilities,
            'address' => $this->studentProfile?->address,
            'barangay' => $this->studentProfile?->barangay,
            'city' => $this->studentProfile?->city,
            'province' => $this->studentProfile?->province,
            'region' => $this->studentProfile?->region,
            'latitude' => $this->studentProfile?->latitude,
            'longitude' => $this->studentProfile?->longitude,
            'birthdate' => $this->studentProfile?->birthdate?->format('Y-m-d'),
            'age' => $age,
            'is_minor' => $age !== null && $age < 18,
            'profile_updated_at' => $this->studentProfile?->updated_at?->toISOString(),
            'guardian_name' => $this->studentProfile?->guardian_name,
            'guardian_relationship' => $this->studentProfile?->guardian_relationship,
            'guardian_contact' => $this->studentProfile?->guardian_contact,
            'guardian_email' => $this->studentProfile?->guardian_email,
            'guardian_is_account_owner' => (bool) $this->studentProfile?->guardian_is_account_owner,
            'has_profile_photo' => filled($this->studentProfile?->profile_photo_path),
            'profile_photo_updated_at' => $this->studentProfile?->profile_photo_updated_at?->toISOString(),
            'profile_photo_review_status' => $this->studentProfile?->profile_photo_review_status,
            'profile_photo_review_note' => $this->studentProfile?->profile_photo_review_note,
            'profile_photo_reviewed_at' => $this->studentProfile?->profile_photo_reviewed_at?->format('M d, Y h:i A'),
            'role' => $this->role,
            'is_admin' => $this->is_admin,
        ];
    }

    public static function applicantProfileRequiredFields(?array $payload = null): array
    {
        $payload ??= [];
        $educationLevel = $payload['education_level'] ?? null;
        $pendingStudies = in_array($payload['enrollment_status'] ?? null, EducationEligibilityPolicy::PENDING_STUDIES, true);
        $requiresCoursePath = in_array($educationLevel, ['senior_high_school', 'college', 'tvet'], true) && ! $pendingStudies;
        $requiresGrades = ! in_array($educationLevel, ['preschool'], true);
        $requiresGuardian = self::applicantRequiresGuardian($payload);

        $fields = [
            'first_name' => 'First name',
            'last_name' => 'Last name',
            'has_profile_photo' => 'Applicant 1x1 or 2x2 photo',
            'contact_number' => 'Contact number',
            'account_managed_by' => 'Account manager',
            'birthdate' => 'Birthdate',
            'citizenship_status' => 'Citizenship declaration',
        ];

        $fields += [
            'education_level' => 'Education level',
            'school' => 'School / learning institution',
            'enrollment_status' => 'Enrollment status',
        ];

        if ($requiresCoursePath) {
            $fields['course_or_strand'] = 'Track / strand / course / program';
        }

        if (! $pendingStudies) {
            $fields['year_level'] = 'Grade / year level';
        }

        if (filled($payload['completed_qualification'] ?? null) && $payload['completed_qualification'] !== 'none') {
            $fields['completed_qualification_school'] = 'Completed qualification school / institution';
            if ($payload['completed_qualification'] === 'other') {
                $fields['completed_qualification_details'] = 'Completed qualification name';
            }
        }

        if ($requiresGrades) {
            $fields['academic_year'] = 'Academic year';
            $fields['academic_term'] = 'Academic term or grading period';
            $fields['grading_scale'] = 'Grading scale';

            if (blank($payload['grading_scale'] ?? null)
                || AcademicRequirement::requiresNumeric($payload['grading_scale'])) {
                $fields['gwa'] = 'GWA / general average';
            }
        }

        $fields += [
            'income_bracket' => 'Household income bracket',
            'household_size' => 'Household size',
            'current_scholarship_status' => 'Outside scholarship status',
            'city' => 'City / municipality',
            'province' => 'Province',
            'region' => 'Region',
        ];

        if (in_array($payload['current_scholarship_status'] ?? null, ['receiving', 'pending'], true)) {
            $fields['current_scholarship_details'] = 'Outside scholarship details';
        }

        if ($requiresGuardian) {
            $fields += [
                'guardian_name' => 'Guardian name',
                'guardian_relationship' => 'Guardian relationship',
                'guardian_contact' => 'Guardian contact',
                'guardian_email' => 'Guardian email',
            ];
        }

        return $fields;
    }

    public function applicantProfileReadiness(): array
    {
        $this->loadMissing('studentProfile');

        $payload = $this->publicPayload();
        $fields = self::applicantProfileRequiredFields($payload);
        $missing = collect($fields)
            ->reject(fn (string $label, string $key) => $key === 'has_profile_photo'
                ? ($payload[$key] ?? false) === true
                : filled($payload[$key] ?? null))
            ->map(fn (string $label, string $key) => [
                'key' => $key,
                'label' => $label,
            ])
            ->values()
            ->all();
        $total = count($fields);
        $completed = $total - count($missing);

        return [
            'complete' => $missing === [],
            'verified' => (bool) $payload['is_profile_verified'],
            'verification_status' => $payload['applicant_verification_status'],
            'completed' => $completed,
            'total' => $total,
            'percent' => $total === 0 ? 100 : (int) round(($completed / $total) * 100),
            'missing' => $missing,
            'is_minor' => self::applicantIsMinor($payload),
            'requires_guardian' => self::applicantRequiresGuardian($payload),
        ];
    }

    public static function applicantIsMinor(?array $payload = null): bool
    {
        $birthdate = $payload['birthdate'] ?? null;

        if (blank($birthdate)) {
            return false;
        }

        try {
            return CarbonImmutable::parse($birthdate)->age < 18;
        } catch (\Throwable) {
            return false;
        }
    }

    public static function applicantRequiresGuardian(?array $payload = null): bool
    {
        $payload ??= [];

        return self::applicantIsMinor($payload)
            || in_array($payload['education_level'] ?? null, ['preschool', 'elementary', 'junior_high_school', 'senior_high_school'], true)
            || in_array($payload['account_managed_by'] ?? null, ['parent_guardian', 'relative', 'school_representative', 'other'], true);
    }

    public function hasCompleteApplicantProfile(): bool
    {
        return $this->applicantProfileReadiness()['complete'];
    }

    private function profileRecord()
    {
        return match ($this->role) {
            'admin' => $this->adminProfile,
            'provider' => $this->providerProfile,
            default => $this->studentProfile,
        };
    }

    private function contactName(): ?string
    {
        $parts = collect([
            $this->first_name,
            $this->middle_initial ? "{$this->middle_initial}." : null,
            $this->last_name,
            $this->suffix,
        ])->filter()->values();

        return $parts->isEmpty() ? null : $parts->implode(' ');
    }
}

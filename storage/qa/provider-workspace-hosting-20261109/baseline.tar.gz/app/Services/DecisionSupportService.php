<?php

namespace App\Services;

use App\Models\ApplicationDocument;
use App\Models\DssCalculationSnapshot;
use App\Models\ScholarshipApplication;
use App\Support\AcademicRequirement;
use App\Support\EducationEligibilityPolicy;
use App\Support\EligibilityReviewSummary;
use App\Support\EligibilityRulePolicy;
use App\Support\ScholarshipSelectionPlan;

class DecisionSupportService
{
    public const METHODOLOGY_VERSION = '2.2';

    private const WEIGHTS = [
        'eligibility' => 65,
        'academic' => 20,
        'financial_need' => 15,
    ];

    public function scoreApplication(ScholarshipApplication $application): array
    {
        $application->loadMissing(['applicant.studentProfile', 'documents', 'scholarship']);

        $eligibilityScore = $this->eligibilityScore($application);
        $documentScore = $this->documentScore($application);
        $academicScore = $this->academicScore($application);
        $financialNeedScore = $this->financialNeedScore($application);
        $reviewStatusScore = $this->reviewStatusScore($application);

        $criteria = [
            $this->criterion('eligibility', 'Eligibility match', $eligibilityScore, 'How well the applicant matches structured scholarship criteria.'),
            $this->criterion('academic', 'Academic merit', $academicScore, 'Academic record compared with the scholarship grading requirement.'),
            $this->criterion('financial_need', 'Financial need', $financialNeedScore, 'Income bracket priority for assistance-focused scholarships.'),
        ];

        $score = collect($criteria)->sum(fn (array $criterion) => $criterion['weighted_score']);
        $score = (int) round($score);
        $recommendation = $this->recommendation($score);

        return [
            'methodology_version' => self::METHODOLOGY_VERSION,
            'score' => $score,
            'suitability_score' => $score,
            'recommendation' => $recommendation['value'],
            'label' => $recommendation['label'],
            'summary' => $recommendation['summary'],
            'weights' => self::WEIGHTS,
            'criteria' => $criteria,
            'application_readiness' => [
                'score' => $documentScore,
                'label' => $this->readinessLabel($documentScore),
                'summary' => 'Measures required-document preparation and acceptance. It does not change applicant suitability.',
            ],
            'review_progress' => [
                'score' => $reviewStatusScore,
                'status' => $application->status,
                'label' => $this->statusLabel($application->status),
                'summary' => 'Shows where the provider is in the review workflow. It does not change applicant suitability.',
            ],
            'decision_notice' => 'Advisory only, not an approval or rejection. Confirm required rules and evidence; preferred differences are review context. The scholarship provider makes the final decision.',
        ];
    }

    public function syncApplication(ScholarshipApplication $application, string $source = 'system'): array
    {
        $eligibilitySnapshot = $this->currentEligibilitySnapshot($application);
        $storedEligibilityScore = $application->eligibility_score;
        $storedEligibilityBreakdown = $application->eligibility_breakdown;
        $preserveSubmittedEligibility = $this->shouldPreserveSubmittedEligibility($application, $source);

        // Program criteria and applicant profiles can change after submission. Refresh the
        // in-memory values before scoring and snapshotting, while keeping the comparison
        // attached to a submitted application immutable for provider review.
        if ($eligibilitySnapshot !== null) {
            $application->setAttribute('eligibility_score', $eligibilitySnapshot['score']);
            $application->setAttribute('eligibility_breakdown', $eligibilitySnapshot);
        }

        $score = $this->scoreApplication($application);

        $updates = [
            'dss_score' => $score['score'],
            'dss_recommendation' => $score['recommendation'],
            'dss_breakdown' => $score,
        ];

        if ($eligibilitySnapshot !== null && ! $preserveSubmittedEligibility) {
            $updates['eligibility_score'] = $eligibilitySnapshot['score'];
            $updates['eligibility_breakdown'] = $eligibilitySnapshot;
        }

        if ($preserveSubmittedEligibility) {
            $application->setAttribute('eligibility_score', $storedEligibilityScore);
            $application->setAttribute('eligibility_breakdown', $storedEligibilityBreakdown);
        }

        $application->forceFill($updates)->saveQuietly();
        $this->captureSnapshot($application->fresh(), $score, $eligibilitySnapshot, $source);

        return $score;
    }

    private function shouldPreserveSubmittedEligibility(
        ScholarshipApplication $application,
        string $source,
    ): bool {
        if (! is_array($application->eligibility_breakdown)) {
            return false;
        }

        if (is_array(data_get($application->submission_snapshot, 'current'))) {
            return true;
        }

        if (in_array($source, ['submission', 'web_application_submitted', 'mobile_application_submitted'], true)) {
            return false;
        }

        return $application->dssSnapshots()
            ->whereIn('source', ['submission', 'web_application_submitted', 'mobile_application_submitted'])
            ->exists();
    }

    public function explainApplication(ScholarshipApplication $application, ?array $score = null): array
    {
        $application->loadMissing(['applicant.studentProfile', 'documents', 'scholarship']);

        $score ??= $this->scoreApplication($application);
        $eligibility = $application->eligibility_breakdown ?? $this->currentEligibilitySnapshot($application) ?? [];
        $eligibilityCriteria = collect($eligibility['criteria'] ?? [])
            ->filter(fn (array $criterion): bool => ($criterion['category'] ?? 'eligibility') === 'eligibility'
                && ($criterion['key'] ?? null) !== 'documents');
        $comparison = $this->eligibilityComparisonSummary($eligibilityCriteria);
        $comparisonContext = $this->eligibilityComparisonContext($application, $eligibility);
        $requirements = app(ScholarshipEligibilityService::class)
            ->applicationDocumentRequirements($application);
        $uploadedDocuments = $application->documents->pluck('document_name')->all();
        $acceptedDocuments = $application->documents
            ->filter(fn (ApplicationDocument $document) => $document->status === 'accepted')
            ->pluck('document_name')
            ->all();
        $missingUploads = collect($requirements)
            ->reject(fn (string $requirement) => $this->containsRequirement($uploadedDocuments, $requirement))
            ->values();
        $missingAccepted = collect($requirements)
            ->reject(fn (string $requirement) => $this->containsRequirement($acceptedDocuments, $requirement))
            ->values();

        $strengths = collect($score['criteria'] ?? [])
            ->filter(fn (array $criterion) => (int) ($criterion['score'] ?? 0) >= 80)
            ->map(fn (array $criterion) => "{$criterion['label']} is strong.");

        $strengths = $strengths->merge(
            $eligibilityCriteria
                ->filter(fn (array $criterion): bool => ($criterion['status'] ?? null) === 'pass' && ! EligibilityReviewSummary::needsReview($criterion))
                ->pluck('note')
        );

        if ($requirements !== [] && $missingUploads->isEmpty()) {
            $strengths->push('All required documents have been uploaded.');
        }

        $needsAttention = collect($score['criteria'] ?? [])
            ->filter(fn (array $criterion) => (int) ($criterion['score'] ?? 0) < 60)
            ->map(fn (array $criterion) => "{$criterion['label']} needs attention.");

        $needsAttention = $needsAttention->merge(
            $eligibilityCriteria
                ->filter(fn (array $criterion): bool => ($criterion['category'] ?? 'eligibility') === 'eligibility'
                    && (in_array($criterion['status'] ?? '', ['fail', 'missing'], true) || EligibilityReviewSummary::needsReview($criterion)))
                ->map(fn (array $criterion): string => match (true) {
                    EligibilityRulePolicy::isBlocking($criterion) => 'Required rule discrepancy: '.($criterion['label'] ?? 'Eligibility rule').'. Confirm the saved value against evidence.',
                    EligibilityReviewSummary::needsReview($criterion) => 'Evidence review: '.($criterion['label'] ?? 'Eligibility rule').'. This is not an automatic match or failure.',
                    ($criterion['status'] ?? null) === 'fail' => 'Preference not matched: '.($criterion['label'] ?? 'Eligibility rule').'. This did not block submission.',
                    default => 'Profile information needed: '.($criterion['label'] ?? 'Eligibility rule').'.',
                })
        );

        if ($missingUploads->isNotEmpty()) {
            $needsAttention->push('Missing uploads: '.$missingUploads->take(3)->implode(', ').($missingUploads->count() > 3 ? ', and more' : '').'.');
        } elseif ($missingAccepted->isNotEmpty()) {
            $needsAttention->push('Some uploaded documents still need provider acceptance.');
        }

        return [
            'headline' => match ($comparison['state']) {
                'required_mismatch' => 'Confirm required rule discrepancies before deciding.',
                'provisional' => 'Suitability score is provisional.',
                'manual_review' => 'Review the evidence before interpreting the score.',
                'preferred_difference' => 'Preferences differ; review the complete applicant record.',
                default => $this->explanationHeadline($score['recommendation'] ?? 'needs_review', $application->status),
            },
            'summary' => $comparison['interpretation'],
            'comparison' => $comparison,
            'eligibility_context' => $comparisonContext,
            'score_interpretation' => $comparison['interpretation'],
            'strengths' => $strengths
                ->filter()
                ->unique()
                ->take(4)
                ->values()
                ->all(),
            'needs_attention' => $needsAttention
                ->filter()
                ->unique()
                ->take(4)
                ->values()
                ->all(),
            'next_action' => $this->recommendedNextAction($application, $score, $missingUploads->all(), $missingAccepted->all(), $comparison),
        ];
    }

    private function eligibilityComparisonSummary(iterable $criteria): array
    {
        return EligibilityReviewSummary::from(['criteria' => collect($criteria)->all()]);
    }

    private function eligibilityComparisonContext(ScholarshipApplication $application, array $saved): array
    {
        $current = $this->currentEligibilitySnapshot($application);
        $hasSaved = is_array($application->eligibility_breakdown);
        $basis = ! $hasSaved ? 'current'
            : (is_array(data_get($application->submission_snapshot, 'current')) ? 'submission' : 'saved');
        $checks = fn (array $value) => collect($value['criteria'] ?? [])
            ->filter(fn (array $item): bool => ($item['category'] ?? 'eligibility') === 'eligibility'
                && ($item['key'] ?? null) !== 'documents')
            ->keyBy('key');
        $ruleChanges = [];
        $profileChanges = [];

        if ($hasSaved && $current !== null) {
            $oldChecks = $checks($saved);
            $newChecks = $checks($current);
            $normalize = fn ($value): string => str((string) $value)->replace('_', ' ')->lower()->squish()->toString();
            foreach ($oldChecks->keys()->merge($newChecks->keys())->unique() as $key) {
                $old = $oldChecks->get($key);
                $new = $newChecks->get($key);
                $label = $old['label'] ?? $new['label'] ?? $key;
                $isOpen = fn (?array $item): bool => $item === null
                    || (($item['status'] ?? null) === 'info' && ! EligibilityReviewSummary::needsReview($item));
                if (! ($isOpen($old) && $isOpen($new))
                    && ($old === null || $new === null
                        || ($old['rule_mode'] ?? 'required') !== ($new['rule_mode'] ?? 'required')
                        || $normalize($old['requirement'] ?? null) !== $normalize($new['requirement'] ?? null)
                        || ($old['rule_context'] ?? null) !== ($new['rule_context'] ?? null))) {
                    $ruleChanges[] = $label;
                }
                if ($old !== null && $new !== null
                    && $normalize($old['student_value'] ?? null) !== $normalize($new['student_value'] ?? null)) {
                    $profileChanges[] = $label;
                }
            }
        }

        $hasChanges = $ruleChanges !== [] || $profileChanges !== [];

        return [
            'basis' => $basis,
            'legacy_required_defaults' => $hasSaved && $checks($saved)->contains(
                fn (array $item): bool => ! in_array($item['rule_mode'] ?? null, EligibilityRulePolicy::MODES, true),
            ),
            'label' => match ($basis) {
                'submission' => 'Saved submission comparison',
                'saved' => 'Saved application comparison',
                default => 'Current comparison - no saved snapshot',
            },
            'rule_changes' => $ruleChanges,
            'profile_changes' => $profileChanges,
            'has_changes' => $hasChanges,
            'score_basis' => 'The DSS suitability score uses current rules and profile data. It is advisory and may differ from the saved application comparison.',
            'current_comparison' => $hasChanges ? [
                'criteria' => $current['criteria'],
                'summary' => EligibilityReviewSummary::from($current),
            ] : null,
        ];
    }

    public function statusProgress(ScholarshipApplication $application): array
    {
        $workflow = app(ApplicationWorkflowService::class)->payload($application);
        $status = $application->status ?: 'submitted';
        $steps = collect($workflow['steps'])
            ->map(fn (array $step): array => [
                'key' => $step['key'],
                'label' => $step['label'],
                'description' => $step['description'],
                'state' => match ($step['status']) {
                    'passed' => 'complete',
                    'not_passed' => 'stopped',
                    'current' => 'current',
                    'skipped' => 'skipped',
                    default => 'upcoming',
                },
                'result' => $step['result'],
            ])
            ->values()
            ->all();

        return [
            'current' => $status,
            'label' => $this->statusLabel($status),
            'application_state' => $workflow['application_state'],
            'application_state_label' => $workflow['application_state_label'],
            'current_stage' => $workflow['current_stage'],
            'current_stage_label' => $workflow['current_stage_label'],
            'configured_stages' => collect($workflow['steps'])->pluck('key')->all(),
            'completed_steps' => $workflow['completed_steps'],
            'total_steps' => $workflow['total_steps'],
            'percent' => $workflow['percent'],
            'tone' => $this->statusTone($status),
            'next_action' => $workflow['next_action']['label'],
            'next_action_details' => $workflow['next_action'],
            'provider_action_details' => $workflow['provider_action'],
            'steps' => $steps,
        ];
    }

    private function progressStage(ScholarshipApplication $application, array $selectionStages): string
    {
        $status = $application->status ?: 'submitted';

        if ($status === 'rejected') {
            $rejectionHistory = $application->statusHistories
                ->sortByDesc('changed_at')
                ->first(fn ($history): bool => $history->to_status === 'rejected');
            $stage = $this->stageForStatus($rejectionHistory?->from_status ?? 'under_review');

            return in_array($stage, $selectionStages, true) ? $stage : 'screening';
        }

        if ($status === 'not_awarded') {
            return 'handoff';
        }

        $stage = $this->stageForStatus($status);

        if (in_array($stage, ['submitted', 'handoff'], true) || in_array($stage, $selectionStages, true)) {
            return $stage;
        }

        return collect($selectionStages)->reject(fn (string $candidate): bool => $candidate === 'distribution')->last()
            ?? 'screening';
    }

    private function stageForStatus(?string $status): string
    {
        return match ($status) {
            null, '', 'submitted' => 'submitted',
            'under_review', 'qualified', 'shortlisted', 'other' => 'screening',
            'exam_qualified', 'exam_scheduled', 'exam_taken', 'exam_passed', 'exam_failed' => 'exam',
            'interview', 'interview_failed' => 'interview',
            'approved', 'waitlisted' => 'handoff',
            'awarded', 'distribution_scheduled', 'disbursed', 'renewed' => 'distribution',
            default => 'screening',
        };
    }

    private function captureSnapshot(
        ScholarshipApplication $application,
        array $score,
        ?array $eligibilitySnapshot,
        string $source,
    ): void {
        $application->loadMissing(['applicant.studentProfile', 'documents', 'scholarship']);
        $profile = $application->applicant?->studentProfile;
        $scholarship = $application->scholarship;

        if (! $profile || ! $scholarship) {
            return;
        }

        $applicantInputs = [
            'profile_updated_at' => $profile->updated_at?->toISOString(),
            'education_level' => $profile->education_level,
            'completed_qualification' => $profile->completed_qualification,
            'completed_qualification_school' => $profile->completed_qualification_school,
            'completed_qualification_year' => $profile->completed_qualification_year,
            'completed_qualification_details' => $profile->completed_qualification_details,
            'school_type' => $profile->school_type,
            'course_or_strand' => $profile->course_or_strand,
            'year_level' => $profile->year_level,
            'gwa' => $profile->gwa,
            'grading_scale' => AcademicRequirement::normalizeScale($profile->grading_scale, $profile->gwa),
            'enrollment_status' => $profile->enrollment_status,
            'current_scholarship_status' => $profile->current_scholarship_status,
            'income_bracket' => $profile->income_bracket,
            'barangay' => $profile->barangay,
            'city' => $profile->city,
            'province' => $profile->province,
            'region' => $profile->region,
        ];
        $scholarshipInputs = [
            'scholarship_updated_at' => $scholarship->updated_at?->toISOString(),
            'status' => $scholarship->status,
            'deadline' => $scholarship->deadline?->toDateString(),
            'eligible_education_levels' => $scholarship->eligible_education_levels,
            'eligible_courses' => $scholarship->eligible_courses,
            'eligible_school_types' => $scholarship->eligible_school_types,
            'eligible_year_levels' => $scholarship->eligible_year_levels,
            'eligible_locations' => $scholarship->eligible_locations,
            'income_requirement' => $scholarship->income_requirement,
            'minimum_gwa' => $scholarship->minimum_gwa,
            'minimum_grade_scale' => AcademicRequirement::normalizeScale($scholarship->minimum_grade_scale, $scholarship->minimum_gwa),
            'eligibility_rule_modes' => $scholarship->eligibilityRuleModes(),
            'education_eligibility_policy' => EducationEligibilityPolicy::normalize($scholarship->education_eligibility_policy),
            'eligibility_conditions' => $scholarship->eligibility_conditions ?? [],
            'exclude_current_scholarship_recipients' => (bool) $scholarship->exclude_current_scholarship_recipients,
            'requirements' => $scholarship->requirements,
        ];
        $documentInputs = $application->documents
            ->sortBy('id')
            ->map(fn (ApplicationDocument $document): array => [
                'id' => $document->id,
                'name' => $document->document_name,
                'status' => $document->status,
                'updated_at' => $document->updated_at?->toISOString(),
            ])
            ->values()
            ->all();
        $eligibility = $eligibilitySnapshot ?? $application->eligibility_breakdown ?? [];
        $academicEvaluation = collect($eligibility['criteria'] ?? [])->firstWhere('key', 'academic');
        $fingerprint = hash('sha256', json_encode([
            'methodology_version' => self::METHODOLOGY_VERSION,
            'application_status' => $application->status,
            'document_checklist' => $application->document_checklist ?? [],
            'documents' => $documentInputs,
            'applicant' => $applicantInputs,
            'scholarship' => $scholarshipInputs,
            'eligibility' => $eligibility,
            'score' => $score,
        ], JSON_THROW_ON_ERROR));

        DssCalculationSnapshot::query()->firstOrCreate([
            'scholarship_application_id' => $application->id,
            'input_hash' => $fingerprint,
        ], [
            'applicant_id' => $application->applicant_id,
            'scholarship_id' => $application->scholarship_id,
            'methodology_version' => self::METHODOLOGY_VERSION,
            'source' => $source,
            'eligibility_score' => $eligibility['score'] ?? $application->eligibility_score,
            'suitability_score' => $score['score'] ?? $application->dss_score,
            'recommendation' => $score['recommendation'] ?? $application->dss_recommendation,
            'eligibility_breakdown' => $eligibility,
            'dss_breakdown' => $score,
            'applicant_inputs' => $applicantInputs,
            'scholarship_inputs' => $scholarshipInputs,
            'academic_evaluation' => $academicEvaluation,
            'calculated_at' => now(),
        ]);
    }

    private function criterion(string $key, string $label, int $score, string $note): array
    {
        $weight = self::WEIGHTS[$key];

        return [
            'key' => $key,
            'label' => $label,
            'score' => $score,
            'weight' => $weight,
            'weighted_score' => round(($score * $weight) / 100, 2),
            'note' => $note,
        ];
    }

    private function eligibilityScore(ScholarshipApplication $application): int
    {
        $currentSnapshot = $this->currentEligibilitySnapshot($application);

        if ($currentSnapshot !== null) {
            return $this->clamp((int) $currentSnapshot['score']);
        }

        if ($application->eligibility_score !== null) {
            return $this->clamp((int) round((float) $application->eligibility_score));
        }

        $breakdown = $application->eligibility_breakdown ?? [];

        return $this->clamp((int) ($breakdown['score'] ?? 60));
    }

    private function currentEligibilitySnapshot(ScholarshipApplication $application): ?array
    {
        if (! $application->applicant?->studentProfile || ! $application->scholarship) {
            return null;
        }

        // File preparation is readiness, not suitability. Keep it outside this score.
        return app(ScholarshipEligibilityService::class)->evaluate(
            $application->scholarship,
            $application->applicant,
            includeReadiness: false,
        );
    }

    private function documentScore(ScholarshipApplication $application): int
    {
        $readiness = app(ScholarshipEligibilityService::class)
            ->applicationDocumentReadiness($application);
        $requiredCount = $readiness['required'];

        if ($requiredCount === 0) {
            return 100;
        }

        $confirmedPercent = $readiness['percent'];
        $uploadedPercent = $readiness['uploaded_percent'];
        $acceptedPercent = $readiness['accepted_percent'];

        return $this->clamp((int) round(($confirmedPercent * 0.15) + ($uploadedPercent * 0.45) + ($acceptedPercent * 0.40)));
    }

    private function academicScore(ScholarshipApplication $application): int
    {
        $gwa = $application->applicant?->studentProfile?->gwa;
        $minimumGwa = $application->scholarship?->minimum_gwa;
        $studentScale = AcademicRequirement::normalizeScale($application->applicant?->studentProfile?->grading_scale, $gwa);
        $requiredScale = AcademicRequirement::normalizeScale($application->scholarship?->minimum_grade_scale, $minimumGwa);

        if (in_array($requiredScale, [AcademicRequirement::SCALE_PASS_FAIL, AcademicRequirement::SCALE_OTHER], true)) {
            return 60;
        }

        if ($gwa === null && $minimumGwa === null) {
            return 100;
        }

        if (in_array($studentScale, [AcademicRequirement::SCALE_PASS_FAIL, AcademicRequirement::SCALE_OTHER], true)
            && AcademicRequirement::requiresNumeric($requiredScale)) {
            return 60;
        }

        if ($gwa === null) {
            return 45;
        }

        if ($minimumGwa === null) {
            return 100;
        }

        $studentGwa = (float) $gwa;
        $requiredGwa = (float) $minimumGwa;

        if ($studentGwa <= 0 || $requiredGwa <= 0) {
            return 60;
        }

        if ($studentScale !== null && $requiredScale !== null && $studentScale !== $requiredScale) {
            return 60;
        }

        if ($requiredScale === AcademicRequirement::SCALE_GRADE_POINT) {
            return $this->clamp((int) round(($requiredGwa / $studentGwa) * 100));
        }

        return $this->clamp((int) round(($studentGwa / $requiredGwa) * 100));
    }

    private function financialNeedScore(ScholarshipApplication $application): int
    {
        $income = strtolower((string) $application->applicant?->studentProfile?->income_bracket);
        $requirement = strtolower((string) $application->scholarship?->income_requirement);

        if ($requirement === '' || $this->isOpenOption($requirement)) {
            return 100;
        }

        if ($income === '') {
            return 50;
        }

        $score = match (true) {
            str_contains($income, 'below') => 100,
            str_contains($income, '10,000 - 20,000') => 90,
            str_contains($income, '20,001 - 40,000') => 75,
            str_contains($income, '40,001 - 60,000') => 55,
            str_contains($income, 'above') => 35,
            default => 60,
        };

        return $this->matchesAnyOption($income, [$requirement])
            ? min(100, $score + 10)
            : max(25, $score - 20);
    }

    private function reviewStatusScore(ScholarshipApplication $application): int
    {
        if ($application->decision_reason === 'missing_documents') {
            return 35;
        }

        if (in_array($application->decision_reason, ['qualified_for_formal_application', 'approved_for_award'], true)) {
            return 100;
        }

        return match ($application->status) {
            'disbursed', 'renewed', 'distribution_scheduled', 'awarded' => 100,
            'approved' => 100,
            'exam_passed' => 97,
            'interview' => 95,
            'shortlisted' => 92,
            'qualified' => 90,
            'exam_taken' => 88,
            'exam_scheduled' => 84,
            'exam_qualified' => 80,
            'under_review' => 75,
            'rejected', 'not_awarded', 'exam_failed', 'interview_failed', 'benefits_terminated', 'withdrawn' => 10,
            default => 60,
        };
    }

    private function recommendation(int $score): array
    {
        if ($score >= 85) {
            return [
                'value' => 'highly_recommended',
                'label' => 'Strong match',
                'summary' => 'Strong suitability based on eligibility, academic information, and financial need.',
            ];
        }

        if ($score >= 70) {
            return [
                'value' => 'recommended',
                'label' => 'Potential match',
                'summary' => 'Good suitability, with some criteria still needing provider confirmation.',
            ];
        }

        if ($score >= 55) {
            return [
                'value' => 'needs_review',
                'label' => 'Needs review',
                'summary' => 'Some suitability criteria are incomplete or need manual confirmation.',
            ];
        }

        return [
            'value' => 'low_priority',
            'label' => 'Limited match',
            'summary' => 'Several current profile values do not match or are still missing.',
        ];
    }

    private function readinessLabel(int $score): string
    {
        return match (true) {
            $score >= 100 => 'Documents ready',
            $score >= 60 => 'Partly ready',
            default => 'Documents needed',
        };
    }

    private function explanationHeadline(string $recommendation, string $status): string
    {
        if (in_array($status, ['awarded', 'distribution_scheduled', 'disbursed', 'renewed'], true)) {
            return 'Award outcome is already recorded.';
        }

        if (in_array($status, ['rejected', 'not_awarded', 'exam_failed', 'interview_failed', 'benefits_terminated', 'withdrawn'], true)) {
            return 'Application is closed; review notes explain the final decision.';
        }

        return match ($recommendation) {
            'highly_recommended' => 'Strong candidate based on current data.',
            'recommended' => 'Good candidate with a few items to confirm.',
            'needs_review' => 'Needs manual review before a decision.',
            'low_priority' => 'Lower priority until missing or weak items improve.',
            'not_recommended' => 'Not recommended based on current review data.',
            default => 'DSS reviewed the current application data.',
        };
    }

    private function recommendedNextAction(ScholarshipApplication $application, array $score, array $missingUploads, array $missingAccepted, array $comparison = []): string
    {
        $workflow = app(ApplicationWorkflowService::class)->payload($application);

        if ($workflow['is_closed']) {
            return 'No stage action is required. Review the recorded result if follow-up is needed.';
        }

        if ($application->correction_status === 'submitted') {
            return 'Review the applicant correction before continuing the current stage.';
        }

        if ($workflow['current_stage'] !== 'screening') {
            return match ($workflow['current_stage']) {
                'formal_application' => 'Confirm whether the applicant completed the provider formal application step.',
                'exam' => 'Record Passed or Not passed after the provider-managed exam.',
                'interview' => 'Record Passed or Not passed after the provider-managed interview.',
                'decision' => 'Record Selected, Waitlisted, or Not selected as the final outcome.',
                default => 'Review the current application stage.',
            };
        }

        if ($missingUploads !== []) {
            return 'Applicant should upload missing requirements before the pre-screening decision.';
        }

        if ($missingAccepted !== []) {
            return 'Provider should review and accept or return the uploaded documents.';
        }

        if (($comparison['required_not_met'] ?? 0) > 0) {
            return 'Confirm the required rule discrepancies using the saved application and supporting evidence before recording the screening result.';
        }

        if (in_array($comparison['state'] ?? null, ['provisional', 'manual_review'], true)) {
            return 'Resolve the missing information or manually review the academic evidence before recording the screening result.';
        }

        if (($score['recommendation'] ?? '') === 'needs_review') {
            return 'Provider should review the flagged criteria and add a decision note.';
        }

        if ((int) ($score['score'] ?? 0) >= 80) {
            return 'Review the rubric and record whether the applicant passes pre-screening.';
        }

        return 'Review eligibility, required files, and rubric criteria before recording the pre-screening result.';
    }

    private function statusTone(string $status): string
    {
        return match ($status) {
            'approved', 'awarded', 'disbursed', 'renewed', 'exam_passed' => 'success',
            'rejected', 'not_awarded', 'exam_failed', 'interview_failed', 'benefits_terminated', 'withdrawn' => 'danger',
            'under_review', 'qualified', 'shortlisted', 'interview', 'exam_qualified', 'exam_scheduled', 'exam_taken', 'distribution_scheduled', 'waitlisted' => 'info',
            default => 'warning',
        };
    }

    private function statusNextAction(string $status, array $selectionStages = []): string
    {
        $nextAfterScreening = $this->nextStageLabel('screening', $selectionStages);
        $nextAfterExam = $this->nextStageLabel('exam', $selectionStages);

        return match ($status) {
            'submitted' => 'Your pre-screening submission is waiting for the provider to check eligibility and required files.',
            'under_review', 'qualified', 'shortlisted', 'other' => "The provider is reviewing your submission. If qualified, you will move to {$nextAfterScreening}.",
            'interview' => 'Follow the shared interview details when posted. The provider will record whether you qualify after review.',
            'exam_qualified' => 'You passed screening. Wait for the provider to post the shared exam schedule.',
            'exam_scheduled' => 'Review and confirm the posted exam schedule, then follow its instructions.',
            'exam_taken' => "Your exam participation is recorded. Wait for the provider decision for {$nextAfterExam}.",
            'exam_passed' => "You passed the exam. Wait for the provider decision for {$nextAfterExam}.",
            'exam_failed' => 'This application did not advance after the exam. Check the provider note for context.',
            'interview_failed' => 'This application did not advance after the interview. Check the provider note for context.',
            'approved' => 'You passed portal pre-screening. Review the documents and instructions for continuing with the provider.',
            'waitlisted' => 'You are an eligible alternate. The provider will notify you if an award slot becomes available.',
            'awarded' => 'Your award is recorded. Wait for the provider to post reward distribution details.',
            'distribution_scheduled' => 'Reward distribution is scheduled; follow the provider instructions.',
            'disbursed' => 'Scholarship support has been released.',
            'renewed' => 'Scholarship renewal has been recorded.',
            'benefits_terminated' => 'The provider stopped future scholarship benefits. Review the recorded reason and provider explanation.',
            'rejected' => 'This pre-screening submission did not qualify for the next stage. Check the provider note.',
            'not_awarded' => 'The provider recorded that the formal process ended without an award.',
            'withdrawn' => 'You withdrew this application. No further review action is required.',
            default => 'Continue monitoring this application.',
        };
    }

    private function nextStageLabel(string $currentStage, array $selectionStages): string
    {
        $stages = ScholarshipSelectionPlan::normalize($selectionStages);
        $currentIndex = array_search($currentStage, $stages, true);
        $nextStage = $currentIndex === false ? null : ($stages[$currentIndex + 1] ?? null);

        return match ($nextStage) {
            'exam' => 'the exam stage',
            'interview' => 'the interview stage',
            'distribution' => 'formal provider processing',
            default => 'the formal provider application',
        };
    }

    private function statusLabel(string $status): string
    {
        return match ($status) {
            'approved' => 'Qualified for formal application',
            'waitlisted' => 'Waitlisted alternate',
            'withdrawn' => 'Withdrawn',
            'awarded' => 'Awarded',
            'not_awarded' => 'Not selected',
            'rejected' => 'Not qualified',
            'exam_qualified' => 'Qualified for exam',
            'exam_scheduled' => 'Exam scheduled',
            'exam_taken' => 'Exam taken',
            'exam_passed' => 'Passed exam',
            'exam_failed' => 'Failed exam',
            'interview_failed' => 'Failed interview',
            'distribution_scheduled' => 'Distribution scheduled',
            'disbursed' => 'Distributed',
            'benefits_terminated' => 'Benefits stopped',
            'for_exam' => 'Meets exam eligibility',
            'exam_completed' => 'Exam completed',
            'passed_exam' => 'Passed exam',
            'failed_exam' => 'Failed exam',
            'failed_interview' => 'Failed interview',
            default => str($status)->replace('_', ' ')->title()->toString(),
        };
    }

    private function containsRequirement(array $documents, string $requirement): bool
    {
        $normalizedRequirement = str($requirement)->lower()->squish()->toString();

        return collect($documents)->contains(function (string $document) use ($normalizedRequirement) {
            $normalizedDocument = str($document)->lower()->squish()->toString();

            return $normalizedDocument === $normalizedRequirement
                || str_contains($normalizedDocument, $normalizedRequirement)
                || str_contains($normalizedRequirement, $normalizedDocument);
        });
    }

    private function matchesAnyOption(string $value, array $options): bool
    {
        $normalizedValue = str($value)->lower()->squish()->toString();

        if ($this->hasOpenOption($options)) {
            return true;
        }

        return collect($options)->contains(function (string $option) use ($normalizedValue) {
            $normalizedOption = str($option)->lower()->squish()->toString();

            return str_contains($normalizedValue, $normalizedOption) || str_contains($normalizedOption, $normalizedValue);
        });
    }

    private function hasOpenOption(array $options): bool
    {
        return collect($options)->contains(fn (string $option) => $this->isOpenOption($option));
    }

    private function isOpenOption(?string $option): bool
    {
        if (! filled($option)) {
            return false;
        }

        $normalized = strtolower((string) preg_replace('/\s+/', ' ', trim(str_replace(['.', ';', ':'], '', $option))));

        return in_array($normalized, [
            'any',
            'all',
            'none',
            'n/a',
            'na',
            'not applicable',
            'no preference',
            'no restriction',
            'no restrictions',
            'open to all',
            'all students',
            'any student',
            'all applicants',
            'any applicant',
            'all education levels',
            'any education level',
            'all levels',
            'any level',
            'all courses',
            'any course',
            'all strands',
            'any strand',
            'all tracks',
            'any track',
            'all grades',
            'any grade',
            'all years',
            'any year',
            'all school types',
            'any school type',
            'all locations',
            'any location',
            'all regions',
            'any region',
            'nationwide',
            'philippines',
            'the philippines',
            'republic of the philippines',
            'nationwide philippines',
            'philippines nationwide',
            'anywhere in the philippines',
            'within the philippines',
            'all over the philippines',
            'all philippines',
            'no income requirement',
        ], true)
            || str_starts_with($normalized, 'any ')
            || str_starts_with($normalized, 'all ')
            || str_contains($normalized, 'n/a')
            || str_contains($normalized, 'open to all')
            || str_contains($normalized, 'no restriction')
            || str_contains($normalized, 'no preference')
            || str_contains($normalized, 'not applicable')
            || (str_contains($normalized, 'nationwide') && ! str_contains($normalized, 'not nationwide'))
            || str_contains($normalized, 'anywhere in the philippines')
            || str_contains($normalized, 'within the philippines')
            || str_contains($normalized, 'all over the philippines');
    }

    private function clamp(int $score): int
    {
        return max(0, min(100, $score));
    }
}

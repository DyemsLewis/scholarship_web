<?php

namespace App\Services;

use App\Models\ApplicantVerificationDocument;
use App\Models\StudentDocument;
use App\Models\User;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RuntimeException;

class ApplicantDocumentLibraryService
{
    private const VERIFICATION_DOCUMENT_NAMES = [
        'academic_record' => 'Latest report card or grades',
        'recent_school_id' => 'Recent school ID',
        'school_record' => 'Certificate of enrollment',
        'identity_record' => 'Proof of identity',
        'income_record' => 'Proof of income',
        'residency_record' => 'Proof of residence',
        'guardian_record' => 'Parent or guardian valid ID',
        'no_current_scholarship_proof' => 'Proof of no current scholarship',
        'achievement_evidence' => 'Achievement evidence',
        'qualification_record' => 'Completed qualification record',
    ];

    public function ensureVerificationCopy(User $user, ApplicantVerificationDocument $verificationDocument): ?StudentDocument
    {
        $documentName = self::VERIFICATION_DOCUMENT_NAMES[$verificationDocument->document_type] ?? null;

        if (! $documentName || $verificationDocument->applicant_id !== $user->id) {
            return null;
        }

        $existing = StudentDocument::query()
            ->where('user_id', $user->id)
            ->where('document_name', $documentName)
            ->first();

        if ($existing) {
            return null;
        }

        $disk = Storage::disk('local');

        if (! $disk->exists($verificationDocument->path)) {
            return null;
        }

        $extension = pathinfo($verificationDocument->path, PATHINFO_EXTENSION);
        $targetPath = "student-documents/{$user->id}/verification-{$verificationDocument->id}-".(string) Str::uuid()
            .($extension !== '' ? ".{$extension}" : '');

        if (! $disk->copy($verificationDocument->path, $targetPath)) {
            throw new RuntimeException('Unable to copy the academic record into the prepared-document library.');
        }

        $document = StudentDocument::query()->firstOrCreate([
            'user_id' => $user->id,
            'document_name' => $documentName,
        ], [
            'original_name' => $verificationDocument->original_name,
            'path' => $targetPath,
            'mime_type' => $verificationDocument->mime_type,
            'size' => $verificationDocument->size,
            'uploaded_at' => $verificationDocument->uploaded_at ?? now(),
            'terms_accepted_at' => $verificationDocument->terms_accepted_at ?? now(),
            'terms_version' => $verificationDocument->terms_version,
        ]);

        if (! $document->wasRecentlyCreated) {
            $disk->delete($targetPath);

            return null;
        }

        return $document;
    }
}

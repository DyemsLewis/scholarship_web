<?php

namespace App\Services;

use App\Models\ApplicationDocument;
use App\Models\Scholarship;
use App\Models\ScholarshipApplication;
use App\Models\StudentDocument;
use App\Models\User;
use App\Support\AcademicRequirement;
use App\Support\EducationEligibilityPolicy;
use App\Support\EligibilityRulePolicy;
use App\Support\LearnerProgramPath;
use App\Support\ScholarshipEligibilityCondition;

class ScholarshipEligibilityService
{
    private const ACTIVE_PLATFORM_AWARD_STATUSES = [
        'awarded',
        'distribution_scheduled',
        'disbursed',
        'renewed',
    ];

    private array $activePlatformScholarshipsByUser = [];

    public function evaluate(Scholarship $scholarship, ?User $user, bool $includeReadiness = true): array
    {
        $profile = $user?->studentProfile;
        $criteria = [];
        $passed = 0;
        $applicable = 0;
        $ruleModes = $scholarship->eligibilityRuleModes();

        $addCriterion = function (
            string $key,
            string $label,
            string $status,
            ?string $studentValue,
            ?string $requirement,
            string $note,
            bool $counts = true,
            ?string $comparisonMode = null,
            string $category = 'eligibility',
            array $metadata = [],
        ) use (&$criteria, &$passed, &$applicable, $ruleModes, $profile): void {
            $context = EducationEligibilityPolicy::contextualize([
                'key' => $key, 'status' => $status, 'comparison_mode' => $comparisonMode, 'note' => $note,
            ], $profile);
            $status = $context['status'];
            $comparisonMode = $context['comparison_mode'];
            $note = $context['note'];
            $ruleMode = $category === 'eligibility' ? ($ruleModes[$key] ?? 'required') : null;
            $criteria[] = [
                'key' => $key,
                'label' => $label,
                'status' => $status,
                'student_value' => $studentValue,
                'requirement' => $requirement,
                'note' => $note,
                'comparison' => match (true) {
                    $comparisonMode === 'scale_mismatch' => 'Your academic record and this program use different grading scales. The provider must review your evidence; this is not an automatic match or failure.',
                    $comparisonMode === 'manual_review' => $note,
                    $ruleMode === 'preferred' && $status === 'fail' => 'Your profile lists '.($this->displayCriterionValue($studentValue) ?: 'no value').', while the provider prefers '.($this->displayCriterionValue($requirement) ?: 'a different value').'. This preference does not block applying.',
                    default => $this->criterionComparison($status, $studentValue, $requirement, $category),
                },
                'comparison_mode' => $comparisonMode,
                'category' => $category,
                ...$metadata,
                'rule_mode' => $ruleMode,
                'is_blocking' => $status === 'fail' && $category === 'eligibility' && $ruleMode === 'required',
                'needs_review' => in_array($comparisonMode, ['scale_mismatch', 'manual_review'], true),
            ];

            if (! $counts) {
                return;
            }

            $applicable++;

            if ($status === 'pass') {
                $passed++;
            }
        };

        $academicMatch = AcademicRequirement::match($profile?->gwa, $profile?->grading_scale, $scholarship->minimum_gwa, $scholarship->minimum_grade_scale);
        $addCriterion(
            'academic',
            $academicMatch['label'],
            $academicMatch['status'],
            $academicMatch['student_value'],
            $academicMatch['requirement'],
            $academicMatch['note'],
            $academicMatch['counts'],
            $academicMatch['comparison_mode'] ?? null,
            metadata: [
                'student_scale' => $academicMatch['student_scale'],
                'requirement_scale' => $academicMatch['requirement_scale'],
                'is_comparable' => $academicMatch['is_comparable'],
                'equivalence' => $academicMatch['equivalence'] ?? null,
            ],
        );

        $this->addOptionCriterion(
            $addCriterion,
            'education_level',
            'Education level',
            $profile?->education_level,
            $scholarship->eligible_education_levels,
            'This program is open to all education levels.',
            'Your education level matches this program.',
            'Confirm if your education level is eligible.',
            'No education level restriction listed.',
        );
        $this->addOptionCriterion(
            $addCriterion,
            'course',
            'Track / strand / course',
            $profile?->course_or_strand,
            $scholarship->eligible_courses,
            'This program accepts any track, strand, or course.',
            'Your track, strand, or course matches the listed target.',
            'Check if your grade-level track, strand, or course is accepted by the provider.',
            'No track, strand, or course restriction listed.',
        );
        $this->addOptionCriterion(
            $addCriterion,
            'school_type',
            'School type',
            $profile?->school_type,
            $scholarship->eligible_school_types,
            'This program accepts any school type.',
            'Your school type matches this program.',
            'Confirm if your school type is eligible.',
            'No school type restriction listed.',
        );
        $this->addOptionCriterion(
            $addCriterion,
            'year_level',
            'Grade / year level',
            $profile?->year_level,
            $scholarship->eligible_year_levels,
            'This program accepts any grade or year level.',
            'Your grade or year level matches this program.',
            'Confirm if your grade or year level is eligible.',
            'No grade or year level restriction listed.',
        );

        $educationPolicy = EducationEligibilityPolicy::normalize($scholarship->education_eligibility_policy);
        $qualification = EducationEligibilityPolicy::qualification($educationPolicy, $profile);
        if ($qualification !== null) {
            $addCriterion($qualification['key'], $qualification['label'], $qualification['status'],
                $qualification['student_value'], $qualification['requirement'], $qualification['note'], true,
                $qualification['comparison_mode'], metadata: ['rule_context' => $qualification['rule_context']]);
        }

        $studentLocation = collect([
            $profile?->barangay,
            $profile?->city,
            $profile?->province,
            $profile?->region,
            $profile?->address,
        ])->filter()->implode(', ');
        $this->addOptionCriterion(
            $addCriterion,
            'location',
            'Location',
            $studentLocation ?: null,
            $scholarship->eligible_locations,
            'This program is open to all listed locations.',
            'Your location matches the scholarship coverage.',
            'Your location may be outside the listed coverage.',
            'No location restriction listed.',
        );

        if (filled($scholarship->income_requirement) && ! $this->isOpenOption($scholarship->income_requirement)) {
            $income = $profile?->income_bracket;
            $matchesIncome = filled($income) && $this->matchesAnyOption($income, [$scholarship->income_requirement]);
            $addCriterion(
                'income',
                'Income bracket',
                filled($income) ? ($matchesIncome ? 'pass' : 'fail') : 'missing',
                $income,
                $scholarship->income_requirement,
                $matchesIncome ? 'Your income bracket matches the listed preference.' : 'Review the income requirement before applying.',
            );
        } else {
            $addCriterion('income', 'Income bracket', 'info', $profile?->income_bracket, $scholarship->income_requirement, 'No income restriction listed.', false);
        }

        if ($scholarship->exclude_current_scholarship_recipients) {
            $scholarshipStatus = $profile?->current_scholarship_status;
            $activePlatformScholarships = collect($this->activePlatformScholarships($user, $scholarship->id));
            $isReceivingExternalSupport = $scholarshipStatus === 'receiving';
            $hasActivePlatformSupport = $activePlatformScholarships->isNotEmpty();
            $hasAcceptedDeclaration = in_array($scholarshipStatus, ['none', 'pending', 'completed'], true);
            $statusLabels = [
                'none' => 'No scholarship outside this portal',
                'receiving' => 'Receiving scholarship support outside this portal',
                'pending' => 'Outside scholarship application pending',
                'completed' => 'Outside scholarship already completed',
            ];
            $studentValues = collect([
                $hasActivePlatformSupport
                    ? 'Portal record: '.$activePlatformScholarships->pluck('title')->implode(', ')
                    : null,
                $statusLabels[$scholarshipStatus] ?? $scholarshipStatus,
            ])->filter()->implode('; ');
            $addCriterion(
                'current_scholarship_support',
                'Current scholarship support',
                blank($scholarshipStatus)
                    ? 'missing'
                    : (($hasActivePlatformSupport || $isReceivingExternalSupport || ! $hasAcceptedDeclaration) ? 'fail' : 'pass'),
                $studentValues ?: null,
                'Must not receive another active scholarship in this portal or elsewhere',
                $hasActivePlatformSupport
                    ? 'The portal found another active scholarship award on this account.'
                    : ($isReceivingExternalSupport
                        ? 'This provider does not accept applicants receiving scholarship support outside the portal.'
                        : ($hasAcceptedDeclaration
                            ? 'No conflicting active scholarship was found in the portal or external declaration.'
                            : 'Choose an outside scholarship status before applying.')),
            );
        } else {
            $addCriterion(
                'current_scholarship_support',
                'Current scholarship support',
                'info',
                $profile?->current_scholarship_status,
                null,
                'This program does not restrict applicants who receive other scholarship support.',
                false,
            );
        }

        $documentReadiness = $includeReadiness ? $this->preparedDocumentReadiness($scholarship, $user) : null;
        if ($documentReadiness !== null && $documentReadiness['required'] > 0) {
            $documentsReady = $documentReadiness['uploaded'] >= $documentReadiness['required'];
            $addCriterion(
                'documents',
                'Prepared documents',
                $documentsReady ? 'pass' : 'missing',
                "{$documentReadiness['uploaded']} of {$documentReadiness['required']} uploaded",
                implode(', ', $documentReadiness['required_documents']),
                $documentsReady
                    ? 'Your document library already covers this program requirement.'
                    : 'Upload matching documents in Documents to improve readiness before applying.',
                true,
                null,
                'readiness',
            );
        } elseif ($includeReadiness) {
            $addCriterion('documents', 'Prepared documents', 'info', null, null, 'No document requirements listed.', false, null, 'readiness');
        }

        $eligibilityConditions = ScholarshipEligibilityCondition::normalize($scholarship->eligibility_conditions ?? []);
        $requiresEnrollmentCheck = collect($eligibilityConditions)->contains(
            fn (array $condition): bool => $condition['key'] === 'currently_enrolled'
                && $condition['verification_type'] === 'automatic',
        );

        $enrollment = EducationEligibilityPolicy::enrollment($educationPolicy, $requiresEnrollmentCheck, $profile);
        if ($enrollment !== null) {
            $addCriterion($enrollment['key'], $enrollment['label'], $enrollment['status'],
                $enrollment['student_value'], $enrollment['requirement'], $enrollment['note'], true,
                $enrollment['comparison_mode'], metadata: ['rule_context' => $enrollment['rule_context']]);
        }

        $score = $applicable === 0 ? 100 : (int) round(($passed / $applicable) * 100);
        $blockingCriteria = $this->blockers(['criteria' => $criteria]);
        $conditionResults = $this->eligibilityConditionResults($eligibilityConditions, $criteria);
        $eligibilityCriteria = collect($criteria)->where('category', 'eligibility');
        $missingCriteria = $eligibilityCriteria->where('status', 'missing');
        $preferredMismatches = $eligibilityCriteria->where('rule_mode', 'preferred')->where('status', 'fail')->values();
        $reviewCriteria = $eligibilityCriteria->where('needs_review', true)->values();
        $statusCounts = [
            'matched' => $eligibilityCriteria->where('status', 'pass')->count(),
            'different' => $eligibilityCriteria->where('status', 'fail')->count(),
            'missing' => $missingCriteria->count(),
            'open' => $eligibilityCriteria->where('status', 'info')->count(),
        ];
        $differenceSummary = match (true) {
            $blockingCriteria !== [] => 'You cannot apply because your profile does not meet these required rules: '.collect($blockingCriteria)->pluck('label')->implode(', ').'. Review the comparison and correct your profile only if its information is inaccurate.',
            $reviewCriteria->isNotEmpty() => 'The provider needs to review: '.$reviewCriteria->pluck('label')->implode(', ').'. These checks are not confirmed matches.',
            $missingCriteria->isNotEmpty() => 'Add '.str($missingCriteria->pluck('label')->implode(', '))->lower().' to your profile for a complete comparison.',
            $preferredMismatches->isNotEmpty() => 'Your profile does not match these provider preferences: '.$preferredMismatches->pluck('label')->implode(', ').'. Preferred differences do not block an application.',
            $eligibilityCriteria->whereIn('status', ['pass', 'fail', 'missing'])->isEmpty() => 'This program is open for the structured eligibility criteria shown.',
            default => 'Your profile matches every restrictive eligibility rule published for this program.',
        };
        $guidance = match (true) {
            $blockingCriteria !== [] => ['state' => 'blocked', 'label' => 'Required rules not met', 'title' => 'Some required rules do not match'],
            $reviewCriteria->isNotEmpty() => ['state' => 'attention', 'label' => 'Needs review', 'title' => 'Some checks need provider review'],
            $missingCriteria->isNotEmpty() => ['state' => 'attention', 'label' => 'Profile information needed', 'title' => 'Complete your profile comparison'],
            $preferredMismatches->isNotEmpty() => ['state' => 'attention', 'label' => 'Preferences differ', 'title' => 'Some preferences do not match'],
            default => ['state' => 'ready', 'label' => 'No required mismatches', 'title' => 'No required rule mismatches found'],
        };

        return [
            'policy_version' => EligibilityRulePolicy::VERSION,
            'rule_modes' => $ruleModes,
            'score' => $score,
            'passed' => $passed,
            'applicable' => $applicable,
            'is_eligible' => $blockingCriteria === [],
            'blocking_criteria' => $blockingCriteria,
            'preferred_mismatches' => $preferredMismatches->all(),
            'review_criteria' => $reviewCriteria->all(),
            'label' => $score >= 80 ? 'Strong match' : ($score >= 50 ? 'Needs review' : 'Low match'),
            'summary' => $applicable === 0
                ? 'This scholarship has no structured matching rules yet.'
                : "{$passed} of {$applicable} structured criteria match your profile.",
            'difference_summary' => $differenceSummary,
            'guidance' => [...$guidance, 'description' => $differenceSummary],
            'status_counts' => $statusCounts,
            'condition_results' => $conditionResults,
            'criteria' => $criteria,
        ];
    }

    public function activePlatformScholarships(?User $user, ?int $exceptScholarshipId = null): array
    {
        if (! $user) {
            return [];
        }

        if (! array_key_exists($user->id, $this->activePlatformScholarshipsByUser)) {
            $this->activePlatformScholarshipsByUser[$user->id] = ScholarshipApplication::query()
                ->with('scholarship:id,title')
                ->where('applicant_id', $user->id)
                ->whereIn('status', self::ACTIVE_PLATFORM_AWARD_STATUSES)
                ->get(['id', 'scholarship_id', 'status'])
                ->map(fn (ScholarshipApplication $application): array => [
                    'application_id' => $application->id,
                    'scholarship_id' => $application->scholarship_id,
                    'title' => $application->scholarship?->title ?? 'Scholarship program',
                    'status' => $application->status,
                ])
                ->values()
                ->all();
        }

        return collect($this->activePlatformScholarshipsByUser[$user->id])
            ->when(
                $exceptScholarshipId !== null,
                fn ($records) => $records->reject(
                    fn (array $record): bool => (int) $record['scholarship_id'] === $exceptScholarshipId,
                ),
            )
            ->values()
            ->all();
    }

    public function blockers(array $eligibilityMatch): array
    {
        return collect($eligibilityMatch['criteria'] ?? [])
            ->filter(fn (array $criterion): bool => EligibilityRulePolicy::isBlocking($criterion))
            ->map(fn (array $criterion) => [
                'key' => $criterion['key'] ?? null,
                'label' => $criterion['label'] ?? 'Eligibility requirement',
                'student_value' => $criterion['student_value'] ?? null,
                'requirement' => $criterion['requirement'] ?? null,
                'note' => $criterion['note'] ?? null,
                'rule_mode' => 'required',
            ])
            ->values()
            ->all();
    }

    public function applicationDocumentReadiness(ScholarshipApplication $application): array
    {
        $application->loadMissing(['documents', 'scholarship']);

        $requiredDocuments = $this->applicationDocumentRequirements($application);
        $confirmedDocuments = collect($application->document_checklist ?? [])
            ->map(fn (string $document) => trim($document))
            ->filter()
            ->values();
        $normalizedName = static fn (mixed $document): string => str((string) $document)
            ->lower()
            ->squish()
            ->toString();
        $requiredByName = collect($requiredDocuments)
            ->mapWithKeys(fn (string $document): array => [$normalizedName($document) => $document]);
        $confirmedNames = $confirmedDocuments
            ->map($normalizedName)
            ->unique()
            ->values();
        $documentsByName = $application->documents
            ->groupBy(fn (ApplicationDocument $document): string => $normalizedName($document->document_name));
        $requiredCount = count($requiredDocuments);
        $confirmedRequiredCount = $requiredByName
            ->keys()
            ->filter(fn (string $document) => $confirmedNames->contains($document))
            ->count();
        $uploadedRequiredNames = $requiredByName
            ->keys()
            ->filter(fn (string $document) => $documentsByName->has($document))
            ->values();
        $acceptedRequiredNames = $requiredByName
            ->keys()
            ->filter(fn (string $document) => $documentsByName
                ->get($document, collect())
                ->contains(fn (ApplicationDocument $file): bool => $file->status === 'accepted'))
            ->values();
        $uploadedRequiredCount = $uploadedRequiredNames->count();
        $acceptedRequiredCount = $acceptedRequiredNames->count();
        $missing = $requiredByName
            ->except($uploadedRequiredNames->all())
            ->values()
            ->all();
        $notAccepted = $requiredByName
            ->except($acceptedRequiredNames->all())
            ->values()
            ->all();
        $needsAttention = $requiredByName
            ->filter(fn (string $_document, string $name): bool => $documentsByName
                ->get($name, collect())
                ->contains(fn (ApplicationDocument $file): bool => in_array($file->status, ['rejected', 'needs_replacement'], true)))
            ->values()
            ->all();

        return [
            'required' => $requiredCount,
            'confirmed' => $confirmedRequiredCount,
            'percent' => $requiredCount === 0 ? 100 : (int) round(($confirmedRequiredCount / $requiredCount) * 100),
            'uploaded' => $uploadedRequiredCount,
            'uploaded_percent' => $requiredCount === 0 ? 100 : (int) round(($uploadedRequiredCount / $requiredCount) * 100),
            'accepted' => $acceptedRequiredCount,
            'accepted_percent' => $requiredCount === 0 ? 100 : (int) round(($acceptedRequiredCount / $requiredCount) * 100),
            'missing' => $missing,
            'not_accepted' => $notAccepted,
            'needs_attention' => $needsAttention,
            'ready' => $requiredCount === 0 || $acceptedRequiredCount === $requiredCount,
        ];
    }

    public function applicationDocumentRequirements(ScholarshipApplication $application): array
    {
        if ($application->document_checklist === null) {
            return $this->documentRequirements($application->scholarship);
        }

        return collect($application->document_checklist)
            ->map(fn (mixed $document): string => trim((string) $document))
            ->filter()
            ->unique(fn (string $document): string => str($document)->lower()->squish()->toString())
            ->values()
            ->all();
    }

    public function preparedDocumentReadiness(Scholarship $scholarship, ?User $user): array
    {
        $requiredDocuments = $scholarship->application_mode === 'provider_review'
            ? []
            : $this->documentRequirements($scholarship);

        if (! $user) {
            return [
                'required' => count($requiredDocuments),
                'uploaded' => 0,
                'percent' => $requiredDocuments === [] ? 100 : 0,
                'required_documents' => $requiredDocuments,
                'matched' => [],
                'missing' => $requiredDocuments,
            ];
        }

        $user->loadMissing('studentDocuments');
        $preparedNames = $user->studentDocuments
            ->map(fn (StudentDocument $document) => $document->document_name)
            ->values();
        $matched = collect($requiredDocuments)
            ->filter(fn (string $requirement) => $preparedNames->contains($requirement))
            ->values()
            ->all();
        $missing = collect($requiredDocuments)
            ->reject(fn (string $requirement) => in_array($requirement, $matched, true))
            ->values()
            ->all();
        $requiredCount = count($requiredDocuments);
        $uploadedCount = count($matched);

        return [
            'required' => $requiredCount,
            'uploaded' => $uploadedCount,
            'percent' => $requiredCount === 0 ? 100 : (int) round(($uploadedCount / $requiredCount) * 100),
            'required_documents' => $requiredDocuments,
            'matched' => $matched,
            'missing' => $missing,
        ];
    }

    public function documentRequirements(?Scholarship $scholarship): array
    {
        return $this->splitDocumentRequirements($scholarship?->requirements);
    }

    public function optionalDocumentRequirements(?Scholarship $scholarship): array
    {
        $requiredNames = collect($this->documentRequirements($scholarship))
            ->map(fn (string $document): string => str($document)->lower()->squish()->toString());

        return collect($this->splitDocumentRequirements($scholarship?->optional_requirements))
            ->reject(fn (string $document): bool => $requiredNames->contains(
                str($document)->lower()->squish()->toString(),
            ))
            ->unique(fn (string $document): string => str($document)->lower()->squish()->toString())
            ->values()
            ->all();
    }

    public function splitDocumentRequirements(?string $requirements): array
    {
        $requirements = $this->splitOptions($requirements);

        return $this->hasOpenOption($requirements) ? [] : $requirements;
    }

    public function splitOptions(?string $value): array
    {
        if (! $value) {
            return [];
        }

        return collect(preg_split('/\r\n|\r|\n|,/', $value))
            ->map(fn (string $option) => trim($option))
            ->filter()
            ->values()
            ->all();
    }

    public function matchesAnyOption(string $value, array $options): bool
    {
        $normalizedValue = $this->normalizeOption($value);

        if ($this->hasOpenOption($options)) {
            return true;
        }

        return collect($options)->contains(function (string $option) use ($normalizedValue) {
            $normalizedOption = $this->normalizeOption($option);

            return str_contains($normalizedValue, $normalizedOption) || str_contains($normalizedOption, $normalizedValue);
        });
    }

    public function hasOpenOption(array $options): bool
    {
        return collect($options)->contains(fn (string $option) => $this->isOpenOption($option));
    }

    public function isOpenOption(?string $option): bool
    {
        if (! filled($option)) {
            return false;
        }

        $normalized = $this->normalizeOption($option);

        return in_array($normalized, [
            'any',
            'all',
            'none',
            'n/a',
            'na',
            'not applicable',
            'no preference',
            'no restriction',
            'no restrictions',
            'open to all',
            'all students',
            'any student',
            'all applicants',
            'any applicant',
            'all education levels',
            'any education level',
            'all levels',
            'any level',
            'all courses',
            'any course',
            'all strands',
            'any strand',
            'all tracks',
            'any track',
            'all grades',
            'any grade',
            'all years',
            'any year',
            'all school types',
            'any school type',
            'all locations',
            'any location',
            'all regions',
            'any region',
            'nationwide',
            'philippines',
            'the philippines',
            'republic of the philippines',
            'nationwide philippines',
            'philippines nationwide',
            'anywhere in the philippines',
            'within the philippines',
            'all over the philippines',
            'all philippines',
            'no income requirement',
            'no income ceiling',
        ], true)
            || str_starts_with($normalized, 'any ')
            || str_starts_with($normalized, 'all ')
            || str_contains($normalized, 'n/a')
            || str_contains($normalized, 'open to all')
            || str_contains($normalized, 'no restriction')
            || str_contains($normalized, 'no preference')
            || str_contains($normalized, 'not applicable')
            || (str_contains($normalized, 'nationwide') && ! str_contains($normalized, 'not nationwide'))
            || str_contains($normalized, 'anywhere in the philippines')
            || str_contains($normalized, 'within the philippines')
            || str_contains($normalized, 'all over the philippines');
    }

    private function normalizeOption(string $option): string
    {
        return str($option)
            ->lower()
            ->replace(['_', '-', '/'], ' ')
            ->replaceMatches('/[.;:]+/', '')
            ->squish()
            ->toString();
    }

    private function criterionComparison(string $status, ?string $studentValue, ?string $requirement, string $category): string
    {
        if ($category === 'readiness') {
            return $status === 'pass'
                ? 'Your prepared files cover this program requirement.'
                : ($status === 'missing'
                    ? 'Some required files still need to be prepared.'
                    : 'This program does not request files during pre-screening.');
        }

        $displayStudentValue = $this->displayCriterionValue($studentValue);
        $displayRequirement = $this->displayCriterionValue($requirement);

        return match ($status) {
            'pass' => filled($displayStudentValue) && filled($displayRequirement)
                ? "Your profile lists {$displayStudentValue}, which is included in {$displayRequirement}."
                : 'Your profile matches this program rule.',
            'fail' => 'Your profile lists '.($displayStudentValue ?: 'no value').', while this program accepts '.($displayRequirement ?: 'a different value').'.',
            'missing' => 'This program checks '.($displayRequirement ?: 'this information').', but it is missing from your profile.',
            default => filled($displayRequirement)
                ? 'This program is open to all applicants for this criterion.'
                : 'The provider did not set a restriction for this criterion.',
        };
    }

    private function displayCriterionValue(?string $value): ?string
    {
        if (! filled($value)) {
            return $value;
        }

        return collect(explode(',', $value))
            ->map(function (string $part): string {
                $part = trim($part);

                return str_contains($part, '_')
                    ? str($part)->replace('_', ' ')->squish()->title()->toString()
                    : $part;
            })
            ->implode(', ');
    }

    private function eligibilityConditionResults(array $conditions, array $criteria): array
    {
        $criteriaByKey = collect($criteria)->keyBy('key');
        $criterionKeys = [
            'currently_enrolled' => ['enrollment_status'],
            'learner_group' => ['education_level', 'completed_qualification', 'course', 'school_type', 'year_level'],
            'academic_performance' => ['academic'],
            'financial_need' => ['income'],
            'location_coverage' => ['location'],
        ];

        return collect($conditions)->map(function (array $condition) use ($criteriaByKey, $criterionKeys): array {
            $verificationType = $condition['verification_type'];
            $base = [
                'key' => $condition['key'],
                'label' => $condition['label'],
                'statement' => $condition['statement'],
                'verification_type' => $verificationType,
                'source' => $condition['source'],
                'is_blocking' => false,
            ];

            if ($verificationType !== 'automatic') {
                return [
                    ...$base,
                    'status' => match ($verificationType) {
                        'applicant_declaration' => 'confirmation_required',
                        'provider_verification' => 'provider_review',
                        default => 'information',
                    },
                    'note' => match ($verificationType) {
                        'applicant_declaration' => 'The applicant must confirm this condition before submitting.',
                        'provider_verification' => 'The provider will verify this condition during pre-screening.',
                        default => 'This condition is provided for applicant information.',
                    },
                    'criteria_keys' => [],
                ];
            }

            $keys = $criterionKeys[$condition['key']] ?? [];
            $checks = collect($keys)
                ->map(fn (string $key) => $criteriaByKey->get($key))
                ->filter()
                ->values();

            if ($checks->isEmpty()) {
                return [
                    ...$base,
                    'status' => 'provider_review',
                    'note' => 'This condition does not have an automatic profile comparison yet, so the provider will verify it.',
                    'criteria_keys' => $keys,
                ];
            }

            $status = match (true) {
                $checks->contains(fn (array $criterion): bool => $criterion['status'] === 'fail') => 'fail',
                $checks->contains(fn (array $criterion): bool => $criterion['status'] === 'missing') => 'missing',
                default => 'pass',
            };
            $attentionCheck = $checks->first(
                fn (array $criterion): bool => $criterion['status'] === $status,
            ) ?? $checks->first();
            $needsReview = $checks->contains(fn (array $criterion): bool => $criterion['needs_review'] ?? false);
            $isBlocking = $checks->contains(fn (array $criterion): bool => EligibilityRulePolicy::isBlocking($criterion));
            if ($status === 'pass' && $needsReview) {
                $status = 'provider_review';
            }

            return [
                ...$base,
                'status' => $status,
                'is_blocking' => $isBlocking,
                'rule_mode' => $isBlocking ? 'required' : ($attentionCheck['rule_mode'] ?? 'required'),
                'needs_review' => $needsReview,
                'note' => $needsReview && $status !== 'fail'
                    ? 'The provider must review the relevant supporting records. This condition is not a confirmed match.'
                    : ($status === 'pass'
                    ? 'Your profile satisfies this automatically checked condition.'
                    : ($attentionCheck['comparison'] ?? $attentionCheck['note'] ?? 'Review this condition.')),
                'criteria_keys' => $keys,
            ];
        })->values()->all();
    }

    private function addOptionCriterion(
        callable $addCriterion,
        string $key,
        string $label,
        ?string $studentValue,
        ?string $requirements,
        string $openNote,
        string $matchNote,
        string $mismatchNote,
        string $unrestrictedNote,
    ): void {
        $options = $this->splitOptions($requirements);

        if ($this->hasOpenOption($options)) {
            $addCriterion($key, $label, 'info', $studentValue, implode(', ', $options), $openNote, false);

            return;
        }

        if ($options === []) {
            $addCriterion($key, $label, 'info', $studentValue, null, $unrestrictedNote, false);

            return;
        }

        $matches = filled($studentValue) && ($key === 'course'
            ? LearnerProgramPath::matchesAny($studentValue, $options)
            : $this->matchesAnyOption($studentValue, $options));
        $addCriterion(
            $key,
            $label,
            filled($studentValue) ? ($matches ? 'pass' : 'fail') : 'missing',
            $studentValue,
            implode(', ', $options),
            $matches ? $matchNote : $mismatchNote,
        );
    }
}

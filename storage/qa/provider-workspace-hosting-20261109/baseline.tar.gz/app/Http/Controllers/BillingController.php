<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\PortalNotification;
use App\Models\ProviderServiceFile;
use App\Models\ProviderServicePurchase;
use App\Models\ProviderServiceRequest;
use App\Models\ProviderServiceUpdate;
use App\Models\User;
use App\Services\PayMongoCheckoutService;
use App\Services\ProviderServiceLifecycleService;
use App\Support\AdminWorkspace;
use App\Support\CsvExport;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Throwable;

class BillingController extends Controller
{
    public function __construct(
        private readonly PayMongoCheckoutService $payMongo,
        private readonly ProviderServiceLifecycleService $serviceLifecycle,
    ) {}

    public function providerPage(Request $request): View|RedirectResponse
    {
        abort_unless($request->user()?->isProvider(), 403);

        if ($request->routeIs('provider.billing.requests')) {
            return redirect()->route('provider.workspaces.billing.requests');
        }

        if ($request->routeIs('provider.billing') && $request->filled('checkout') && $request->filled('reference')) {
            $owner = $request->user()->providerOrganizationOwner();
            $purchase = ProviderServicePurchase::query()
                ->where('provider_id', $owner->id)
                ->where('reference_number', (string) $request->string('reference'))
                ->first();

            if ($purchase && array_key_exists($purchase->plan_code, config('billing.plans', []))) {
                return redirect()->route('provider.workspaces.billing.services.show', [
                    'plan' => $purchase->plan_code,
                    'checkout' => (string) $request->string('checkout'),
                    'reference' => $purchase->reference_number,
                ]);
            }
        }

        if ($request->route('plan')) {
            abort_unless(array_key_exists((string) $request->route('plan'), config('billing.plans', [])), 404);

            return view('provider-service-detail');
        }

        return view('provider-billing');
    }

    public function providerServiceCatalogData(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isProvider(), 403);

        $owner = $request->user()->providerOrganizationOwner()->loadMissing('providerProfile');

        return response()->json([
            'organization' => [
                'id' => $owner->id,
                'name' => $owner->provider_name ?: $owner->name,
            ],
            'plans' => collect(config('billing.plans', []))
                ->map(fn (array $plan, string $code) => $this->servicePlanPayload($code, $plan))
                ->values(),
        ]);
    }

    public function providerServiceDetailData(Request $request, string $plan): JsonResponse
    {
        abort_unless($request->user()?->isProvider(), 403);

        $plans = config('billing.plans', []);
        abort_unless(array_key_exists($plan, $plans), 404);

        return response()->json([
            'plan' => $this->servicePlanPayload($plan, $plans[$plan], true),
        ]);
    }

    public function providerData(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isProvider(), 403);

        $owner = $request->user()->providerOrganizationOwner()->loadMissing('providerProfile');
        $purchases = ProviderServicePurchase::query()
            ->with(['creator.providerProfile', 'assignee.adminProfile'])
            ->where('provider_id', $owner->id)
            ->latest()
            ->limit(30)
            ->get();

        return response()->json([
            'organization' => [
                'id' => $owner->id,
                'name' => $owner->provider_name ?: $owner->name,
            ],
            'gateway' => [
                'name' => 'PayMongo',
                'configured' => $this->payMongo->isConfigured(),
                'payment_methods' => config('billing.paymongo.payment_methods', []),
            ],
            'plans' => collect(config('billing.plans', []))
                ->map(fn (array $plan, string $code) => $this->servicePlanPayload($code, $plan, true))
                ->values(),
            'purchases' => $purchases->map(fn (ProviderServicePurchase $purchase) => $this->purchasePayload($purchase))->values(),
        ]);
    }

    public function providerBillingStaffWorkspace(Request $request): View
    {
        abort_unless($request->user()?->isProvider(), 403);
        abort_unless($request->user()->hasPortalPermission('manage_billing'), 403);

        return view('provider-billing-staff-workspace');
    }

    public function providerBillingStaffWorkspaceData(Request $request): JsonResponse
    {
        $staff = $request->user();
        abort_unless($staff?->isProvider(), 403);
        abort_unless($staff->hasPortalPermission('manage_billing'), 403);

        $validated = $request->validate([
            'queue' => ['sometimes', Rule::in(['requests', 'needs_action', 'active', 'waiting', 'completed'])],
            'search' => ['sometimes', 'nullable', 'string', 'max:120'],
            'page' => ['sometimes', 'integer', 'min:1'],
        ]);
        $queue = $validated['queue'] ?? 'requests';
        $search = trim((string) ($validated['search'] ?? ''));
        $perPage = 5;
        $owner = $staff->providerOrganizationOwner()->loadMissing('providerProfile');
        $purchaseBase = ProviderServicePurchase::query()
            ->with(['creator.providerProfile', 'assignee.adminProfile'])
            ->where('provider_id', $owner->id);
        $requestBase = ProviderServiceRequest::query()
            ->with(['scholarship', 'purchase'])
            ->where('provider_id', $owner->id)
            ->whereIn('status', ['ready_for_review', 'checkout_started']);
        $legacyPaymentBase = ProviderServicePurchase::query()
            ->with(['creator.providerProfile', 'assignee.adminProfile'])
            ->where('provider_id', $owner->id)
            ->whereNull('service_request_id')
            ->whereIn('status', ['pending', 'failed']);

        $summary = [
            'requests' => (clone $requestBase)->count() + (clone $legacyPaymentBase)->count(),
            'needs_action' => $this->applyProviderBillingQueue((clone $purchaseBase), 'needs_action')->count(),
            'active' => $this->applyProviderBillingQueue((clone $purchaseBase), 'active')->count(),
            'waiting' => $this->applyProviderBillingQueue((clone $purchaseBase), 'waiting')->count(),
            'completed' => $this->applyProviderBillingQueue((clone $purchaseBase), 'completed')->count(),
            'total' => (clone $requestBase)->count()
                + (clone $purchaseBase)->where('status', 'paid')->count()
                + (clone $legacyPaymentBase)->count(),
        ];

        if ($queue === 'requests') {
            $serviceRequests = (clone $requestBase)
                ->when($search !== '', function ($query) use ($search): void {
                    $query->where(function ($builder) use ($search): void {
                        $builder
                            ->where('plan_name', 'like', "%{$search}%")
                            ->orWhere('request_summary', 'like', "%{$search}%")
                            ->orWhereHas('scholarship', fn ($program) => $program->where('title', 'like', "%{$search}%"));
                    });
                })
                ->get()
                ->map(fn (ProviderServiceRequest $serviceRequest) => $this->providerServiceRequestDirectoryPayload($serviceRequest));
            $legacyPayments = (clone $legacyPaymentBase)
                ->when($search !== '', function ($query) use ($search): void {
                    $query->where(function ($builder) use ($search): void {
                        $builder
                            ->where('plan_name', 'like', "%{$search}%")
                            ->orWhere('reference_number', 'like', "%{$search}%")
                            ->orWhere('request_summary', 'like', "%{$search}%");
                    });
                })
                ->get()
                ->map(fn (ProviderServicePurchase $purchase) => $this->providerLegacyPaymentDirectoryPayload($purchase));
            $allEntries = $serviceRequests
                ->merge($legacyPayments)
                ->sortByDesc('updated_at')
                ->values();
            $currentPage = (int) ($validated['page'] ?? 1);
            $records = new LengthAwarePaginator(
                $allEntries->forPage($currentPage, $perPage)->values(),
                $allEntries->count(),
                $perPage,
                $currentPage,
                ['path' => $request->url(), 'query' => $request->query()],
            );
            $entries = collect($records->items())->values();
        } else {
            $records = $this->applyProviderBillingQueue((clone $purchaseBase), $queue)
                ->when($search !== '', function ($query) use ($search): void {
                    $query->where(function ($builder) use ($search): void {
                        $builder
                            ->where('plan_name', 'like', "%{$search}%")
                            ->orWhere('reference_number', 'like', "%{$search}%")
                            ->orWhere('request_summary', 'like', "%{$search}%");
                    });
                })
                ->latest('updated_at')
                ->paginate($perPage);
            $entries = collect($records->items())
                ->map(fn (ProviderServicePurchase $purchase) => $this->providerBillingWorkspacePayload($purchase))
                ->values();
        }

        return response()->json([
            'workspace' => [
                'role' => 'Billing staff',
                'organization_name' => $owner->provider_name ?: $owner->name,
                'gateway_name' => 'PayMongo',
                'gateway_configured' => $this->payMongo->isConfigured(),
                'service_count' => count(config('billing.plans', [])),
                'services_url' => route('provider.workspaces.billing.services'),
            ],
            'summary' => $summary,
            'queue' => $queue,
            'entries' => $entries,
            'requests' => $queue === 'requests' ? $entries : [],
            'purchases' => $queue === 'requests' ? [] : $entries,
            'pagination' => [
                'current_page' => $records->currentPage(),
                'last_page' => $records->lastPage(),
                'per_page' => $records->perPage(),
                'total' => $records->total(),
                'from' => $records->firstItem(),
                'to' => $records->lastItem(),
            ],
        ]);
    }

    public function providerBillingExport(Request $request): StreamedResponse
    {
        $staff = $request->user();
        abort_unless($staff?->isProvider() && $staff->hasPortalPermission('manage_billing'), 403);
        $validated = $request->validate([
            'queue' => ['required', Rule::in(['needs_action', 'active', 'waiting', 'completed'])],
            'search' => ['nullable', 'string', 'max:120'],
        ]);
        $owner = $staff->providerOrganizationOwner();
        $search = trim((string) ($validated['search'] ?? ''));
        $query = $this->applyProviderBillingQueue(
            ProviderServicePurchase::query()->with('assignee.adminProfile')->where('provider_id', $owner->id),
            $validated['queue'],
        )->when($search !== '', function ($builder) use ($search): void {
            $builder->where(function ($searchQuery) use ($search): void {
                $searchQuery->where('plan_name', 'like', "%{$search}%")
                    ->orWhere('reference_number', 'like', "%{$search}%")
                    ->orWhere('request_summary', 'like', "%{$search}%");
            });
        })->latest('updated_at');

        return response()->streamDownload(function () use ($query): void {
            $handle = fopen('php://output', 'wb');
            CsvExport::writeRow($handle, [
                'Reference', 'Service', 'Amount', 'Currency', 'Delivery status', 'Current action',
                'Assigned to', 'Paid at', 'Target due', 'Closed at', 'Revision count',
                'Cancellation status', 'Refund status',
            ]);

            foreach ($query->cursor() as $purchase) {
                CsvExport::writeRow($handle, [
                    $purchase->reference_number,
                    $purchase->plan_name,
                    $purchase->amount,
                    $purchase->currency,
                    $purchase->fulfillment_status,
                    $purchase->current_action,
                    $purchase->assignee?->name,
                    $purchase->paid_at?->toISOString(),
                    $purchase->target_due_at?->toISOString(),
                    $purchase->closed_at?->toISOString(),
                    $purchase->revision_count,
                    $purchase->cancellation_status,
                    $purchase->refund_status,
                ]);
            }

            fclose($handle);
        }, 'provider-services-'.$validated['queue'].'-'.now()->format('Ymd-His').'.csv', [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    public function providerWorkspacePage(Request $request, ProviderServicePurchase $purchase): View
    {
        $this->authorizeProviderPurchase($request, $purchase);

        $workspacePage = match (true) {
            $request->routeIs('provider.billing.workspace.meeting') => 'providerServiceMeeting',
            $request->routeIs('provider.billing.workspace.files') => 'providerServiceFiles',
            $request->routeIs('provider.billing.workspace.updates') => 'providerServiceUpdates',
            $request->routeIs('provider.billing.workspace.closeout') => 'providerServiceCloseout',
            $request->routeIs('provider.billing.workspace.history') => 'providerServiceHistory',
            default => 'providerServiceOverview',
        };

        return view('provider-service-workspace', compact('purchase', 'workspacePage'));
    }

    public function providerWorkspaceData(Request $request, ProviderServicePurchase $purchase): JsonResponse
    {
        $this->authorizeProviderPurchase($request, $purchase);
        $validated = $request->validate([
            'section' => ['sometimes', Rule::in(['overview', 'meeting', 'files', 'updates', 'closeout', 'history'])],
        ]);

        return response()->json([
            'purchase' => $this->workspacePayload($purchase, false, $validated['section'] ?? 'overview'),
        ]);
    }

    public function updateProviderRequest(Request $request, ProviderServicePurchase $purchase): JsonResponse
    {
        $this->authorizeProviderPurchase($request, $purchase);
        $this->requirePaidService($purchase);
        $this->requireNoPendingCancellation($purchase);

        if (in_array($purchase->fulfillment_status, ['provider_review', 'completed', 'cancelled'], true)) {
            return response()->json([
                'message' => 'Reopen this service before changing its request brief.',
            ], 422);
        }

        $validated = $request->validate([
            'request_summary' => ['required', 'string', 'min:20', 'max:2000'],
            'requested_outcome' => ['required', 'string', 'min:10', 'max:1200'],
        ]);

        $purchase = $this->transitionServiceDelivery(
            $purchase,
            $purchase->fulfillment_status === 'needs_information' ? 'ready' : $purchase->fulfillment_status,
            $request->user(),
            [
                'request_summary' => trim($validated['request_summary']),
                'requested_outcome' => trim($validated['requested_outcome']),
                'fulfillment_notes' => $purchase->fulfillment_status === 'needs_information'
                    ? 'The provider supplied additional information. The request is ready for support review.'
                    : $purchase->fulfillment_notes,
            ],
            'provider_information_supplied',
        );

        $update = $purchase->updates()->create([
            'actor_id' => $request->user()->id,
            'kind' => 'provider_response',
            'message' => 'The provider updated the service brief and requested outcome.',
            'visible_to_provider' => true,
        ]);

        ActivityLog::record(
            $request->user(),
            'provider_service_brief_updated',
            "{$request->user()->name} updated the brief for {$purchase->reference_number}.",
            $request,
            ['purchase_id' => $purchase->id],
        );
        $this->notifyBillingAdminsOfUpdate(
            $purchase,
            'Service brief updated',
            "The provider updated the brief for {$purchase->plan_name}.",
            "provider_service_brief:{$update->id}",
            section: 'overview',
        );

        return response()->json([
            'message' => 'Service brief updated.',
            'purchase' => $this->workspacePayload($purchase->fresh(), false, 'overview'),
        ]);
    }

    public function requestProviderMeeting(Request $request, ProviderServicePurchase $purchase): JsonResponse
    {
        $this->authorizeProviderPurchase($request, $purchase);
        $this->requirePaidService($purchase);
        $this->requireNoPendingCancellation($purchase);

        if (in_array($purchase->fulfillment_status, ['completed', 'cancelled'], true)) {
            return response()->json([
                'message' => 'A meeting cannot be requested for a closed service.',
            ], 422);
        }

        $validated = $request->validate([
            'meeting_scheduled_for' => ['required', 'date', 'after:now'],
            'meeting_mode' => ['required', Rule::in(['online', 'onsite'])],
            'meeting_purpose' => ['required', 'string', 'min:10', 'max:1000'],
        ]);

        $purchase->update([
            'meeting_scheduled_for' => $validated['meeting_scheduled_for'],
            'meeting_mode' => $validated['meeting_mode'],
            'meeting_purpose' => trim($validated['meeting_purpose']),
            'meeting_status' => 'requested',
            'meeting_admin_note' => null,
            'meeting_join_url' => null,
            'meeting_decided_at' => null,
            'meeting_decided_by' => null,
            'action_due_at' => null,
        ]);
        $this->clearServiceMeetingReminders($purchase);
        $purchase = $this->serviceLifecycle->syncCurrentAction($purchase);

        $meetingDate = $this->meetingDateLabel($purchase);
        $meetingMode = $purchase->meeting_mode === 'online' ? 'Online' : 'On-site';
        $update = $purchase->updates()->create([
            'actor_id' => $request->user()->id,
            'kind' => 'meeting_request',
            'message' => "Meeting requested for {$meetingDate} ({$meetingMode}). Purpose: {$purchase->meeting_purpose}",
            'visible_to_provider' => true,
        ]);

        ActivityLog::record(
            $request->user(),
            'provider_service_meeting_requested',
            "{$request->user()->name} requested a meeting for {$purchase->reference_number}.",
            $request,
            ['purchase_id' => $purchase->id, 'meeting_scheduled_for' => $purchase->meeting_scheduled_for?->toISOString()],
        );
        $this->notifyBillingAdminsOfUpdate(
            $purchase,
            'Provider requested a meeting',
            "A {$meetingMode} meeting was requested for {$meetingDate} for {$purchase->plan_name}.",
            "provider_service_meeting_request:{$update->id}",
            'provider_service_meeting',
            'meeting',
        );

        return response()->json([
            'message' => 'Meeting request sent for admin confirmation.',
            'purchase' => $this->workspacePayload($purchase, false, 'meeting'),
        ], 201);
    }

    public function storeProviderUpdate(Request $request, ProviderServicePurchase $purchase): JsonResponse
    {
        $this->authorizeProviderPurchase($request, $purchase);
        $this->requirePaidService($purchase);
        $this->requireNoPendingCancellation($purchase);

        if (in_array($purchase->fulfillment_status, ['provider_review', 'completed', 'cancelled'], true)) {
            return response()->json([
                'message' => 'Reopen this service before adding another response.',
            ], 422);
        }

        $validated = $request->validate([
            'message' => ['required', 'string', 'min:3', 'max:2000'],
        ]);
        $update = $purchase->updates()->create([
            'actor_id' => $request->user()->id,
            'kind' => 'provider_response',
            'message' => trim($validated['message']),
            'visible_to_provider' => true,
        ]);

        if ($purchase->fulfillment_status === 'needs_information') {
            $purchase = $this->transitionServiceDelivery(
                $purchase,
                'ready',
                $request->user(),
                ['fulfillment_notes' => 'The provider responded. The request is ready for support review.'],
                'provider_information_supplied',
            );
        }

        ActivityLog::record(
            $request->user(),
            'provider_service_response_added',
            "{$request->user()->name} responded on {$purchase->reference_number}.",
            $request,
            ['purchase_id' => $purchase->id, 'update_id' => $update->id],
        );
        $this->notifyBillingAdminsOfUpdate(
            $purchase,
            'Provider responded to a service request',
            "A new response was added to {$purchase->plan_name}.",
            "provider_service_response:{$update->id}",
            section: 'updates',
        );

        return response()->json([
            'message' => 'Response added.',
            'purchase' => $this->workspacePayload($purchase->fresh(), false, 'updates'),
        ], 201);
    }

    public function uploadProviderFile(Request $request, ProviderServicePurchase $purchase): JsonResponse
    {
        $this->authorizeProviderPurchase($request, $purchase);
        $this->requirePaidService($purchase);
        $this->requireNoPendingCancellation($purchase);

        if (in_array($purchase->fulfillment_status, ['provider_review', 'completed', 'cancelled'], true)) {
            return response()->json([
                'message' => 'Reopen this service before uploading another file.',
            ], 422);
        }

        $validated = $request->validate([
            'service_file' => ['required', 'file', 'max:10240', 'mimes:pdf,jpg,jpeg,png,doc,docx,xls,xlsx,csv,txt'],
        ]);
        $file = $validated['service_file'];
        $path = $file->store("provider-services/{$purchase->id}/supporting", 'local');

        if (! is_string($path)) {
            throw ValidationException::withMessages([
                'service_file' => 'The supporting file could not be stored. Please try again.',
            ]);
        }

        $serviceFile = $purchase->files()->create([
            'uploaded_by' => $request->user()->id,
            'category' => 'supporting',
            'original_name' => $file->getClientOriginalName(),
            'path' => $path,
            'mime_type' => $file->getMimeType(),
            'size' => $file->getSize(),
            'visible_to_provider' => true,
        ]);
        $update = $purchase->updates()->create([
            'actor_id' => $request->user()->id,
            'kind' => 'provider_file',
            'message' => "Supporting file uploaded: {$serviceFile->original_name}",
            'visible_to_provider' => true,
        ]);

        ActivityLog::record(
            $request->user(),
            'provider_service_file_uploaded',
            "{$request->user()->name} uploaded a supporting file to {$purchase->reference_number}.",
            $request,
            ['purchase_id' => $purchase->id, 'file_id' => $serviceFile->id],
        );
        $this->notifyBillingAdminsOfUpdate(
            $purchase,
            'Provider uploaded a service file',
            "A supporting file was added to {$purchase->plan_name}.",
            "provider_service_file:{$update->id}",
            section: 'files',
        );

        return response()->json([
            'message' => 'Supporting file uploaded.',
            'purchase' => $this->workspacePayload($purchase->fresh(), false, 'files'),
        ], 201);
    }

    public function confirmProviderCompletion(Request $request, ProviderServicePurchase $purchase): JsonResponse
    {
        $this->authorizeProviderPurchase($request, $purchase);
        $this->requirePaidService($purchase);
        $this->requireNoPendingCancellation($purchase);

        if ($purchase->fulfillment_status !== 'provider_review') {
            return response()->json([
                'message' => 'This service must be ready for provider review before it can be confirmed complete.',
            ], 422);
        }

        $validated = $request->validate([
            'rating' => ['nullable', 'integer', 'between:1,5'],
            'feedback' => ['nullable', 'string', 'max:2000'],
        ]);

        $purchase = $this->transitionServiceDelivery(
            $purchase,
            'completed',
            $request->user(),
            [
                'provider_confirmed_at' => now(),
                'provider_feedback' => filled($validated['feedback'] ?? null) ? trim($validated['feedback']) : null,
                'provider_rating' => $validated['rating'] ?? null,
                'fulfilled_at' => now(),
                'reopened_at' => null,
            ],
            'provider_completion_confirmed',
        );
        $update = $purchase->updates()->create([
            'actor_id' => $request->user()->id,
            'kind' => 'completion_confirmed',
            'message' => 'The provider confirmed that the service was completed.',
            'visible_to_provider' => true,
        ]);

        ActivityLog::record(
            $request->user(),
            'provider_service_completion_confirmed',
            "{$request->user()->name} confirmed completion of {$purchase->reference_number}.",
            $request,
            ['purchase_id' => $purchase->id, 'rating' => $purchase->provider_rating],
        );
        $this->notifyBillingAdminsOfUpdate(
            $purchase,
            'Provider confirmed service completion',
            "{$purchase->plan_name} was accepted by the provider.",
            "provider_service_confirmed:{$update->id}",
            section: 'closeout',
        );

        return response()->json([
            'message' => 'Service completion confirmed.',
            'purchase' => $this->workspacePayload($purchase->fresh(), false, 'closeout'),
        ]);
    }

    public function reopenProviderService(Request $request, ProviderServicePurchase $purchase): JsonResponse
    {
        $this->authorizeProviderPurchase($request, $purchase);
        $this->requirePaidService($purchase);
        $this->requireNoPendingCancellation($purchase);

        if (! in_array($purchase->fulfillment_status, ['provider_review', 'completed'], true)) {
            return response()->json([
                'message' => 'Only a service awaiting confirmation or already completed can be reopened.',
            ], 422);
        }

        $validated = $request->validate([
            'reason' => ['required', 'string', 'min:10', 'max:2000'],
        ]);
        $update = $purchase->updates()->create([
            'actor_id' => $request->user()->id,
            'kind' => 'reopened',
            'message' => trim($validated['reason']),
            'visible_to_provider' => true,
        ]);
        $purchase = $this->transitionServiceDelivery(
            $purchase,
            'in_progress',
            $request->user(),
            [
                'provider_confirmed_at' => null,
                'fulfilled_at' => null,
            ],
            'provider_revision_requested',
        );

        ActivityLog::record(
            $request->user(),
            'provider_service_reopened',
            "{$request->user()->name} reopened {$purchase->reference_number}.",
            $request,
            ['purchase_id' => $purchase->id, 'update_id' => $update->id],
        );
        $this->notifyBillingAdminsOfUpdate(
            $purchase,
            'Provider reopened a service request',
            "{$purchase->plan_name} needs additional work.",
            "provider_service_reopened:{$update->id}",
            section: 'closeout',
        );

        return response()->json([
            'message' => 'Service reopened for additional work.',
            'purchase' => $this->workspacePayload($purchase->fresh(), false, 'closeout'),
        ]);
    }

    public function requestProviderCancellation(Request $request, ProviderServicePurchase $purchase): JsonResponse
    {
        $this->authorizeProviderPurchase($request, $purchase);
        $this->requirePaidService($purchase);

        if (in_array($purchase->fulfillment_status, ['completed', 'cancelled'], true)) {
            return response()->json(['message' => 'A closed service cannot receive a new cancellation request.'], 422);
        }

        if ($purchase->cancellation_status === 'requested') {
            return response()->json(['message' => 'This cancellation request is already awaiting review.'], 422);
        }

        $validated = $request->validate([
            'reason' => ['required', 'string', 'min:20', 'max:2000'],
        ]);
        $reason = trim($validated['reason']);

        $purchase->update([
            'cancellation_status' => 'requested',
            'cancellation_reason' => $reason,
            'cancellation_requested_at' => now(),
            'cancellation_requested_by' => $request->user()->id,
            'cancellation_decision_note' => null,
            'cancellation_decided_at' => null,
            'cancellation_decided_by' => null,
            'cancelled_at' => null,
            'refund_status' => null,
            'refund_reference' => null,
            'action_due_at' => null,
        ]);
        $purchase = $this->serviceLifecycle->syncCurrentAction($purchase);
        $this->serviceLifecycle->recordAuditEvent($purchase, $request->user(), 'service_cancellation_requested', [
            'cancellation_reason' => $reason,
        ]);
        $update = $purchase->updates()->create([
            'actor_id' => $request->user()->id,
            'kind' => 'cancellation_requested',
            'message' => $reason,
            'visible_to_provider' => true,
        ]);

        ActivityLog::record(
            $request->user(),
            'provider_service_cancellation_requested',
            "{$request->user()->name} requested cancellation of {$purchase->reference_number}.",
            $request,
            ['purchase_id' => $purchase->id],
        );
        $this->notifyBillingAdminsOfUpdate(
            $purchase,
            'Service cancellation needs review',
            "The provider requested cancellation of {$purchase->plan_name}.",
            "provider_service_cancellation:{$update->id}",
            'provider_service_cancellation',
            'closeout',
        );

        return response()->json([
            'message' => 'Cancellation request sent for review.',
            'purchase' => $this->workspacePayload($purchase->fresh(), false, 'closeout'),
        ], 201);
    }

    public function decideProviderCancellation(Request $request, ProviderServicePurchase $purchase): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        $this->requirePaidService($purchase);

        if ($purchase->cancellation_status !== 'requested') {
            return response()->json(['message' => 'There is no pending cancellation request to review.'], 422);
        }

        $validated = $request->validate([
            'decision' => ['required', Rule::in(['approved', 'declined'])],
            'decision_note' => ['required', 'string', 'min:10', 'max:2000'],
            'refund_status' => ['nullable', 'required_if:decision,approved', Rule::in(ProviderServicePurchase::REFUND_STATUSES)],
            'refund_reference' => ['nullable', 'required_if:refund_status,refunded', 'string', 'min:3', 'max:120'],
        ]);
        $decision = $validated['decision'];
        $note = trim($validated['decision_note']);
        $attributes = [
            'cancellation_status' => $decision,
            'cancellation_decision_note' => $note,
            'cancellation_decided_at' => now(),
            'cancellation_decided_by' => $request->user()->id,
            'refund_status' => $decision === 'approved' ? $validated['refund_status'] : null,
            'refund_reference' => $decision === 'approved' && filled($validated['refund_reference'] ?? null)
                ? trim($validated['refund_reference'])
                : null,
        ];

        if ($decision === 'approved') {
            $purchase = $this->transitionServiceDelivery(
                $purchase,
                'cancelled',
                $request->user(),
                [
                    ...$attributes,
                    'cancelled_at' => now(),
                    'meeting_status' => in_array($purchase->meeting_status, ['requested', 'confirmed'], true)
                        ? 'cancelled'
                        : $purchase->meeting_status,
                ],
                'service_cancellation_approved',
            );
            $this->clearServiceMeetingReminders($purchase);
        } else {
            $purchase->update($attributes);
            $purchase = $this->serviceLifecycle->syncCurrentAction($purchase);
            $this->serviceLifecycle->recordAuditEvent($purchase, $request->user(), 'service_cancellation_declined', [
                'cancellation_decision_note' => $note,
            ]);
        }

        $update = $purchase->updates()->create([
            'actor_id' => $request->user()->id,
            'kind' => "cancellation_{$decision}",
            'message' => $note,
            'visible_to_provider' => true,
        ]);
        ActivityLog::record(
            $request->user(),
            "provider_service_cancellation_{$decision}",
            "{$request->user()->name} {$decision} cancellation of {$purchase->reference_number}.",
            $request,
            ['purchase_id' => $purchase->id, 'refund_status' => $purchase->refund_status],
        );
        $this->notifyProviderTeam(
            $purchase,
            'provider_service_cancellation',
            $decision === 'approved' ? 'Service cancellation approved' : 'Service cancellation declined',
            $note,
            "provider_service_cancellation_decision:{$update->id}",
            'closeout',
        );

        return response()->json([
            'message' => $decision === 'approved' ? 'Service cancelled and refund disposition recorded.' : 'Cancellation request declined.',
            'purchase' => $this->workspacePayload($purchase->fresh(), true, 'closeout'),
        ]);
    }

    public function restoreCancelledService(Request $request, ProviderServicePurchase $purchase): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        $this->requirePaidService($purchase);

        if ($purchase->fulfillment_status !== 'cancelled') {
            return response()->json(['message' => 'Only a cancelled service can be restored.'], 422);
        }

        if (in_array($purchase->refund_status, ['manual_refund_pending', 'refunded'], true)) {
            return response()->json(['message' => 'Resolve the recorded refund before restoring this service.'], 422);
        }

        $validated = $request->validate([
            'reason' => ['required', 'string', 'min:10', 'max:2000'],
        ]);
        $reason = trim($validated['reason']);
        $purchase = $this->transitionServiceDelivery(
            $purchase,
            'in_progress',
            $request->user(),
            [
                'cancellation_status' => 'reversed',
                'cancellation_decision_note' => $reason,
                'cancellation_decided_at' => now(),
                'cancellation_decided_by' => $request->user()->id,
                'refund_status' => 'not_applicable',
                'refund_reference' => null,
            ],
            'service_cancellation_reversed',
        );
        $update = $purchase->updates()->create([
            'actor_id' => $request->user()->id,
            'kind' => 'cancellation_reversed',
            'message' => $reason,
            'visible_to_provider' => true,
        ]);
        ActivityLog::record(
            $request->user(),
            'provider_service_cancellation_reversed',
            "{$request->user()->name} restored {$purchase->reference_number}.",
            $request,
            ['purchase_id' => $purchase->id],
        );
        $this->notifyProviderTeam(
            $purchase,
            'provider_service_cancellation',
            'Cancelled service restored',
            $reason,
            "provider_service_restored:{$update->id}",
            'closeout',
        );

        return response()->json([
            'message' => 'Service restored to active delivery.',
            'purchase' => $this->workspacePayload($purchase->fresh(), true, 'closeout'),
        ]);
    }

    public function checkout(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isProvider(), 403);

        if (! $this->payMongo->isConfigured()) {
            return response()->json([
                'message' => 'Online payment is temporarily unavailable. Please try again later or contact platform support.',
            ], 503);
        }

        $plans = config('billing.plans', []);
        $cycleSupportAreas = array_keys($plans['application_cycle_support']['support_areas'] ?? []);
        $validated = $request->validate([
            'plan_code' => ['required', 'string', Rule::in(array_keys($plans))],
            'accept_terms' => ['accepted'],
            'support_areas' => [
                Rule::requiredIf($request->input('plan_code') === 'application_cycle_support'),
                'array',
                'min:1',
                'max:6',
            ],
            'support_areas.*' => ['string', 'distinct', Rule::in($cycleSupportAreas)],
            'support_note' => ['nullable', 'string', 'max:1000'],
        ]);
        $plan = $plans[$validated['plan_code']];
        $actor = $request->user();
        $owner = $actor->providerOrganizationOwner()->loadMissing('providerProfile');
        $selectedSupportAreas = collect($validated['support_areas'] ?? [])
            ->map(fn (string $area) => $plan['support_areas'][$area] ?? null)
            ->filter()
            ->values();
        $supportNote = trim((string) ($validated['support_note'] ?? ''));
        $requestSummary = $selectedSupportAreas->isNotEmpty()
            ? 'Support requested: '.$selectedSupportAreas->join(', ').'.'
            : null;

        if ($requestSummary && $supportNote !== '') {
            $requestSummary .= "\n\nProvider note: {$supportNote}";
        }

        $purchase = ProviderServicePurchase::create([
            'provider_id' => $owner->id,
            'created_by' => $actor->id,
            'plan_code' => $validated['plan_code'],
            'plan_name' => $plan['name'],
            'amount' => (int) $plan['amount'],
            'currency' => config('billing.currency', 'PHP'),
            'status' => 'pending',
            'fulfillment_status' => 'queued',
            'reference_number' => $this->uniqueReferenceNumber(),
            'service_terms_accepted_at' => now(),
            'request_summary' => $requestSummary,
            'requested_outcome' => $selectedSupportAreas->isNotEmpty()
                ? 'A clear, organized application cycle and action plan for the selected support areas.'
                : null,
            'priority' => 'normal',
            'fulfillment_notes' => 'Work enters the platform queue after payment is confirmed.',
            'milestones' => $this->defaultMilestones($plan),
        ]);
        $purchase = $this->serviceLifecycle->initialize($purchase);

        try {
            $checkout = $this->payMongo->createCheckout($purchase);
        } catch (Throwable $error) {
            $purchase = $this->serviceLifecycle->transitionPayment(
                $purchase,
                'failed',
                $actor,
                [
                    'failed_at' => now(),
                    'failure_message' => 'Checkout could not be started.',
                ],
                'checkout_start_failed',
            );

            ActivityLog::record(
                $actor,
                'provider_service_checkout_failed',
                "Checkout could not be started for {$purchase->reference_number}.",
                $request,
                [
                    'purchase_id' => $purchase->id,
                    'provider_id' => $owner->id,
                    'plan_code' => $purchase->plan_code,
                    'error' => $error->getMessage(),
                ],
            );

            return response()->json([
                'message' => 'The payment page could not be opened. Please try again later.',
            ], 503);
        }

        $purchase->update([
            'checkout_session_id' => $checkout['id'],
            'checkout_url' => $checkout['checkout_url'],
            'livemode' => $checkout['livemode'],
        ]);

        ActivityLog::record(
            $actor,
            'provider_service_checkout_created',
            "{$actor->name} opened checkout for {$purchase->plan_name}.",
            $request,
            [
                'purchase_id' => $purchase->id,
                'provider_id' => $owner->id,
                'plan_code' => $purchase->plan_code,
                'reference_number' => $purchase->reference_number,
                'livemode' => $purchase->livemode,
            ],
        );

        return response()->json([
            'message' => 'Secure checkout is ready.',
            'checkout_url' => $checkout['checkout_url'],
            'purchase' => $this->purchasePayload($purchase->fresh('creator.providerProfile')),
        ], 201);
    }

    public function syncCheckout(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isProvider(), 403);

        $validated = $request->validate([
            'reference' => ['required', 'string', 'max:80'],
        ]);
        $owner = $request->user()->providerOrganizationOwner();
        $purchase = ProviderServicePurchase::query()
            ->with(['provider.providerProfile', 'creator.providerProfile'])
            ->where('provider_id', $owner->id)
            ->where('reference_number', $validated['reference'])
            ->first();

        if (! $purchase) {
            return response()->json(['message' => 'Payment reference was not found.'], 404);
        }

        if ($purchase->status === 'paid') {
            return response()->json([
                'message' => 'Payment is already confirmed.',
                'confirmed' => true,
                'purchase' => $this->purchasePayload($purchase),
            ]);
        }

        if ($purchase->status !== 'pending' || blank($purchase->checkout_session_id)) {
            return response()->json([
                'message' => 'This order does not have a pending checkout to confirm.',
            ], 422);
        }

        try {
            $resource = $this->payMongo->retrieveCheckout($purchase->checkout_session_id);
        } catch (Throwable $error) {
            report($error);

            return response()->json([
                'message' => 'PayMongo could not confirm the payment right now. The order remains pending.',
            ], 503);
        }

        $payments = data_get($resource, 'attributes.payments', []);
        $hasPaidPayment = is_array($payments) && collect($payments)->contains(function ($payment): bool {
            return data_get($payment, 'attributes.status', data_get($payment, 'status')) === 'paid';
        });

        if (! $hasPaidPayment) {
            return response()->json([
                'message' => 'PayMongo has not confirmed a paid payment yet. You can check again shortly.',
                'confirmed' => false,
                'purchase' => $this->purchasePayload($purchase),
            ], 202);
        }

        $livemode = data_get($resource, 'attributes.livemode');

        if (! is_bool($livemode) || $livemode !== (bool) $purchase->livemode) {
            return response()->json([
                'message' => 'Checkout mode does not match the original order.',
            ], 422);
        }

        $recordingResponse = $this->recordPaidCheckout($request, $resource, null, $livemode);

        if (! $recordingResponse->isSuccessful()) {
            return $recordingResponse;
        }

        $purchase = $purchase->fresh(['provider.providerProfile', 'creator.providerProfile']);

        return response()->json([
            'message' => 'Payment confirmed by PayMongo.',
            'confirmed' => $purchase->status === 'paid',
            'purchase' => $this->purchasePayload($purchase),
        ]);
    }

    public function webhook(Request $request): JsonResponse
    {
        $rawPayload = $request->getContent();
        $signature = $this->payMongo->verifyWebhookSignature(
            $rawPayload,
            $request->header('Paymongo-Signature'),
        );

        if (! $signature['valid']) {
            return response()->json(['message' => 'Invalid webhook signature.'], 401);
        }

        $payload = json_decode($rawPayload, true);

        if (! is_array($payload)) {
            return response()->json(['message' => 'Invalid webhook payload.'], 400);
        }

        [$eventType, $resource, $eventId, $payloadLivemode] = $this->webhookEvent($payload);

        if ($payloadLivemode !== null && $payloadLivemode !== $signature['livemode']) {
            return response()->json(['message' => 'Webhook mode does not match its signature.'], 401);
        }

        if ($eventType !== 'checkout_session.payment.paid') {
            return response()->json(['received' => true]);
        }

        if (! is_array($resource)) {
            return response()->json(['message' => 'Checkout session data is missing.'], 422);
        }

        return $this->recordPaidCheckout($request, $resource, $eventId, $signature['livemode']);
    }

    public function adminPage(Request $request): View|RedirectResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);

        if (AdminWorkspace::usesBillingOfficerWorkspace($request->user())) {
            return redirect()->route(AdminWorkspace::BILLING_OFFICER_ROUTE, $request->query());
        }

        if (AdminWorkspace::usesPortalManagerWorkspace($request->user())) {
            return redirect()->route('admin.workspaces.portal.billing', $request->query());
        }

        return view('admin-billing');
    }

    public function billingOfficerWorkspaceData(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($request->user()->hasPortalPermission('manage_billing'), 403);

        return $this->adminData($request);
    }

    public function adminWorkspacePage(Request $request, ProviderServicePurchase $purchase): View|RedirectResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);

        return redirect()->route('admin.workspaces.billing.requests.show', [
            'purchase' => $purchase,
        ]);
    }

    public function adminWorkspaceData(Request $request, ProviderServicePurchase $purchase): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);

        $validated = $request->validate([
            'section' => ['nullable', Rule::in(['overview', 'delivery', 'files', 'updates', 'meeting', 'closeout', 'history'])],
        ]);

        $assignees = User::query()
            ->where('role', 'admin')
            ->where(fn ($query) => $query->whereNull('account_status')->orWhere('account_status', 'active'))
            ->with('adminProfile')
            ->orderBy('username')
            ->get()
            ->filter(fn (User $admin) => $admin->hasPortalPermission('manage_billing'))
            ->map(fn (User $admin) => [
                'id' => $admin->id,
                'name' => $admin->name,
                'email' => $admin->email,
            ])
            ->values();

        return response()->json([
            'purchase' => $this->workspacePayload($purchase, true, $validated['section'] ?? 'overview'),
            'assignees' => $assignees,
            'status_options' => $this->deliveryStatusOptions($purchase),
        ]);
    }

    public function decideProviderMeeting(Request $request, ProviderServicePurchase $purchase): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        $this->requirePaidService($purchase);
        $this->requireNoPendingCancellation($purchase);

        if ($purchase->fulfillment_status === 'cancelled') {
            return response()->json(['message' => 'A meeting cannot be changed for a cancelled service.'], 422);
        }

        if ($purchase->meeting_status !== 'requested' || ! $purchase->meeting_scheduled_for) {
            return response()->json([
                'message' => 'There is no pending meeting request to review.',
            ], 422);
        }

        $validated = $request->validate([
            'meeting_status' => ['required', Rule::in(['confirmed', 'declined'])],
            'meeting_admin_note' => ['nullable', 'required_if:meeting_status,declined', 'string', 'min:5', 'max:1000'],
            'meeting_join_url' => [
                'nullable',
                Rule::requiredIf(fn (): bool => $request->input('meeting_status') === 'confirmed'
                    && $purchase->meeting_mode === 'online'),
                'url:http,https',
                'max:2048',
            ],
        ]);
        $adminNote = filled($validated['meeting_admin_note'] ?? null)
            ? trim($validated['meeting_admin_note'])
            : null;

        $purchase->update([
            'meeting_status' => $validated['meeting_status'],
            'meeting_admin_note' => $adminNote,
            'meeting_join_url' => $validated['meeting_status'] === 'confirmed' && $purchase->meeting_mode === 'online'
                ? trim($validated['meeting_join_url'])
                : null,
            'meeting_decided_at' => now(),
            'meeting_decided_by' => $request->user()->id,
        ]);
        if ($validated['meeting_status'] === 'declined') {
            $this->clearServiceMeetingReminders($purchase);
        }
        $purchase = $this->serviceLifecycle->syncCurrentAction($purchase);

        $meetingDate = $this->meetingDateLabel($purchase);
        $isConfirmed = $purchase->meeting_status === 'confirmed';
        $message = $isConfirmed
            ? "Meeting confirmed for {$meetingDate}."
            : "Meeting request for {$meetingDate} was declined.";

        if ($adminNote) {
            $message .= " Admin note: {$adminNote}";
        }

        $update = $purchase->updates()->create([
            'actor_id' => $request->user()->id,
            'kind' => $isConfirmed ? 'meeting_confirmed' : 'meeting_declined',
            'message' => $message,
            'visible_to_provider' => true,
        ]);

        ActivityLog::record(
            $request->user(),
            $isConfirmed ? 'provider_service_meeting_confirmed' : 'provider_service_meeting_declined',
            "{$request->user()->name} {$purchase->meeting_status} the meeting for {$purchase->reference_number}.",
            $request,
            ['purchase_id' => $purchase->id, 'meeting_scheduled_for' => $purchase->meeting_scheduled_for?->toISOString()],
        );
        $this->notifyProviderTeam(
            $purchase,
            'provider_service_meeting',
            $isConfirmed ? 'Service meeting confirmed' : 'Choose another meeting time',
            $message,
            "provider_service_meeting_decision:{$update->id}",
            'meeting',
        );

        return response()->json([
            'message' => $isConfirmed ? 'Meeting confirmed.' : 'Meeting request declined.',
            'purchase' => $this->workspacePayload($purchase, true, 'meeting'),
        ]);
    }

    public function storeAdminUpdate(Request $request, ProviderServicePurchase $purchase): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        $this->requirePaidService($purchase);
        $this->requireNoPendingCancellation($purchase);

        if ($purchase->fulfillment_status === 'cancelled') {
            return response()->json(['message' => 'Restore this cancelled service before posting another update.'], 422);
        }

        $validated = $request->validate([
            'kind' => ['required', Rule::in(['progress_update', 'clarification_request', 'internal_note'])],
            'message' => ['required', 'string', 'min:3', 'max:2000'],
        ]);
        $isInternal = $validated['kind'] === 'internal_note';
        if ($validated['kind'] === 'clarification_request') {
            $purchase = $this->transitionServiceDelivery(
                $purchase,
                'needs_information',
                $request->user(),
                ['fulfillment_notes' => trim($validated['message'])],
                'platform_information_requested',
            );
        }

        $update = $purchase->updates()->create([
            'actor_id' => $request->user()->id,
            'kind' => $validated['kind'],
            'message' => trim($validated['message']),
            'visible_to_provider' => ! $isInternal,
        ]);

        ActivityLog::record(
            $request->user(),
            'provider_service_update_added',
            "{$request->user()->name} added a {$validated['kind']} to {$purchase->reference_number}.",
            $request,
            [
                'purchase_id' => $purchase->id,
                'update_id' => $update->id,
                'visible_to_provider' => ! $isInternal,
            ],
        );

        if (! $isInternal) {
            $this->notifyProviderTeam(
                $purchase,
                'provider_service_update',
                $validated['kind'] === 'clarification_request' ? 'Information needed for your service' : 'Provider service update',
                trim($validated['message']),
                "provider_service_update:{$update->id}",
                'updates',
            );
        }

        return response()->json([
            'message' => $isInternal ? 'Internal note added.' : 'Provider update posted.',
            'purchase' => $this->workspacePayload($purchase->fresh(), true, 'updates'),
        ], 201);
    }

    public function uploadAdminDeliverable(Request $request, ProviderServicePurchase $purchase): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        $this->requirePaidService($purchase);
        $this->requireNoPendingCancellation($purchase);

        if (in_array($purchase->fulfillment_status, ['completed', 'cancelled'], true)) {
            return response()->json([
                'message' => 'The service must be reopened before another deliverable is uploaded.',
            ], 422);
        }

        $validated = $request->validate([
            'service_file' => ['required', 'file', 'max:10240', 'mimes:pdf,jpg,jpeg,png,doc,docx,xls,xlsx,csv,txt'],
        ]);
        $file = $validated['service_file'];
        $path = $file->store("provider-services/{$purchase->id}/deliverables", 'local');

        if (! is_string($path)) {
            throw ValidationException::withMessages([
                'service_file' => 'The deliverable could not be stored. Please try again.',
            ]);
        }

        $serviceFile = $purchase->files()->create([
            'uploaded_by' => $request->user()->id,
            'category' => 'deliverable',
            'original_name' => $file->getClientOriginalName(),
            'path' => $path,
            'mime_type' => $file->getMimeType(),
            'size' => $file->getSize(),
            'visible_to_provider' => true,
        ]);
        $update = $purchase->updates()->create([
            'actor_id' => $request->user()->id,
            'kind' => 'deliverable',
            'message' => "Deliverable uploaded: {$serviceFile->original_name}",
            'visible_to_provider' => true,
        ]);

        ActivityLog::record(
            $request->user(),
            'provider_service_deliverable_uploaded',
            "{$request->user()->name} uploaded a deliverable to {$purchase->reference_number}.",
            $request,
            ['purchase_id' => $purchase->id, 'file_id' => $serviceFile->id],
        );
        $this->notifyProviderTeam(
            $purchase,
            'provider_service_deliverable',
            'Service deliverable available',
            "A new deliverable is available for {$purchase->plan_name}.",
            "provider_service_deliverable:{$update->id}",
            'files',
        );

        return response()->json([
            'message' => 'Deliverable uploaded and shared with the provider.',
            'purchase' => $this->workspacePayload($purchase->fresh(), true, 'files'),
        ], 201);
    }

    public function viewServiceFile(Request $request, ProviderServiceFile $file)
    {
        $this->authorizeServiceFile($request, $file);
        abort_unless(Storage::disk('local')->exists($file->path), 404);

        return Storage::disk('local')->response($file->path, $file->original_name, [
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    public function downloadServiceFile(Request $request, ProviderServiceFile $file)
    {
        $this->authorizeServiceFile($request, $file);
        abort_unless(Storage::disk('local')->exists($file->path), 404);

        return Storage::disk('local')->download($file->path, $file->original_name, [
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    public function adminData(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);

        $validated = $request->validate([
            'payment_status' => ['nullable', Rule::in(['all', ...ProviderServicePurchase::PAYMENT_STATUSES])],
            'fulfillment_status' => ['nullable', Rule::in(['all', ...ProviderServicePurchase::FULFILLMENT_STATUSES])],
            'search' => ['nullable', 'string', 'max:120'],
            'page' => ['nullable', 'integer', 'min:1'],
        ]);
        $paymentStatus = $validated['payment_status'] ?? 'paid';
        $fulfillmentStatus = $validated['fulfillment_status'] ?? 'all';
        $search = trim($validated['search'] ?? '');

        $query = ProviderServicePurchase::query()
            ->with(['provider.providerProfile', 'creator.providerProfile', 'fulfiller.adminProfile', 'assignee.adminProfile'])
            ->when($paymentStatus !== 'all', fn ($builder) => $builder->where('status', $paymentStatus))
            ->when($fulfillmentStatus === 'ready', fn ($builder) => $builder->whereIn('fulfillment_status', ['queued', 'ready']))
            ->when(! in_array($fulfillmentStatus, ['all', 'ready'], true), fn ($builder) => $builder->where('fulfillment_status', $fulfillmentStatus))
            ->when($search !== '', function ($builder) use ($search): void {
                $builder->where(function ($nested) use ($search): void {
                    $nested->where('reference_number', 'like', "%{$search}%")
                        ->orWhere('plan_name', 'like', "%{$search}%")
                        ->orWhereHas('provider.providerProfile', fn ($profile) => $profile->where('provider_name', 'like', "%{$search}%"));
                });
            })
            ->latest('paid_at')
            ->latest();

        $purchases = $query->paginate(20);
        $counts = ProviderServicePurchase::query()
            ->where('status', 'paid')
            ->selectRaw('fulfillment_status, COUNT(*) as aggregate')
            ->groupBy('fulfillment_status')
            ->pluck('aggregate', 'fulfillment_status');

        return response()->json([
            'counts' => [
                'all' => (int) $counts->sum(),
                'queued' => (int) ($counts['queued'] ?? 0),
                'needs_information' => (int) ($counts['needs_information'] ?? 0),
                'ready' => (int) (($counts['ready'] ?? 0) + ($counts['queued'] ?? 0)),
                'in_progress' => (int) ($counts['in_progress'] ?? 0),
                'provider_review' => (int) ($counts['provider_review'] ?? 0),
                'completed' => (int) (($counts['completed'] ?? 0) + ($counts['cancelled'] ?? 0)),
                'cancelled' => (int) ($counts['cancelled'] ?? 0),
            ],
            'purchases' => collect($purchases->items())
                ->map(fn (ProviderServicePurchase $purchase) => $this->purchasePayload($purchase, true))
                ->values(),
            'pagination' => [
                'current_page' => $purchases->currentPage(),
                'last_page' => $purchases->lastPage(),
                'per_page' => $purchases->perPage(),
                'total' => $purchases->total(),
            ],
        ]);
    }

    public function updateFulfillment(Request $request, ProviderServicePurchase $purchase): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);

        if ($purchase->fulfillment_status === 'cancelled') {
            return response()->json(['message' => 'Restore this cancelled service before changing delivery.'], 422);
        }

        if ($purchase->cancellation_status === 'requested') {
            return response()->json(['message' => 'Review the pending cancellation before changing delivery.'], 422);
        }

        $validated = $request->validate([
            'fulfillment_status' => ['required', Rule::in([
                'needs_information',
                'ready',
                'in_progress',
                'provider_review',
            ])],
            'fulfillment_notes' => ['nullable', 'string', 'max:2000'],
            'assigned_to' => ['nullable', 'integer', 'exists:users,id'],
            'priority' => ['nullable', Rule::in(['low', 'normal', 'high', 'urgent'])],
            'target_due_at' => ['bail', 'nullable', 'date', function (string $attribute, mixed $value, \Closure $fail) use ($purchase): void {
                $target = Carbon::parse($value, config('app.timezone'))->timezone(config('app.timezone'));
                $saved = $purchase->target_due_at?->copy()->timezone(config('app.timezone'));
                if ($target->copy()->startOfDay()->isBefore(now(config('app.timezone'))->startOfDay())
                    && (! $saved || ! $target->isSameDay($saved))) {
                    $fail('Keep the saved overdue date or choose today or a future target date.');
                }
            }],
            'milestones' => ['nullable', 'array', 'max:12'],
            'milestones.*.id' => ['required_with:milestones', 'string', 'max:80'],
            'milestones.*.label' => ['required_with:milestones', 'string', 'max:160'],
            'milestones.*.completed' => ['required_with:milestones', 'boolean'],
            'provider_update' => ['nullable', 'string', 'max:2000'],
            'internal_note' => ['nullable', 'string', 'max:2000'],
        ]);

        if ($purchase->status !== 'paid') {
            return response()->json([
                'message' => 'Only confirmed payments can enter service fulfillment.',
            ], 422);
        }

        if (filled($validated['assigned_to'] ?? null)) {
            $assignee = User::query()->find($validated['assigned_to']);

            if (! $assignee?->isAdmin()
                || ! in_array($assignee->account_status, [null, 'active'], true)
                || ! $assignee->hasPortalPermission('manage_billing')) {
                throw ValidationException::withMessages([
                    'assigned_to' => 'Choose an active administrator with service-management permission.',
                ]);
            }
        }

        $milestones = array_key_exists('milestones', $validated)
            ? collect($validated['milestones'])
                ->map(fn (array $milestone) => [
                    'id' => $milestone['id'],
                    'label' => trim($milestone['label']),
                    'completed' => (bool) $milestone['completed'],
                ])
                ->values()
                ->all()
            : ($purchase->milestones ?? []);
        $providerUpdate = filled($validated['provider_update'] ?? null)
            ? trim($validated['provider_update'])
            : null;

        if ($validated['fulfillment_status'] === 'needs_information' && ! $providerUpdate) {
            throw ValidationException::withMessages([
                'provider_update' => 'Explain what information the provider needs to supply.',
            ]);
        }

        if ($validated['fulfillment_status'] === 'provider_review') {
            if ($milestones === [] || collect($milestones)->contains(fn (array $milestone) => ! $milestone['completed'])) {
                throw ValidationException::withMessages([
                    'milestones' => 'Complete every service milestone before sending the work for provider review.',
                ]);
            }

            if (! $providerUpdate) {
                throw ValidationException::withMessages([
                    'provider_update' => 'Add a completion summary for the provider before requesting confirmation.',
                ]);
            }
        }

        $targetDueAt = ! array_key_exists('target_due_at', $validated) ? $purchase->target_due_at : (filled($validated['target_due_at'])
            ? Carbon::parse($validated['target_due_at'], config('app.timezone'))->timezone(config('app.timezone'))
            : null);
        if ($targetDueAt && $purchase->target_due_at
            && $targetDueAt->isSameDay($purchase->target_due_at->copy()->timezone(config('app.timezone')))) {
            $targetDueAt = $purchase->target_due_at;
        }

        $previousStatus = $purchase->fulfillment_status;
        $purchase = $this->transitionServiceDelivery(
            $purchase,
            $validated['fulfillment_status'],
            $request->user(),
            [
                'fulfillment_notes' => ! array_key_exists('fulfillment_notes', $validated) ? $purchase->fulfillment_notes : (filled($validated['fulfillment_notes'])
                    ? trim($validated['fulfillment_notes'])
                    : null),
                'assigned_to' => array_key_exists('assigned_to', $validated) ? $validated['assigned_to'] : $purchase->assigned_to,
                'priority' => $validated['priority'] ?? $purchase->priority,
                'target_due_at' => $targetDueAt,
                'milestones' => $milestones,
                'fulfilled_by' => $request->user()->id,
                'fulfilled_at' => null,
                'provider_confirmed_at' => null,
            ],
            'platform_delivery_status_changed',
        );

        if ($providerUpdate) {
            $purchase->updates()->create([
                'actor_id' => $request->user()->id,
                'kind' => $validated['fulfillment_status'] === 'needs_information'
                    ? 'clarification_request'
                    : 'progress_update',
                'message' => $providerUpdate,
                'visible_to_provider' => true,
            ]);
        }

        if (filled($validated['internal_note'] ?? null)) {
            $purchase->updates()->create([
                'actor_id' => $request->user()->id,
                'kind' => 'internal_note',
                'message' => trim($validated['internal_note']),
                'visible_to_provider' => false,
            ]);
        }

        ActivityLog::record(
            $request->user(),
            'provider_service_fulfillment_updated',
            "{$request->user()->name} changed {$purchase->reference_number} from {$previousStatus} to {$purchase->fulfillment_status}.",
            $request,
            [
                'purchase_id' => $purchase->id,
                'provider_id' => $purchase->provider_id,
                'from_status' => $previousStatus,
                'to_status' => $purchase->fulfillment_status,
            ],
        );

        if ($previousStatus !== $purchase->fulfillment_status || $providerUpdate) {
            $this->notifyProviderTeam(
                $purchase,
                'provider_service_status',
                'Provider service status updated',
                $providerUpdate ?: "{$purchase->plan_name} is now {$this->statusLabel($purchase->fulfillment_status)}.",
                'provider_service_status:'.$purchase->id.':'.Str::uuid(),
                $purchase->fulfillment_status === 'needs_information' ? 'updates' : null,
            );
        }

        return response()->json([
            'message' => 'Service status updated.',
            'purchase' => $this->workspacePayload($purchase->fresh(), true, 'delivery'),
        ]);
    }

    private function recordPaidCheckout(
        Request $request,
        array $resource,
        ?string $eventId,
        bool $livemode,
    ): JsonResponse {
        $attributes = is_array($resource['attributes'] ?? null) ? $resource['attributes'] : [];
        $sessionId = is_string($resource['id'] ?? null) ? $resource['id'] : null;
        $reference = $attributes['reference_number'] ?? null;
        $metadata = is_array($attributes['metadata'] ?? null) ? $attributes['metadata'] : [];
        $purchaseId = filter_var($metadata['purchase_id'] ?? null, FILTER_VALIDATE_INT);
        $payments = is_array($attributes['payments'] ?? null) ? $attributes['payments'] : [];
        $payment = collect($payments)->first(function ($item): bool {
            $status = data_get($item, 'attributes.status', data_get($item, 'status'));

            return $status === 'paid';
        }) ?? ($payments[0] ?? null);
        $paymentAttributes = is_array(data_get($payment, 'attributes'))
            ? data_get($payment, 'attributes')
            : (is_array($payment) ? $payment : []);
        $paymentStatus = $paymentAttributes['status'] ?? null;
        $amount = $paymentAttributes['amount'] ?? $attributes['amount'] ?? $this->lineItemsAmount($attributes['line_items'] ?? []);
        $currency = strtoupper((string) ($paymentAttributes['currency'] ?? $attributes['currency'] ?? ''));

        if ($paymentStatus !== null && $paymentStatus !== 'paid') {
            return response()->json(['message' => 'The checkout payment is not paid.'], 422);
        }

        $purchaseQuery = ProviderServicePurchase::query();

        if (filled($reference)) {
            $purchaseQuery->where('reference_number', $reference);
        } elseif ($purchaseId !== false) {
            $purchaseQuery->whereKey($purchaseId);
        } elseif (filled($sessionId)) {
            $purchaseQuery->where('checkout_session_id', $sessionId);
        } else {
            return response()->json(['message' => 'Payment reference is missing.'], 422);
        }

        $purchase = $purchaseQuery->first();

        if (! $purchase) {
            return response()->json(['message' => 'Payment reference was not found.'], 404);
        }

        if (! is_numeric($amount) || (int) $amount !== $purchase->amount || $currency !== $purchase->currency) {
            return response()->json(['message' => 'Payment amount or currency does not match the order.'], 422);
        }

        if ($purchaseId !== false && (int) $purchaseId !== $purchase->id) {
            return response()->json(['message' => 'Payment metadata does not match the order.'], 422);
        }

        if (isset($metadata['provider_id']) && (int) $metadata['provider_id'] !== $purchase->provider_id) {
            return response()->json(['message' => 'Payment provider metadata does not match the order.'], 422);
        }

        if (isset($metadata['plan_code']) && $metadata['plan_code'] !== $purchase->plan_code) {
            return response()->json(['message' => 'Payment service metadata does not match the order.'], 422);
        }

        if (filled($purchase->checkout_session_id) && filled($sessionId) && $purchase->checkout_session_id !== $sessionId) {
            return response()->json(['message' => 'Checkout session does not match the order.'], 422);
        }

        $wasRecorded = DB::transaction(function () use (
            $purchase,
            $sessionId,
            $payment,
            $paymentAttributes,
            $eventId,
            $livemode,
            $amount,
            $currency,
        ): bool {
            $lockedPurchase = ProviderServicePurchase::query()->lockForUpdate()->findOrFail($purchase->id);

            if ($lockedPurchase->status === 'paid') {
                return false;
            }

            $this->serviceLifecycle->transitionPayment(
                $lockedPurchase,
                'paid',
                null,
                [
                    'checkout_session_id' => $sessionId ?: $lockedPurchase->checkout_session_id,
                    'checkout_url' => null,
                    'payment_id' => data_get($payment, 'id'),
                    'payment_intent_id' => data_get($paymentAttributes, 'payment_intent.id')
                        ?? data_get($paymentAttributes, 'payment_intent_id'),
                    'payment_method' => data_get($paymentAttributes, 'source.type')
                        ?? data_get($paymentAttributes, 'payment_method_used')
                        ?? data_get($paymentAttributes, 'payment_method.type'),
                    'livemode' => $livemode,
                    'paid_at' => now(),
                    'failed_at' => null,
                    'failure_message' => null,
                    'gateway_metadata' => [
                        'event_id' => $eventId,
                        'verified_amount' => (int) $amount,
                        'verified_currency' => $currency,
                    ],
                ],
                'payment_confirmed',
            );

            return true;
        });

        if (! $wasRecorded) {
            return response()->json(['received' => true, 'duplicate' => true]);
        }

        $purchase = $purchase->fresh(['provider.providerProfile', 'creator.providerProfile']);
        ActivityLog::record(
            null,
            'provider_service_payment_confirmed',
            "PayMongo confirmed payment for {$purchase->reference_number}.",
            $request,
            [
                'purchase_id' => $purchase->id,
                'provider_id' => $purchase->provider_id,
                'plan_code' => $purchase->plan_code,
                'livemode' => $purchase->livemode,
            ],
        );

        $this->notifyProviderTeam(
            $purchase,
            'provider_service_paid',
            'Payment confirmed',
            "Payment for {$purchase->plan_name} was confirmed. The service is now in the admin queue.",
            "provider_service_paid:{$purchase->id}",
        );
        $this->notifyBillingAdmins($purchase);

        return response()->json(['received' => true]);
    }

    /**
     * @return array{0: ?string, 1: mixed, 2: ?string, 3: ?bool}
     */
    private function webhookEvent(array $payload): array
    {
        $eventData = data_get($payload, 'data', []);
        $attributes = is_array(data_get($eventData, 'attributes')) ? data_get($eventData, 'attributes') : [];
        $eventType = $attributes['type'] ?? data_get($eventData, 'type');
        $resource = $attributes['data'] ?? data_get($eventData, 'data');
        $eventId = is_string(data_get($eventData, 'id')) ? data_get($eventData, 'id') : null;
        $modeValue = $attributes['livemode'] ?? data_get($resource, 'attributes.livemode');
        $livemode = is_bool($modeValue) ? $modeValue : null;

        return [is_string($eventType) ? $eventType : null, $resource, $eventId, $livemode];
    }

    private function lineItemsAmount(mixed $lineItems): ?int
    {
        if (! is_array($lineItems) || $lineItems === []) {
            return null;
        }

        return collect($lineItems)->sum(function ($item): int {
            $amount = (int) (data_get($item, 'attributes.amount') ?? data_get($item, 'amount') ?? 0);
            $quantity = max(1, (int) (data_get($item, 'attributes.quantity') ?? data_get($item, 'quantity') ?? 1));

            return $amount * $quantity;
        });
    }

    private function notifyProviderTeam(
        ProviderServicePurchase $purchase,
        string $type,
        string $title,
        string $message,
        string $deduplicationPrefix,
        ?string $section = null,
    ): void {
        User::query()
            ->where('role', 'provider')
            ->where(function ($query) use ($purchase): void {
                $query->whereKey($purchase->provider_id)
                    ->orWhere('parent_account_id', $purchase->provider_id);
            })
            ->where(fn ($query) => $query->whereNull('account_status')->orWhere('account_status', 'active'))
            ->get()
            ->filter(fn (User $user) => ! $user->isManagedAccount() || $user->hasPortalPermission('manage_billing'))
            ->each(function (User $user) use ($purchase, $type, $title, $message, $deduplicationPrefix, $section): void {
                PortalNotification::firstOrCreate([
                    'deduplication_key' => "{$deduplicationPrefix}:{$user->id}",
                ], [
                    'user_id' => $user->id,
                    'type' => $type,
                    'title' => $title,
                    'message' => $message,
                    'action_url' => "/provider/billing/{$purchase->id}".($section ? "/{$section}" : ''),
                ]);
            });
    }

    private function clearServiceMeetingReminders(ProviderServicePurchase $purchase): void
    {
        PortalNotification::query()
            ->whereNull('read_at')
            ->where('deduplication_key', 'like', "provider-service:{$purchase->id}:meeting:%")
            ->update(['read_at' => now()]);
    }

    private function notifyBillingAdmins(ProviderServicePurchase $purchase): void
    {
        $providerName = $purchase->provider?->provider_name ?: $purchase->provider?->name ?: 'A provider';

        User::query()
            ->where('role', 'admin')
            ->where(fn ($query) => $query->whereNull('account_status')->orWhere('account_status', 'active'))
            ->get()
            ->filter(fn (User $user) => $user->hasPortalPermission('manage_billing'))
            ->each(function (User $user) use ($purchase, $providerName): void {
                PortalNotification::firstOrCreate([
                    'deduplication_key' => "provider_service_admin_queue:{$purchase->id}:{$user->id}",
                ], [
                    'user_id' => $user->id,
                    'type' => 'provider_service_queue',
                    'title' => 'Paid provider service ready',
                    'message' => "{$providerName} paid for {$purchase->plan_name}. Open Service Payments to begin fulfillment.",
                    'action_url' => "/admin/workspaces/billing/requests/{$purchase->id}/delivery",
                ]);
            });
    }

    private function notifyBillingAdminsOfUpdate(
        ProviderServicePurchase $purchase,
        string $title,
        string $message,
        string $deduplicationPrefix,
        string $type = 'provider_service_update',
        ?string $section = null,
    ): void {
        User::query()
            ->where('role', 'admin')
            ->where(fn ($query) => $query->whereNull('account_status')->orWhere('account_status', 'active'))
            ->get()
            ->filter(fn (User $user) => $user->hasPortalPermission('manage_billing'))
            ->each(function (User $user) use ($purchase, $title, $message, $deduplicationPrefix, $type, $section): void {
                PortalNotification::firstOrCreate([
                    'deduplication_key' => "{$deduplicationPrefix}:{$user->id}",
                ], [
                    'user_id' => $user->id,
                    'type' => $type,
                    'title' => $title,
                    'message' => $message,
                    'action_url' => "/admin/workspaces/billing/requests/{$purchase->id}".($section ? "/{$section}" : ''),
                ]);
            });
    }

    private function applyProviderBillingQueue($query, string $queue)
    {
        return match ($queue) {
            'needs_action' => $query->where(function ($builder): void {
                $builder
                    ->where('status', 'paid')
                    ->whereIn('fulfillment_status', ['needs_information', 'provider_review']);
            }),
            'active' => $query
                ->where('status', 'paid')
                ->where('fulfillment_status', 'in_progress'),
            'waiting' => $query
                ->where('status', 'paid')
                ->whereIn('fulfillment_status', ['queued', 'ready']),
            'completed' => $query
                ->where('status', 'paid')
                ->whereIn('fulfillment_status', ['completed', 'cancelled']),
            default => $query,
        };
    }

    private function providerServiceRequestDirectoryPayload(ProviderServiceRequest $serviceRequest): array
    {
        $serviceRequest->loadMissing(['scholarship', 'purchase']);
        $purchase = $serviceRequest->purchase;
        [$statusLabel, $statusDetail] = match (true) {
            $purchase?->status === 'failed' => [
                'Payment unsuccessful',
                'Review the request before trying payment again.',
            ],
            $serviceRequest->status === 'checkout_started' => [
                'Payment pending',
                'Continue checkout or confirm the payment status.',
            ],
            default => [
                'Ready for review',
                'Confirm the scope and total before payment.',
            ],
        };

        return [
            'id' => 'request-'.$serviceRequest->id,
            'record_id' => $serviceRequest->id,
            'entry_type' => 'request',
            'plan_name' => $serviceRequest->plan_name,
            'program_name' => $serviceRequest->scholarship?->title ?: 'Organization-wide',
            'reference_number' => $purchase?->reference_number,
            'amount' => $serviceRequest->amount,
            'currency' => $serviceRequest->currency,
            'status' => $serviceRequest->status,
            'work_state' => 'requests',
            'work_label' => $statusLabel,
            'work_detail' => $statusDetail,
            'created_at' => $serviceRequest->created_at,
            'updated_at' => $serviceRequest->updated_at,
            'action_label' => 'Review request',
            'action_url' => route('provider.workspaces.billing.service-requests.review', $serviceRequest),
            'can_refresh_payment' => false,
        ];
    }

    private function providerLegacyPaymentDirectoryPayload(ProviderServicePurchase $purchase): array
    {
        $payload = $this->purchasePayload($purchase);
        $failed = $purchase->status === 'failed';

        return [
            ...$payload,
            'entry_type' => 'request',
            'program_name' => 'Legacy service request',
            'work_state' => 'requests',
            'work_label' => $failed ? 'Payment unsuccessful' : 'Payment pending',
            'work_detail' => $failed
                ? 'Start a new request when you are ready to try again.'
                : 'Continue checkout or refresh the payment status.',
            'action_label' => $failed ? 'Browse services' : ($purchase->checkout_url ? 'Continue payment' : 'Open request'),
            'action_url' => $failed
                ? route('provider.workspaces.billing.services')
                : ($purchase->checkout_url ?: $payload['workspace_url']),
            'can_refresh_payment' => $purchase->status === 'pending',
        ];
    }

    private function servicePlanPayload(string $code, array $plan, bool $includeDetails = false): array
    {
        $payload = [
            'code' => $code,
            'name' => $plan['name'],
            'short_name' => $plan['short_name'] ?? $plan['name'],
            'description' => $plan['description'],
            'best_for' => $plan['best_for'] ?? null,
            'category' => $plan['category'] ?? 'Provider support',
            'outcome' => $plan['outcome'] ?? null,
            'timeline' => $plan['timeline'] ?? null,
            'format' => $plan['format'] ?? null,
            'amount' => (int) $plan['amount'],
            'currency' => config('billing.currency', 'PHP'),
            'details_url' => route('provider.workspaces.billing.services.show', ['plan' => $code]),
        ];

        if (! $includeDetails) {
            return $payload;
        }

        return [
            ...$payload,
            'features' => array_values($plan['features'] ?? []),
            'preparation' => array_values($plan['preparation'] ?? []),
            'process' => array_values($plan['process'] ?? []),
            'scope_note' => $plan['scope_note'] ?? null,
            'support_areas' => collect($plan['support_areas'] ?? [])
                ->map(fn (string $label, string $value) => [
                    'value' => $value,
                    'label' => $label,
                ])
                ->values(),
        ];
    }

    private function providerBillingWorkspacePayload(ProviderServicePurchase $purchase): array
    {
        $payload = $this->purchasePayload($purchase);
        $workState = match (true) {
            $purchase->status === 'pending' => 'needs_action',
            $purchase->status === 'failed' => 'needs_action',
            $purchase->fulfillment_status === 'needs_information' => 'needs_action',
            $purchase->fulfillment_status === 'provider_review' => 'needs_action',
            $purchase->fulfillment_status === 'in_progress' => 'active',
            in_array($purchase->fulfillment_status, ['completed', 'cancelled'], true) => 'completed',
            default => 'waiting',
        };
        [$workLabel, $workDetail, $actionLabel, $actionUrl] = match (true) {
            $purchase->status === 'pending' => [
                'Payment pending',
                'Complete payment or refresh its status to start this request.',
                $purchase->checkout_url ? 'Complete payment' : 'Check payment',
                $purchase->checkout_url ?: $payload['workspace_url'],
            ],
            $purchase->status === 'failed' => [
                'Payment failed',
                'This request did not start. Choose the service again when ready.',
                'Browse services',
                route('provider.workspaces.billing.services'),
            ],
            $purchase->fulfillment_status === 'needs_information' => [
                'Response needed',
                $purchase->fulfillment_notes ?: 'Platform support needs more information before work can continue.',
                'Respond',
                $payload['workspace_url'].'/updates',
            ],
            $purchase->fulfillment_status === 'provider_review' => [
                'Review delivery',
                'Check the delivered work, then confirm completion or request changes.',
                'Review result',
                $payload['workspace_url'],
            ],
            $purchase->fulfillment_status === 'in_progress' => [
                'In progress',
                $purchase->fulfillment_notes ?: 'Platform support is working on this request.',
                'Open request',
                $payload['workspace_url'],
            ],
            $purchase->fulfillment_status === 'completed' => [
                'Completed',
                $purchase->fulfillment_notes ?: 'This service request is complete.',
                'View record',
                $payload['workspace_url'].'/closeout',
            ],
            $purchase->fulfillment_status === 'cancelled' => [
                'Cancelled',
                'Cancellation and refund details are recorded.',
                'View record',
                $payload['workspace_url'].'/closeout',
            ],
            default => [
                'Waiting for support',
                'Payment is confirmed and the request is waiting for platform support.',
                'Open request',
                $payload['workspace_url'],
            ],
        };

        return [
            ...$payload,
            'entry_type' => 'service',
            'program_name' => null,
            'work_state' => $workState,
            'work_label' => $workLabel,
            'work_detail' => $workDetail,
            'action_label' => $actionLabel,
            'action_url' => $actionUrl,
            'can_refresh_payment' => $purchase->status === 'pending',
        ];
    }

    private function purchasePayload(ProviderServicePurchase $purchase, bool $includeProvider = false): array
    {
        $purchase->loadMissing(['creator.providerProfile', 'fulfiller.adminProfile', 'assignee.adminProfile', 'meetingDecider.adminProfile', 'cancellationRequester', 'cancellationDecider']);
        $payload = [
            'id' => $purchase->id,
            'reference_number' => $purchase->reference_number,
            'plan_code' => $purchase->plan_code,
            'plan_name' => $purchase->plan_name,
            'amount' => $purchase->amount,
            'currency' => $purchase->currency,
            'status' => $purchase->status,
            'payment_status' => $purchase->status,
            'fulfillment_status' => $purchase->fulfillment_status,
            'current_action_owner' => $purchase->current_action_owner,
            'current_action' => $purchase->current_action,
            'action_due_at' => $purchase->action_due_at?->toISOString(),
            'action_due_status' => $this->actionDueMeta($purchase)['status'],
            'action_due_label' => $this->actionDueMeta($purchase)['label'],
            'current_action_url' => $this->currentActionUrl($purchase, $includeProvider),
            'priority' => $purchase->priority ?? 'normal',
            'request_summary' => $purchase->request_summary,
            'requested_outcome' => $purchase->requested_outcome,
            'assigned_to' => $purchase->assigned_to,
            'assigned_to_name' => $purchase->assignee?->name,
            'target_due_at' => $purchase->target_due_at?->toISOString(),
            'milestones' => $purchase->milestones ?? [],
            'meeting_scheduled_for' => $purchase->meeting_scheduled_for?->toISOString(),
            'meeting_mode' => $purchase->meeting_mode,
            'meeting_purpose' => $purchase->meeting_purpose,
            'meeting_status' => $purchase->meeting_status,
            'meeting_admin_note' => $purchase->meeting_admin_note,
            'meeting_join_url' => $purchase->meeting_join_url,
            'meeting_decided_at' => $purchase->meeting_decided_at?->toISOString(),
            'meeting_decided_by' => $purchase->meeting_decided_by,
            'meeting_decided_by_name' => $purchase->meetingDecider?->name,
            'payment_method' => $purchase->payment_method,
            'livemode' => $purchase->livemode,
            'checkout_url' => $purchase->status === 'pending' ? $purchase->checkout_url : null,
            'created_by' => $purchase->creator?->name,
            'created_at' => $purchase->created_at?->toISOString(),
            'paid_at' => $purchase->paid_at?->toISOString(),
            'started_at' => $purchase->started_at?->toISOString(),
            'fulfilled_at' => $purchase->fulfilled_at?->toISOString(),
            'closed_at' => $purchase->closed_at?->toISOString(),
            'provider_confirmed_at' => $purchase->provider_confirmed_at?->toISOString(),
            'provider_feedback' => $purchase->provider_feedback,
            'provider_rating' => $purchase->provider_rating,
            'reopened_at' => $purchase->reopened_at?->toISOString(),
            'revision_count' => (int) $purchase->revision_count,
            'cancellation_status' => $purchase->cancellation_status,
            'cancellation_reason' => $purchase->cancellation_reason,
            'cancellation_requested_at' => $purchase->cancellation_requested_at?->toISOString(),
            'cancellation_requested_by_name' => $purchase->cancellationRequester?->name,
            'cancellation_decision_note' => $purchase->cancellation_decision_note,
            'cancellation_decided_at' => $purchase->cancellation_decided_at?->toISOString(),
            'cancellation_decided_by_name' => $purchase->cancellationDecider?->name,
            'cancelled_at' => $purchase->cancelled_at?->toISOString(),
            'refund_status' => $purchase->refund_status,
            'refund_reference' => $purchase->refund_reference,
            'fulfillment_notes' => $purchase->fulfillment_notes,
            'fulfilled_by' => $purchase->fulfiller?->name,
            'workspace_url' => $includeProvider
                ? "/admin/workspaces/billing/requests/{$purchase->id}"
                : "/provider/billing/{$purchase->id}",
        ];

        if ($includeProvider) {
            $payload['provider'] = [
                'id' => $purchase->provider_id,
                'name' => $purchase->provider?->provider_name ?: $purchase->provider?->name,
                'email' => $purchase->provider?->email,
            ];
        }

        return $payload;
    }

    /** @return array{status:?string,label:?string} */
    private function actionDueMeta(ProviderServicePurchase $purchase): array
    {
        if (! $purchase->action_due_at || ! $purchase->current_action_owner) {
            return ['status' => null, 'label' => null];
        }

        $timezone = config('app.timezone');
        $today = now($timezone)->startOfDay();
        $dueAt = $purchase->action_due_at->copy()->timezone($timezone);
        $days = (int) $today->diffInDays($dueAt->copy()->startOfDay(), false);

        return [
            'status' => match (true) {
                $days < 0 => 'overdue',
                $days === 0 => 'due_today',
                $days <= 2 => 'due_soon',
                default => 'scheduled',
            },
            'label' => match (true) {
                $days < 0 => 'Overdue by '.abs($days).' day'.(abs($days) === 1 ? '' : 's'),
                $days === 0 => 'Due today',
                $days === 1 => 'Due tomorrow',
                default => 'Due '.$dueAt->format('M j, Y'),
            },
        ];
    }

    private function currentActionUrl(ProviderServicePurchase $purchase, bool $adminView): ?string
    {
        if (! $purchase->current_action_owner) {
            return null;
        }

        if ($adminView) {
            $section = match (true) {
                $purchase->current_action === 'Review the meeting request' => 'meeting',
                $purchase->current_action === 'Review the cancellation request' => 'closeout',
                $purchase->fulfillment_status === 'needs_information' => 'updates',
                $purchase->fulfillment_status === 'provider_review' => 'closeout',
                default => 'delivery',
            };

            return "/admin/workspaces/billing/requests/{$purchase->id}/{$section}";
        }

        $section = match ($purchase->fulfillment_status) {
            'needs_information' => '/updates',
            'provider_review', 'completed', 'cancelled' => '/closeout',
            default => '',
        };

        return "/provider/billing/{$purchase->id}{$section}";
    }

    private function deliveryStatusOptions(ProviderServicePurchase $purchase): array
    {
        return collect([
            ['value' => 'needs_information', 'label' => 'Needs information'],
            ['value' => 'ready', 'label' => 'Ready to start'],
            ['value' => 'in_progress', 'label' => 'In progress'],
            ['value' => 'provider_review', 'label' => 'Ready for provider review'],
        ])->filter(fn (array $option): bool => $this->serviceLifecycle->canTransitionDelivery($purchase, $option['value']))->values()->all();
    }

    private function workspacePayload(ProviderServicePurchase $purchase, bool $includeInternal, string $section = 'all'): array
    {
        $purchase->loadMissing([
            'provider.providerProfile',
            'creator.providerProfile',
            'fulfiller.adminProfile',
            'assignee.adminProfile',
            'meetingDecider.adminProfile',
            'cancellationRequester',
            'cancellationDecider',
        ]);
        $plan = config("billing.plans.{$purchase->plan_code}", []);
        $milestones = $purchase->milestones;

        if (! is_array($milestones) || $milestones === []) {
            $milestones = $this->defaultMilestones(is_array($plan) ? $plan : []);
        }

        $loadUpdates = in_array($section, ['all', 'updates'], true);
        $loadFiles = in_array($section, ['all', 'files'], true);
        $updates = $loadUpdates
            ? $purchase->updates()
                ->with(['actor.adminProfile', 'actor.providerProfile'])
                ->when(! $includeInternal, fn ($query) => $query->where('visible_to_provider', true))
                ->oldest()
                ->get()
                ->map(fn (ProviderServiceUpdate $update) => [
                    'id' => $update->id,
                    'kind' => $update->kind,
                    'message' => $update->message,
                    'visible_to_provider' => $update->visible_to_provider,
                    'actor_name' => $update->actor?->name ?: 'Platform support',
                    'actor_role' => $update->actor?->role ?: 'system',
                    'created_at' => $update->created_at?->toISOString(),
                ])
                ->values()
            : collect();
        $files = $loadFiles
            ? $purchase->files()
                ->with(['uploader.adminProfile', 'uploader.providerProfile'])
                ->when(! $includeInternal, fn ($query) => $query->where('visible_to_provider', true))
                ->latest()
                ->get()
                ->map(fn (ProviderServiceFile $file) => [
                    'id' => $file->id,
                    'category' => $file->category,
                    'original_name' => $file->original_name,
                    'mime_type' => $file->mime_type,
                    'size' => $file->size,
                    'visible_to_provider' => $file->visible_to_provider,
                    'uploaded_by' => $file->uploader?->name ?: 'Platform support',
                    'created_at' => $file->created_at?->toISOString(),
                    'view_url' => route('service-files.view', $file),
                    'download_url' => route('service-files.download', $file),
                ])
                ->values()
            : collect();
        $lifecycleEvents = in_array($section, ['all', 'history'], true)
            ? $purchase->lifecycleEvents()
                ->with(['actor.adminProfile', 'actor.providerProfile'])
                ->oldest()
                ->get()
                ->map(fn ($event) => [
                    'id' => $event->id,
                    'event_type' => $event->event_type,
                    'payment_from' => $event->payment_from,
                    'payment_to' => $event->payment_to,
                    'delivery_from' => $event->delivery_from,
                    'delivery_to' => $event->delivery_to,
                    'action_owner' => $event->action_owner,
                    'actor_name' => $event->actor?->name ?: 'System',
                    'metadata' => $event->metadata ?? [],
                    'created_at' => $event->created_at?->toISOString(),
                ])
                ->values()
            : collect();

        return [
            ...$this->purchasePayload($purchase, $includeInternal),
            ...($includeInternal ? ['delivery_status_options' => $this->deliveryStatusOptions($purchase)] : []),
            'milestones' => $milestones,
            'plan_description' => $plan['description'] ?? null,
            'plan_features' => array_values($plan['features'] ?? []),
            'updates' => $updates,
            'files' => $files,
            'lifecycle_events' => $lifecycleEvents,
        ];
    }

    private function meetingDateLabel(ProviderServicePurchase $purchase): string
    {
        return $purchase->meeting_scheduled_for
            ? $purchase->meeting_scheduled_for->timezone(config('app.timezone'))->format('M j, Y g:i A')
            : 'the selected date';
    }

    private function defaultMilestones(array $plan): array
    {
        return collect($plan['features'] ?? [])
            ->values()
            ->map(fn (string $feature, int $index) => [
                'id' => 'milestone_'.($index + 1),
                'label' => $feature,
                'completed' => false,
            ])
            ->all();
    }

    /**
     * @param  array<string, mixed>  $attributes
     */
    private function transitionServiceDelivery(
        ProviderServicePurchase $purchase,
        string $toStatus,
        ?User $actor,
        array $attributes = [],
        string $eventType = 'delivery_status_changed',
    ): ProviderServicePurchase {
        try {
            return $this->serviceLifecycle->transitionDelivery(
                $purchase,
                $toStatus,
                $actor,
                $attributes,
                $eventType,
            );
        } catch (DomainException $error) {
            throw ValidationException::withMessages([
                'fulfillment_status' => $error->getMessage(),
            ]);
        }
    }

    private function authorizeProviderPurchase(Request $request, ProviderServicePurchase $purchase): void
    {
        $user = $request->user();

        abort_unless($user?->isProvider(), 403);
        abort_unless($user->providerOrganizationId() === $purchase->provider_id, 403);
    }

    private function authorizeServiceFile(Request $request, ProviderServiceFile $file): void
    {
        $file->loadMissing('purchase');
        $user = $request->user();

        abort_unless($user, 403);

        if ($user->isAdmin()) {
            abort_unless($user->hasPortalPermission('manage_billing'), 403);

            return;
        }

        abort_unless($user->isProvider(), 403);
        abort_unless($user->hasPortalPermission('manage_billing'), 403);
        abort_unless($file->visible_to_provider, 403);
        abort_unless($file->purchase?->provider_id === $user->providerOrganizationId(), 403);
    }

    private function requirePaidService(ProviderServicePurchase $purchase): void
    {
        if ($purchase->status !== 'paid') {
            throw ValidationException::withMessages([
                'service' => 'The payment must be confirmed before the service workspace can be updated.',
            ]);
        }
    }

    private function requireNoPendingCancellation(ProviderServicePurchase $purchase): void
    {
        if ($purchase->cancellation_status === 'requested') {
            throw ValidationException::withMessages([
                'service' => 'Wait for the cancellation decision before changing this service.',
            ]);
        }
    }

    private function uniqueReferenceNumber(): string
    {
        do {
            $reference = 'SP-'.now()->format('Ymd').'-'.Str::upper(Str::random(10));
        } while (ProviderServicePurchase::query()->where('reference_number', $reference)->exists());

        return $reference;
    }

    private function statusLabel(string $status): string
    {
        return Str::of($status)->replace('_', ' ')->lower()->toString();
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\ApplicantVerificationDocument;
use App\Models\ApplicationDocument;
use App\Models\ApplicationSchedule;
use App\Models\ApplicationStageAssignment;
use App\Models\ApplicationStatusHistory;
use App\Models\PortalNotification;
use App\Models\RecipientBenefitReceiptResponse;
use App\Models\RecipientBenefitReleaseRecord;
use App\Models\RecipientMonitoringAdjustmentRequest;
use App\Models\RecipientMonitoringCycle;
use App\Models\RecipientMonitoringCycleRequirement;
use App\Models\RecipientMonitoringIntervention;
use App\Models\RecipientMonitoringSubmission;
use App\Models\RecipientSupportDecision;
use App\Models\Scholarship;
use App\Models\ScholarshipApplication;
use App\Models\ScholarshipBookmark;
use App\Models\ScholarshipFunnelEvent;
use App\Models\StudentDocument;
use App\Models\User;
use App\Rules\PhoneNumber;
use App\Services\AcademicRecordOcrService;
use App\Services\ApplicantApplicationDetailService;
use App\Services\ApplicantDashboardService;
use App\Services\ApplicantDocumentLibraryService;
use App\Services\ApplicantEvidenceReviewService;
use App\Services\ApplicantMonitoringDetailService;
use App\Services\ApplicantScholarshipDetailService;
use App\Services\ApplicationStageOperationsService;
use App\Services\ApplicationWorkflowService;
use App\Services\DecisionSupportService;
use App\Services\BenefitDeliveryReportService;
use App\Services\RecipientBenefitEntitlementService;
use App\Services\RecipientMonitoringCaseService;
use App\Services\ScholarshipEligibilityService;
use App\Services\ScholarshipEventService;
use App\Support\AcademicRequirement;
use App\Support\ApplicantStageActivityPayload;
use App\Support\ApplicationSchedulePayload;
use App\Support\CompletedQualification;
use App\Support\EducationEligibilityPolicy;
use App\Support\EligibilityRulePolicy;
use App\Support\PreScreeningHandoffRecord;
use App\Support\RecipientAgreement;
use App\Support\RecipientMonitoringRequirementType;
use App\Support\ReviewRubric;
use App\Support\ScholarshipPreparationContext;
use App\Support\ScholarshipSelectionPlan;
use App\Support\Terms;
use Carbon\CarbonImmutable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use InvalidArgumentException;
use Throwable;

class ApplicantDashboardController extends Controller
{
    public function __construct(
        private readonly ScholarshipEligibilityService $eligibilityService,
        private readonly ApplicantDocumentLibraryService $documentLibraryService,
        private readonly ApplicationWorkflowService $workflowService,
        private readonly AcademicRecordOcrService $academicRecordOcrService,
        private readonly ApplicantApplicationDetailService $applicationDetailService,
        private readonly ApplicantMonitoringDetailService $monitoringDetailService,
    ) {}

    public function index(Request $request): View|RedirectResponse
    {
        if ($redirect = $this->ensureApplicant($request)) {
            return $redirect;
        }

        return view('dashboard');
    }

    public function scholarships(Request $request): View|RedirectResponse
    {
        if ($redirect = $this->ensureApplicant($request)) {
            return $redirect;
        }

        return view('dashboard-scholarships');
    }

    public function scholarshipsData(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);

        $scholarships = $this->publishedScholarships()
            ->get()
            ->map(fn (Scholarship $scholarship) => $this->scholarshipPayload($scholarship, $request->user()))
            ->values();

        return response()->json([
            'user' => $this->userPayload($request),
            'scholarships' => $scholarships,
        ]);
    }

    public function providers(Request $request): View|RedirectResponse
    {
        if ($redirect = $this->ensureApplicant($request)) {
            return $redirect;
        }

        return view('dashboard-providers');
    }

    public function providersData(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);

        $providers = User::query()
            ->where('role', 'provider')
            ->whereNull('parent_account_id')
            ->where('account_status', 'active')
            ->whereNotNull('email_verified_at')
            ->whereHas('providerProfile', fn (Builder $query) => $query->where('verification_status', 'approved'))
            ->with([
                'providerProfile',
                'providerScholarships' => fn ($query) => $query
                    ->discoverable()
                    ->orderByRaw('deadline is null')
                    ->orderBy('deadline'),
            ])
            ->get()
            ->map(fn (User $provider) => $this->publicProviderPayload($provider))
            ->sortBy([
                ['programs_count', 'desc'],
                ['name', 'asc'],
            ])
            ->values();

        return response()->json([
            'user' => $this->userPayload($request),
            'providers' => $providers,
            'summary' => [
                'providers' => $providers->count(),
                'programs' => $providers->sum('programs_count'),
            ],
        ]);
    }

    public function providerDetail(Request $request, User $provider): View|RedirectResponse
    {
        if ($redirect = $this->ensureApplicant($request)) {
            return $redirect;
        }

        abort_unless($this->isPublicProvider($provider), 404);

        return view('dashboard-providers', ['provider' => $provider]);
    }

    public function providerDetailData(Request $request, User $provider): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($this->isPublicProvider($provider), 404);

        $provider->load([
            'providerProfile',
            'providerScholarships' => fn ($query) => $query
                ->with(['provider.providerProfile', 'events'])
                ->withCount(['bookmarks', 'applications'])
                ->discoverable()
                ->orderByRaw('deadline is null')
                ->orderBy('deadline'),
        ]);

        return response()->json([
            'user' => $this->userPayload($request),
            'provider' => $this->publicProviderPayload($provider, $request->user()),
        ]);
    }

    public function scholarshipDetail(
        Request $request,
        Scholarship $scholarship,
        string $section = 'summary',
    ): View|RedirectResponse {
        if ($redirect = $this->ensureApplicant($request)) {
            return $redirect;
        }

        abort_unless($scholarship->isPubliclyVisible(), 404);
        abort_unless(in_array($section, ['summary', 'eligibility', 'award', 'application', 'provider'], true), 404);

        return view('dashboard-scholarship-detail', [
            'scholarship' => $scholarship,
            'section' => $section,
        ]);
    }

    public function scholarshipDetailData(
        Request $request,
        Scholarship $scholarship,
        ApplicantScholarshipDetailService $detailService,
    ): JsonResponse {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($scholarship->isPubliclyVisible(), 404);

        $viewEvent = ScholarshipFunnelEvent::record(
            $request->user(),
            'scholarship_viewed',
            $scholarship,
            source: 'web',
            deduplicationKey: "scholarship_viewed:web:{$request->user()->id}:{$scholarship->id}:".now()->toDateString(),
        );

        if ($viewEvent->wasRecentlyCreated) {
            $scholarship->increment('views_count');
        }

        $view = (string) $request->query('section', 'summary');
        $view = in_array($view, ['summary', 'eligibility', 'award', 'application', 'provider'], true)
            ? $view
            : 'summary';
        $scholarship->load(['provider.providerProfile', 'benefits', 'events'])
            ->loadCount(['bookmarks', 'applications']);

        return response()->json([
            'user' => $this->userPayload($request),
            'detail' => $detailService->build($scholarship, $request->user(), $view),
        ]);
    }

    public function providerPreview(Request $request): Response
    {
        $this->authorizeProviderPreview($request, 'manage_profile');
        $provider = $request->user()->providerOrganizationOwner();

        return response()
            ->view('dashboard-providers', [
                'provider' => $provider,
                'preview' => true,
                'previewBackUrl' => route('provider.workspaces.organization-profile.public', absolute: false),
            ])
            ->header('X-Robots-Tag', 'noindex, nofollow, noarchive');
    }

    public function providerPreviewData(Request $request): JsonResponse
    {
        $this->authorizeProviderPreview($request, 'manage_profile');
        $provider = $request->user()->providerOrganizationOwner();
        $provider->load([
            'providerProfile',
            'providerScholarships' => fn ($query) => $query
                ->with(['provider.providerProfile', 'events'])
                ->withCount(['bookmarks', 'applications'])
                ->discoverable()
                ->orderByRaw('deadline is null')
                ->orderBy('deadline'),
        ]);
        $payload = $this->publicProviderPayload($provider, $request->user());
        $payload['is_verified'] = $provider->providerProfile?->isVerified() ?? false;
        $payload['verification_label'] = $payload['is_verified']
            ? 'Verified organization'
            : 'Verification pending';

        return response()->json([
            'user' => $this->userPayload($request),
            'provider' => $payload,
            'preview' => [
                'enabled' => true,
                'status' => $payload['verification_label'],
                'back_url' => route('provider.workspaces.organization-profile.public', absolute: false),
            ],
        ]);
    }

    public function scholarshipPreview(
        Request $request,
        Scholarship $scholarship,
        string $section = 'summary',
    ): Response {
        $this->authorizeScholarshipPreview($request, $scholarship);
        abort_unless(in_array($section, ['summary', 'eligibility', 'award', 'application', 'provider'], true), 404);

        return response()
            ->view('dashboard-scholarship-detail', [
                'scholarship' => $scholarship,
                'section' => $section,
                'preview' => true,
                'previewBackUrl' => route('provider.programs.edit.step', [
                    'scholarship' => $scholarship,
                    'step' => 'review',
                ], false),
            ])
            ->header('X-Robots-Tag', 'noindex, nofollow, noarchive');
    }

    public function scholarshipPreviewData(
        Request $request,
        Scholarship $scholarship,
        ApplicantScholarshipDetailService $detailService,
    ): JsonResponse {
        $this->authorizeScholarshipPreview($request, $scholarship);
        $view = (string) $request->query('section', 'summary');
        $scenario = (string) $request->query('scenario', 'general');

        return response()->json([
            'user' => $this->userPayload($request),
            'detail' => $detailService->buildPreview(
                $scholarship,
                $request->user(),
                $view,
                $scenario,
            ),
            'preview' => [
                'enabled' => true,
                'status' => Str::headline($scholarship->status ?: 'draft'),
                'scenario' => in_array($scenario, ['general', 'eligible', 'ineligible'], true)
                    ? $scenario
                    : 'general',
                'back_url' => route('provider.programs.edit.step', [
                    'scholarship' => $scholarship,
                    'step' => 'review',
                ], false),
            ],
        ]);
    }

    public function trackApplicationStart(Request $request, Scholarship $scholarship): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($scholarship->isAcceptingApplications(), 404);

        if (! ScholarshipApplication::query()
            ->where('scholarship_id', $scholarship->id)
            ->where('applicant_id', $request->user()->id)
            ->exists()) {
            ScholarshipFunnelEvent::record(
                $request->user(),
                'application_started',
                $scholarship,
                source: 'web',
                metadata: [
                    'profile_complete' => $request->user()->hasCompleteApplicantProfile(),
                ],
                deduplicationKey: "application_started:web:{$request->user()->id}:{$scholarship->id}",
            );
        }

        return response()->json(['tracked' => true]);
    }

    public function applications(Request $request): View|RedirectResponse
    {
        if ($redirect = $this->ensureApplicant($request)) {
            return $redirect;
        }

        if ($request->query('view') === 'monitoring') {
            return redirect()->route('dashboard.monitoring');
        }

        return view('dashboard-applications');
    }

    public function startApplication(Request $request, Scholarship $scholarship): View|RedirectResponse
    {
        if ($redirect = $this->ensureApplicant($request)) {
            return $redirect;
        }

        abort_unless($scholarship->isAcceptingApplications(), 404);

        return view('dashboard-applications', [
            'scholarship' => $scholarship,
        ]);
    }

    public function monitoring(Request $request): View|RedirectResponse
    {
        if ($redirect = $this->ensureApplicant($request)) {
            return $redirect;
        }

        return view('dashboard-monitoring');
    }

    public function monitoringDetail(
        Request $request,
        ScholarshipApplication $application,
        string $section = 'overview',
    ): View|RedirectResponse {
        if ($redirect = $this->ensureApplicant($request)) {
            return $redirect;
        }

        abort_unless($application->applicant_id === $request->user()->id, 403);
        abort_unless(in_array($section, ['overview', 'check-ins', 'benefits', 'history'], true), 404);

        return view('dashboard-monitoring-detail', [
            'application' => $application,
            'section' => $section,
        ]);
    }

    public function monitoringDetailData(
        Request $request,
        ScholarshipApplication $application,
    ): JsonResponse {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($application->applicant_id === $request->user()->id, 403);

        try {
            $detail = $this->monitoringDetailService->build(
                $application,
                $request->user(),
                $this->recipientMonitoringPayload($application),
                (string) $request->query('view', 'overview'),
                $request->filled('record') ? (string) $request->query('record') : null,
            );
        } catch (InvalidArgumentException) {
            abort(404);
        }

        return response()->json([
            'user' => $this->userPayload($request),
            'detail' => $detail,
        ]);
    }

    public function monitoringCheckInDetail(
        Request $request,
        ScholarshipApplication $application,
        string $record,
    ): View|RedirectResponse {
        if ($redirect = $this->ensureApplicant($request)) {
            return $redirect;
        }

        abort_unless($application->applicant_id === $request->user()->id, 403);

        return view('dashboard-monitoring-detail', [
            'application' => $application,
            'section' => 'check-ins',
            'record' => $record,
        ]);
    }

    public function monitoringBenefitDetail(
        Request $request,
        ScholarshipApplication $application,
        string $record,
    ): View|RedirectResponse {
        if ($redirect = $this->ensureApplicant($request)) {
            return $redirect;
        }

        abort_unless($application->applicant_id === $request->user()->id, 403);

        return view('dashboard-monitoring-detail', [
            'application' => $application,
            'section' => 'benefits',
            'record' => $record,
        ]);
    }

    public function monitoringSupportOutcomeDetail(
        Request $request,
        ScholarshipApplication $application,
        string $record,
    ): View|RedirectResponse {
        if ($redirect = $this->ensureApplicant($request)) {
            return $redirect;
        }

        abort_unless($application->applicant_id === $request->user()->id, 403);

        return view('dashboard-monitoring-detail', [
            'application' => $application,
            'section' => 'history',
            'record' => $record,
        ]);
    }

    public function documents(Request $request): View|RedirectResponse
    {
        if ($redirect = $this->ensureApplicant($request)) {
            return $redirect;
        }

        return view('dashboard-documents');
    }

    public function applicationDetail(
        Request $request,
        ScholarshipApplication $application,
        string $section = 'summary',
    ): View|RedirectResponse {
        if ($redirect = $this->ensureApplicant($request)) {
            return $redirect;
        }

        abort_unless($application->applicant_id === $request->user()->id, 403);

        return view('dashboard-application-detail', [
            'application' => $application,
            'section' => $section,
        ]);
    }

    public function profile(Request $request): View|RedirectResponse
    {
        if ($redirect = $this->ensureApplicant($request)) {
            return $redirect;
        }

        return view('dashboard-profile');
    }

    public function profileData(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);

        $user = $request->user()->loadMissing(['studentProfile', 'providerProfile', 'adminProfile']);
        $verificationDocuments = $user->applicantVerificationDocuments()
            ->with('latestReviewEvent')
            ->latest('uploaded_at')
            ->get();

        return response()->json([
            'user' => $user->publicPayload(),
            'profile_readiness' => $user->applicantProfileReadiness(),
            'preparation_context' => ScholarshipPreparationContext::fromRequest($request),
            'match_summary' => $this->profileMatchSummary($user),
            'platform_active_scholarships' => $this->eligibilityService->activePlatformScholarships($user),
            'prepared_documents_count' => $user->studentDocuments()->count(),
            'academic_ocr' => $this->academicRecordOcrService->publicConfiguration(),
            'verification_documents' => $verificationDocuments
                ->map(fn (ApplicantVerificationDocument $document) => $this->applicantVerificationDocumentPayload($document))
                ->values(),
        ]);
    }

    public function data(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);

        $profileReadiness = $request->user()->applicantProfileReadiness();
        $scholarships = $this->publishedScholarships()
            ->get()
            ->map(fn (Scholarship $scholarship) => $this->scholarshipPayload($scholarship, $request->user()))
            ->filter(fn (array $scholarship) => (bool) data_get($scholarship, 'eligibility_match.is_eligible', false))
            ->sortByDesc(fn (array $scholarship) => (int) data_get($scholarship, 'eligibility_match.score', 0))
            ->take(8)
            ->values();
        $applications = ScholarshipApplication::query()
            ->with(['documents', 'schedules', 'statusHistories.actor', 'scholarship.provider.providerProfile', 'scholarship.events'])
            ->where('applicant_id', $request->user()->id)
            ->latest('submitted_at')
            ->limit(5)
            ->get();
        $applications->each(fn (ScholarshipApplication $application) => app(DecisionSupportService::class)->syncApplication($application));
        $this->syncApplicantReminders($request->user());

        return response()->json([
            'user' => $this->userPayload($request),
            'profile_readiness' => $profileReadiness,
            'recommendations_ready' => $profileReadiness['complete'],
            'stats' => $this->statsPayload($request),
            'scholarships' => $scholarships,
            'applications' => $applications->map(fn (ScholarshipApplication $application) => $this->applicationPayload($application))->values(),
            'action_alerts' => PortalNotification::query()
                ->where('user_id', $request->user()->id)
                ->whereNull('read_at')
                ->whereIn('type', [
                    'program_announcement',
                    'application_correction',
                    'document_review',
                    'application_status',
                    'application_outcome',
                    'application_schedule',
                    'applicant_profile_verification',
                ])
                ->latest()
                ->limit(6)
                ->get()
                ->map(fn (PortalNotification $notification): array => [
                    'id' => $notification->id,
                    'type' => $notification->type,
                    'title' => $notification->title,
                    'message' => $notification->message,
                    'action_url' => $notification->action_url,
                    'created_at' => $notification->created_at?->format('M d, Y h:i A'),
                ])
                ->values(),
            'next_steps' => [
                'Review available scholarship programs.',
                'Prepare documents listed in each scholarship requirement.',
                'Complete your applicant profile before submitting applications.',
            ],
        ]);
    }

    public function overviewData(
        Request $request,
        ApplicantDashboardService $dashboardService,
    ): JsonResponse {
        abort_unless($request->user()?->isApplicant(), 403);

        $this->syncApplicantReminders($request->user());

        return response()->json($dashboardService->build($request->user()));
    }

    public function applicationsData(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);

        $scholarships = $this->publishedScholarships()->get();
        $preparedDocuments = StudentDocument::query()
            ->where('user_id', $request->user()->id)
            ->latest('uploaded_at')
            ->get()
            ->filter(fn (StudentDocument $document): bool => Storage::disk('local')->exists($document->path))
            ->values();
        $request->user()->setRelation('studentDocuments', $preparedDocuments);
        $applications = ScholarshipApplication::query()
            ->with(['documents', 'schedules', 'statusHistories.actor', 'scholarship.provider.providerProfile', 'scholarship.events'])
            ->where('applicant_id', $request->user()->id)
            ->latest('submitted_at')
            ->get();
        $this->syncApplicantReminders($request->user());

        return response()->json([
            'user' => $this->userPayload($request),
            'profile_readiness' => $request->user()->applicantProfileReadiness(),
            'stats' => $this->statsPayload($request),
            'scholarships' => $scholarships->map(fn (Scholarship $scholarship) => $this->scholarshipPayload($scholarship, $request->user()))->values(),
            'prepared_documents' => $preparedDocuments
                ->map(fn (StudentDocument $document) => $this->studentDocumentPayload($document))
                ->values(),
            'applications' => $applications->map(fn (ScholarshipApplication $application) => $this->applicationPayload($application))->values(),
        ]);
    }

    public function applicationDetailData(Request $request, ScholarshipApplication $application): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($application->applicant_id === $request->user()->id, 403);

        $application->load(['documents', 'schedules', 'stageAssignments.session', 'stageAssignments.attendance', 'statusHistories.actor', 'scholarship.provider.providerProfile', 'scholarship.events']);
        app(DecisionSupportService::class)->syncApplication($application);
        $application = $application->fresh()->load(['documents', 'schedules', 'stageAssignments.session', 'stageAssignments.attendance', 'statusHistories.actor', 'scholarship.provider.providerProfile', 'scholarship.events']);

        return response()->json([
            'user' => $this->userPayload($request),
            'stats' => $this->statsPayload($request),
            'detail' => $this->applicationDetailService->build(
                $application,
                $request->user(),
                (string) $request->query('view', 'summary'),
            ),
            'application' => $this->applicationPayload($application),
        ]);
    }

    public function documentsData(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);

        $applications = ScholarshipApplication::query()
            ->with(['documents', 'schedules', 'statusHistories.actor', 'scholarship.provider.providerProfile', 'scholarship.events'])
            ->where('applicant_id', $request->user()->id)
            ->latest('submitted_at')
            ->get();
        $documents = $applications->flatMap(fn (ScholarshipApplication $application) => $application->documents);
        $studentDocuments = StudentDocument::query()
            ->where('user_id', $request->user()->id)
            ->latest('uploaded_at')
            ->get();
        $this->syncApplicantReminders($request->user());

        return response()->json([
            'user' => $this->userPayload($request),
            'preparation_context' => ScholarshipPreparationContext::fromRequest($request),
            'stats' => [
                'applications' => $applications->count(),
                'prepared' => $studentDocuments->count(),
                'uploaded' => $documents->count(),
                'accepted' => $documents->where('status', 'accepted')->count(),
                'pending' => $documents->where('status', 'pending')->count(),
                'needs_attention' => $documents->whereIn('status', ['rejected', 'needs_replacement'])->count(),
            ],
            'document_options' => $this->documentLibraryOptions(),
            'prepared_documents' => $studentDocuments->map(fn (StudentDocument $document) => $this->studentDocumentPayload($document))->values(),
            'applications' => $applications->map(fn (ScholarshipApplication $application) => $this->applicationPayload($application))->values(),
        ]);
    }

    public function uploadPreparedDocument(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);

        $validated = $request->validate([
            'document_name' => ['required', 'string', 'max:255'],
            'document_file' => ['required', 'file', 'max:5120', 'mimes:pdf,jpg,jpeg,png,doc,docx'],
            'terms_accepted' => ['accepted'],
        ]);

        $documentName = trim($validated['document_name']);
        $file = $validated['document_file'];
        $existing = StudentDocument::query()
            ->where('user_id', $request->user()->id)
            ->where('document_name', $documentName)
            ->first();
        $oldPath = $existing?->path;
        $path = $file->store("student-documents/{$request->user()->id}", 'local');

        if (! is_string($path)) {
            throw ValidationException::withMessages([
                'document_file' => 'The document could not be stored. Please try again.',
            ]);
        }

        try {
            $document = DB::transaction(fn () => StudentDocument::query()->updateOrCreate([
                'user_id' => $request->user()->id,
                'document_name' => $documentName,
            ], [
                'original_name' => $file->getClientOriginalName(),
                'path' => $path,
                'mime_type' => $file->getClientMimeType(),
                'size' => $file->getSize(),
                'uploaded_at' => now(),
                'terms_accepted_at' => now(),
                'terms_version' => Terms::VERSION,
            ]));
        } catch (Throwable $error) {
            Storage::disk('local')->delete($path);

            throw $error;
        }

        if ($oldPath && $oldPath !== $path) {
            Storage::disk('local')->delete($oldPath);
        }

        ActivityLog::record(
            $request->user(),
            'prepared_document_uploaded',
            "{$request->user()->name} uploaded prepared document {$document->document_name}.",
            $request,
            ['student_document_id' => $document->id],
        );

        ScholarshipFunnelEvent::record(
            $request->user(),
            'prepared_document_uploaded',
            source: 'web',
            metadata: [
                'student_document_id' => $document->id,
                'document_name' => $document->document_name,
                'replaced_existing' => $existing !== null,
            ],
        );

        return response()->json([
            'message' => 'Prepared document saved.',
            'document' => $this->studentDocumentPayload($document),
        ]);
    }

    public function deletePreparedDocument(Request $request, StudentDocument $document): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($document->user_id === $request->user()->id, 403);

        $path = $document->path;
        $documentName = $document->document_name;
        $document->delete();
        Storage::disk('local')->delete($path);

        ActivityLog::record(
            $request->user(),
            'prepared_document_deleted',
            "{$request->user()->name} removed prepared document {$documentName}.",
            $request,
        );

        ScholarshipFunnelEvent::record(
            $request->user(),
            'prepared_document_deleted',
            source: 'web',
            metadata: ['document_name' => $documentName],
        );

        return response()->json([
            'message' => 'Prepared document removed.',
        ]);
    }

    public function downloadPreparedDocument(Request $request, StudentDocument $document)
    {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($document->user_id === $request->user()->id, 403);
        abort_unless(Storage::disk('local')->exists($document->path), 404);

        return Storage::disk('local')->download($document->path, $document->original_name, [
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    public function viewPreparedDocument(Request $request, StudentDocument $document)
    {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($document->user_id === $request->user()->id, 403);
        abort_unless(Storage::disk('local')->exists($document->path), 404);

        return Storage::disk('local')->response($document->path, $document->original_name, [
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    public function uploadApplicantVerificationDocument(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);

        $documentType = (string) $request->input('document_type');
        $usesAcademicOcr = $this->academicRecordOcrService->configured()
            && $documentType === 'academic_record';
        $requiresImageOrPdf = $usesAcademicOcr || $documentType === 'recent_school_id';
        $maximumFileSize = $usesAcademicOcr
            ? max(1, (int) config('services.academic_ocr.max_file_size_kb', 1024))
            : 5120;
        $allowedFileTypes = $requiresImageOrPdf ? 'pdf,jpg,jpeg,png' : 'pdf,jpg,jpeg,png,doc,docx';
        $validated = $request->validate([
            'document_type' => ['required', Rule::in(ApplicantVerificationDocument::PROFILE_UPLOAD_TYPES)],
            'document_file' => ['required', 'file', "max:{$maximumFileSize}", "mimes:{$allowedFileTypes}"],
            'terms_accepted' => ['accepted'],
            'expected_revision' => ['sometimes', 'nullable', 'integer', 'min:0'],
        ]);

        $user = $request->user();
        $isAcademicRecord = $validated['document_type'] === 'academic_record';
        $isRequiredEvidence = in_array($validated['document_type'], ApplicantVerificationDocument::requiredTypesFor($user), true);
        $isAchievementEvidence = $validated['document_type'] === 'achievement_evidence';
        $documentLabel = match ($validated['document_type']) {
            'academic_record' => 'academic record',
            'recent_school_id' => 'recent school ID',
            'school_record' => 'school enrollment proof',
            'identity_record' => 'identity and birth record',
            'income_record' => 'household income proof',
            'residency_record' => 'residence proof',
            'guardian_record' => 'parent or guardian ID',
            'no_current_scholarship_proof' => 'proof of no current scholarship',
            'achievement_evidence' => 'achievement evidence',
            'qualification_record' => 'completed qualification record',
        };
        $existing = $user->applicantVerificationDocuments()
            ->where('document_type', $validated['document_type'])
            ->first();

        $file = $validated['document_file'];
        $path = $file->store("applicant-verification/{$user->id}", 'local');
        $oldPath = $existing?->path;

        if (! is_string($path)) {
            throw ValidationException::withMessages([
                'document_file' => 'The profile proof could not be stored. Please try again.',
            ]);
        }

        try {
            $document = DB::transaction(function () use ($user, $validated, $file, $path, $isAcademicRecord, $isRequiredEvidence, $isAchievementEvidence, &$oldPath): ApplicantVerificationDocument {
                $user = User::query()->lockForUpdate()->findOrFail($user->id);
                $current = $user->applicantVerificationDocuments()->where('document_type', $validated['document_type'])->lockForUpdate()->first();
                $this->assertCurrentEvidenceRevision($validated['expected_revision'] ?? null, $current);
                $oldPath = $current?->path;
                $document = ApplicantVerificationDocument::query()->updateOrCreate([
                    'applicant_id' => $user->id,
                    'document_type' => $validated['document_type'],
                ], [
                    'uploaded_by' => $user->id,
                    'original_name' => $file->getClientOriginalName(),
                    'path' => $path,
                    'mime_type' => $file->getMimeType(),
                    'size' => $file->getSize() ?: 0,
                    'status' => 'submitted',
                    'review_notes' => null,
                    'uploaded_at' => now(),
                    'terms_accepted_at' => now(),
                    'terms_version' => Terms::VERSION,
                    'ocr_status' => AcademicRecordOcrService::STATUS_NOT_REQUESTED,
                    'ocr_provider' => null,
                    'ocr_grade' => null,
                    'ocr_grading_scale' => null,
                    'ocr_label' => null,
                    'ocr_message' => null,
                    'ocr_processed_at' => null,
                ]);

                if ($isAcademicRecord) {
                    $profileValues = [
                        'verification_status' => 'pending',
                        'verification_notes' => null,
                        'verified_at' => null,
                        'verified_by' => null,
                        'academic_result_source' => null,
                        'academic_result_extracted_at' => null,
                    ];

                    if ($this->academicRecordOcrService->configured()) {
                        $profileValues['gwa'] = null;
                        $profileValues['grading_scale'] = null;
                    }

                    $user->studentProfile()->updateOrCreate(['user_id' => $user->id], $profileValues);
                    $user->applicantVerificationDocuments()
                        ->where('document_type', 'academic_record')
                        ->update([
                            'status' => 'submitted',
                            'review_notes' => null,
                        ]);
                }

                if ($isAchievementEvidence && filled($user->studentProfile?->achievements)) {
                    $user->studentProfile()->update([
                        'verification_status' => 'pending',
                        'verification_notes' => null,
                        'verified_at' => null,
                        'verified_by' => null,
                    ]);
                }

                if ($isRequiredEvidence || ($isAchievementEvidence && filled($user->studentProfile?->achievements))) {
                    app(ApplicantEvidenceReviewService::class)->reopenProfile($user);
                }

                return $document->fresh();
            });
        } catch (Throwable $error) {
            Storage::disk('local')->delete($path);

            throw $error;
        }

        if ($oldPath && $oldPath !== $path) {
            Storage::disk('local')->delete($oldPath);
        }

        $ocrResult = $isAcademicRecord
            ? $this->processAcademicRecordScan($user, $document)
            : null;

        try {
            $preparedDocument = $this->documentLibraryService->ensureVerificationCopy($user, $document);
        } catch (Throwable $error) {
            $preparedDocument = null;
            ActivityLog::record(
                $user,
                'verification_document_library_copy_failed',
                "{$user->name}'s {$documentLabel} could not be copied to Documents.",
                $request,
                ['document_id' => $document->id, 'error' => $error->getMessage()],
            );
        }

        User::query()
            ->where('role', 'admin')
            ->get()
            ->filter(fn (User $admin) => $admin->hasPortalPermission('manage_reviews'))
            ->each(fn (User $admin) => PortalNotification::create([
                'user_id' => $admin->id,
                'type' => 'applicant_profile_verification',
                'title' => str($documentLabel)->title().' uploaded',
                'message' => "{$user->name} submitted a {$documentLabel} for profile review.",
                'action_url' => "/admin/applicants/{$user->id}/review",
            ]));

        ActivityLog::record(
            $user,
            'applicant_verification_document_uploaded',
            "{$user->name} uploaded a {$documentLabel} for profile review.",
            $request,
            [
                'document_id' => $document->id,
                'document_type' => $document->document_type,
                'prepared_document_id' => $preparedDocument?->id,
                'ocr_status' => $ocrResult['status'] ?? AcademicRecordOcrService::STATUS_NOT_REQUESTED,
            ],
        );

        $message = str($documentLabel)->title().($existing ? ' replaced. Awaiting a new review.' : ' saved. Awaiting review.');

        if ($isAcademicRecord) {
            if (($ocrResult['status'] ?? null) === AcademicRecordOcrService::STATUS_SUCCEEDED) {
                $message .= ' The academic result was extracted and sent for review.';
            } elseif ($this->academicRecordOcrService->configured()) {
                $message .= ' The scan needs attention; an authorized reviewer can confirm the result from your file.';
            }
        }

        if ($preparedDocument) {
            $message .= ' A copy is in My Documents.';
        }

        return response()->json([
            'message' => $message,
            ...$this->applicantProfileStatePayload($user),
            'verification_documents' => $this->applicantVerificationDocumentsPayload($user),
            'prepared_document' => $preparedDocument ? $this->studentDocumentPayload($preparedDocument) : null,
            'prepared_documents_count' => $user->studentDocuments()->count(),
            'academic_ocr' => $this->academicRecordOcrService->publicConfiguration(),
        ], $existing ? 200 : 201);
    }

    public function rescanApplicantVerificationDocument(Request $request, ApplicantVerificationDocument $document): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($document->applicant_id === $request->user()->id, 403);
        abort_unless($document->document_type === 'academic_record', 404);
        $validated = $request->validate(['expected_revision' => ['sometimes', 'integer', 'min:1']]);
        $this->assertCurrentEvidenceRevision($validated['expected_revision'] ?? null, $document);

        if (! $this->academicRecordOcrService->enabled()) {
            return response()->json([
                'message' => 'Automatic academic scanning is not enabled.',
            ], 422);
        }

        $result = $this->processAcademicRecordScan($request->user(), $document);

        ActivityLog::record(
            $request->user(),
            'applicant_academic_record_rescanned',
            "{$request->user()->name} retried academic record scanning.",
            $request,
            [
                'document_id' => $document->id,
                'ocr_status' => $result['status'],
            ],
        );

        return response()->json([
            'message' => $result['message'],
            ...$this->applicantProfileStatePayload($request->user()),
            'verification_documents' => $this->applicantVerificationDocumentsPayload($request->user()),
            'academic_ocr' => $this->academicRecordOcrService->publicConfiguration(),
        ]);
    }

    public function deleteApplicantVerificationDocument(Request $request, ApplicantVerificationDocument $document): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($document->applicant_id === $request->user()->id, 403);
        $validated = $request->validate(['expected_revision' => ['sometimes', 'integer', 'min:1']]);

        $path = $document->path;
        $user = $request->user();
        $removedAcademicRecord = $document->document_type === 'academic_record';
        $removedAchievementEvidence = $document->document_type === 'achievement_evidence';

        if ($removedAchievementEvidence && filled($user->studentProfile?->achievements)) {
            throw ValidationException::withMessages([
                'document' => 'Clear and save the achievement entry before removing its supporting evidence.',
            ]);
        }
        DB::transaction(function () use ($document, $user, $validated, $removedAcademicRecord, &$path): void {
            $user = User::query()->lockForUpdate()->findOrFail($user->id);
            $document = $user->applicantVerificationDocuments()->lockForUpdate()->findOrFail($document->id);
            $this->assertCurrentEvidenceRevision($validated['expected_revision'] ?? null, $document);
            $path = $document->path;
            if ($document->document_type === 'achievement_evidence' && filled($user->studentProfile?->achievements)) {
                throw ValidationException::withMessages(['document' => 'Clear and save the achievement entry before removing its supporting evidence.']);
            }
            $document->delete();
            $hasAcademicRecord = $user->applicantVerificationDocuments()
                ->where('document_type', 'academic_record')
                ->exists();

            if ($removedAcademicRecord) {
                $profileValues = [
                    'verification_status' => $hasAcademicRecord ? 'pending' : 'unsubmitted',
                    'verification_notes' => null,
                    'verified_at' => null,
                    'verified_by' => null,
                ];

                if ($user->studentProfile?->academic_result_source === 'ocr') {
                    $profileValues = [
                        ...$profileValues,
                        'gwa' => null,
                        'grading_scale' => null,
                        'academic_result_source' => null,
                        'academic_result_extracted_at' => null,
                    ];
                }

                $user->studentProfile()->update($profileValues);

                if ($hasAcademicRecord) {
                    $user->applicantVerificationDocuments()
                        ->where('document_type', 'academic_record')
                        ->update([
                            'status' => 'submitted',
                            'review_notes' => null,
                        ]);
                }
            }

        });
        Storage::disk('local')->delete($path);

        ActivityLog::record(
            $user,
            'applicant_verification_document_deleted',
            match ($document->document_type) {
                'academic_record' => "{$user->name} removed an academic verification record.",
                'recent_school_id' => "{$user->name} removed a recent school ID.",
                'school_record' => "{$user->name} removed a school enrollment proof.",
                'no_current_scholarship_proof' => "{$user->name} removed proof of no current scholarship.",
                'achievement_evidence' => "{$user->name} removed achievement evidence.",
                'qualification_record' => "{$user->name} removed a completed qualification record.",
                default => "{$user->name} removed a legacy profile verification file.",
            },
            $request,
        );

        return response()->json([
            'message' => match ($document->document_type) {
                'academic_record' => 'Academic record removed. Upload a current record when you are ready for verification.',
                'recent_school_id' => 'Recent school ID removed. Upload a current ID to complete your required evidence.',
                'school_record' => 'School enrollment proof removed. Upload a current record to complete your required evidence.',
                'identity_record', 'income_record', 'residency_record', 'guardian_record' => 'Supporting record removed. Upload a replacement before your profile can be verified again.',
                'no_current_scholarship_proof' => 'Proof of no current scholarship removed.',
                'achievement_evidence' => 'Achievement evidence removed.',
                'qualification_record' => 'Completed qualification record removed. A declared qualification needs supporting evidence before your profile can be verified again.',
                default => 'Older proof file removed. Your academic verification was not changed.',
            },
            ...$this->applicantProfileStatePayload($user),
            'verification_documents' => $this->applicantVerificationDocumentsPayload($user),
            'prepared_documents_count' => $user->studentDocuments()->count(),
            'academic_ocr' => $this->academicRecordOcrService->publicConfiguration(),
        ]);
    }

    public function viewApplicantVerificationDocument(Request $request, ApplicantVerificationDocument $document)
    {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($document->applicant_id === $request->user()->id, 403);
        abort_unless(Storage::disk('local')->exists($document->path), 404);

        return Storage::disk('local')->response($document->path, $document->original_name, [
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    public function uploadProfilePhoto(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);

        $validated = $request->validate([
            'profile_photo' => [
                'required',
                'image',
                'mimes:jpg,jpeg,png',
                'max:5120',
                'dimensions:min_width=300,min_height=300,max_width=4000,max_height=4000,ratio=1/1',
            ],
        ], [
            'profile_photo.dimensions' => 'Use a square 1x1 or 2x2-style photo between 300 x 300 and 4000 x 4000 pixels.',
        ]);

        $user = $request->user();
        $profile = $user->studentProfile()->firstOrCreate(['user_id' => $user->id]);
        $file = $validated['profile_photo'];
        $path = $file->store("profile-photos/{$user->id}", 'local');

        if (! is_string($path)) {
            throw ValidationException::withMessages([
                'profile_photo' => 'The applicant photo could not be stored. Please try again.',
            ]);
        }

        $oldPath = $profile->profile_photo_path;
        $photoReviewStatus = $profile->profile_photo_review_status;
        $photoReviewerId = $profile->profile_photo_reviewed_by;
        $photoReviewApplicationId = $profile->profile_photo_review_application_id;
        $isRequestedReplacement = in_array($photoReviewStatus, ['needs_replacement', 'resubmitted'], true);

        try {
            $profile->update([
                'profile_photo_path' => $path,
                'profile_photo_original_name' => $file->getClientOriginalName(),
                'profile_photo_mime_type' => $file->getMimeType(),
                'profile_photo_size' => $file->getSize() ?: 0,
                'profile_photo_updated_at' => now(),
                'profile_photo_review_status' => $isRequestedReplacement ? 'resubmitted' : null,
                'profile_photo_review_note' => $isRequestedReplacement ? $profile->profile_photo_review_note : null,
                'profile_photo_reviewed_by' => $isRequestedReplacement ? $photoReviewerId : null,
                'profile_photo_reviewed_at' => $isRequestedReplacement ? now() : null,
                'profile_photo_review_application_id' => $isRequestedReplacement ? $photoReviewApplicationId : null,
            ]);
        } catch (Throwable $error) {
            Storage::disk('local')->delete($path);

            throw $error;
        }

        if ($oldPath && $oldPath !== $path) {
            Storage::disk('local')->delete($oldPath);
        }

        ActivityLog::record(
            $user,
            'applicant_profile_photo_updated',
            "{$user->name} updated their applicant profile photo.",
            $request,
            ['replacement_requested' => $isRequestedReplacement],
        );

        PortalNotification::query()
            ->where('user_id', $user->id)
            ->where('deduplication_key', "profile-photo-review:{$user->id}")
            ->update(['read_at' => now()]);

        if ($isRequestedReplacement && $photoReviewerId) {
            $reviewer = User::query()->find($photoReviewerId);

            if ($reviewer) {
                $reviewUrl = $reviewer->isAdmin()
                    ? route('admin.applicants.review.show', $user, false)
                    : ($photoReviewApplicationId
                        ? route('provider.applications.show', $photoReviewApplicationId, false).'?section=applicant'
                        : '/provider/applications/review');

                PortalNotification::updateOrCreate(
                    [
                        'user_id' => $reviewer->id,
                        'deduplication_key' => "profile-photo-resubmitted:{$user->id}:{$reviewer->id}",
                    ],
                    [
                        'type' => 'profile_photo_resubmitted',
                        'title' => 'Applicant uploaded a new 2x2 photo',
                        'message' => "{$user->name} uploaded the requested replacement photo. Open the applicant review to check it.",
                        'action_url' => $reviewUrl,
                        'read_at' => null,
                    ],
                );
            }
        }

        $user->unsetRelation('studentProfile');

        return response()->json([
            'message' => 'Applicant photo updated.',
            ...$this->applicantProfileStatePayload($user),
        ]);
    }

    public function viewProfilePhoto(Request $request)
    {
        abort_unless($request->user()?->isApplicant(), 403);

        $profile = $request->user()->studentProfile;
        abort_unless($profile?->profile_photo_path, 404);
        abort_unless(Storage::disk('local')->exists($profile->profile_photo_path), 404);

        return Storage::disk('local')->response(
            $profile->profile_photo_path,
            $profile->profile_photo_original_name ?: 'applicant-photo',
            [
                'Cache-Control' => 'private, no-store',
                'X-Content-Type-Options' => 'nosniff',
            ],
        );
    }

    public function deleteProfilePhoto(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);

        $user = $request->user();
        $profile = $user->studentProfile;
        abort_unless($profile?->profile_photo_path, 404);

        $path = $profile->profile_photo_path;
        $profile->update([
            'profile_photo_path' => null,
            'profile_photo_original_name' => null,
            'profile_photo_mime_type' => null,
            'profile_photo_size' => null,
            'profile_photo_updated_at' => null,
        ]);
        Storage::disk('local')->delete($path);

        ActivityLog::record(
            $user,
            'applicant_profile_photo_deleted',
            "{$user->name} removed their applicant profile photo.",
            $request,
        );

        $user->unsetRelation('studentProfile');

        return response()->json([
            'message' => 'Applicant photo removed.',
            ...$this->applicantProfileStatePayload($user),
        ]);
    }

    public function updateProfile(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);

        $user = $request->user();
        if ($request->input('profile_section') === null || $request->input('profile_section') === 'academic') {
            $request->merge(CompletedQualification::input($request->all(), $user->studentProfile));
        }
        $academicRecord = $user->applicantVerificationDocuments()
            ->where('document_type', 'academic_record')
            ->first();
        $manualAcademicEntryAllowed = $this->academicRecordOcrService->configured()
            && $academicRecord
            && in_array($academicRecord->ocr_status, [
                AcademicRecordOcrService::STATUS_FAILED,
                AcademicRecordOcrService::STATUS_NEEDS_REVIEW,
                AcademicRecordOcrService::STATUS_UNAVAILABLE,
            ], true);
        $ocrManagedGrades = $this->academicRecordOcrService->configured() && ! $manualAcademicEntryAllowed;
        $gradeMaximum = $request->input('grading_scale') === AcademicRequirement::SCALE_GRADE_POINT ? 5 : 100;
        $profileSection = $request->input('profile_section');
        $sectionFields = [
            'personal' => [
                'first_name', 'last_name', 'middle_initial', 'suffix', 'gender', 'contact_number',
                'account_managed_by', 'citizenship_status', 'birthdate',
            ],
            'academic' => [
                ...CompletedQualification::FIELDS,
                'education_level', 'school', 'school_type', 'learner_reference_number',
                'course_or_strand', 'year_level', 'enrollment_status', 'academic_year',
                'academic_term', 'gwa', 'grading_scale',
            ],
            'household' => [
                'income_bracket', 'household_size', 'current_scholarship_status',
                'current_scholarship_details', 'guardian_name', 'guardian_relationship',
                'guardian_contact', 'guardian_email', 'guardian_is_account_owner',
            ],
            'location' => ['address', 'barangay', 'city', 'province', 'region', 'latitude', 'longitude'],
            'verification' => ['gwa', 'grading_scale'],
        ];
        $validationRules = [
            ...CompletedQualification::rules($request->all()),
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'middle_initial' => ['nullable', 'string', 'size:1', 'regex:/^[A-Za-z]$/'],
            'suffix' => ['nullable', 'string', 'max:20'],
            'gender' => ['nullable', Rule::in(['female', 'male', 'non_binary', 'prefer_not_to_say'])],
            'contact_number' => ['required', 'string', 'max:30', new PhoneNumber],
            'account_managed_by' => ['nullable', Rule::in(['learner', 'parent_guardian', 'relative', 'school_representative', 'other'])],
            'citizenship_status' => ['nullable', Rule::in(['filipino', 'dual_filipino', 'other'])],
            'education_level' => ['nullable', 'string', 'max:100'],
            'school' => ['nullable', 'string', 'max:255'],
            'school_type' => ['nullable', 'string', 'max:100'],
            'learner_reference_number' => ['nullable', 'string', 'max:50', 'regex:/^[A-Za-z0-9_.-]*$/'],
            'course_or_strand' => ['nullable', 'string', 'max:255'],
            'year_level' => ['nullable', 'string', 'max:100'],
            'enrollment_status' => ['nullable', 'string', 'max:100'],
            'academic_year' => ['nullable', 'string', 'max:20'],
            'academic_term' => ['nullable', Rule::in(['full_year', 'first_grading_period', 'second_grading_period', 'third_grading_period', 'fourth_grading_period', 'first_semester', 'second_semester', 'third_term', 'summer_term', 'latest_completed_term', 'not_applicable'])],
            'gwa' => $ocrManagedGrades ? ['nullable'] : ['nullable', 'numeric', 'min:0', "max:{$gradeMaximum}"],
            'grading_scale' => $ocrManagedGrades ? ['nullable'] : ['nullable', Rule::in(AcademicRequirement::SCALES)],
            'income_bracket' => ['nullable', 'string', 'max:100'],
            'household_size' => ['nullable', 'integer', 'min:1', 'max:30'],
            'preferred_categories' => ['nullable', 'string', 'max:1000'],
            'preferred_locations' => ['nullable', 'string', 'max:1000'],
            'willing_to_relocate' => ['nullable', Rule::in(['yes', 'no', 'depends'])],
            'support_needs' => ['nullable', 'string', 'max:1500'],
            'current_scholarship_status' => ['required', Rule::in(['none', 'receiving', 'pending', 'completed'])],
            'current_scholarship_details' => ['nullable', 'required_if:current_scholarship_status,receiving,pending', 'string', 'max:1000'],
            'scholarship_goal' => ['nullable', 'string', 'max:1500'],
            'achievements' => ['nullable', 'string', 'max:1500'],
            'activities_and_responsibilities' => ['nullable', 'string', 'max:1500'],
            'address' => ['nullable', 'string', 'max:500'],
            'barangay' => ['nullable', 'string', 'max:255'],
            'city' => ['nullable', 'string', 'max:255'],
            'province' => ['nullable', 'string', 'max:255'],
            'region' => ['nullable', 'string', 'max:255'],
            'latitude' => ['nullable', 'required_with:longitude', 'numeric', 'between:-90,90', new \App\Rules\PhilippineLandPin],
            'longitude' => ['nullable', 'required_with:latitude', 'numeric', 'between:-180,180', new \App\Rules\PhilippineLandPin],
            'birthdate' => ['nullable', 'date', 'before_or_equal:'.now()->subYears(5)->toDateString(), 'after_or_equal:'.now()->subYears(100)->toDateString()],
            'guardian_name' => ['nullable', 'string', 'max:255'],
            'guardian_relationship' => ['nullable', 'string', 'max:100'],
            'guardian_contact' => ['nullable', 'string', 'max:30', new PhoneNumber],
            'guardian_email' => ['nullable', 'email', 'max:255'],
            'guardian_is_account_owner' => ['nullable', 'boolean'],
        ];

        if ($profileSection !== null) {
            $validationRules = array_intersect_key(
                $validationRules,
                array_flip($sectionFields[is_string($profileSection) ? $profileSection : ''] ?? []),
            );
            $validationRules['profile_section'] = ['required', Rule::in(array_keys($sectionFields))];
        }

        $validated = $request->validate($validationRules);
        unset($validated['profile_section']);

        if ($ocrManagedGrades) {
            unset($validated['gwa'], $validated['grading_scale']);
        } elseif (array_key_exists('grading_scale', $validated)
            && ! AcademicRequirement::requiresNumeric($validated['grading_scale'])) {
            $validated['gwa'] = null;
        }

        if (array_key_exists('current_scholarship_status', $validated)
            && ! in_array($validated['current_scholarship_status'], ['receiving', 'pending'], true)) {
            $validated['current_scholarship_details'] = null;
        }

        $submittedAchievements = trim((string) ($validated['achievements'] ?? $user->studentProfile?->achievements ?? ''));
        $savedAchievements = trim((string) ($user->studentProfile?->achievements ?? ''));
        $achievementChanged = array_key_exists('achievements', $validated)
            && $submittedAchievements !== $savedAchievements;

        if ($achievementChanged
            && $submittedAchievements !== ''
            && ! $user->applicantVerificationDocuments()->where('document_type', 'achievement_evidence')->exists()) {
            throw ValidationException::withMessages([
                'achievements' => 'Upload achievement evidence before saving a new or changed achievement.',
            ]);
        }

        $profileValues = $validated;

        if (array_key_exists('middle_initial', $profileValues)) {
            $profileValues['middle_initial'] = filled($profileValues['middle_initial'])
                ? strtoupper($profileValues['middle_initial'])
                : null;
        }

        if (array_key_exists('guardian_is_account_owner', $profileValues)) {
            $profileValues['guardian_is_account_owner'] = (bool) $profileValues['guardian_is_account_owner'];
        }
        $studentProfile = $user->studentProfile()->firstOrNew(['user_id' => $user->id]);
        $studentProfile->fill($profileValues);
        $manualAcademicResultChanged = $manualAcademicEntryAllowed
            && $studentProfile->isDirty(['gwa', 'grading_scale']);

        if ($manualAcademicResultChanged) {
            $hasCompleteManualResult = filled($studentProfile->grading_scale)
                && (! AcademicRequirement::requiresNumeric($studentProfile->grading_scale) || $studentProfile->gwa !== null);

            $studentProfile->fill([
                'academic_result_source' => $hasCompleteManualResult ? 'applicant_manual' : null,
                'academic_result_extracted_at' => null,
            ]);
        }
        $verifiedFields = [
            ...CompletedQualification::FIELDS,
            'first_name', 'last_name', 'middle_initial', 'suffix', 'birthdate', 'citizenship_status',
            'income_bracket', 'household_size', 'guardian_name', 'guardian_relationship', 'account_managed_by',
            'address', 'barangay', 'city', 'province', 'region',
            'education_level',
            'school',
            'school_type',
            'learner_reference_number',
            'course_or_strand',
            'year_level',
            'enrollment_status',
            'academic_year',
            'academic_term',
            'gwa',
            'grading_scale',
            'achievements',
        ];
        $verifiedFields = array_filter($verifiedFields, fn (string $field): bool => ! in_array($field, ['first_name', 'last_name', 'middle_initial', 'suffix'], true)
            || strcasecmp(trim((string) $studentProfile->getOriginal($field)), trim((string) $studentProfile->getAttribute($field))) !== 0);
        $verificationReset = $studentProfile->verification_status === 'approved'
            && $studentProfile->isDirty($verifiedFields);

        if ($verificationReset) {
            $studentProfile->fill([
                'verification_status' => $user->applicantVerificationDocuments()
                    ->where('document_type', 'academic_record')
                    ->exists() ? 'pending' : 'unsubmitted',
                'verification_notes' => null,
                'verified_at' => null,
                'verified_by' => null,
            ]);
        }

        DB::transaction(function () use ($studentProfile, $user): void {
            User::query()->lockForUpdate()->findOrFail($user->id);
            $studentProfile->save();
        });
        $user->unsetRelation('studentProfile');

        if ($verificationReset) {
            User::query()
                ->where('role', 'admin')
                ->where('account_status', 'active')
                ->get()
                ->filter(fn (User $admin) => $admin->hasPortalPermission('manage_reviews'))
                ->each(fn (User $admin) => PortalNotification::create([
                    'user_id' => $admin->id,
                    'type' => 'applicant_profile_verification',
                    'title' => 'Verified profile details changed',
                    'message' => "{$user->name} changed verified profile information and needs another review.",
                    'action_url' => route('admin.applicants.review.show', $user, false),
                ]));
        }

        ScholarshipApplication::query()
            ->with(['applicant.studentProfile', 'documents', 'scholarship'])
            ->where('applicant_id', $user->id)
            ->get()
            ->each(fn (ScholarshipApplication $application) => app(DecisionSupportService::class)->syncApplication($application, 'web_profile_updated'));

        $profileReadiness = $user->applicantProfileReadiness();

        if ($profileReadiness['complete']) {
            ScholarshipFunnelEvent::record(
                $user,
                'profile_completed',
                source: 'web',
                metadata: ['education_level' => $user->studentProfile?->education_level],
                deduplicationKey: "profile_completed:{$user->id}",
            );
        }

        ActivityLog::record(
            $user,
            'profile_updated',
            "{$user->name} updated their applicant profile.",
            $request,
            [
                'verification_reset' => $verificationReset,
                'manual_academic_result_entered' => $manualAcademicResultChanged,
                'profile_section' => $profileSection,
            ],
        );

        return response()->json([
            'message' => $verificationReset
                ? 'Verified profile details updated and returned for review.'
                : 'Applicant profile updated.',
            'verification_documents' => $this->applicantVerificationDocumentsPayload($user),
            'user' => $this->userPayload($request),
            'profile_readiness' => $user->applicantProfileReadiness(),
            'match_summary' => $this->profileMatchSummary($user),
            'platform_active_scholarships' => $this->eligibilityService->activePlatformScholarships($user),
            'verification_reset' => $verificationReset,
        ]);
    }

    public function storeApplication(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);

        if (! $request->user()->hasVerifiedEmail()) {
            return response()->json([
                'message' => 'Verify your email address before submitting an application.',
                'verification_required' => true,
            ], 403);
        }

        $profileReadiness = $request->user()->applicantProfileReadiness();

        if (! $profileReadiness['complete']) {
            return response()->json([
                'message' => 'Complete your student profile before applying.',
                'missing_fields' => $profileReadiness['missing'],
                'profile_readiness' => $profileReadiness,
            ], 422);
        }

        if (! $profileReadiness['verified']) {
            return response()->json([
                'message' => 'Your applicant profile must be verified before you can apply. Open Supporting Evidence in your profile to upload or review your verification records.',
                'profile_verification_required' => true,
                'profile_readiness' => $profileReadiness,
                'profile_url' => '/dashboard/profile?section=verification',
            ], 403);
        }

        $validated = $request->validate([
            'scholarship_id' => [
                'required',
                Rule::exists('scholarships', 'id')->where(fn ($query) => $query->where('status', 'published')),
            ],
            'document_checklist' => ['sometimes', 'array'],
            'document_checklist.*' => ['string', 'max:255'],
            'application_answers' => ['sometimes', 'array', 'max:5'],
            'application_answers.*.question_id' => ['required', 'string', 'max:80'],
            'application_answers.*.answer' => ['nullable', 'string', 'max:1500'],
            'notes' => ['nullable', 'string', 'max:1000'],
            'terms_accepted' => ['accepted'],
        ]);

        $alreadyApplied = ScholarshipApplication::query()
            ->where('scholarship_id', $validated['scholarship_id'])
            ->where('applicant_id', $request->user()->id)
            ->exists();

        if ($alreadyApplied) {
            return response()->json([
                'message' => 'You already submitted an application for this scholarship.',
            ], 422);
        }

        $scholarship = Scholarship::query()
            ->with(['provider.providerProfile', 'events'])
            ->findOrFail($validated['scholarship_id']);

        if (! $scholarship->isAcceptingApplications()) {
            return response()->json([
                'message' => $scholarship->hasReachedApplicationLimit()
                    ? 'This scholarship has reached its application limit.'
                    : ($scholarship->application_opens_at?->isFuture()
                        ? 'Applications open on '.$scholarship->application_opens_at->format('M d, Y').'.'
                        : 'This scholarship is no longer accepting applications.'),
            ], 422);
        }

        $applicationAnswers = $this->normalizeApplicationAnswers(
            $scholarship,
            $validated['application_answers'] ?? [],
        );

        $eligibilityMatch = $this->eligibilityMatch($scholarship, $request->user());
        $eligibilityBlockers = $this->applicationEligibilityBlockers($eligibilityMatch);

        if ($eligibilityBlockers !== []) {
            return response()->json([
                'message' => 'You are not eligible to apply for this scholarship based on your current student profile.',
                'eligibility_match' => $eligibilityMatch,
                'blocking_criteria' => $eligibilityBlockers,
            ], 422);
        }

        $requiredDocuments = collect($scholarship->application_mode === 'provider_review'
            ? []
            : $this->documentRequirements($scholarship))
            ->unique()
            ->values()
            ->all();
        $optionalDocuments = $scholarship->application_mode === 'provider_review'
            ? []
            : $this->eligibilityService->optionalDocumentRequirements($scholarship);
        $preparedDocumentNames = $requiredDocuments === []
            ? collect()
            : $request->user()->studentDocuments()
                ->whereIn('document_name', $requiredDocuments)
                ->get()
                ->filter(fn (StudentDocument $document): bool => Storage::disk('local')->exists($document->path))
                ->pluck('document_name');
        $missingDocuments = collect($requiredDocuments)
            ->reject(fn (string $requirement): bool => $preparedDocumentNames->contains($requirement))
            ->values()
            ->all();

        if ($missingDocuments !== []) {
            return response()->json([
                'message' => 'Upload every required document before continuing with your application.',
                'missing_documents' => $missingDocuments,
            ], 422);
        }

        $acceptedAt = now();
        $copiedDocumentPaths = [];

        try {
            $application = DB::transaction(function () use (
                $scholarship,
                $request,
                $requiredDocuments,
                $optionalDocuments,
                $eligibilityMatch,
                $applicationAnswers,
                $validated,
                $acceptedAt,
                &$copiedDocumentPaths,
            ): ScholarshipApplication {
                $lockedScholarship = Scholarship::query()
                    ->whereKey($scholarship->id)
                    ->lockForUpdate()
                    ->firstOrFail();

                if ($lockedScholarship->hasReachedApplicationLimit()) {
                    throw ValidationException::withMessages([
                        'scholarship_id' => 'This scholarship has reached its application limit.',
                    ]);
                }

                $application = ScholarshipApplication::create([
                    'scholarship_id' => $scholarship->id,
                    'applicant_id' => $request->user()->id,
                    'status' => 'submitted',
                    'document_checklist' => $requiredDocuments,
                    'optional_document_checklist' => $optionalDocuments,
                    'eligibility_score' => $eligibilityMatch['score'],
                    'eligibility_breakdown' => $eligibilityMatch,
                    'review_rubric_snapshot' => $scholarship->review_rubric ?? [],
                    'application_answers' => $applicationAnswers,
                    'notes' => $validated['notes'] ?? null,
                    'submitted_at' => $acceptedAt,
                    'terms_accepted_at' => $acceptedAt,
                    'terms_version' => Terms::VERSION,
                ]);

                ApplicationStatusHistory::create([
                    'scholarship_application_id' => $application->id,
                    'changed_by' => $request->user()->id,
                    'from_status' => null,
                    'to_status' => 'submitted',
                    'review_notes' => 'Application submitted by applicant.',
                    'changed_at' => now(),
                ]);

                $this->attachPreparedDocumentsToApplication(
                    $request->user(),
                    $application,
                    $requiredDocuments,
                    $optionalDocuments,
                    $copiedDocumentPaths,
                );
                $application = $this->workflowService->start($application);
                app(DecisionSupportService::class)->syncApplication($application, 'web_application_submitted');
                app(ScholarshipEventService::class)->syncApplication($application->fresh());

                return $application;
            });
        } catch (Throwable $error) {
            foreach ($copiedDocumentPaths as $copiedPath) {
                Storage::disk('local')->delete($copiedPath);
            }

            if (ScholarshipApplication::query()
                ->where('scholarship_id', $scholarship->id)
                ->where('applicant_id', $request->user()->id)
                ->exists()) {
                return response()->json([
                    'message' => 'You already submitted an application for this scholarship.',
                ], 422);
            }

            throw $error;
        }

        ScholarshipFunnelEvent::record(
            $request->user(),
            'application_submitted',
            $scholarship,
            $application,
            'web',
            [
                'eligibility_score' => $application->fresh()->eligibility_score,
                'dss_score' => $application->fresh()->dss_score,
            ],
            "application_submitted:{$application->id}",
        );

        ActivityLog::record(
            $request->user(),
            'application_submitted',
            "{$request->user()->name} submitted an application for {$scholarship->title}.",
            $request,
            ['application_id' => $application->id, 'scholarship_id' => $scholarship->id],
        );

        PortalNotification::create([
            'user_id' => $scholarship->provider_id,
            'type' => 'application',
            'title' => 'New scholarship application',
            'message' => "{$request->user()->name} submitted an application for {$scholarship->title}.",
            'action_url' => '/provider/applications/review',
        ]);
        PortalNotification::create([
            'user_id' => $request->user()->id,
            'type' => 'application_submitted',
            'title' => 'Application submitted',
            'message' => "Your application for {$scholarship->title} was submitted successfully.",
            'action_url' => '/dashboard/applications',
        ]);

        $freshApplication = $application->fresh()->load(['documents', 'statusHistories.actor', 'scholarship.provider.providerProfile', 'scholarship.events']);

        return response()->json([
            'message' => 'Application submitted successfully.',
            'application' => $this->applicationPayload($freshApplication),
        ], 201);
    }

    public function saveScholarship(Request $request, Scholarship $scholarship): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($scholarship->isDiscoverable(), 404);

        $bookmark = ScholarshipBookmark::query()->firstOrCreate([
            'scholarship_id' => $scholarship->id,
            'user_id' => $request->user()->id,
        ]);

        if ($bookmark->wasRecentlyCreated) {
            ScholarshipFunnelEvent::record(
                $request->user(),
                'scholarship_saved',
                $scholarship,
                source: 'web',
            );
        }

        ActivityLog::record(
            $request->user(),
            'scholarship_saved',
            "{$request->user()->name} saved scholarship {$scholarship->title}.",
            $request,
            ['scholarship_id' => $scholarship->id],
        );

        return response()->json([
            'message' => 'Scholarship saved.',
            'scholarship' => $this->scholarshipPayload($scholarship->fresh()->load(['provider.providerProfile', 'events']), $request->user()),
            'stats' => $this->statsPayload($request),
        ]);
    }

    public function unsaveScholarship(Request $request, Scholarship $scholarship): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);

        $deleted = ScholarshipBookmark::query()
            ->where('scholarship_id', $scholarship->id)
            ->where('user_id', $request->user()->id)
            ->delete();

        if ($deleted > 0) {
            ScholarshipFunnelEvent::record(
                $request->user(),
                'scholarship_unsaved',
                $scholarship,
                source: 'web',
            );
        }

        ActivityLog::record(
            $request->user(),
            'scholarship_unsaved',
            "{$request->user()->name} removed saved scholarship {$scholarship->title}.",
            $request,
            ['scholarship_id' => $scholarship->id],
        );

        return response()->json([
            'message' => 'Scholarship removed from saved list.',
            'scholarship' => $this->scholarshipPayload($scholarship->fresh()->load(['provider.providerProfile', 'events']), $request->user()),
            'stats' => $this->statsPayload($request),
        ]);
    }

    public function uploadDocument(Request $request, ScholarshipApplication $application): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($application->applicant_id === $request->user()->id, 403);

        $validated = $request->validate([
            'document_name' => ['required', 'string', 'max:255'],
            'document_file' => ['required', 'file', 'max:5120', 'mimes:pdf,jpg,jpeg,png,doc,docx'],
            'terms_accepted' => ['accepted'],
        ]);

        $file = $validated['document_file'];
        $existing = ApplicationDocument::query()
            ->where('scholarship_application_id', $application->id)
            ->where('document_name', $validated['document_name'])
            ->first();
        $this->ensureApplicationDocumentsEditable($application, $existing);
        $path = $file->store("application-documents/{$application->id}", 'local');

        if (! is_string($path)) {
            throw ValidationException::withMessages([
                'document_file' => 'The document could not be stored. Please try again.',
            ]);
        }

        try {
            [$document, $oldPath] = DB::transaction(function () use (
                $application,
                $validated,
                $request,
                $file,
                $path,
            ): array {
                $lockedApplication = ScholarshipApplication::query()
                    ->with(['scholarship', 'stageProgresses'])
                    ->whereKey($application->id)
                    ->lockForUpdate()
                    ->firstOrFail();
                $lockedExisting = ApplicationDocument::query()
                    ->where('scholarship_application_id', $lockedApplication->id)
                    ->where('document_name', $validated['document_name'])
                    ->lockForUpdate()
                    ->first();
                $this->ensureApplicationDocumentsEditable($lockedApplication, $lockedExisting);
                $oldPath = $lockedExisting?->path;
                $document = ApplicationDocument::query()->updateOrCreate([
                    'scholarship_application_id' => $lockedApplication->id,
                    'document_name' => $validated['document_name'],
                ], [
                    'uploaded_by' => $request->user()->id,
                    'original_name' => $file->getClientOriginalName(),
                    'path' => $path,
                    'mime_type' => $file->getClientMimeType(),
                    'size' => $file->getSize(),
                    'status' => 'pending',
                    'review_notes' => null,
                    'reviewed_by' => null,
                    'reviewed_at' => null,
                    'uploaded_at' => now(),
                    'terms_accepted_at' => now(),
                    'terms_version' => Terms::VERSION,
                ]);

                return [$document, $oldPath];
            });
        } catch (Throwable $error) {
            Storage::disk('local')->delete($path);

            throw $error;
        }

        if ($oldPath && $oldPath !== $path) {
            Storage::disk('local')->delete($oldPath);
        }

        ActivityLog::record(
            $request->user(),
            'document_uploaded',
            "{$request->user()->name} uploaded {$document->document_name} for application #{$application->id}.",
            $request,
            ['application_id' => $application->id, 'document_id' => $document->id],
        );

        ScholarshipFunnelEvent::record(
            $request->user(),
            'application_document_uploaded',
            application: $application,
            source: 'web',
            metadata: ['document_name' => $document->document_name],
        );

        $application->loadMissing('scholarship');
        PortalNotification::create([
            'user_id' => $application->scholarship->provider_id,
            'type' => 'application_document',
            'title' => 'Application document updated',
            'message' => "{$request->user()->name} uploaded {$document->document_name} for application #{$application->id}.",
            'action_url' => route('provider.applications.show', $application, false),
        ]);

        $freshApplication = $application->fresh()->load(['documents', 'statusHistories.actor', 'scholarship.provider.providerProfile', 'scholarship.events']);
        app(DecisionSupportService::class)->syncApplication($freshApplication, 'web_document_uploaded');

        return response()->json([
            'message' => 'Document uploaded successfully.',
            'application' => $this->applicationPayload($freshApplication),
        ]);
    }

    public function deleteDocument(Request $request, ApplicationDocument $document): JsonResponse
    {
        $document->load('application');
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($document->application?->applicant_id === $request->user()->id, 403);
        $this->ensureApplicationDocumentsEditable($document->application, null, false);

        [$application, $path, $documentName] = DB::transaction(function () use ($document): array {
            $lockedApplication = ScholarshipApplication::query()
                ->with(['scholarship', 'stageProgresses'])
                ->whereKey($document->scholarship_application_id)
                ->lockForUpdate()
                ->firstOrFail();
            $this->ensureApplicationDocumentsEditable($lockedApplication, null, false);
            $lockedDocument = ApplicationDocument::query()
                ->whereKey($document->id)
                ->where('scholarship_application_id', $lockedApplication->id)
                ->lockForUpdate()
                ->firstOrFail();
            $path = $lockedDocument->path;
            $documentName = $lockedDocument->document_name;
            $lockedDocument->delete();

            return [$lockedApplication, $path, $documentName];
        });
        Storage::disk('local')->delete($path);

        ActivityLog::record(
            $request->user(),
            'document_deleted',
            "{$request->user()->name} removed {$documentName} from application #{$application?->id}.",
            $request,
            ['application_id' => $application?->id],
        );

        ScholarshipFunnelEvent::record(
            $request->user(),
            'application_document_deleted',
            application: $application,
            source: 'web',
            metadata: ['document_name' => $documentName],
        );

        $application->loadMissing('scholarship');
        PortalNotification::create([
            'user_id' => $application->scholarship->provider_id,
            'type' => 'application_document',
            'title' => 'Application document removed',
            'message' => "{$request->user()->name} removed {$documentName} from application #{$application->id}.",
            'action_url' => route('provider.applications.show', $application, false),
        ]);

        $freshApplication = $application->fresh()->load(['documents', 'statusHistories.actor', 'scholarship.provider.providerProfile', 'scholarship.events']);
        app(DecisionSupportService::class)->syncApplication($freshApplication, 'web_document_deleted');

        return response()->json([
            'message' => 'Document removed.',
            'application' => $this->applicationPayload($freshApplication),
        ]);
    }

    public function respondToApplication(Request $request, ScholarshipApplication $application): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($application->applicant_id === $request->user()->id, 403);

        $application->loadMissing('scholarship');

        if ($application->final_outcome !== 'selected' || blank($application->provider_contract_terms_snapshot)) {
            return response()->json([
                'message' => 'No in-platform acceptance is required. The scholarship provider manages confirmation and reward distribution directly.',
            ], 422);
        }

        if (filled($application->student_response_status)) {
            return response()->json([
                'message' => 'You already responded to this recipient agreement.',
            ], 422);
        }

        $validated = $request->validate([
            'response' => ['required', Rule::in(['accepted', 'declined'])],
            'terms_accepted' => ['exclude_unless:response,accepted', 'required', 'accepted'],
            'note' => [Rule::requiredIf($request->input('response') === 'declined'), 'nullable', 'string', 'min:5', 'max:1000'],
        ]);
        $response = $validated['response'];
        $now = now();

        $application->update([
            'student_response_status' => $response,
            'student_responded_at' => $now,
            'student_response_note' => $validated['note'] ?? null,
            'student_response_terms_accepted_at' => $response === 'accepted' ? $now : null,
            'student_response_terms_version' => $response === 'accepted'
                ? $application->provider_contract_terms_version
                : null,
            'provider_contract_terms_accepted_at' => $response === 'accepted' ? $now : null,
            'provider_contract_acceptance_ip' => $response === 'accepted' ? $request->ip() : null,
            'provider_contract_acceptance_user_agent' => $response === 'accepted'
                ? Str::limit($request->userAgent() ?? '', 500, '')
                : null,
        ]);

        if ($response === 'accepted') {
            app(RecipientBenefitEntitlementService::class)->activateForAcceptedApplication($application);
            app(RecipientMonitoringCaseService::class)->activateForAcceptedApplication($application);
        }

        ApplicationStatusHistory::create([
            'scholarship_application_id' => $application->id,
            'changed_by' => $request->user()->id,
            'from_status' => $application->status,
            'to_status' => "agreement_{$response}",
            'review_notes' => $response === 'accepted'
                ? 'Applicant accepted the recipient agreement.'
                : 'Applicant declined the recipient agreement.',
            'changed_at' => $now,
        ]);

        $programTitle = $application->scholarship?->title ?? 'the scholarship program';
        $providerMessage = $response === 'accepted'
            ? "{$request->user()->name} accepted the recipient agreement for {$programTitle}."
            : "{$request->user()->name} declined the recipient agreement for {$programTitle}. Review their note before proceeding.";
        PortalNotification::create([
            'user_id' => $application->scholarship->provider_id,
            'type' => 'recipient_agreement_response',
            'title' => $response === 'accepted' ? 'Recipient agreement accepted' : 'Recipient agreement declined',
            'message' => $providerMessage,
            'action_url' => route('provider.applications.show', $application, false).'?section=decision',
        ]);
        $this->notifyAdditionalProviderReviewers(
            $application,
            'recipient_agreement_response',
            $response === 'accepted' ? 'Recipient agreement accepted' : 'Recipient agreement declined',
            $providerMessage,
        );
        ActivityLog::record(
            $request->user(),
            "recipient_agreement_{$response}",
            "{$request->user()->name} {$response} the recipient agreement for application #{$application->id}.",
            $request,
            ['application_id' => $application->id, 'agreement_version' => $application->provider_contract_terms_version],
        );

        $freshApplication = $application->fresh()->load([
            'documents',
            'schedules',
            'statusHistories.actor',
            'scholarship.provider.providerProfile',
            'scholarship.events',
        ]);

        return response()->json([
            'message' => $response === 'accepted'
                ? 'Recipient agreement accepted.'
                : 'Your decision was sent to the provider.',
            'application' => $this->applicationPayload($freshApplication),
        ]);
    }

    public function uploadRecipientMonitoringGrade(
        Request $request,
        ScholarshipApplication $application,
        RecipientMonitoringCycle $cycle,
    ): JsonResponse {
        $this->ensureRecipientMonitoringSubmissionAllowed($request, $application, $cycle);

        $maximumFileSize = $this->academicRecordOcrService->configured()
            ? max(1, (int) config('services.academic_ocr.max_file_size_kb', 1024))
            : 5120;
        $validated = $request->validate([
            'grade_record' => ['required', 'file', "max:{$maximumFileSize}", 'mimes:pdf,jpg,jpeg,png'],
            'terms_accepted' => ['accepted'],
        ]);
        $file = $validated['grade_record'];
        $existing = RecipientMonitoringSubmission::query()
            ->where('recipient_monitoring_cycle_id', $cycle->id)
            ->where('scholarship_application_id', $application->id)
            ->first();
        $path = $file->store("recipient-monitoring/{$application->id}/{$cycle->id}", 'local');
        $oldPath = $existing?->path;

        if (! is_string($path)) {
            throw ValidationException::withMessages([
                'grade_record' => 'The grade record could not be stored. Please try again.',
            ]);
        }

        try {
            $submission = RecipientMonitoringSubmission::query()->updateOrCreate([
                'recipient_monitoring_cycle_id' => $cycle->id,
                'scholarship_application_id' => $application->id,
            ], [
                'applicant_id' => $request->user()->id,
                'original_name' => $file->getClientOriginalName(),
                'path' => $path,
                'mime_type' => $file->getMimeType(),
                'size' => $file->getSize() ?: 0,
                'ocr_status' => AcademicRecordOcrService::STATUS_NOT_REQUESTED,
                'ocr_provider' => null,
                'ocr_grade' => null,
                'ocr_grading_scale' => null,
                'ocr_label' => null,
                'ocr_message' => null,
                'ocr_processed_at' => null,
                'reported_grade' => null,
                'reported_grading_scale' => null,
                'grade_source' => null,
                'submitted_at' => now(),
                'review_status' => 'pending',
                'review_notes' => null,
                'reviewed_by' => null,
                'reviewed_at' => null,
            ]);
        } catch (Throwable $error) {
            Storage::disk('local')->delete($path);

            throw $error;
        }

        if ($oldPath && $oldPath !== $path) {
            Storage::disk('local')->delete($oldPath);
        }

        $result = $this->processRecipientMonitoringScan($submission);
        $programTitle = $application->scholarship?->title ?? 'the scholarship program';
        $providerMessage = "{$request->user()->name} submitted the {$cycle->title} grade record for {$programTitle}.";
        PortalNotification::query()->updateOrCreate([
            'deduplication_key' => "recipient-monitoring-submission:{$submission->id}:provider:{$application->scholarship?->provider_id}",
        ], [
            'user_id' => $application->scholarship?->provider_id,
            'type' => 'recipient_monitoring_submission',
            'title' => 'Academic progress record submitted',
            'message' => $providerMessage,
            'action_url' => route('provider.monitoring.show', $application->scholarship_id, false),
            'read_at' => null,
        ]);
        $this->notifyAdditionalProviderReviewers(
            $application,
            'recipient_monitoring_submission',
            'Academic progress record submitted',
            $providerMessage,
            'overview',
        );

        ActivityLog::record(
            $request->user(),
            'recipient_monitoring_grade_uploaded',
            "{$request->user()->name} uploaded a grade record for {$cycle->title}.",
            $request,
            [
                'application_id' => $application->id,
                'monitoring_cycle_id' => $cycle->id,
                'submission_id' => $submission->id,
                'ocr_status' => $result['status'],
            ],
        );

        $freshApplication = $application->fresh()->load([
            'documents',
            'schedules',
            'statusHistories.actor',
            'scholarship.provider.providerProfile',
            'scholarship.events',
        ]);

        return response()->json([
            'message' => $result['status'] === AcademicRecordOcrService::STATUS_SUCCEEDED
                ? 'Grade record uploaded and the academic result was extracted for provider review.'
                : 'Grade record uploaded. Enter the result shown on the record because automatic extraction needs help.',
            'application' => $this->applicationPayload($freshApplication),
        ], $existing ? 200 : 201);
    }

    public function saveRecipientMonitoringManualGrade(
        Request $request,
        ScholarshipApplication $application,
        RecipientMonitoringCycle $cycle,
    ): JsonResponse {
        $this->ensureRecipientMonitoringSubmissionAllowed($request, $application, $cycle);
        $submission = RecipientMonitoringSubmission::query()
            ->where('recipient_monitoring_cycle_id', $cycle->id)
            ->where('scholarship_application_id', $application->id)
            ->firstOrFail();

        if ($submission->ocr_status === AcademicRecordOcrService::STATUS_SUCCEEDED) {
            throw ValidationException::withMessages([
                'grade' => 'The scanner already extracted a result. The provider will compare it with the uploaded record.',
            ]);
        }

        $validated = $request->validate([
            'grade' => ['required', 'numeric'],
            'grading_scale' => ['required', Rule::in([
                AcademicRequirement::SCALE_PERCENTAGE,
                AcademicRequirement::SCALE_GRADE_POINT,
            ])],
        ]);
        $grade = (float) $validated['grade'];
        $validGrade = $validated['grading_scale'] === AcademicRequirement::SCALE_GRADE_POINT
            ? $grade >= 1 && $grade <= 5
            : $grade >= 0 && $grade <= 100;

        if (! $validGrade) {
            throw ValidationException::withMessages([
                'grade' => $validated['grading_scale'] === AcademicRequirement::SCALE_GRADE_POINT
                    ? 'Enter the grade point shown on the record, from 1.00 to 5.00.'
                    : 'Enter the percentage shown on the record, from 0 to 100.',
            ]);
        }

        $submission->update([
            'reported_grade' => $grade,
            'reported_grading_scale' => $validated['grading_scale'],
            'grade_source' => 'applicant_manual',
            'review_status' => 'pending',
            'review_notes' => null,
            'reviewed_by' => null,
            'reviewed_at' => null,
        ]);

        $application->loadMissing('scholarship');
        PortalNotification::create([
            'user_id' => $application->scholarship?->provider_id,
            'type' => 'recipient_monitoring_submission',
            'title' => 'Academic result updated',
            'message' => "{$request->user()->name} entered the result shown on the {$cycle->title} grade record.",
            'action_url' => route('provider.monitoring.show', $application->scholarship_id, false),
        ]);

        ActivityLog::record(
            $request->user(),
            'recipient_monitoring_grade_entered_manually',
            "{$request->user()->name} entered the result shown on the {$cycle->title} grade record.",
            $request,
            [
                'application_id' => $application->id,
                'monitoring_cycle_id' => $cycle->id,
                'submission_id' => $submission->id,
            ],
        );

        $freshApplication = $application->fresh()->load([
            'documents',
            'schedules',
            'statusHistories.actor',
            'scholarship.provider.providerProfile',
            'scholarship.events',
        ]);

        return response()->json([
            'message' => 'The result was saved with the uploaded record for provider verification.',
            'application' => $this->applicationPayload($freshApplication),
        ]);
    }

    public function uploadRecipientMonitoringRequirement(
        Request $request,
        ScholarshipApplication $application,
        RecipientMonitoringCycleRequirement $requirement,
    ): JsonResponse {
        $requirement->loadMissing('cycle');
        $cycle = $requirement->cycle;
        abort_unless($cycle, 404);
        $this->ensureRecipientMonitoringSubmissionAllowed($request, $application, $cycle, $requirement);

        $isAcademic = $requirement->type === RecipientMonitoringRequirementType::ACADEMIC_PROGRESS;
        $maximumFileSize = $isAcademic && $this->academicRecordOcrService->configured()
            ? max(1, (int) config('services.academic_ocr.max_file_size_kb', 1024))
            : 5120;
        $validated = $request->validate([
            'supporting_record' => ['required', 'file', "max:{$maximumFileSize}", 'mimes:pdf,jpg,jpeg,png'],
            'applicant_note' => ['nullable', 'string', 'max:500'],
            'terms_accepted' => ['accepted'],
        ]);
        $file = $validated['supporting_record'];
        $existing = RecipientMonitoringSubmission::query()
            ->where('recipient_monitoring_cycle_requirement_id', $requirement->id)
            ->where('scholarship_application_id', $application->id)
            ->first();
        $path = $file->store(
            "recipient-monitoring/{$application->id}/{$cycle->id}/{$requirement->id}",
            'local',
        );
        $oldPath = $existing?->path;

        if (! is_string($path)) {
            throw ValidationException::withMessages([
                'supporting_record' => 'The supporting record could not be stored. Please try again.',
            ]);
        }

        try {
            $submission = RecipientMonitoringSubmission::query()->updateOrCreate([
                'recipient_monitoring_cycle_requirement_id' => $requirement->id,
                'scholarship_application_id' => $application->id,
            ], [
                'recipient_monitoring_cycle_id' => $cycle->id,
                'applicant_id' => $request->user()->id,
                'applicant_note' => trim((string) ($validated['applicant_note'] ?? '')) ?: null,
                'submission_source' => 'applicant_upload',
                'original_name' => $file->getClientOriginalName(),
                'path' => $path,
                'mime_type' => $file->getMimeType(),
                'size' => $file->getSize() ?: 0,
                'ocr_status' => AcademicRecordOcrService::STATUS_NOT_REQUESTED,
                'ocr_provider' => null,
                'ocr_grade' => null,
                'ocr_grading_scale' => null,
                'ocr_label' => null,
                'ocr_message' => null,
                'ocr_processed_at' => null,
                'reported_grade' => null,
                'reported_grading_scale' => null,
                'grade_source' => null,
                'submitted_at' => now(),
                'review_status' => 'pending',
                'review_notes' => null,
                'reviewed_by' => null,
                'reviewed_at' => null,
            ]);
        } catch (Throwable $error) {
            Storage::disk('local')->delete($path);
            throw $error;
        }

        if ($oldPath && $oldPath !== $path) {
            Storage::disk('local')->delete($oldPath);
        }

        $scanResult = $isAcademic
            ? $this->processRecipientMonitoringScan($submission)
            : ['status' => AcademicRecordOcrService::STATUS_NOT_REQUESTED];
        $application->loadMissing('scholarship');
        $programTitle = $application->scholarship?->title ?? 'the scholarship program';
        $providerMessage = "{$request->user()->name} submitted {$requirement->title} for {$programTitle}.";

        PortalNotification::query()->updateOrCreate([
            'deduplication_key' => "recipient-monitoring-item:{$submission->id}:provider:{$application->scholarship?->provider_id}",
        ], [
            'user_id' => $application->scholarship?->provider_id,
            'type' => 'recipient_monitoring_submission',
            'title' => 'Monitoring requirement submitted',
            'message' => $providerMessage,
            'action_url' => route('provider.monitoring.academic', $application->scholarship_id, false),
            'read_at' => null,
        ]);
        $this->notifyAdditionalProviderReviewers(
            $application,
            'recipient_monitoring_submission',
            'Monitoring requirement submitted',
            $providerMessage,
            'overview',
        );

        ActivityLog::record(
            $request->user(),
            'recipient_monitoring_requirement_uploaded',
            "{$request->user()->name} uploaded {$requirement->title} for {$cycle->title}.",
            $request,
            [
                'application_id' => $application->id,
                'monitoring_cycle_id' => $cycle->id,
                'monitoring_requirement_id' => $requirement->id,
                'submission_id' => $submission->id,
                'ocr_status' => $scanResult['status'],
            ],
        );

        $freshApplication = $application->fresh()->load([
            'documents',
            'schedules',
            'statusHistories.actor',
            'scholarship.provider.providerProfile',
            'scholarship.events',
        ]);

        return response()->json([
            'message' => $isAcademic
                ? ($scanResult['status'] === AcademicRecordOcrService::STATUS_SUCCEEDED
                    ? 'Academic record uploaded and the result was extracted for provider review.'
                    : 'Academic record uploaded. Enter the result if automatic extraction needs help.')
                : 'Supporting record uploaded for provider review.',
            'application' => $this->applicationPayload($freshApplication),
        ], $existing ? 200 : 201);
    }

    public function saveRecipientMonitoringRequirementManualGrade(
        Request $request,
        ScholarshipApplication $application,
        RecipientMonitoringCycleRequirement $requirement,
    ): JsonResponse {
        $requirement->loadMissing('cycle');
        $cycle = $requirement->cycle;
        abort_unless($cycle, 404);
        abort_unless($requirement->type === RecipientMonitoringRequirementType::ACADEMIC_PROGRESS, 404);
        $this->ensureRecipientMonitoringSubmissionAllowed($request, $application, $cycle, $requirement);

        $submission = RecipientMonitoringSubmission::query()
            ->where('recipient_monitoring_cycle_requirement_id', $requirement->id)
            ->where('scholarship_application_id', $application->id)
            ->firstOrFail();

        if ($submission->ocr_status === AcademicRecordOcrService::STATUS_SUCCEEDED) {
            throw ValidationException::withMessages([
                'grade' => 'The scanner already extracted a result. The provider will compare it with the uploaded record.',
            ]);
        }

        $validated = $request->validate([
            'grade' => ['required', 'numeric'],
            'grading_scale' => ['required', Rule::in([
                AcademicRequirement::SCALE_PERCENTAGE,
                AcademicRequirement::SCALE_GRADE_POINT,
            ])],
        ]);
        $grade = (float) $validated['grade'];
        $validGrade = $validated['grading_scale'] === AcademicRequirement::SCALE_GRADE_POINT
            ? $grade >= 1 && $grade <= 5
            : $grade >= 0 && $grade <= 100;

        if (! $validGrade) {
            throw ValidationException::withMessages([
                'grade' => $validated['grading_scale'] === AcademicRequirement::SCALE_GRADE_POINT
                    ? 'Enter a grade point from 1.00 to 5.00.'
                    : 'Enter a percentage from 0 to 100.',
            ]);
        }

        $submission->update([
            'reported_grade' => $grade,
            'reported_grading_scale' => $validated['grading_scale'],
            'grade_source' => 'applicant_manual',
            'review_status' => 'pending',
            'review_notes' => null,
            'reviewed_by' => null,
            'reviewed_at' => null,
        ]);

        $freshApplication = $application->fresh()->load([
            'documents',
            'schedules',
            'statusHistories.actor',
            'scholarship.provider.providerProfile',
            'scholarship.events',
        ]);

        return response()->json([
            'message' => 'The academic result was saved for provider verification.',
            'application' => $this->applicationPayload($freshApplication),
        ]);
    }

    public function storeRecipientMonitoringAdjustmentRequest(
        Request $request,
        ScholarshipApplication $application,
        RecipientMonitoringCycleRequirement $requirement,
    ): JsonResponse {
        $requirement->loadMissing('cycle.scholarship');
        $cycle = $requirement->cycle;
        abort_unless($cycle, 404);
        $this->ensureRecipientMonitoringAdjustmentAllowed($request, $application, $cycle, $requirement);

        $validated = $request->validate([
            'request_type' => ['required', Rule::in(['extension', 'exception'])],
            'reason_category' => ['required', Rule::in([
                'illness',
                'family_emergency',
                'school_schedule',
                'transfer',
                'technical_issue',
                'other',
            ])],
            'explanation' => ['required', 'string', 'min:10', 'max:2000'],
            'requested_due_at' => [
                Rule::requiredIf($request->input('request_type') === 'extension'),
                'nullable',
                'date',
                'after:'.$cycle->due_at->format('Y-m-d'),
                'before_or_equal:'.$cycle->due_at->copy()->addDays(60)->format('Y-m-d'),
            ],
            'supporting_record' => $cycle->isInPerson() ? ['prohibited'] : ['nullable', 'file', 'max:5120', 'mimes:pdf,jpg,jpeg,png'],
            'confirmation' => ['accepted'],
        ]);
        if ($validated['request_type'] === 'extension' && ! $requirement->requires_file) {
            throw ValidationException::withMessages([
                'request_type' => 'This provider-recorded requirement accepts an exception request instead of a deadline extension.',
            ]);
        }
        $file = $validated['supporting_record'] ?? null;
        $path = $file?->store(
            "recipient-monitoring/{$application->id}/{$cycle->id}/adjustments",
            'local',
        );

        if ($file && ! is_string($path)) {
            throw ValidationException::withMessages([
                'supporting_record' => 'The supporting record could not be stored. Please try again.',
            ]);
        }

        try {
            $adjustment = RecipientMonitoringAdjustmentRequest::create([
                'recipient_monitoring_cycle_id' => $cycle->id,
                'recipient_monitoring_cycle_requirement_id' => $requirement->id,
                'scholarship_application_id' => $application->id,
                'applicant_id' => $request->user()->id,
                'request_type' => $validated['request_type'],
                'reason_category' => $validated['reason_category'],
                'explanation' => trim($validated['explanation']),
                'requested_due_at' => $validated['requested_due_at'] ?? null,
                'attachment_original_name' => $file?->getClientOriginalName(),
                'attachment_path' => $path,
                'attachment_mime_type' => $file?->getMimeType(),
                'attachment_size' => $file?->getSize() ?: 0,
                'status' => 'pending',
            ]);
        } catch (Throwable $error) {
            if ($path) {
                Storage::disk('local')->delete($path);
            }
            throw $error;
        }

        $application->loadMissing(['applicant', 'scholarship']);
        $programTitle = $application->scholarship?->title ?? 'the scholarship program';
        $message = "{$request->user()->name} requested a monitoring {$validated['request_type']} for {$requirement->title} in {$programTitle}.";
        PortalNotification::query()->updateOrCreate([
            'deduplication_key' => "recipient-monitoring-adjustment:{$adjustment->id}:provider:{$application->scholarship?->provider_id}",
        ], [
            'user_id' => $application->scholarship?->provider_id,
            'type' => 'recipient_monitoring_adjustment',
            'title' => 'Monitoring request received',
            'message' => $message,
            'action_url' => route('provider.monitoring.academic', $application->scholarship_id, false),
            'read_at' => null,
        ]);
        $this->notifyAdditionalProviderReviewers(
            $application,
            'recipient_monitoring_adjustment',
            'Monitoring request received',
            $message,
            'monitoring',
        );

        ActivityLog::record(
            $request->user(),
            'recipient_monitoring_adjustment_requested',
            "{$request->user()->name} requested a {$validated['request_type']} for {$requirement->title}.",
            $request,
            [
                'application_id' => $application->id,
                'monitoring_cycle_id' => $cycle->id,
                'monitoring_requirement_id' => $requirement->id,
                'adjustment_request_id' => $adjustment->id,
                'request_type' => $validated['request_type'],
            ],
        );

        $freshApplication = $application->fresh()->load([
            'documents',
            'schedules',
            'statusHistories.actor',
            'scholarship.provider.providerProfile',
            'scholarship.events',
        ]);

        return response()->json([
            'message' => 'Your request was sent to the provider for review.',
            'application' => $this->applicationPayload($freshApplication),
        ], 201);
    }

    public function viewRecipientMonitoringAdjustmentAttachment(
        Request $request,
        RecipientMonitoringAdjustmentRequest $adjustment,
    ) {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($adjustment->applicant_id === $request->user()->id, 403);
        abort_unless(filled($adjustment->attachment_path)
            && Storage::disk('local')->exists($adjustment->attachment_path), 404);

        return Storage::disk('local')->response(
            $adjustment->attachment_path,
            $adjustment->attachment_original_name,
            [
                'Cache-Control' => 'private, no-store',
                'X-Content-Type-Options' => 'nosniff',
            ],
        );
    }

    public function viewRecipientMonitoringGrade(
        Request $request,
        RecipientMonitoringSubmission $submission,
    ) {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($submission->applicant_id === $request->user()->id, 403);
        abort_unless(filled($submission->path) && Storage::disk('local')->exists($submission->path), 404);

        return Storage::disk('local')->response($submission->path, $submission->original_name, [
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    public function viewRecipientBenefitReleaseReceipt(
        Request $request,
        RecipientBenefitReleaseRecord $record,
    ) {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($record->applicant_id === $request->user()->id, 403);
        abort_unless(filled($record->receipt_path) && Storage::disk('local')->exists($record->receipt_path), 404);

        return Storage::disk('local')->response($record->receipt_path, $record->receipt_original_name, [
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    public function respondToRecipientBenefitRelease(
        Request $request,
        RecipientBenefitReleaseRecord $record,
    ): JsonResponse {
        abort_unless($request->user()?->isApplicant(), 403);
        $record->loadMissing(['release.scholarship', 'application.scholarship', 'receiptResponse']);
        abort_unless($record->applicant_id === $request->user()->id, 403);

        if ($record->status !== 'released') {
            throw ValidationException::withMessages([
                'response_type' => 'You can respond after the provider records this benefit as released.',
            ]);
        }

        if ($record->receiptResponse) {
            throw ValidationException::withMessages([
                'response_type' => 'Your response to this release is already recorded.',
            ]);
        }

        if (app(BenefitDeliveryReportService::class)->openForRecord($record)->exists()) {
            throw ValidationException::withMessages(['response_type' => 'An open delivery report covers this benefit. Respond through that report so its resolution is recorded.']);
        }

        $validated = $request->validate([
            'response_type' => ['required', Rule::in(['confirmed', 'issue'])],
            'received_on' => [
                Rule::requiredIf($request->input('response_type') === 'confirmed'),
                'nullable',
                'date',
                'before_or_equal:today',
            ],
            'recipient_note' => ['nullable', 'string', 'max:1000'],
            'issue_type' => [
                Rule::requiredIf($request->input('response_type') === 'issue'),
                'nullable',
                Rule::in(['not_received', 'incorrect_amount', 'incomplete_benefit', 'damaged_item', 'other']),
            ],
            'issue_details' => [
                Rule::requiredIf($request->input('response_type') === 'issue'),
                'nullable',
                'string',
                'min:5',
                'max:1500',
            ],
            'evidence' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png', 'max:5120'],
            'acknowledged' => ['accepted'],
        ]);

        $evidence = $request->file('evidence');
        $evidencePath = $evidence?->store("benefit-receipt-responses/{$record->id}/recipient", 'local');

        try {
            $response = DB::transaction(function () use ($request, $record, $validated, $evidence, $evidencePath): RecipientBenefitReceiptResponse {
                // Serialize normal receipts with report creation and report responses.
                ScholarshipApplication::query()->lockForUpdate()->findOrFail($record->scholarship_application_id);
                $record = RecipientBenefitReleaseRecord::query()->lockForUpdate()->findOrFail($record->id);
                if ($record->status !== 'released' || $record->receiptResponse()->exists()
                    || app(BenefitDeliveryReportService::class)->openForRecord($record)->exists()) {
                    throw ValidationException::withMessages(['response_type' => 'This release or its delivery report changed. Reload it before responding.']);
                }
                $response = RecipientBenefitReceiptResponse::create([
                    'recipient_benefit_release_record_id' => $record->id,
                    'scholarship_application_id' => $record->scholarship_application_id,
                    'applicant_id' => $request->user()->id,
                    'response_type' => $validated['response_type'],
                    'received_on' => $validated['response_type'] === 'confirmed' ? $validated['received_on'] : null,
                    'recipient_note' => trim((string) ($validated['recipient_note'] ?? '')) ?: null,
                    'issue_type' => $validated['response_type'] === 'issue' ? $validated['issue_type'] : null,
                    'issue_details' => $validated['response_type'] === 'issue' ? $validated['issue_details'] : null,
                    'evidence_original_name' => $evidence?->getClientOriginalName(),
                    'evidence_path' => $evidencePath,
                    'evidence_mime_type' => $evidence?->getMimeType(),
                    'evidence_size' => $evidence?->getSize() ?: 0,
                    'status' => $validated['response_type'] === 'confirmed' ? 'confirmed' : 'open',
                    'responded_at' => now(),
                ]);
                app(RecipientBenefitEntitlementService::class)->syncRecipientResponse($response);
                if ($response->response_type === 'issue') {
                    app(BenefitDeliveryReportService::class)->importReceipt($request->user(), $response);
                }

                return $response;
            });
        } catch (Throwable $error) {
            if ($evidencePath) {
                Storage::disk('local')->delete($evidencePath);
            }

            throw $error;
        }

        $application = $record->application;
        $programTitle = $record->release?->scholarship?->title ?? 'Scholarship program';
        $isIssue = $response->response_type === 'issue';
        PortalNotification::create([
            'user_id' => $record->release?->scholarship?->provider_id,
            'type' => $isIssue ? 'benefit_receipt_issue' : 'benefit_receipt_confirmed',
            'title' => $isIssue ? 'Recipient reported a release issue' : 'Recipient confirmed benefit receipt',
            'message' => $isIssue
                ? "{$request->user()->name} reported an issue with {$record->release?->title} for {$programTitle}."
                : "{$request->user()->name} confirmed receipt of {$record->release?->title} for {$programTitle}.",
            'action_url' => route('provider.monitoring.releases', $record->release?->scholarship_id, false),
        ]);

        ActivityLog::record(
            $request->user(),
            $isIssue ? 'benefit_receipt_issue_reported' : 'benefit_receipt_confirmed',
            $isIssue
                ? "{$request->user()->name} reported a benefit release issue."
                : "{$request->user()->name} confirmed a benefit release receipt.",
            $request,
            [
                'application_id' => $record->scholarship_application_id,
                'benefit_release_record_id' => $record->id,
                'benefit_receipt_response_id' => $response->id,
            ],
        );

        $freshApplication = $application->fresh()->load([
            'documents',
            'schedules',
            'statusHistories.actor',
            'scholarship.provider.providerProfile',
            'scholarship.events',
        ]);

        return response()->json([
            'message' => $isIssue
                ? 'Your issue was sent to the provider for review.'
                : 'Your benefit receipt was confirmed.',
            'application' => $this->applicationPayload($freshApplication),
        ], 201);
    }

    public function viewRecipientBenefitReceiptResponseFile(
        Request $request,
        RecipientBenefitReceiptResponse $response,
        string $kind,
    ) {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($response->applicant_id === $request->user()->id, 403);

        $isResolutionProof = $kind === 'resolution-proof';
        $path = $isResolutionProof ? $response->resolution_proof_path : $response->evidence_path;
        $name = $isResolutionProof ? $response->resolution_proof_original_name : $response->evidence_original_name;
        abort_unless(filled($path) && Storage::disk('local')->exists($path), 404);

        return Storage::disk('local')->response($path, $name, [
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    public function respondToRecipientSupportDecision(
        Request $request,
        RecipientSupportDecision $decision,
    ): JsonResponse {
        abort_unless($request->user()?->isApplicant(), 403);
        $decision->loadMissing('application.scholarship');
        abort_unless($decision->applicant_id === $request->user()->id, 403);

        $latestDecisionId = $decision->application?->supportDecisions()
            ->orderByDesc('decided_at')
            ->orderByDesc('id')
            ->value('id');
        if ((int) $latestDecisionId !== $decision->id) {
            throw ValidationException::withMessages([
                'response_type' => 'Only the latest support outcome can receive a response.',
            ]);
        }

        if ($decision->applicant_response_type) {
            throw ValidationException::withMessages([
                'response_type' => 'Your response to this support outcome is already recorded.',
            ]);
        }

        $validated = $request->validate([
            'response_type' => ['required', Rule::in(['acknowledged', 'clarification_requested', 'reconsideration_requested'])],
            'message' => [
                Rule::requiredIf($request->input('response_type') !== 'acknowledged'),
                'nullable',
                'string',
                'min:5',
                'max:1500',
            ],
            'attachment' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png', 'max:5120'],
            'confirmed' => ['accepted'],
        ]);

        if ($validated['response_type'] === 'reconsideration_requested' && $decision->decision !== 'terminated') {
            throw ValidationException::withMessages([
                'response_type' => 'Reconsideration is available only when support was ended early.',
            ]);
        }

        if ($decision->agreement_case_review_id && $validated['response_type'] !== 'acknowledged') {
            throw ValidationException::withMessages(['response_type' => 'This support decision has an independent case review. Open Case reviews and appeals to submit information or appeal; the provider cannot decide its own appeal.']);
        }

        $attachment = $request->file('attachment');
        $path = $attachment?->store("support-decisions/{$decision->scholarship_application_id}/applicant", 'local');
        $isAcknowledgement = $validated['response_type'] === 'acknowledged';

        try {
            $decision->update([
                'applicant_response_type' => $validated['response_type'],
                'applicant_response_message' => trim((string) ($validated['message'] ?? '')) ?: null,
                'applicant_response_original_name' => $attachment?->getClientOriginalName(),
                'applicant_response_path' => $path,
                'applicant_response_mime_type' => $attachment?->getMimeType(),
                'applicant_response_size' => $attachment?->getSize() ?: 0,
                'applicant_responded_at' => now(),
                'response_status' => $isAcknowledgement ? 'acknowledged' : 'open',
            ]);
        } catch (Throwable $error) {
            if ($path) {
                Storage::disk('local')->delete($path);
            }

            throw $error;
        }

        $application = $decision->application;
        $programTitle = $application?->scholarship?->title ?? 'Scholarship program';
        PortalNotification::create([
            'user_id' => $application?->scholarship?->provider_id,
            'type' => $isAcknowledgement ? 'support_decision_acknowledged' : 'support_decision_review_requested',
            'title' => $isAcknowledgement ? 'Support outcome acknowledged' : 'Recipient requested an outcome review',
            'message' => $isAcknowledgement
                ? "{$request->user()->name} acknowledged the support outcome for {$programTitle}."
                : "{$request->user()->name} requested {$validated['response_type']} for {$programTitle}.",
            'action_url' => route('provider.monitoring.outcomes', $application?->scholarship_id, false),
        ]);

        ActivityLog::record(
            $request->user(),
            'recipient_support_decision_response_recorded',
            "{$request->user()->name} recorded {$validated['response_type']} for a support outcome.",
            $request,
            [
                'application_id' => $decision->scholarship_application_id,
                'recipient_support_decision_id' => $decision->id,
                'response_type' => $validated['response_type'],
            ],
        );

        $freshApplication = $application->fresh()->load([
            'documents',
            'schedules',
            'statusHistories.actor',
            'scholarship.provider.providerProfile',
            'scholarship.events',
        ]);

        return response()->json([
            'message' => $isAcknowledgement
                ? 'Support outcome acknowledged.'
                : 'Your request was sent to the provider.',
            'application' => $this->applicationPayload($freshApplication),
        ], 201);
    }

    public function viewRecipientSupportDecisionFile(
        Request $request,
        RecipientSupportDecision $decision,
        string $kind,
    ) {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($decision->applicant_id === $request->user()->id, 403);

        [$path, $name] = match ($kind) {
            'applicant-response' => [$decision->applicant_response_path, $decision->applicant_response_original_name],
            'resolution-proof' => [$decision->resolution_proof_path, $decision->resolution_proof_original_name],
            default => [$decision->decision_document_path, $decision->decision_document_original_name],
        };
        abort_unless(filled($path) && Storage::disk('local')->exists($path), 404);

        return Storage::disk('local')->response($path, $name, [
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    public function withdrawApplication(Request $request, ScholarshipApplication $application): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($application->applicant_id === $request->user()->id, 403);

        $validated = $request->validate([
            'reason' => ['required', 'string', 'min:5', 'max:1000'],
        ]);
        $workflow = $this->workflowService->payload($application);
        $previousStatus = $application->status;

        if ($workflow['is_closed']) {
            throw ValidationException::withMessages([
                'reason' => 'This application can no longer be withdrawn online. Contact the provider if you need help.',
            ]);
        }

        $application = $this->workflowService->withdraw(
            $application,
            $request->user(),
            $validated['reason'],
        );

        $application->loadMissing('scholarship');
        PortalNotification::create([
            'user_id' => $application->scholarship->provider_id,
            'type' => 'application_withdrawn',
            'title' => 'Application withdrawn',
            'message' => "{$request->user()->name} withdrew their application for {$application->scholarship->title}.",
            'action_url' => route('provider.applications.show', $application, false),
        ]);
        $this->notifyAdditionalProviderReviewers(
            $application,
            'application_withdrawn',
            'Application withdrawn',
            "{$request->user()->name} withdrew their application for {$application->scholarship->title}.",
        );

        ActivityLog::record(
            $request->user(),
            'application_withdrawn',
            "{$request->user()->name} withdrew application #{$application->id}.",
            $request,
            ['application_id' => $application->id, 'previous_status' => $previousStatus],
        );
        ScholarshipFunnelEvent::record(
            $request->user(),
            'application_status_withdrawn',
            $application->scholarship,
            $application,
            'web',
            ['previous_status' => $previousStatus],
        );

        $freshApplication = $application->fresh()->load([
            'documents',
            'schedules',
            'statusHistories.actor',
            'scholarship.provider.providerProfile',
            'scholarship.events',
        ]);
        app(DecisionSupportService::class)->syncApplication($freshApplication, 'applicant_withdrawn');

        return response()->json([
            'message' => 'Application withdrawn. The provider has been notified.',
            'application' => $this->applicationPayload($freshApplication),
        ]);
    }

    public function respondToCorrection(Request $request, ScholarshipApplication $application): JsonResponse
    {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($application->applicant_id === $request->user()->id, 403);

        $validated = $request->validate([
            'response' => ['required', 'string', 'min:3', 'max:1500'],
        ]);

        $application = $this->workflowService->submitCorrection(
            $application,
            $validated['response'],
        );
        $application->loadMissing('scholarship');

        $correctionMessage = "{$request->user()->name} responded to the correction request for {$application->scholarship->title}.";
        PortalNotification::create([
            'user_id' => $application->scholarship->provider_id,
            'type' => 'application_correction',
            'title' => 'Applicant submitted a correction',
            'message' => $correctionMessage,
            'action_url' => route('provider.applications.show', $application, false).'?section=decision',
        ]);
        $this->notifyAdditionalProviderReviewers(
            $application,
            'application_correction',
            'Applicant submitted a correction',
            $correctionMessage,
            'decision',
        );
        ActivityLog::record(
            $request->user(),
            'application_correction_submitted',
            "{$request->user()->name} submitted a correction for application #{$application->id}.",
            $request,
            ['application_id' => $application->id],
        );

        $freshApplication = $application->fresh()->load([
            'documents',
            'schedules',
            'statusHistories.actor',
            'scholarship.provider.providerProfile',
            'scholarship.events',
        ]);

        return response()->json([
            'message' => 'Correction sent to the provider for review.',
            'application' => $this->applicationPayload($freshApplication),
        ]);
    }

    public function acknowledgeApplicationSchedule(
        Request $request,
        ScholarshipApplication $application,
        ApplicationSchedule $schedule,
    ): JsonResponse {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($application->applicant_id === $request->user()->id, 403);
        abort_unless($schedule->scholarship_application_id === $application->id, 404);

        if (! ApplicationSchedulePayload::requiresApplicantAcknowledgment($schedule)) {
            return response()->json([
                'message' => 'Schedules are delivered through portal and email notifications and do not require applicant acknowledgment.',
            ], 422);
        }

        if ($schedule->status !== 'scheduled') {
            return response()->json([
                'message' => 'Only an active schedule can be acknowledged.',
            ], 422);
        }

        if ($schedule->applicant_acknowledged_at === null) {
            $schedule->update(['applicant_acknowledged_at' => now()]);
            $scheduleLabel = Str::of($schedule->type)->replace('_', ' ')->lower()->toString();

            ActivityLog::record(
                $request->user(),
                'application_schedule_acknowledged',
                "{$request->user()->name} acknowledged the {$scheduleLabel} schedule for application #{$application->id}.",
                $request,
                ['application_id' => $application->id, 'schedule_id' => $schedule->id],
            );

            if ($application->scholarship?->provider_id) {
                PortalNotification::create([
                    'user_id' => $application->scholarship->provider_id,
                    'type' => 'schedule_acknowledged',
                    'title' => ucfirst($scheduleLabel).' schedule acknowledged',
                    'message' => "{$request->user()->name} confirmed that they saw the {$scheduleLabel} schedule for {$application->scholarship->title}.",
                    'action_url' => route('provider.applications.show', $application, false),
                ]);
            }
        }

        $freshApplication = $application->fresh()->load([
            'applicant.studentProfile',
            'documents',
            'schedules',
            'statusHistories.actor',
            'scholarship.provider.providerProfile',
            'scholarship.events',
        ]);

        return response()->json([
            'message' => 'Schedule acknowledged. The provider can now see your confirmation.',
            'schedule' => ApplicationSchedulePayload::make($schedule->fresh()),
            'application' => $this->applicationPayload($freshApplication),
        ]);
    }

    public function acknowledgeStageActivity(
        Request $request,
        ScholarshipApplication $application,
        ApplicationStageAssignment $assignment,
        ApplicationStageOperationsService $operations,
    ): JsonResponse {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($application->applicant_id === $request->user()->id, 403);
        abort_unless($assignment->scholarship_application_id === $application->id, 404);

        $assignment = $operations->acknowledgeAssignment($assignment, $request->user());

        return response()->json([
            'message' => 'Activity acknowledged. The provider can now see your confirmation.',
            'activity' => ApplicantStageActivityPayload::make($assignment),
        ]);
    }

    private function ensureApplicant(Request $request): ?RedirectResponse
    {
        if (! $request->user()) {
            return redirect()->route('login');
        }

        if ($request->user()->isAdmin()) {
            return redirect()->route('admin.index');
        }

        if ($request->user()->isProvider()) {
            return redirect()->route('provider.index');
        }

        abort_unless($request->user()->isApplicant(), 403);

        return null;
    }

    private function publishedScholarships()
    {
        return Scholarship::query()
            ->with(['provider.providerProfile', 'events'])
            ->withCount(['bookmarks', 'applications'])
            ->discoverable()
            ->orderByRaw('deadline is null')
            ->orderBy('deadline')
            ->latest();
    }

    private function isPublicProvider(User $provider): bool
    {
        $provider->loadMissing('providerProfile');

        return $provider->isProvider()
            && ! $provider->isManagedAccount()
            && $provider->isActive()
            && $provider->hasVerifiedEmail()
            && $provider->providerProfile?->isVerified();
    }

    private function authorizeProviderPreview(Request $request, string $permission): void
    {
        $actor = $request->user();

        abort_unless($actor?->isProvider(), 403);
        abort_unless($actor->hasPortalPermission($permission), 403);
    }

    private function authorizeScholarshipPreview(Request $request, Scholarship $scholarship): void
    {
        $this->authorizeProviderPreview($request, 'manage_programs');
        abort_unless($request->user()->canAccessProviderProgram($scholarship), 403);
    }

    private function publicProviderPayload(User $provider, ?User $applicant = null): array
    {
        $profile = $provider->providerProfile;
        $programs = $provider->relationLoaded('providerScholarships')
            ? $provider->providerScholarships->values()
            : collect();

        return [
            'id' => $provider->id,
            'name' => $profile?->provider_name ?: $provider->name,
            'type' => $profile?->provider_type,
            'logo_url' => filled($profile?->logo_path)
                ? asset(ltrim($profile->logo_path, '/'))
                : null,
            'cover_url' => $profile?->coverImageUrl(),
            'mission' => $profile?->mission,
            'description' => $profile?->provider_description,
            'year_established' => $profile?->year_established,
            'service_area' => $profile?->service_area,
            'website' => $profile?->provider_website,
            'address' => $profile?->provider_address,
            'latitude' => $profile?->latitude,
            'longitude' => $profile?->longitude,
            'contact_email' => $profile?->provider_contact_email,
            'contact_number' => $profile?->provider_contact_number,
            'contact_department' => $profile?->contact_department,
            'office_hours' => $profile?->office_hours,
            'is_verified' => $profile?->isVerified() ?? false,
            'verification_label' => $profile?->isVerified()
                ? 'Verified organization'
                : 'Verification pending',
            'programs_count' => $programs->count(),
            'focus_areas' => $programs
                ->pluck('category')
                ->filter()
                ->unique()
                ->values(),
            'programs' => $applicant
                ? $programs
                    ->map(fn (Scholarship $scholarship) => $this->scholarshipPayload($scholarship, $applicant))
                    ->values()
                : [],
        ];
    }

    private function userPayload(Request $request): array
    {
        return $request->user()->loadMissing(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload();
    }

    private function applicantProfileStatePayload(User $user): array
    {
        $user = $user->fresh(['studentProfile']);

        return [
            'user' => $user->publicPayload(),
            'profile_readiness' => $user->applicantProfileReadiness(),
        ];
    }

    private function statsPayload(Request $request): array
    {
        return [
            'available_scholarships' => Scholarship::query()->discoverable()->count(),
            'applications' => ScholarshipApplication::query()->where('applicant_id', $request->user()->id)->count(),
            'saved' => ScholarshipBookmark::query()->where('user_id', $request->user()->id)->count(),
        ];
    }

    private function scholarshipPayload(Scholarship $scholarship, ?User $user = null): array
    {
        $scholarship->loadMissing('events');
        $selectionStages = ScholarshipSelectionPlan::normalize($scholarship->selection_stages);
        $match = $this->eligibilityMatch($scholarship, $user);
        $preparedDocuments = $this->preparedDocumentReadiness($scholarship, $user);
        $distanceKm = $this->distanceKm($user?->studentProfile, $scholarship);
        $saved = $user
            ? ScholarshipBookmark::query()
                ->where('scholarship_id', $scholarship->id)
                ->where('user_id', $user->id)
                ->exists()
            : false;
        $hasApplied = $user
            ? ScholarshipApplication::query()
                ->where('scholarship_id', $scholarship->id)
                ->where('applicant_id', $user->id)
                ->exists()
            : false;
        $profileComplete = $user ? (bool) $user->applicantProfileReadiness()['complete'] : false;
        $applicationCount = $scholarship->applicationCount();
        $applicationLimitReached = $scholarship->application_limit !== null
            && $applicationCount >= $scholarship->application_limit;
        $remainingApplicationCapacity = $scholarship->application_limit === null
            ? null
            : max(0, $scholarship->application_limit - $applicationCount);
        $isAcceptingApplications = $scholarship->isAcceptingApplications();

        return [
            'id' => $scholarship->id,
            'image_path' => $scholarship->image_path,
            'logo_url' => $scholarship->logoUrl(),
            'cover_image_url' => $scholarship->coverImageUrl(),
            'image_url' => $this->scholarshipLogoUrl($scholarship),
            'title' => $scholarship->title,
            'category' => $scholarship->category,
            'program_cycle' => $scholarship->program_cycle,
            'description' => $scholarship->description,
            'provider_objectives' => $scholarship->provider_objectives ?? [],
            'provider_objective_notes' => $scholarship->provider_objective_notes,
            'eligibility' => $scholarship->eligibility,
            'eligible_education_levels' => $scholarship->eligible_education_levels,
            'eligibility_rule_modes' => $scholarship->eligibilityRuleModes(),
            'education_eligibility_policy' => EducationEligibilityPolicy::normalize($scholarship->education_eligibility_policy),
            'eligible_courses' => $scholarship->eligible_courses,
            'eligible_school_types' => $scholarship->eligible_school_types,
            'eligible_year_levels' => $scholarship->eligible_year_levels,
            'eligible_locations' => $scholarship->eligible_locations,
            'income_requirement' => $scholarship->income_requirement,
            'exclude_current_scholarship_recipients' => (bool) $scholarship->exclude_current_scholarship_recipients,
            'location_name' => $scholarship->location_name,
            'location_address' => $scholarship->location_address,
            'latitude' => $scholarship->latitude,
            'longitude' => $scholarship->longitude,
            'map_url' => $this->mapUrl($scholarship),
            'embed_map_url' => $this->embedMapUrl($scholarship),
            'distance_km' => $distanceKm,
            'distance_label' => $distanceKm === null ? null : number_format($distanceKm, 1).' km away',
            'requirements' => $scholarship->requirements,
            'optional_requirements' => $scholarship->optional_requirements,
            'post_qualification_requirements' => $scholarship->post_qualification_requirements,
            'application_questions' => $scholarship->application_questions ?? [],
            'benefits' => $scholarship->benefitPayload(),
            'benefit_summary' => $scholarship->benefitSummary(),
            'award_amount' => $scholarship->award_amount,
            'minimum_gwa' => $scholarship->minimum_gwa,
            'minimum_grade_scale' => AcademicRequirement::normalizeScale($scholarship->minimum_grade_scale, $scholarship->minimum_gwa),
            'minimum_grade_label' => AcademicRequirement::requirementLabel($scholarship->minimum_gwa, $scholarship->minimum_grade_scale),
            'slots_available' => $scholarship->slots_available,
            'application_limit' => $scholarship->application_limit,
            'applications_count' => $applicationCount,
            'application_slots_remaining' => $remainingApplicationCapacity,
            'application_limit_reached' => $applicationLimitReached,
            'application_mode' => $scholarship->application_mode,
            'selection_stages' => $selectionStages,
            'program_events' => $scholarship->events
                ->where('status', 'scheduled')
                ->filter(fn ($event): bool => in_array($event->type, $selectionStages, true))
                ->sortBy('scheduled_at')
                ->map(fn ($event): array => [
                    'id' => $event->id,
                    'type' => $event->type,
                    'title' => $event->title,
                    'scheduled_at' => $event->scheduled_at?->toISOString(),
                    'scheduled_label' => $event->scheduled_at?->format('M d, Y h:i A'),
                    'mode' => $event->mode,
                    'venue' => $event->venue,
                    'location_address' => $event->location_address,
                    'status' => $event->status,
                ])
                ->values(),
            'renewal_policy' => $scholarship->renewal_policy,
            'return_service_contract' => $scholarship->return_service_contract,
            'other_contract_terms' => $scholarship->other_contract_terms,
            'recipient_agreement' => $scholarship->recipient_agreement,
            'contact_email' => $scholarship->contact_email,
            'contact_number' => $scholarship->contact_number,
            'application_opens_at' => $scholarship->application_opens_at?->format('M d, Y'),
            'application_opens_date' => $scholarship->application_opens_at?->format('Y-m-d'),
            'expected_results_at' => $scholarship->expected_results_at?->format('M d, Y'),
            'support_starts_at' => $scholarship->support_starts_at?->format('M d, Y'),
            'support_ends_at' => $scholarship->support_ends_at?->format('M d, Y'),
            'official_program_url' => $scholarship->official_program_url,
            'contact_person' => $scholarship->contact_person,
            'contact_department' => $scholarship->contact_department,
            'deadline' => $scholarship->deadline?->format('M d, Y'),
            'bookmarks_count' => $scholarship->bookmarks_count ?? $scholarship->bookmarks()->count(),
            'is_saved' => $saved,
            'has_applied' => $hasApplied,
            'is_accepting_applications' => $isAcceptingApplications,
            'can_start_application' => $isAcceptingApplications
                && $profileComplete
                && $user?->applicantAcademicVerificationStatus() === 'approved'
                && (bool) ($match['is_eligible'] ?? false)
                && ! $hasApplied,
            'eligibility_match' => $match,
            'preference_match' => $this->preferenceMatch($scholarship, $user),
            'prepared_documents' => $preparedDocuments,
            'eligibility_guide' => [
                'requires_gwa' => filled($scholarship->minimum_gwa),
                'minimum_gwa' => $scholarship->minimum_gwa,
                'minimum_grade_scale' => AcademicRequirement::normalizeScale($scholarship->minimum_grade_scale, $scholarship->minimum_gwa),
                'minimum_grade_label' => AcademicRequirement::requirementLabel($scholarship->minimum_gwa, $scholarship->minimum_grade_scale),
                'required_documents' => $scholarship->application_mode === 'provider_review'
                    ? 0
                    : count($this->documentRequirements($scholarship)),
                'prepared_documents' => $preparedDocuments['uploaded'],
                'note' => AcademicRequirement::requirementLabel($scholarship->minimum_gwa, $scholarship->minimum_grade_scale),
            ],
            'provider' => [
                'id' => $scholarship->provider?->id,
                'name' => $scholarship->provider?->provider_name ?? $scholarship->provider?->name,
                'type' => $scholarship->provider?->provider_type,
                'logo_url' => filled($scholarship->provider?->providerProfile?->logo_path)
                    ? asset(ltrim($scholarship->provider->providerProfile->logo_path, '/'))
                    : null,
                'cover_url' => $scholarship->provider?->providerProfile?->coverImageUrl(),
                'website' => $scholarship->provider?->provider_website,
                'description' => $scholarship->provider?->provider_description,
                'mission' => $scholarship->provider?->providerProfile?->mission,
                'year_established' => $scholarship->provider?->providerProfile?->year_established,
                'service_area' => $scholarship->provider?->providerProfile?->service_area,
                'contact_department' => $scholarship->provider?->providerProfile?->contact_department,
                'office_hours' => $scholarship->provider?->providerProfile?->office_hours,
            ],
        ];
    }

    private function scholarshipLogoUrl(Scholarship $scholarship): string
    {
        return $scholarship->logoUrl();
    }

    private function mapUrl(Scholarship $scholarship): ?string
    {
        if ($scholarship->latitude !== null && $scholarship->longitude !== null) {
            return "https://www.openstreetmap.org/?mlat={$scholarship->latitude}&mlon={$scholarship->longitude}#map=15/{$scholarship->latitude}/{$scholarship->longitude}";
        }

        $query = $scholarship->location_address ?: $scholarship->location_name;

        return filled($query)
            ? 'https://www.openstreetmap.org/search?query='.rawurlencode($query)
            : null;
    }

    private function embedMapUrl(Scholarship $scholarship): ?string
    {
        if ($scholarship->latitude !== null && $scholarship->longitude !== null) {
            return "https://www.openstreetmap.org/export/embed.html?marker={$scholarship->latitude},{$scholarship->longitude}&layer=mapnik";
        }

        return null;
    }

    private function distanceKm($profile, Scholarship $scholarship): ?float
    {
        if (
            $profile?->latitude === null
            || $profile?->longitude === null
            || $scholarship->latitude === null
            || $scholarship->longitude === null
        ) {
            return null;
        }

        $studentLatitude = deg2rad((float) $profile->latitude);
        $studentLongitude = deg2rad((float) $profile->longitude);
        $scholarshipLatitude = deg2rad((float) $scholarship->latitude);
        $scholarshipLongitude = deg2rad((float) $scholarship->longitude);

        $latitudeDelta = $scholarshipLatitude - $studentLatitude;
        $longitudeDelta = $scholarshipLongitude - $studentLongitude;
        $angle = (sin($latitudeDelta / 2) ** 2)
            + cos($studentLatitude) * cos($scholarshipLatitude) * (sin($longitudeDelta / 2) ** 2);
        $angle = min(1, max(0, $angle));

        return round(6371 * 2 * atan2(sqrt($angle), sqrt(1 - $angle)), 1);
    }

    private function applicationPayload(ScholarshipApplication $application): array
    {
        $workflow = $this->workflowService->payload($application);
        $decisionSupport = app(DecisionSupportService::class);
        $dss = $decisionSupport->scoreApplication($application);
        $readiness = $this->documentReadiness($application);
        $recipientAgreement = RecipientAgreement::payload($application);
        $recipientMonitoring = $this->recipientMonitoringPayload($application);
        $rubricReview = ReviewRubric::result(
            $application->review_rubric_snapshot ?: ($application->scholarship?->review_rubric ?? []),
            $application->rubric_scores ?? [],
        );
        $application->loadMissing(['schedules', 'stageAssignments.session', 'stageAssignments.attendance']);
        $application->scholarship?->loadMissing('events');
        $examStatuses = ['exam_qualified', 'exam_scheduled', 'exam_taken', 'exam_passed', 'exam_failed'];
        $exam = in_array($application->status, $examStatuses, true)
            && $application->scholarship
            && in_array('exam', ScholarshipSelectionPlan::normalize($application->scholarship->selection_stages), true)
                ? $this->examPayload($application->scholarship)
                : null;

        return [
            'id' => $application->id,
            'detail_url' => route('dashboard.applications.show', $application),
            'status' => $application->status,
            'application_state' => $workflow['application_state'],
            'workflow_stage' => $workflow['current_stage'],
            'final_outcome' => $workflow['final_outcome'],
            'workflow' => $workflow,
            'submission_version' => (int) data_get($application->submission_snapshot, 'version', 1),
            'document_checklist' => $application->document_checklist ?? [],
            'optional_document_checklist' => $application->optional_document_checklist
                ?? $this->eligibilityService->optionalDocumentRequirements($application->scholarship),
            'document_readiness' => $readiness,
            'eligibility_score' => $application->eligibility_score,
            'eligibility_breakdown' => $application->eligibility_breakdown,
            'documents' => $application->documents->map(fn (ApplicationDocument $document) => $this->documentPayload($document))->values(),
            'application_answers' => $application->application_answers ?? [],
            'notes' => $application->notes,
            'review_notes' => $application->review_notes,
            'correction_status' => $application->correction_status,
            'correction_message' => $application->correction_message,
            'correction_targets' => $application->correction_targets ?? [],
            'correction_response' => $application->correction_response,
            'correction_requested_at' => $application->correction_requested_at?->format('M d, Y h:i A'),
            'correction_responded_at' => $application->correction_responded_at?->format('M d, Y h:i A'),
            'correction_resolved_at' => $application->correction_resolved_at?->format('M d, Y h:i A'),
            'withdrawal_reason' => $application->withdrawal_reason,
            'withdrawn_at' => $application->withdrawn_at?->format('M d, Y h:i A'),
            'waitlist_position' => $application->waitlist_position,
            'waitlisted_at' => $application->waitlisted_at?->format('M d, Y h:i A'),
            'can_withdraw' => ! $workflow['is_closed'],
            'decision_reason' => $application->decision_reason,
            'awarded_amount' => $application->awarded_amount,
            'display_award_amount' => $application->awarded_amount ?? $application->scholarship?->award_amount,
            'award_amount_source' => $application->awarded_amount !== null
                ? 'application'
                : ($application->scholarship?->award_amount !== null ? 'program' : null),
            'outcome_notes' => $application->outcome_notes,
            'outcome_at' => $application->outcome_at?->format('M d, Y'),
            'distribution_scheduled_for' => $application->distribution_scheduled_for?->format('M d, Y'),
            'distribution_instructions' => $application->distribution_instructions,
            'recipient_agreement' => $recipientAgreement,
            'recipient_monitoring' => $recipientMonitoring,
            'requires_student_response' => $recipientAgreement['requires_response'] ?? false,
            'can_respond' => $recipientAgreement['can_respond'] ?? false,
            'pre_screening_handoff' => PreScreeningHandoffRecord::make($application, $workflow, $readiness, $dss),
            'formal_application_handoff' => $this->formalApplicationHandoffPayload($application),
            'schedules' => $application->schedules
                ->sortBy('scheduled_at')
                ->map(fn (ApplicationSchedule $schedule) => ApplicationSchedulePayload::make($schedule))
                ->values(),
            'selection_activities' => $application->stageAssignments
                ->sortBy(fn (ApplicationStageAssignment $assignment) => $assignment->session?->starts_at?->getTimestamp() ?? PHP_INT_MAX)
                ->map(fn (ApplicationStageAssignment $assignment) => ApplicantStageActivityPayload::make($assignment))
                ->filter()
                ->values(),
            'dss_score' => $dss['score'],
            'dss_recommendation' => $dss['recommendation'],
            'dss_breakdown' => $dss,
            'dss_explanation' => $decisionSupport->explainApplication($application, $dss),
            'rubric_review' => $rubricReview['is_complete'] ? $rubricReview : null,
            'rubric_scored_at' => $rubricReview['is_complete']
                ? $application->rubric_scored_at?->format('M d, Y h:i A')
                : null,
            'status_progress' => $decisionSupport->statusProgress($application),
            'timeline' => $this->timelinePayload($application),
            'submitted_at' => $application->submitted_at?->format('M d, Y h:i A'),
            'scholarship' => $application->scholarship
                ? $this->scholarshipPayload($application->scholarship, $application->applicant)
                : null,
            'exam' => $exam,
        ];
    }

    private function normalizeApplicationAnswers(Scholarship $scholarship, array $submittedAnswers): array
    {
        $answersByQuestion = collect($submittedAnswers)
            ->filter(fn (mixed $answer): bool => is_array($answer) && filled($answer['question_id'] ?? null))
            ->keyBy(fn (array $answer): string => (string) $answer['question_id']);
        $missingRequired = [];

        $answers = collect($scholarship->application_questions ?? [])
            ->filter(fn (mixed $question): bool => is_array($question) && filled($question['id'] ?? null) && filled($question['prompt'] ?? null))
            ->map(function (array $question) use ($answersByQuestion, &$missingRequired): array {
                $questionId = (string) $question['id'];
                $answer = trim((string) data_get($answersByQuestion->get($questionId), 'answer', ''));
                $required = (bool) ($question['required'] ?? false);

                if ($required && $answer === '') {
                    $missingRequired[] = (string) $question['prompt'];
                }

                return [
                    'question_id' => $questionId,
                    'prompt' => (string) $question['prompt'],
                    'required' => $required,
                    'answer' => $answer,
                ];
            })
            ->values()
            ->all();

        if ($missingRequired !== []) {
            throw ValidationException::withMessages([
                'application_answers' => 'Answer every required provider question before submitting.',
            ]);
        }

        return $answers;
    }

    private function examPayload(Scholarship $scholarship): array
    {
        $scholarship->loadMissing('events');
        $event = $scholarship->events->firstWhere('type', 'exam');

        return [
            'title' => $event?->title ?: "{$scholarship->title} exam",
            'assessment_type' => 'qualifying_exam',
            'image_url' => $this->scholarshipLogoUrl($scholarship),
            'description' => 'The scholarship provider conducts and grades this exam outside the portal.',
            'delivery_mode' => $event?->mode ?? 'provider_managed',
            'venue' => $event?->venue ?: $event?->location_address,
            'instructions' => $event?->instructions,
        ];
    }

    private function documentReadiness(ScholarshipApplication $application): array
    {
        return $this->eligibilityService->applicationDocumentReadiness($application);
    }

    private function formalApplicationHandoffPayload(ScholarshipApplication $application): ?array
    {
        $workflow = $this->workflowService->payload($application);
        $formalApplicationStatus = data_get(
            collect($workflow['steps'])->firstWhere('key', 'formal_application'),
            'status',
        );

        if (! in_array($formalApplicationStatus, ['current', 'passed'], true)) {
            return null;
        }

        $scholarship = $application->scholarship;

        if (! $scholarship) {
            return null;
        }

        return [
            'requirements' => $this->splitDocumentRequirements($scholarship->post_qualification_requirements),
            'mode' => $scholarship->handoff_mode ?: 'provider_contact',
            'instructions' => $scholarship->handoff_instructions,
            'deadline' => $scholarship->handoff_deadline?->format('M d, Y'),
            'location_name' => $scholarship->handoff_location_name,
            'location_address' => $scholarship->handoff_location_address,
            'latitude' => $scholarship->handoff_latitude,
            'longitude' => $scholarship->handoff_longitude,
            'map_url' => $scholarship->handoffMapUrl(),
            'url' => $scholarship->handoff_url,
            'contact_person' => $scholarship->contact_person,
            'contact_department' => $scholarship->contact_department,
            'contact_email' => $scholarship->contact_email,
            'contact_number' => $scholarship->contact_number,
            'notice' => 'This portal qualification allows you to continue with the provider. It is not a final scholarship award.',
        ];
    }

    private function documentRequirements(?Scholarship $scholarship): array
    {
        return $this->eligibilityService->documentRequirements($scholarship);
    }

    private function splitDocumentRequirements(?string $requirements): array
    {
        return $this->eligibilityService->splitDocumentRequirements($requirements);
    }

    private function documentLibraryOptions(): array
    {
        return [
            'Latest report card or grades',
            'Certificate of enrollment',
            'Recent school ID',
            'Proof of identity',
            'Proof of residence',
            'Proof of income',
            'Certificate of indigency',
            'Birth certificate',
            'Parent or guardian valid ID',
            'Transcript of records',
            'Good moral certificate',
            'Barangay certificate of residency',
            'Government-issued ID',
            'Recent 2x2 ID photo',
            'Admission or acceptance letter',
            'Other identity or school proof',
        ];
    }

    private function preparedDocumentReadiness(Scholarship $scholarship, ?User $user): array
    {
        return $this->eligibilityService->preparedDocumentReadiness($scholarship, $user);
    }

    private function ensureApplicationDocumentsEditable(
        ScholarshipApplication $application,
        ?ApplicationDocument $document = null,
        bool $allowRequestedReplacement = true,
    ): void {
        if ($this->workflowService->payload($application)['is_closed']) {
            throw ValidationException::withMessages([
                'document_file' => 'Application files are locked after the application is closed.',
            ]);
        }

        if ($application->correction_status === 'requested') {
            return;
        }

        if (in_array($application->status, ['submitted', 'under_review', 'qualified', 'shortlisted'], true)) {
            return;
        }

        if ($allowRequestedReplacement
            && $document
            && in_array($document->status, ['rejected', 'needs_replacement'], true)) {
            return;
        }

        throw ValidationException::withMessages([
            'document_file' => 'Application files are locked after the review stage. Contact the provider if a replacement is required.',
        ]);
    }

    private function attachPreparedDocumentsToApplication(
        User $user,
        ScholarshipApplication $application,
        array $confirmedDocuments,
        array $optionalDocuments,
        array &$copiedPaths,
    ): void {
        $application->loadMissing('scholarship');
        $requiredDocuments = $application->scholarship?->application_mode === 'provider_review'
            ? []
            : ($confirmedDocuments !== []
            ? collect($confirmedDocuments)->map(fn (string $document) => trim($document))->filter()->values()->all()
            : $this->documentRequirements($application->scholarship));
        $requirements = collect($requiredDocuments)
            ->merge($optionalDocuments)
            ->map(fn (string $document) => trim($document))
            ->filter()
            ->unique(fn (string $document) => str($document)->lower()->squish()->toString())
            ->values()
            ->all();

        if ($requirements === []) {
            return;
        }

        $preparedDocuments = $user->studentDocuments()
            ->whereIn('document_name', $requirements)
            ->get();

        foreach ($preparedDocuments as $studentDocument) {
            if (! Storage::disk('local')->exists($studentDocument->path)) {
                continue;
            }

            $extension = pathinfo($studentDocument->original_name, PATHINFO_EXTENSION);
            Storage::disk('local')->makeDirectory("application-documents/{$application->id}");
            $targetPath = 'application-documents/'.$application->id.'/'.(string) Str::uuid().($extension ? ".{$extension}" : '');

            if (! Storage::disk('local')->copy($studentDocument->path, $targetPath)) {
                throw new \RuntimeException("Unable to copy {$studentDocument->document_name} into the application.");
            }

            $copiedPaths[] = $targetPath;
            ApplicationDocument::query()->updateOrCreate([
                'scholarship_application_id' => $application->id,
                'document_name' => $studentDocument->document_name,
            ], [
                'uploaded_by' => $user->id,
                'original_name' => $studentDocument->original_name,
                'path' => $targetPath,
                'mime_type' => $studentDocument->mime_type,
                'size' => $studentDocument->size,
                'status' => 'pending',
                'review_notes' => null,
                'reviewed_by' => null,
                'reviewed_at' => null,
                'uploaded_at' => now(),
                'terms_accepted_at' => $application->terms_accepted_at ?? now(),
                'terms_version' => $application->terms_version ?? Terms::VERSION,
            ]);
        }
    }

    private function documentPayload(ApplicationDocument $document): array
    {
        return [
            'id' => $document->id,
            'document_name' => $document->document_name,
            'original_name' => $document->original_name,
            'size' => $document->size,
            'status' => $document->status,
            'review_notes' => $document->review_notes,
            'reviewed_at' => $document->reviewed_at?->format('M d, Y h:i A'),
            'uploaded_at' => $document->uploaded_at?->format('M d, Y h:i A'),
            'view_url' => route('documents.view', $document),
            'download_url' => route('documents.download', $document),
        ];
    }

    private function studentDocumentPayload(StudentDocument $document): array
    {
        return [
            'id' => $document->id,
            'document_name' => $document->document_name,
            'original_name' => $document->original_name,
            'size' => $document->size,
            'uploaded_at' => $document->uploaded_at?->format('M d, Y h:i A'),
            'view_url' => route('dashboard.student-documents.view', $document),
            'download_url' => route('dashboard.student-documents.download', $document),
        ];
    }

    private function applicantVerificationDocumentsPayload(User $user)
    {
        return $user->applicantVerificationDocuments()
            ->with('latestReviewEvent')
            ->latest('uploaded_at')
            ->get()
            ->map(fn (ApplicantVerificationDocument $document) => $this->applicantVerificationDocumentPayload($document))
            ->values();
    }

    private function applicantVerificationDocumentPayload(ApplicantVerificationDocument $document): array
    {
        return [
            'id' => $document->id,
            'document_type' => $document->document_type,
            'label' => ApplicantVerificationDocument::EVIDENCE_DETAILS[$document->document_type]['label'] ?? str($document->document_type)->headline()->toString(),
            'supports' => ApplicantVerificationDocument::EVIDENCE_DETAILS[$document->document_type]['supports'] ?? null,
            'original_name' => $document->original_name,
            'size' => $document->size,
            'status' => $document->status,
            'review_notes' => $document->review_notes,
            ...$document->reviewPayload(),
            'file_available' => Storage::disk('local')->exists($document->path),
            'review_context' => [
                'action' => $document->latestReviewEvent?->action,
                'changed_fields' => $document->latestReviewEvent?->changed_fields ?? [],
                'at' => $document->latestReviewEvent?->created_at?->toIso8601String(),
            ],
            'ocr_status' => $document->ocr_status ?? AcademicRecordOcrService::STATUS_NOT_REQUESTED,
            'ocr_provider' => $document->ocr_provider,
            'ocr_grade' => $document->ocr_grade,
            'ocr_grading_scale' => $document->ocr_grading_scale,
            'ocr_label' => $document->ocr_label,
            'ocr_message' => $document->ocr_message,
            'ocr_processed_at' => $document->ocr_processed_at?->format('M d, Y h:i A'),
            'uploaded_at' => $document->uploaded_at?->format('M d, Y h:i A'),
            'view_url' => route('dashboard.applicant-verification-documents.view', $document),
        ];
    }

    private function assertCurrentEvidenceRevision(?int $expected, ?ApplicantVerificationDocument $document): void
    {
        abort_if($expected !== null && $expected !== ($document?->revision ?? 0), 409,
            'This supporting record changed. Refresh your evidence before replacing, removing, or scanning it.');
    }

    private function ensureRecipientMonitoringAdjustmentAllowed(
        Request $request,
        ScholarshipApplication $application,
        RecipientMonitoringCycle $cycle,
        RecipientMonitoringCycleRequirement $requirement,
    ): void {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($application->applicant_id === $request->user()->id, 403);
        abort_unless($cycle->scholarship_id === $application->scholarship_id, 404);
        abort_unless($requirement->recipient_monitoring_cycle_id === $cycle->id, 404);

        $isSelected = $application->final_outcome === 'selected'
            || in_array($application->status, ['awarded', 'distribution_scheduled', 'disbursed', 'renewed'], true);
        if (! $isSelected || $application->student_response_status !== 'accepted') {
            throw ValidationException::withMessages([
                'adjustment_request' => 'Monitoring requests are available only to confirmed recipients.',
            ]);
        }

        if (! $cycle->allow_exception_requests) {
            throw ValidationException::withMessages([
                'adjustment_request' => 'This monitoring plan does not accept online extension or exception requests.',
            ]);
        }

        if ($cycle->status !== 'open'
            || now()->startOfDay()->isAfter($cycle->due_at->copy()->addDays($cycle->grace_period_days))) {
            throw ValidationException::withMessages([
                'adjustment_request' => 'The request window for this check-in has closed. Contact the provider directly.',
            ]);
        }

        $completed = RecipientMonitoringSubmission::query()
            ->where('recipient_monitoring_cycle_requirement_id', $requirement->id)
            ->where('scholarship_application_id', $application->id)
            ->whereIn('review_status', ['met', 'excused'])
            ->exists();
        if ($completed) {
            throw ValidationException::withMessages([
                'adjustment_request' => 'This requirement is already completed.',
            ]);
        }

        $hasPendingRequest = RecipientMonitoringAdjustmentRequest::query()
            ->where('recipient_monitoring_cycle_requirement_id', $requirement->id)
            ->where('scholarship_application_id', $application->id)
            ->where('status', 'pending')
            ->exists();
        if ($hasPendingRequest) {
            throw ValidationException::withMessages([
                'adjustment_request' => 'A request for this requirement is already waiting for provider review.',
            ]);
        }
    }

    private function ensureRecipientMonitoringSubmissionAllowed(
        Request $request,
        ScholarshipApplication $application,
        RecipientMonitoringCycle $cycle,
        ?RecipientMonitoringCycleRequirement $requirement = null,
    ): void {
        abort_unless($request->user()?->isApplicant(), 403);
        abort_unless($application->applicant_id === $request->user()->id, 403);
        abort_unless($cycle->scholarship_id === $application->scholarship_id, 404);
        abort_unless(! $requirement || $requirement->recipient_monitoring_cycle_id === $cycle->id, 404);

        if ($cycle->isInPerson()) {
            throw ValidationException::withMessages([
                $requirement ? 'supporting_record' : 'grade_record' => 'Bring the documents to the scheduled check-in. Online submissions are not accepted for this appointment.',
            ]);
        }

        if ($requirement && ! $requirement->requires_file) {
            throw ValidationException::withMessages([
                'supporting_record' => 'This requirement is recorded by the provider and does not accept an applicant upload.',
            ]);
        }

        $application->loadMissing('scholarship');
        $isSelected = $application->final_outcome === 'selected'
            || in_array($application->status, ['awarded', 'distribution_scheduled', 'disbursed', 'renewed', 'benefits_terminated'], true);

        if (! $isSelected) {
            throw ValidationException::withMessages([
                'grade_record' => 'Academic monitoring is available only to selected recipients.',
            ]);
        }

        if ($application->student_response_status !== 'accepted') {
            throw ValidationException::withMessages([
                'grade_record' => 'Accept the recipient agreement before submitting an academic progress record.',
            ]);
        }

        if ($application->status === 'benefits_terminated') {
            throw ValidationException::withMessages([
                'grade_record' => 'Online monitoring submissions are closed for this recipient record. Contact the provider for assistance.',
            ]);
        }

        $correctionRequested = RecipientMonitoringSubmission::query()
            ->where('recipient_monitoring_cycle_id', $cycle->id)
            ->where('scholarship_application_id', $application->id)
            ->when(
                $requirement,
                fn ($query) => $query->where('recipient_monitoring_cycle_requirement_id', $requirement->id),
                fn ($query) => $query->whereNull('recipient_monitoring_cycle_requirement_id'),
            )
            ->where('review_status', 'needs_correction')
            ->exists();
        $approvedDueAt = $requirement
            ? RecipientMonitoringAdjustmentRequest::query()
                ->where('recipient_monitoring_cycle_requirement_id', $requirement->id)
                ->where('scholarship_application_id', $application->id)
                ->where('request_type', 'extension')
                ->where('status', 'approved')
                ->whereNotNull('approved_due_at')
                ->max('approved_due_at')
            : null;
        $effectiveDueAt = $approvedDueAt
            ? CarbonImmutable::parse($approvedDueAt)
            : $cycle->due_at;

        if ($cycle->status !== 'open'
            || (! $correctionRequested && $cycle->opens_at && $cycle->opens_at->isAfter(now()->startOfDay()))
            || (! $correctionRequested && $effectiveDueAt && $effectiveDueAt->isBefore(now()->startOfDay()))) {
            throw ValidationException::withMessages([
                'grade_record' => 'This academic monitoring period is not currently accepting submissions.',
            ]);
        }
    }

    private function recipientMonitoringPayload(ScholarshipApplication $application): array
    {
        $isSelected = $application->final_outcome === 'selected'
            || in_array($application->status, ['awarded', 'distribution_scheduled', 'disbursed', 'renewed', 'benefits_terminated'], true);

        if (! $isSelected || ! $application->scholarship) {
            return [
                'eligible' => false,
                'check_ins' => [],
                'cycles' => [],
                'benefit_releases' => [],
                'support_decisions' => [],
                'support_status' => null,
                'pending_count' => 0,
            ];
        }

        $application->loadMissing([
            'monitoringSubmissions.requirement',
            'monitoringSubmissions.reviewer',
            'monitoringSubmissions.reviews.reviewer',
            'monitoringAdjustmentRequests.decider',
            'monitoringInterventions.creator',
            'benefitReleaseRecords.release.creator',
            'benefitReleaseRecords.recorder',
            'benefitReleaseRecords.receiptResponse.resolver',
            'supportDecisions.decider',
            'supportDecisions.resolver',
            'scholarship.monitoringCycles.requirements',
        ]);
        $agreementAccepted = $application->student_response_status === 'accepted';
        $latestSupportDecision = $application->supportDecisions->first();
        $benefitsActive = $application->status !== 'benefits_terminated'
            && ! in_array($latestSupportDecision?->decision, ['completed', 'terminated'], true);
        $supportStatus = $latestSupportDecision?->decision
            ?? ($application->status === 'benefits_terminated' ? 'terminated' : 'active');
        $monitoringCycles = $application->scholarship->monitoringCycles;
        $cycles = $monitoringCycles
            ->filter(fn (RecipientMonitoringCycle $cycle): bool => $cycle->requirements->isEmpty())
            ->whereIn('status', ['open', 'closed'])
            ->map(function (RecipientMonitoringCycle $cycle) use ($application, $agreementAccepted, $benefitsActive): array {
                $submission = $application->monitoringSubmissions
                    ->firstWhere('recipient_monitoring_cycle_id', $cycle->id);
                $isPastDue = $cycle->due_at?->isBefore(now()->startOfDay()) ?? false;
                $isNotOpenYet = $cycle->opens_at?->isAfter(now()->startOfDay()) ?? false;
                $correctionRequested = $submission?->review_status === 'needs_correction';
                $canSubmit = $agreementAccepted
                    && $benefitsActive
                    && $cycle->status === 'open'
                    && ($correctionRequested || (! $isPastDue && ! $isNotOpenYet));

                return [
                    'id' => $cycle->id,
                    'title' => $cycle->title,
                    'period_type' => $cycle->period_type,
                    'academic_period' => $cycle->academic_period,
                    'school_year' => $cycle->school_year,
                    'opens_at' => $cycle->opens_at?->format('Y-m-d'),
                    'opens_label' => $cycle->opens_at?->format('M d, Y'),
                    'due_at' => $cycle->due_at?->format('Y-m-d'),
                    'due_label' => $cycle->due_at?->format('M d, Y'),
                    'minimum_grade' => $cycle->minimum_grade,
                    'grading_scale' => $cycle->grading_scale,
                    'requirement_label' => AcademicRequirement::requirementLabel($cycle->minimum_grade, $cycle->grading_scale),
                    'instructions' => $cycle->instructions,
                    'status' => $correctionRequested
                        ? 'action_needed'
                        : ($isPastDue ? 'closed' : ($isNotOpenYet ? 'upcoming' : $cycle->status)),
                    'can_submit' => $canSubmit,
                    'correction_requested' => $correctionRequested,
                    'locked_reason' => $agreementAccepted
                        ? (! $benefitsActive
                            ? 'Monitoring is closed for this recipient record.'
                            : ($isPastDue
                                ? 'The submission deadline has passed.'
                                : ($isNotOpenYet ? 'This period is not open yet.' : null)))
                        : 'Accept the recipient agreement before uploading this record.',
                    'submission' => $submission
                        ? $this->applicantRecipientMonitoringSubmissionPayload($submission, $cycle)
                        : null,
                ];
            })
            ->values();
        $checkIns = $monitoringCycles
            ->filter(fn (RecipientMonitoringCycle $cycle): bool => $cycle->requirements->isNotEmpty())
            ->whereIn('status', ['open', 'closed'])
            ->map(fn (RecipientMonitoringCycle $cycle): array => $this->applicantMonitoringCheckInPayload(
                $cycle,
                $application,
                $agreementAccepted,
                $benefitsActive,
            ))
            ->values();
        $benefitReleases = $application->benefitReleaseRecords
            ->sortByDesc(fn (RecipientBenefitReleaseRecord $record) => $record->release?->release_at)
            ->map(fn (RecipientBenefitReleaseRecord $record): array => $this->applicantBenefitReleasePayload($record))
            ->values();

        return [
            'eligible' => true,
            'agreement_accepted' => $agreementAccepted,
            'academic_ocr' => $this->academicRecordOcrService->publicConfiguration(),
            'check_ins' => $checkIns,
            'cycles' => $cycles,
            'benefit_releases' => $benefitReleases,
            'support_status' => $supportStatus,
            'support_status_label' => match ($supportStatus) {
                'renewed' => 'Scholarship support renewed',
                'completed' => 'Scholarship program completed',
                'terminated' => 'Scholarship support ended early',
                default => 'Scholarship support active',
            },
            'support_decisions' => $application->supportDecisions
                ->map(fn (RecipientSupportDecision $decision): array => $this->applicantSupportDecisionPayload($decision))
                ->values(),
            'pending_count' => $checkIns->sum('pending_count') + $cycles
                ->filter(fn (array $cycle): bool => $cycle['can_submit']
                    && ($cycle['submission'] === null || $cycle['correction_requested']))
                ->count()
                + $benefitReleases->where('can_respond', true)->count()
                + ($latestSupportDecision && blank($latestSupportDecision->applicant_response_type) ? 1 : 0),
        ];
    }

    private function applicantMonitoringCheckInPayload(
        RecipientMonitoringCycle $cycle,
        ScholarshipApplication $application,
        bool $agreementAccepted,
        bool $benefitsActive,
    ): array {
        $caseService = app(RecipientMonitoringCaseService::class);
        $monitoringCase = $caseService->sync($cycle, $application);
        $cycleAdjustments = $application->monitoringAdjustmentRequests
            ->where('recipient_monitoring_cycle_id', $cycle->id)
            ->values();
        $cycleInterventions = $application->monitoringInterventions
            ->where('recipient_monitoring_cycle_id', $cycle->id)
            ->values();
        $monitoringCasePayload = $caseService->payload(
            $monitoringCase,
            $cycleAdjustments,
            $cycleInterventions,
            true,
            'applicant',
        );
        $isNotOpenYet = $cycle->opens_at?->isAfter(now()->startOfDay()) ?? false;
        $definitions = RecipientMonitoringRequirementType::definitions();
        $cycleSubmissions = $application->monitoringSubmissions
            ->where('recipient_monitoring_cycle_id', $cycle->id);
        $requirements = $cycle->requirements->map(function (
            RecipientMonitoringCycleRequirement $requirement,
        ) use (
            $application,
            $cycle,
            $cycleSubmissions,
            $agreementAccepted,
            $benefitsActive,
            $isNotOpenYet,
            $definitions,
        ): array {
            $submission = $cycleSubmissions
                ->firstWhere('recipient_monitoring_cycle_requirement_id', $requirement->id);
            $adjustments = $application->monitoringAdjustmentRequests
                ->where('recipient_monitoring_cycle_id', $cycle->id)
                ->where('recipient_monitoring_cycle_requirement_id', $requirement->id)
                ->sortByDesc('id');
            $latestAdjustment = $adjustments->first();
            $approvedExtension = $adjustments
                ->where('request_type', 'extension')
                ->where('status', 'approved')
                ->whereNotNull('approved_due_at')
                ->sortByDesc('approved_due_at')
                ->first();
            $effectiveDueAt = $approvedExtension?->approved_due_at ?? $cycle->due_at;
            $isRequirementPastDue = $effectiveDueAt?->isBefore(now()->startOfDay()) ?? false;
            $isWithinGracePeriod = $isRequirementPastDue
                && ! now()->startOfDay()->isAfter(
                    $effectiveDueAt->copy()->addDays($cycle->grace_period_days),
                );
            $correctionRequested = $submission?->review_status === 'needs_correction';
            $canSubmit = ! $cycle->isInPerson() && $requirement->requires_file
                && $agreementAccepted
                && $benefitsActive
                && $cycle->status === 'open'
                && ($correctionRequested || (! $isRequirementPastDue && ! $isNotOpenYet));
            $status = match (true) {
                $correctionRequested => 'action_needed',
                $submission?->review_status === 'met' => 'completed',
                $submission?->review_status === 'excused' => 'completed',
                $submission?->review_status === 'not_met' => 'not_met',
                $submission !== null => 'submitted',
                $latestAdjustment?->status === 'pending' => 'request_pending',
                $approvedExtension !== null => 'extension_approved',
                $cycle->isInPerson() => $requirement->requires_original_verification ? 'bring_document' : 'awaiting_provider',
                ! $requirement->requires_file => 'provider_recorded',
                $isNotOpenYet => 'upcoming',
                $isWithinGracePeriod && $cycle->allow_exception_requests => 'grace_period',
                $isRequirementPastDue => 'closed',
                default => 'open',
            };
            $definition = $definitions[$requirement->type] ?? [];

            return [
                'id' => $requirement->id,
                'type' => $requirement->type,
                'type_label' => $definition['label'] ?? Str::headline($requirement->type),
                'icon' => $definition['icon'] ?? 'fa-solid fa-list-check',
                'title' => $requirement->title,
                'description' => $requirement->description,
                'evidence_description' => $requirement->evidence_description,
                'required' => $requirement->required,
                'requires_file' => $requirement->requires_file,
                'requires_original_verification' => $requirement->requires_original_verification,
                'minimum_grade' => $requirement->minimum_grade !== null
                    ? (float) $requirement->minimum_grade
                    : null,
                'grading_scale' => $requirement->grading_scale,
                'requirement_label' => $requirement->type === RecipientMonitoringRequirementType::ACADEMIC_PROGRESS
                    ? AcademicRequirement::requirementLabel($requirement->minimum_grade, $requirement->grading_scale)
                    : null,
                'status' => $status,
                'status_label' => match ($status) {
                    'action_needed' => 'Replacement requested',
                    'completed' => 'Completed',
                    'not_met' => 'Provider follow-up',
                    'submitted' => 'Waiting for review',
                    'request_pending' => 'Request pending',
                    'extension_approved' => 'Extension approved',
                    'bring_document' => 'Bring to check-in',
                    'awaiting_provider' => 'Provider will record',
                    'provider_recorded' => 'Provider records this',
                    'upcoming' => 'Opens later',
                    'grace_period' => 'Request window open',
                    'closed' => 'Submission closed',
                    default => 'To submit',
                },
                'can_submit' => $canSubmit,
                'can_request_adjustment' => $cycle->allow_exception_requests
                    && $agreementAccepted
                    && $benefitsActive
                    && $cycle->status === 'open'
                    && ! in_array($submission?->review_status, ['met', 'excused'], true)
                    && $latestAdjustment?->status !== 'pending'
                    && ! now()->startOfDay()->isAfter($cycle->due_at->copy()->addDays($cycle->grace_period_days)),
                'correction_requested' => $correctionRequested,
                'effective_due_at' => $effectiveDueAt?->format('Y-m-d'),
                'effective_due_label' => $effectiveDueAt?->format('M d, Y'),
                'locked_reason' => $agreementAccepted
                    ? (! $benefitsActive
                        ? 'Monitoring is closed for this recipient record.'
                        : (! $requirement->requires_file
                            ? ($cycle->isInPerson() && $requirement->requires_original_verification
                                ? 'Bring this document to the appointment for the provider to check.'
                                : 'The provider records this item.')
                            : ($isRequirementPastDue
                                ? ($isWithinGracePeriod && $cycle->allow_exception_requests
                                    ? 'The deadline passed. You can request an extension or exception.'
                                    : 'The submission deadline has passed.')
                                : ($isNotOpenYet ? 'This check-in is not open yet.' : null))))
                    : 'Accept the recipient agreement before completing this requirement.',
                'adjustment_request' => $latestAdjustment
                    ? $this->applicantMonitoringAdjustmentPayload($latestAdjustment)
                    : null,
                'interventions' => $application->monitoringInterventions
                    ->where('recipient_monitoring_cycle_id', $cycle->id)
                    ->where('recipient_monitoring_cycle_requirement_id', $requirement->id)
                    ->sortByDesc('id')
                    ->map(fn (RecipientMonitoringIntervention $intervention): array => (
                        $this->applicantMonitoringInterventionPayload($intervention)
                    ))
                    ->values(),
                'submission' => $submission
                    ? $this->applicantRecipientMonitoringSubmissionPayload($submission, $cycle)
                    : null,
            ];
        })->values();
        $requiredUploads = $requirements->where('required', true)->where('requires_file', true);

        return [
            'id' => $cycle->id,
            'title' => $cycle->title,
            'period_label' => collect([$cycle->academic_period, $cycle->school_year])->filter()->implode(' - ')
                ?: Str::headline($cycle->period_type),
            'opens_at' => $cycle->opens_at?->format('Y-m-d'),
            'opens_label' => $cycle->opens_at?->format('M d, Y'),
            'due_at' => $cycle->due_at?->format('Y-m-d'),
            'due_label' => $cycle->due_at?->format('M d, Y'),
            'handoff' => $cycle->handoffDetails(),
            'instructions' => $cycle->instructions,
            'monitoring_plan_version' => $cycle->monitoring_plan_version,
            'allow_exception_requests' => $cycle->allow_exception_requests,
            'grace_period_days' => $cycle->grace_period_days,
            'monitoring_case' => $monitoringCasePayload,
            'case_status' => $monitoringCasePayload['status'],
            'due_status' => $monitoringCasePayload['due_status'],
            'effective_due_at' => $monitoringCasePayload['effective_due_at'],
            'effective_due_label' => $monitoringCasePayload['effective_due_label'],
            'next_action' => $monitoringCasePayload['next_action'],
            'status' => match ($monitoringCasePayload['due_status']) {
                'upcoming' => 'upcoming',
                'grace_period' => 'grace_period',
                'overdue' => $cycle->isInPerson() ? 'open' : 'closed',
                'closed' => in_array($cycle->status, ['closed', 'cancelled'], true)
                    ? $cycle->status
                    : 'closed',
                default => $cycle->status,
            },
            'requirements' => $requirements,
            'required_count' => $requiredUploads->count(),
            'submitted_count' => $requiredUploads->whereNotNull('submission')->count(),
            'pending_count' => $requiredUploads->filter(fn (array $requirement): bool => (
                $requirement['can_submit']
                && ($requirement['submission'] === null || $requirement['correction_requested'])
            ))->count(),
        ];
    }

    private function applicantMonitoringAdjustmentPayload(
        RecipientMonitoringAdjustmentRequest $adjustment,
    ): array {
        return [
            'id' => $adjustment->id,
            'request_type' => $adjustment->request_type,
            'request_type_label' => $adjustment->request_type === 'extension' ? 'Extension request' : 'Exception request',
            'reason_category' => $adjustment->reason_category,
            'reason_label' => Str::headline($adjustment->reason_category),
            'explanation' => $adjustment->explanation,
            'requested_due_at' => $adjustment->requested_due_at?->format('Y-m-d'),
            'requested_due_label' => $adjustment->requested_due_at?->format('M d, Y'),
            'status' => $adjustment->status,
            'status_label' => match ($adjustment->status) {
                'approved' => 'Approved',
                'declined' => 'Declined',
                default => 'Waiting for provider',
            },
            'decision_notes' => $adjustment->decision_notes,
            'approved_due_at' => $adjustment->approved_due_at?->format('Y-m-d'),
            'approved_due_label' => $adjustment->approved_due_at?->format('M d, Y'),
            'decided_by' => $adjustment->decider?->name,
            'decided_at' => $adjustment->decided_at?->format('M d, Y h:i A'),
            'submitted_at' => $adjustment->created_at?->format('M d, Y h:i A'),
            'attachment' => filled($adjustment->attachment_path) ? [
                'original_name' => $adjustment->attachment_original_name,
                'size' => $adjustment->attachment_size,
                'view_url' => route('dashboard.monitoring-adjustment-requests.attachment', $adjustment, false),
            ] : null,
        ];
    }

    private function applicantMonitoringInterventionPayload(
        RecipientMonitoringIntervention $intervention,
    ): array {
        return [
            'id' => $intervention->id,
            'type' => $intervention->type,
            'type_label' => match ($intervention->type) {
                'reminder' => 'Reminder',
                'consultation' => 'Consultation',
                'support_plan' => 'Support plan',
                'warning' => 'Formal warning',
                default => Str::headline($intervention->type),
            },
            'summary' => $intervention->summary,
            'action_required' => $intervention->action_required,
            'follow_up_on' => $intervention->follow_up_on?->format('Y-m-d'),
            'follow_up_label' => $intervention->follow_up_on?->format('M d, Y'),
            'status' => $intervention->status,
            'status_label' => $intervention->status === 'completed' ? 'Completed' : 'Open',
            'completion_notes' => $intervention->completion_notes,
            'completed_at' => $intervention->completed_at?->format('M d, Y h:i A'),
            'created_by' => $intervention->creator?->name,
            'created_at' => $intervention->created_at?->format('M d, Y h:i A'),
        ];
    }

    private function applicantBenefitReleasePayload(RecipientBenefitReleaseRecord $record): array
    {
        $record->loadMissing(['allocations.entitlement', 'receiptResponse.resolver']);
        $release = $record->release;
        $response = $record->receiptResponse;
        $deliveryReportOpen = app(BenefitDeliveryReportService::class)->openForRecord($record)->exists();
        $lifecycleStatus = match (true) {
            $deliveryReportOpen => 'issue_open',
            $response?->recipient_resolution_confirmed_at !== null => 'fulfilled',
            $response?->status === 'confirmed' => 'fulfilled',
            $response?->status === 'open' => 'issue_open',
            $response?->status === 'resolved' => 'resolved',
            $record->status === 'released' => 'confirmation_needed',
            default => $record->status,
        };

        return [
            'id' => $release?->id,
            'record_id' => $record->id,
            'title' => $release?->title,
            'release_at' => $release?->release_at?->format('Y-m-d\TH:i'),
            'release_label' => $release?->release_at?->format('M d, Y h:i A'),
            'benefit_description' => $release?->benefit_description,
            'amount' => $release?->amount,
            'amount_label' => $release?->amount !== null ? 'PHP '.number_format((float) $release->amount, 2) : null,
            'release_method' => $release?->release_method,
            'release_method_label' => match ($release?->release_method) {
                'bank_transfer' => 'Bank transfer',
                'e_wallet' => 'E-wallet',
                'other' => 'Other arrangement',
                default => 'In person',
            },
            'location' => $release?->location,
            'latitude' => $release?->latitude,
            'longitude' => $release?->longitude,
            'instructions' => $release?->instructions,
            'requires_original_verification' => (bool) $release?->requires_original_verification,
            'status' => $record->status,
            'lifecycle_status' => $lifecycleStatus,
            'status_label' => match ($lifecycleStatus) {
                'fulfilled' => 'Receipt confirmed',
                'issue_open' => 'Provider review needed',
                'resolved' => 'Issue resolved',
                'confirmation_needed' => 'Confirm receipt',
                'prepared' => 'Prepared for release',
                'missed' => 'Appointment missed',
                'withheld' => 'Release withheld',
                default => 'Scheduled',
            },
            'originals_verified' => $record->originals_verified,
            'notes' => $record->notes,
            'recorded_by' => $record->recorder?->name,
            'recorded_at' => $record->recorded_at?->format('M d, Y h:i A'),
            'released_at' => $record->released_at?->format('M d, Y h:i A'),
            'can_respond' => $record->status === 'released' && $response === null && ! $deliveryReportOpen,
            'benefits' => $record->allocations->map(fn ($allocation): array => [
                'benefit_id' => $allocation->entitlement?->scholarship_benefit_id,
                'title' => $allocation->entitlement?->title,
                'frequency' => $allocation->entitlement?->frequency,
                'status' => $allocation->status,
                'entitlement_status' => $allocation->entitlement?->status,
            ])->values(),
            'receipt_response' => $response ? [
                'id' => $response->id,
                'response_type' => $response->response_type,
                'response_label' => $response->response_type === 'confirmed' ? 'Receipt confirmed' : 'Issue reported',
                'status' => $response->status,
                'status_label' => match ($response->status) {
                    'confirmed' => 'Confirmed',
                    'resolved' => 'Resolved',
                    default => 'Provider review needed',
                },
                'received_on' => $response->received_on?->format('Y-m-d'),
                'received_label' => $response->received_on?->format('M d, Y'),
                'recipient_note' => $response->recipient_note,
                'issue_type' => $response->issue_type,
                'issue_type_label' => $response->issue_type ? Str::headline($response->issue_type) : null,
                'issue_details' => $response->issue_details,
                'responded_at' => $response->responded_at?->format('M d, Y h:i A'),
                'resolution_outcome' => $response->resolution_outcome,
                'resolution_outcome_label' => $response->resolution_outcome ? Str::headline($response->resolution_outcome) : null,
                'resolution_notes' => $response->resolution_notes,
                'resolved_by' => $response->resolver?->name,
                'resolved_at' => $response->resolved_at?->format('M d, Y h:i A'),
                'evidence' => $response->evidence_path ? [
                    'original_name' => $response->evidence_original_name,
                    'size' => $response->evidence_size,
                    'view_url' => route('dashboard.benefit-receipt-responses.file', [$response, 'kind' => 'evidence'], false),
                ] : null,
                'resolution_proof' => $response->resolution_proof_path ? [
                    'original_name' => $response->resolution_proof_original_name,
                    'size' => $response->resolution_proof_size,
                    'view_url' => route('dashboard.benefit-receipt-responses.file', [$response, 'kind' => 'resolution-proof'], false),
                ] : null,
            ] : null,
            'receipt' => $record->receipt_path ? [
                'id' => $record->id,
                'original_name' => $record->receipt_original_name,
                'size' => $record->receipt_size,
                'view_url' => route('dashboard.benefit-release-records.receipt', $record, false),
            ] : null,
        ];
    }

    private function applicantSupportDecisionPayload(RecipientSupportDecision $decision): array
    {
        $decision->loadMissing(['decider', 'resolver']);

        return [
            'id' => $decision->id,
            'decision' => $decision->decision,
            'decision_label' => match ($decision->decision) {
                'renewed' => 'Support renewed',
                'completed' => 'Program completed',
                'terminated' => 'Support ended early',
                default => Str::headline($decision->decision),
            },
            'reason_category' => $decision->reason_category,
            'reason_category_label' => $decision->reason_category ? Str::headline($decision->reason_category) : null,
            'effective_label' => $decision->effective_on?->format('M d, Y'),
            'effective_on' => $decision->effective_on?->toDateString(),
            'support_ends_label' => $decision->support_ends_on?->format('M d, Y'),
            'next_review_label' => $decision->next_review_on?->format('M d, Y'),
            'notice_given_label' => $decision->notice_given_on?->format('M d, Y'),
            'reason' => $decision->reason,
            'next_period_terms' => $decision->next_period_terms,
            'decided_by' => $decision->decider?->name,
            'decided_at' => $decision->decided_at?->format('M d, Y h:i A'),
            'decided_at_iso' => $decision->decided_at?->toIso8601String(),
            'case_review_url' => $decision->agreementReview ? route('dashboard.recipient-cases.show', $decision->agreementReview->recipient_agreement_case_id, false) : null,
            'can_respond' => blank($decision->applicant_response_type),
            'applicant_response_type' => $decision->applicant_response_type,
            'applicant_response_label' => match ($decision->applicant_response_type) {
                'acknowledged' => 'Acknowledged',
                'clarification_requested' => 'Clarification requested',
                'reconsideration_requested' => 'Reconsideration requested',
                default => null,
            },
            'applicant_response_message' => $decision->applicant_response_message,
            'applicant_responded_at' => $decision->applicant_responded_at?->format('M d, Y h:i A'),
            'response_status' => $decision->response_status,
            'response_status_label' => match ($decision->response_status) {
                'acknowledged' => 'Acknowledged',
                'open' => 'Provider review needed',
                'resolved' => 'Resolved',
                default => 'Response needed',
            },
            'resolution_outcome' => $decision->resolution_outcome,
            'resolution_outcome_label' => $decision->resolution_outcome ? Str::headline($decision->resolution_outcome) : null,
            'resolution_notes' => $decision->resolution_notes,
            'resolved_by' => $decision->resolver?->name,
            'resolved_at' => $decision->resolved_at?->format('M d, Y h:i A'),
            'decision_document' => $decision->decision_document_path ? [
                'original_name' => $decision->decision_document_original_name,
                'size' => $decision->decision_document_size,
                'view_url' => route('dashboard.support-decisions.file', [$decision, 'kind' => 'decision-document'], false),
            ] : null,
            'applicant_response_file' => $decision->applicant_response_path ? [
                'original_name' => $decision->applicant_response_original_name,
                'size' => $decision->applicant_response_size,
                'view_url' => route('dashboard.support-decisions.file', [$decision, 'kind' => 'applicant-response'], false),
            ] : null,
            'resolution_proof' => $decision->resolution_proof_path ? [
                'original_name' => $decision->resolution_proof_original_name,
                'size' => $decision->resolution_proof_size,
                'view_url' => route('dashboard.support-decisions.file', [$decision, 'kind' => 'resolution-proof'], false),
            ] : null,
        ];
    }

    private function applicantRecipientMonitoringSubmissionPayload(
        RecipientMonitoringSubmission $submission,
        RecipientMonitoringCycle $cycle,
    ): array {
        $submission->loadMissing(['requirement', 'reviewer', 'reviews.reviewer']);
        $requirement = $submission->requirement;
        $grade = $submission->grade_source === 'applicant_manual'
            ? $submission->reported_grade
            : ($submission->ocr_grade ?? $submission->reported_grade);
        $scale = $submission->grade_source === 'applicant_manual'
            ? $submission->reported_grading_scale
            : ($submission->ocr_grading_scale ?? $submission->reported_grading_scale);
        $manualStatuses = [
            AcademicRecordOcrService::STATUS_NOT_REQUESTED,
            AcademicRecordOcrService::STATUS_NEEDS_REVIEW,
            AcademicRecordOcrService::STATUS_FAILED,
            AcademicRecordOcrService::STATUS_UNAVAILABLE,
        ];

        return [
            'id' => $submission->id,
            'requirement_id' => $submission->recipient_monitoring_cycle_requirement_id,
            'requirement_type' => $requirement?->type,
            'submission_source' => $submission->submission_source ?? 'applicant_upload',
            'has_file' => filled($submission->path),
            'original_name' => $submission->original_name,
            'size' => $submission->size,
            'submitted_at' => $submission->submitted_at?->format('M d, Y h:i A'),
            'ocr_status' => $submission->ocr_status,
            'ocr_provider' => $submission->ocr_provider,
            'ocr_grade' => $submission->ocr_grade,
            'ocr_grading_scale' => $submission->ocr_grading_scale,
            'ocr_label' => $submission->ocr_label,
            'ocr_message' => $submission->ocr_message,
            'grade' => $grade,
            'grading_scale' => $scale,
            'grade_source' => $submission->grade_source,
            'grade_label' => AcademicRequirement::studentLabel($grade, $scale),
            'review_status' => $submission->review_status ?? 'pending',
            'review_status_label' => match ($submission->review_status) {
                'met' => 'Requirement met',
                'not_met' => 'Requirement not met',
                'needs_correction' => 'Replacement requested',
                'excused' => 'Exception approved',
                default => 'Waiting for provider review',
            },
            'review_notes' => $submission->review_notes,
            'reviewed_by' => $submission->reviewer?->name,
            'reviewed_at' => $submission->reviewed_at?->format('M d, Y h:i A'),
            'reviews' => $submission->reviews->map(fn ($review): array => [
                'id' => $review->id,
                'decision' => $review->decision,
                'decision_label' => match ($review->decision) {
                    'met' => 'Requirement met',
                    'not_met' => 'Requirement not met',
                    'needs_correction' => 'Replacement requested',
                    'excused' => 'Exception approved',
                    default => Str::headline($review->decision),
                },
                'notes' => $review->notes,
                'reviewed_by' => $review->reviewer?->name,
                'decided_at' => $review->decided_at?->format('M d, Y h:i A'),
            ])->values(),
            'comparison' => ($requirement?->type ?? RecipientMonitoringRequirementType::ACADEMIC_PROGRESS)
                === RecipientMonitoringRequirementType::ACADEMIC_PROGRESS
                    ? AcademicRequirement::match(
                        $grade,
                        $scale,
                        $requirement?->minimum_grade ?? $cycle->minimum_grade,
                        $requirement?->grading_scale ?? $cycle->grading_scale,
                    )
                    : null,
            'manual_entry_allowed' => ($requirement?->type ?? RecipientMonitoringRequirementType::ACADEMIC_PROGRESS)
                === RecipientMonitoringRequirementType::ACADEMIC_PROGRESS
                && in_array($submission->ocr_status, $manualStatuses, true),
            'view_url' => filled($submission->path)
                ? route('dashboard.monitoring-submissions.view', $submission, false)
                : null,
        ];
    }

    private function processRecipientMonitoringScan(RecipientMonitoringSubmission $submission): array
    {
        if (! Storage::disk('local')->exists($submission->path)) {
            $result = [
                'status' => AcademicRecordOcrService::STATUS_FAILED,
                'provider' => 'ocr_space',
                'grade' => null,
                'grading_scale' => null,
                'label' => null,
                'message' => 'The stored grade record could not be opened for scanning.',
            ];
        } else {
            $result = $this->academicRecordOcrService->scan(
                Storage::disk('local')->get($submission->path),
                $submission->original_name,
                $submission->mime_type,
            );
        }

        $submission->update([
            'ocr_status' => $result['status'],
            'ocr_provider' => $result['provider'],
            'ocr_grade' => $result['grade'],
            'ocr_grading_scale' => $result['grading_scale'],
            'ocr_label' => $result['label'],
            'ocr_message' => $result['message'],
            'ocr_processed_at' => now(),
            'reported_grade' => $result['status'] === AcademicRecordOcrService::STATUS_SUCCEEDED
                ? $result['grade']
                : null,
            'reported_grading_scale' => $result['status'] === AcademicRecordOcrService::STATUS_SUCCEEDED
                ? $result['grading_scale']
                : null,
            'grade_source' => $result['status'] === AcademicRecordOcrService::STATUS_SUCCEEDED
                ? 'ocr'
                : null,
        ]);

        return $result;
    }

    private function processAcademicRecordScan(User $user, ApplicantVerificationDocument $document): array
    {
        if (! Storage::disk('local')->exists($document->path)) {
            $result = [
                'status' => AcademicRecordOcrService::STATUS_FAILED,
                'provider' => 'ocr_space',
                'grade' => null,
                'grading_scale' => null,
                'label' => null,
                'message' => 'The stored academic record could not be opened for scanning.',
            ];
        } else {
            $result = $this->academicRecordOcrService->scan(
                Storage::disk('local')->get($document->path),
                $document->original_name,
                $document->mime_type,
            );
        }

        $applied = DB::transaction(function () use ($user, $document, $result): bool {
            User::query()->lockForUpdate()->findOrFail($user->id);
            $current = $user->applicantVerificationDocuments()->lockForUpdate()->find($document->id);
            if (! $current || $current->revision !== $document->revision || $current->path !== $document->path) {
                return false;
            }
            $document = $current;
            $document->update([
                'ocr_status' => $result['status'],
                'ocr_provider' => $result['provider'],
                'ocr_grade' => $result['grade'],
                'ocr_grading_scale' => $result['grading_scale'],
                'ocr_label' => $result['label'],
                'ocr_message' => $result['message'],
                'ocr_processed_at' => now(),
            ]);

            if ($result['status'] !== AcademicRecordOcrService::STATUS_SUCCEEDED) {
                return true;
            }

            $user->studentProfile()->updateOrCreate(['user_id' => $user->id], [
                'gwa' => $result['grade'],
                'grading_scale' => $result['grading_scale'],
                'academic_result_source' => 'ocr',
                'academic_result_extracted_at' => now(),
                'verification_status' => 'pending',
                'verification_notes' => null,
                'verified_at' => null,
                'verified_by' => null,
            ]);

            return true;
        });

        if (! $applied) {
            $result['status'] = AcademicRecordOcrService::STATUS_NOT_REQUESTED;
            $result['message'] = 'The evidence changed during scanning. The old scan was not applied; reload the current record.';
        }

        $user->unsetRelation('studentProfile');

        return $result;
    }

    private function notifyAdditionalProviderReviewers(
        ScholarshipApplication $application,
        string $type,
        string $title,
        string $message,
        string $section = 'decision',
    ): void {
        $providerId = (int) $application->scholarship?->provider_id;
        $recipientIds = collect([
            $application->assigned_reviewer_id,
            $application->correction_requested_by,
        ])
            ->filter()
            ->map(fn (mixed $userId): int => (int) $userId)
            ->unique()
            ->reject(fn (int $userId): bool => $userId === $providerId);

        User::query()
            ->whereIn('id', $recipientIds)
            ->where('role', 'provider')
            ->where('parent_account_id', $providerId)
            ->pluck('id')
            ->each(fn (int $userId) => PortalNotification::create([
                'user_id' => $userId,
                'type' => $type,
                'title' => $title,
                'message' => $message,
                'action_url' => route('provider.applications.show', $application, false)."?section={$section}",
            ]));
    }

    private function timelinePayload(ScholarshipApplication $application): array
    {
        if ($application->statusHistories->isEmpty()) {
            return [[
                'id' => "submitted-{$application->id}",
                'from_status' => null,
                'to_status' => $application->status,
                'decision_reason' => $application->decision_reason,
                'review_notes' => 'Application record created.',
                'actor' => $application->applicant?->name ?? 'Applicant',
                'changed_at' => $application->submitted_at?->format('M d, Y h:i A'),
            ]];
        }

        return $application->statusHistories
            ->sortBy('changed_at')
            ->map(fn (ApplicationStatusHistory $history) => [
                'id' => $history->id,
                'from_status' => $history->from_status,
                'to_status' => $history->to_status,
                'decision_reason' => $history->decision_reason,
                'review_notes' => $history->review_notes,
                'actor' => $history->actor?->name ?? 'System',
                'changed_at' => $history->changed_at?->format('M d, Y h:i A'),
            ])
            ->values()
            ->all();
    }

    private function profileMatchSummary(User $user): array
    {
        $evaluations = $this->publishedScholarships()
            ->get()
            ->map(function (Scholarship $scholarship) use ($user): array {
                $match = $this->eligibilityMatch($scholarship, $user);
                $profileCriteria = collect($match['criteria'] ?? [])
                    ->reject(fn (array $criterion): bool => ($criterion['key'] ?? null) === 'documents')
                    ->filter(fn (array $criterion): bool => in_array($criterion['status'] ?? null, ['pass', 'fail', 'missing'], true))
                    ->values();
                $passed = $profileCriteria->where('status', 'pass')->count();
                $score = $profileCriteria->isEmpty()
                    ? 100
                    : (int) round(($passed / $profileCriteria->count()) * 100);
                $eligible = $this->applicationEligibilityBlockers($match) === [];

                return [
                    'eligible' => $eligible,
                    'score' => $score,
                    'criteria' => $profileCriteria->all(),
                    'preference' => $this->preferenceMatch($scholarship, $user),
                ];
            });
        $topGaps = $evaluations
            ->flatMap(fn (array $evaluation) => $evaluation['criteria'])
            ->filter(fn (array $criterion): bool => in_array($criterion['status'] ?? null, ['fail', 'missing'], true))
            ->groupBy(fn (array $criterion): string => (string) ($criterion['key'] ?? $criterion['label'] ?? 'other'))
            ->map(fn ($criteria): array => [
                'key' => $criteria->first()['key'] ?? null,
                'label' => $criteria->first()['label'] ?? 'Profile detail',
                'count' => $criteria->count(),
                'has_blocker' => $criteria->contains(fn (array $criterion): bool => EligibilityRulePolicy::isBlocking($criterion)),
            ])
            ->sortByDesc(fn (array $gap): int => ($gap['has_blocker'] ? 1000 : 0) + $gap['count'])
            ->take(4)
            ->values();

        return [
            'available_programs' => $evaluations->count(),
            'eligible_programs' => $evaluations->where('eligible', true)->count(),
            'strong_matches' => $evaluations->filter(fn (array $evaluation): bool => $evaluation['eligible'] && $evaluation['score'] >= 80)->count(),
            'needs_review' => $evaluations->filter(fn (array $evaluation): bool => $evaluation['eligible'] && $evaluation['score'] < 80)->count(),
            'blocked_programs' => $evaluations->where('eligible', false)->count(),
            'preference_matches' => $evaluations->filter(fn (array $evaluation): bool => ($evaluation['preference']['configured'] ?? false)
                && (int) ($evaluation['preference']['score'] ?? 0) >= 80)->count(),
            'top_gaps' => $topGaps,
            'calculated_at' => now()->toISOString(),
        ];
    }

    private function preferenceMatch(Scholarship $scholarship, ?User $user): array
    {
        $profile = $user?->studentProfile;

        if (! $profile) {
            return [
                'configured' => false,
                'score' => null,
                'label' => 'No preferences set',
                'criteria' => [],
            ];
        }

        $criteria = [];
        $categoryPreferences = $this->splitOptions($profile->preferred_categories);

        if ($categoryPreferences !== []) {
            $matchesCategory = filled($scholarship->category)
                && $this->matchesAnyOption($scholarship->category, $categoryPreferences);
            $criteria[] = [
                'key' => 'category',
                'label' => 'Scholarship type',
                'status' => $matchesCategory ? 'match' : 'miss',
                'note' => $matchesCategory ? 'Matches a preferred scholarship type.' : 'Outside the selected scholarship types.',
            ];
        }

        $locationPreferences = $this->splitOptions($profile->preferred_locations);

        if ($locationPreferences !== []) {
            $locationText = collect([
                $scholarship->eligible_locations,
                $scholarship->location_name,
                $scholarship->location_address,
            ])->filter()->implode(', ');
            $studentLocations = collect([$profile->city, $profile->province, $profile->region])->filter()->values()->all();
            $hasOpenLocation = collect($locationPreferences)->contains(fn (string $option): bool => $this->isOpenOption($option));
            $wantsOnline = collect($locationPreferences)->contains(fn (string $option): bool => str_contains(strtolower($option), 'online'));
            $wantsNearby = collect($locationPreferences)->contains(fn (string $option): bool => str_contains(strtolower($option), 'near my home'));
            $explicitLocations = collect($locationPreferences)
                ->reject(fn (string $option): bool => $this->isOpenOption($option)
                    || str_contains(strtolower($option), 'online')
                    || str_contains(strtolower($option), 'near my home'))
                ->values()
                ->all();
            $distanceKm = $this->distanceKm($profile, $scholarship);
            $matchesLocation = $hasOpenLocation
                || ($wantsOnline && in_array($scholarship->application_mode, ['online', 'hybrid'], true))
                || ($wantsNearby && (($distanceKm !== null && $distanceKm <= 50)
                    || (filled($locationText) && $studentLocations !== [] && $this->matchesAnyOption($locationText, $studentLocations))))
                || ($explicitLocations !== [] && filled($locationText) && $this->matchesAnyOption($locationText, $explicitLocations));

            $criteria[] = [
                'key' => 'location',
                'label' => 'Preferred location',
                'status' => $matchesLocation ? 'match' : 'miss',
                'note' => $matchesLocation ? 'Matches a selected location preference.' : 'Outside the selected location preferences.',
            ];
        }

        if ($profile->willing_to_relocate === 'no') {
            $distanceKm = $this->distanceKm($profile, $scholarship);

            if ($distanceKm !== null) {
                $fitsTravelPreference = $distanceKm <= 50 || in_array($scholarship->application_mode, ['online', 'hybrid'], true);
                $criteria[] = [
                    'key' => 'travel',
                    'label' => 'Travel preference',
                    'status' => $fitsTravelPreference ? 'match' : 'miss',
                    'note' => $fitsTravelPreference ? 'Fits the local-only preference.' : 'May require travel or relocation.',
                ];
            }
        }

        $matched = collect($criteria)->where('status', 'match')->count();
        $score = $criteria === [] ? null : (int) round(($matched / count($criteria)) * 100);

        return [
            'configured' => $criteria !== [],
            'score' => $score,
            'label' => match (true) {
                $score === null => 'No preferences set',
                $score >= 80 => 'Fits your preferences',
                $score >= 50 => 'Some preferences match',
                default => 'Outside your preferences',
            },
            'criteria' => $criteria,
        ];
    }

    private function eligibilityMatch(Scholarship $scholarship, ?User $user): array
    {
        return $this->eligibilityService->evaluate($scholarship, $user);
    }

    private function applicationEligibilityBlockers(array $eligibilityMatch): array
    {
        return $this->eligibilityService->blockers($eligibilityMatch);
    }

    private function splitOptions(?string $value): array
    {
        return $this->eligibilityService->splitOptions($value);
    }

    private function matchesAnyOption(string $value, array $options): bool
    {
        return $this->eligibilityService->matchesAnyOption($value, $options);
    }

    private function hasOpenOption(array $options): bool
    {
        return $this->eligibilityService->hasOpenOption($options);
    }

    private function isOpenOption(?string $option): bool
    {
        return $this->eligibilityService->isOpenOption($option);
    }

    private function syncApplicantReminders(User $user): void
    {
        $profileReadiness = $user->applicantProfileReadiness();

        if (! $profileReadiness['complete']) {
            PortalNotification::updateOrCreate([
                'user_id' => $user->id,
                'type' => 'profile_reminder',
                'title' => 'Complete your student profile',
            ], [
                'message' => "Your profile is {$profileReadiness['percent']}% complete. Complete it before submitting applications.",
                'action_url' => '/dashboard/profile',
            ]);
        }

        $applications = ScholarshipApplication::query()
            ->with(['documents', 'scholarship'])
            ->where('applicant_id', $user->id)
            ->whereIn('status', ['submitted', 'under_review', 'qualified', 'shortlisted', 'interview'])
            ->get();

        foreach ($applications as $application) {
            $documentReadiness = $this->documentReadiness($application);

            if (($documentReadiness['uploaded_percent'] ?? 100) >= 100) {
                continue;
            }

            $missing = collect($documentReadiness['missing'] ?? [])->take(3)->implode(', ');

            PortalNotification::updateOrCreate([
                'user_id' => $user->id,
                'type' => 'document_reminder',
                'title' => "Documents needed for {$application->scholarship?->title}",
            ], [
                'message' => $missing
                    ? "Upload or replace these requirements: {$missing}."
                    : 'Upload the remaining requirements for this application.',
                'action_url' => '/dashboard/applications',
            ]);
        }

        Scholarship::query()
            ->acceptingApplications()
            ->whereDate('deadline', '>=', now()->toDateString())
            ->whereDate('deadline', '<=', now()->addDays(7)->toDateString())
            ->whereHas('bookmarks', fn ($query) => $query->where('user_id', $user->id))
            ->whereDoesntHave('applications', fn ($query) => $query->where('applicant_id', $user->id))
            ->get()
            ->each(fn (Scholarship $scholarship) => PortalNotification::updateOrCreate([
                'user_id' => $user->id,
                'type' => 'deadline_reminder',
                'title' => "Deadline approaching: {$scholarship->title}",
            ], [
                'message' => "This saved scholarship is due on {$scholarship->deadline?->format('M d, Y')}.",
                'action_url' => "/dashboard/scholarships/{$scholarship->id}",
            ]));
    }
}

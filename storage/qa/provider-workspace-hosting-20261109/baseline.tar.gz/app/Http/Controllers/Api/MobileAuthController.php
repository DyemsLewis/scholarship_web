<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;
use App\Models\ApplicationDocument;
use App\Models\ApplicationSchedule;
use App\Models\ApplicationStatusHistory;
use App\Models\MobileApiToken;
use App\Models\PortalNotification;
use App\Models\Scholarship;
use App\Models\ScholarshipApplication;
use App\Models\ScholarshipBookmark;
use App\Models\ScholarshipFunnelEvent;
use App\Models\StudentDocument;
use App\Models\User;
use App\Rules\PhoneNumber;
use App\Services\ApplicationWorkflowService;
use App\Services\DecisionSupportService;
use App\Services\ScholarshipEligibilityService;
use App\Support\AcademicRequirement;
use App\Support\ApplicationSchedulePayload;
use App\Support\CompletedQualification;
use App\Support\EducationEligibilityPolicy;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Throwable;

class MobileAuthController extends Controller
{
    public function __construct(
        private readonly ScholarshipEligibilityService $eligibilityService,
        private readonly ApplicationWorkflowService $workflowService,
    ) {}

    public function register(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'middle_initial' => ['nullable', 'string', 'size:1', 'regex:/^[A-Za-z]$/'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'username' => ['required', 'string', 'min:4', 'max:255', 'regex:/^[A-Za-z0-9_.-]+$/', 'unique:users,username'],
            'contact_number' => ['required', 'string', 'max:30', new PhoneNumber],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        $middleInitial = filled($validated['middle_initial'] ?? null)
            ? strtoupper($validated['middle_initial'])
            : null;

        $user = User::create([
            'email' => $validated['email'],
            'username' => $validated['username'],
            'role' => 'applicant',
            'password' => $validated['password'],
        ]);

        $user->studentProfile()->create([
            'first_name' => $validated['first_name'],
            'last_name' => $validated['last_name'],
            'middle_initial' => $middleInitial,
            'contact_number' => $validated['contact_number'],
        ]);

        ActivityLog::record(
            $user,
            'mobile_registered',
            "{$user->name} registered from the mobile app.",
            $request,
        );

        return response()->json([
            'message' => 'Registration complete.',
            'token' => $this->createToken($user),
            'user' => $this->userPayload($user),
        ], 201);
    }

    public function login(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'login' => ['nullable', 'string', 'max:255', 'required_without:email'],
            'email' => ['nullable', 'string', 'max:255', 'required_without:login'],
            'password' => ['required', 'string'],
        ]);

        $login = trim((string) ($validated['login'] ?? $validated['email']));
        $loginField = filter_var($login, FILTER_VALIDATE_EMAIL) ? 'email' : 'username';
        $loginValue = $loginField === 'email' ? strtolower($login) : $login;
        $user = User::query()->where($loginField, $loginValue)->first();

        if (! $user || ! Hash::check($validated['password'], $user->password)) {
            ActivityLog::record(
                null,
                'mobile_login_failed',
                "Failed mobile login attempt for {$loginValue}.",
                $request,
                ['login_type' => $loginField, 'login' => $loginValue],
            );

            return response()->json([
                'message' => 'The username, email, or password is incorrect.',
            ], 422);
        }

        if ($user->role !== 'applicant') {
            return response()->json([
                'message' => 'Only applicant accounts can use the mobile app.',
            ], 403);
        }

        if ($user->isSuspended()) {
            ActivityLog::record(
                $user,
                'mobile_login_blocked_suspended',
                "{$user->name} attempted mobile login while suspended.",
                $request,
            );

            return response()->json([
                'message' => 'Your account is suspended. Contact an administrator for help.',
            ], 403);
        }

        if ($user->must_reset_password) {
            ActivityLog::record(
                $user,
                'mobile_login_blocked_password_reset_required',
                "{$user->name} attempted mobile login with a required password reset.",
                $request,
            );

            return response()->json([
                'message' => 'A password reset is required before you can use the mobile app.',
            ], 423);
        }

        ActivityLog::record(
            $user,
            'mobile_login',
            "{$user->name} logged in from the mobile app.",
            $request,
        );

        return response()->json([
            'message' => 'Login successful.',
            'token' => $this->createToken($user),
            'user' => $this->userPayload($user),
        ]);
    }

    public function profile(Request $request): JsonResponse
    {
        [$token, $user] = $this->resolveToken($request);

        if (! $token || ! $user) {
            return response()->json([
                'message' => 'Unauthenticated.',
            ], 401);
        }

        $token->forceFill(['last_used_at' => now()])->save();
        $scholarships = $this->publishedScholarships()->get();
        $applications = ScholarshipApplication::query()
            ->with(['documents', 'schedules', 'statusHistories.actor', 'scholarship.provider.providerProfile'])
            ->where('applicant_id', $user->id)
            ->latest('submitted_at')
            ->get();
        $applications->each(fn (ScholarshipApplication $application) => app(DecisionSupportService::class)->syncApplication($application));
        $this->syncApplicantReminders($user);

        return response()->json([
            'user' => $this->userPayload($user),
            'profile_readiness' => $user->applicantProfileReadiness(),
            'platform_active_scholarships' => $this->eligibilityService->activePlatformScholarships($user),
            'stats' => $this->statsPayload($user),
            'scholarships' => $scholarships->map(fn (Scholarship $scholarship) => $this->scholarshipPayload($scholarship, $user))->values(),
            'applications' => $applications->map(fn (ScholarshipApplication $application) => $this->applicationPayload($application))->values(),
            'notifications' => $this->notificationsPayload($user),
            'next_steps' => [
                'Complete your applicant profile for better match scores.',
                'Upload prepared documents before applying to faster-moving programs.',
                'Save scholarship programs you want to revisit.',
                'Use the application wizard to confirm requirements and submit applications.',
            ],
        ]);
    }

    public function updateProfile(Request $request): JsonResponse
    {
        [$token, $user] = $this->resolveToken($request);

        if (! $token || ! $user) {
            return response()->json([
                'message' => 'Unauthenticated.',
            ], 401);
        }

        $request->merge(CompletedQualification::input($request->all(), $user->studentProfile));
        $gradeMaximum = $request->input('grading_scale', $user->studentProfile?->grading_scale) === AcademicRequirement::SCALE_GRADE_POINT ? 5 : 100;

        $validated = $request->validate([
            ...CompletedQualification::rules($request->all()),
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'middle_initial' => ['nullable', 'string', 'size:1', 'regex:/^[A-Za-z]$/'],
            'suffix' => ['nullable', 'string', 'max:20'],
            'gender' => ['nullable', Rule::in(['female', 'male', 'non_binary', 'prefer_not_to_say'])],
            'contact_number' => ['required', 'string', 'max:30', new PhoneNumber],
            'account_managed_by' => ['nullable', Rule::in(['learner', 'parent_guardian', 'relative', 'school_representative', 'other'])],
            'citizenship_status' => ['nullable', Rule::in(['filipino', 'dual_filipino', 'other'])],
            'education_level' => ['nullable', 'string', 'max:100'],
            'school' => ['nullable', 'string', 'max:255'],
            'school_type' => ['nullable', 'string', 'max:100'],
            'learner_reference_number' => ['nullable', 'string', 'max:50', 'regex:/^[A-Za-z0-9_.-]*$/'],
            'course_or_strand' => ['nullable', 'string', 'max:255'],
            'year_level' => ['nullable', 'string', 'max:100'],
            'enrollment_status' => ['nullable', 'string', 'max:100'],
            'academic_year' => ['nullable', 'string', 'max:20'],
            'academic_term' => ['nullable', Rule::in(['full_year', 'first_grading_period', 'second_grading_period', 'third_grading_period', 'fourth_grading_period', 'first_semester', 'second_semester', 'third_term', 'summer_term', 'latest_completed_term', 'not_applicable'])],
            'gwa' => ['nullable', 'numeric', 'min:0', "max:{$gradeMaximum}"],
            'grading_scale' => ['nullable', Rule::in(AcademicRequirement::SCALES)],
            'income_bracket' => ['nullable', 'string', 'max:100'],
            'household_size' => ['nullable', 'integer', 'min:1', 'max:30'],
            'preferred_categories' => ['nullable', 'string', 'max:1000'],
            'preferred_locations' => ['nullable', 'string', 'max:1000'],
            'willing_to_relocate' => ['nullable', Rule::in(['yes', 'no', 'depends'])],
            'support_needs' => ['nullable', 'string', 'max:1500'],
            'current_scholarship_status' => ['required', Rule::in(['none', 'receiving', 'pending', 'completed'])],
            'current_scholarship_details' => ['nullable', 'required_if:current_scholarship_status,receiving,pending', 'string', 'max:1000'],
            'scholarship_goal' => ['nullable', 'string', 'max:1500'],
            'achievements' => ['nullable', 'string', 'max:1500'],
            'activities_and_responsibilities' => ['nullable', 'string', 'max:1500'],
            'address' => ['nullable', 'string', 'max:500'],
            'barangay' => ['nullable', 'string', 'max:255'],
            'city' => ['nullable', 'string', 'max:255'],
            'province' => ['nullable', 'string', 'max:255'],
            'region' => ['nullable', 'string', 'max:255'],
            'latitude' => ['nullable', 'numeric', 'between:-90,90', new \App\Rules\PhilippineLandPin],
            'longitude' => ['nullable', 'numeric', 'between:-180,180', new \App\Rules\PhilippineLandPin],
            'birthdate' => ['nullable', 'date', 'before_or_equal:'.now()->subYears(5)->toDateString(), 'after_or_equal:'.now()->subYears(100)->toDateString()],
            'guardian_name' => ['nullable', 'string', 'max:255'],
            'guardian_relationship' => ['nullable', 'string', 'max:100'],
            'guardian_contact' => ['nullable', 'string', 'max:30', new PhoneNumber],
            'guardian_email' => ['nullable', 'email', 'max:255'],
            'guardian_is_account_owner' => ['nullable', 'boolean'],
        ]);

        if (array_key_exists('grading_scale', $validated) && ! AcademicRequirement::requiresNumeric($validated['grading_scale'])) {
            $validated['gwa'] = null;
        }

        if (! in_array($validated['current_scholarship_status'] ?? null, ['receiving', 'pending'], true)) {
            $validated['current_scholarship_details'] = null;
        }

        $submittedAchievements = trim((string) ($validated['achievements'] ?? ''));
        $savedAchievements = trim((string) ($user->studentProfile?->achievements ?? ''));

        if ($submittedAchievements !== $savedAchievements
            && $submittedAchievements !== ''
            && ! $user->applicantVerificationDocuments()->where('document_type', 'achievement_evidence')->exists()) {
            throw ValidationException::withMessages([
                'achievements' => 'Upload achievement evidence from the applicant web profile before saving a new or changed achievement.',
            ]);
        }

        $profileValues = [
            ...$validated,
            'middle_initial' => filled($validated['middle_initial'] ?? null) ? strtoupper($validated['middle_initial']) : null,
            'guardian_is_account_owner' => (bool) ($validated['guardian_is_account_owner'] ?? false),
        ];
        $studentProfile = $user->studentProfile()->firstOrNew(['user_id' => $user->id]);
        $studentProfile->fill($profileValues);
        $verifiedFields = [
            ...CompletedQualification::FIELDS,
            'first_name', 'last_name', 'middle_initial', 'suffix', 'birthdate', 'citizenship_status',
            'income_bracket', 'household_size', 'guardian_name', 'guardian_relationship', 'account_managed_by',
            'address', 'barangay', 'city', 'province', 'region',
            'education_level',
            'school',
            'school_type',
            'learner_reference_number',
            'course_or_strand',
            'year_level',
            'enrollment_status',
            'academic_year',
            'academic_term',
            'gwa',
            'grading_scale',
            'achievements',
        ];
        $verifiedFields = array_filter($verifiedFields, fn (string $field): bool => ! in_array($field, ['first_name', 'last_name', 'middle_initial', 'suffix'], true)
            || strcasecmp(trim((string) $studentProfile->getOriginal($field)), trim((string) $studentProfile->getAttribute($field))) !== 0);
        $verificationReset = $studentProfile->verification_status === 'approved'
            && $studentProfile->isDirty($verifiedFields);

        if ($verificationReset) {
            $studentProfile->fill([
                'verification_status' => $user->applicantVerificationDocuments()
                    ->where('document_type', 'academic_record')
                    ->exists() ? 'pending' : 'unsubmitted',
                'verification_notes' => null,
                'verified_at' => null,
                'verified_by' => null,
            ]);
        }

        DB::transaction(function () use ($studentProfile, $user): void {
            User::query()->lockForUpdate()->findOrFail($user->id);
            $studentProfile->save();
        });

        $user->unsetRelation('studentProfile');

        if ($verificationReset) {
            User::query()
                ->where('role', 'admin')
                ->where('account_status', 'active')
                ->get()
                ->filter(fn (User $admin) => $admin->hasPortalPermission('manage_reviews'))
                ->each(fn (User $admin) => PortalNotification::create([
                    'user_id' => $admin->id,
                    'type' => 'applicant_profile_verification',
                    'title' => 'Verified profile details changed',
                    'message' => "{$user->name} changed verified profile information and needs another review.",
                    'action_url' => route('admin.applicants.review.show', $user, false),
                ]));
        }

        if ($user->hasCompleteApplicantProfile()) {
            ScholarshipFunnelEvent::record(
                $user,
                'profile_completed',
                source: 'mobile',
                metadata: ['education_level' => $user->studentProfile?->education_level],
                deduplicationKey: "profile_completed:{$user->id}",
            );
        }

        ScholarshipApplication::query()
            ->with(['applicant.studentProfile', 'documents', 'scholarship'])
            ->where('applicant_id', $user->id)
            ->get()
            ->each(fn (ScholarshipApplication $application) => app(DecisionSupportService::class)->syncApplication($application, 'mobile_profile_updated'));

        ActivityLog::record(
            $user,
            'mobile_profile_updated',
            "{$user->name} updated their profile from the mobile app.",
            $request,
            ['verification_reset' => $verificationReset],
        );

        $freshUser = $user->fresh();

        return response()->json([
            'message' => $verificationReset
                ? 'Verified profile details updated and returned for review.'
                : 'Applicant profile updated.',
            'user' => $this->userPayload($freshUser),
            'profile_readiness' => $freshUser->applicantProfileReadiness(),
            'platform_active_scholarships' => $this->eligibilityService->activePlatformScholarships($freshUser),
            'verification_reset' => $verificationReset,
        ]);
    }

    public function uploadProfilePhoto(Request $request): JsonResponse
    {
        [$token, $user] = $this->resolveToken($request);

        if (! $token || ! $user) {
            return response()->json(['message' => 'Unauthenticated.'], 401);
        }

        $validated = $request->validate([
            'profile_photo' => [
                'required',
                'image',
                'mimes:jpg,jpeg,png',
                'max:5120',
                'dimensions:min_width=300,min_height=300,max_width=4000,max_height=4000,ratio=1/1',
            ],
        ], [
            'profile_photo.dimensions' => 'Use a square 1x1 or 2x2-style photo between 300 x 300 and 4000 x 4000 pixels.',
        ]);

        $token->forceFill(['last_used_at' => now()])->save();
        $profile = $user->studentProfile()->firstOrCreate(['user_id' => $user->id]);
        $file = $validated['profile_photo'];
        $path = $file->store("profile-photos/{$user->id}", 'local');

        if (! is_string($path)) {
            throw ValidationException::withMessages([
                'profile_photo' => 'The applicant photo could not be stored. Please try again.',
            ]);
        }

        $oldPath = $profile->profile_photo_path;

        try {
            $profile->update([
                'profile_photo_path' => $path,
                'profile_photo_original_name' => $file->getClientOriginalName(),
                'profile_photo_mime_type' => $file->getMimeType(),
                'profile_photo_size' => $file->getSize() ?: 0,
                'profile_photo_updated_at' => now(),
            ]);
        } catch (Throwable $error) {
            Storage::disk('local')->delete($path);

            throw $error;
        }

        if ($oldPath && $oldPath !== $path) {
            Storage::disk('local')->delete($oldPath);
        }

        ActivityLog::record(
            $user,
            'mobile_applicant_profile_photo_updated',
            "{$user->name} updated their applicant profile photo from the mobile app.",
            $request,
        );

        $freshUser = $user->fresh();

        return response()->json([
            'message' => 'Applicant photo updated.',
            'user' => $this->userPayload($freshUser),
            'profile_readiness' => $freshUser->applicantProfileReadiness(),
        ]);
    }

    public function documents(Request $request): JsonResponse
    {
        [$token, $user] = $this->resolveToken($request);

        if (! $token || ! $user) {
            return response()->json([
                'message' => 'Unauthenticated.',
            ], 401);
        }

        $token->forceFill(['last_used_at' => now()])->save();
        $applications = ScholarshipApplication::query()
            ->with(['documents', 'schedules', 'statusHistories.actor', 'scholarship.provider.providerProfile'])
            ->where('applicant_id', $user->id)
            ->latest('submitted_at')
            ->get();
        $documents = $applications->flatMap(fn (ScholarshipApplication $application) => $application->documents);
        $studentDocuments = StudentDocument::query()
            ->where('user_id', $user->id)
            ->latest('uploaded_at')
            ->get();
        $this->syncApplicantReminders($user);

        return response()->json([
            'user' => $this->userPayload($user),
            'stats' => [
                'applications' => $applications->count(),
                'prepared' => $studentDocuments->count(),
                'uploaded' => $documents->count(),
                'accepted' => $documents->where('status', 'accepted')->count(),
                'pending' => $documents->where('status', 'pending')->count(),
                'needs_attention' => $documents->whereIn('status', ['rejected', 'needs_replacement'])->count(),
            ],
            'document_options' => $this->documentLibraryOptions($user),
            'prepared_documents' => $studentDocuments->map(fn (StudentDocument $document) => $this->studentDocumentPayload($document))->values(),
            'applications' => $applications->map(fn (ScholarshipApplication $application) => $this->applicationPayload($application))->values(),
        ]);
    }

    public function uploadPreparedDocument(Request $request): JsonResponse
    {
        [$token, $user] = $this->resolveToken($request);

        if (! $token || ! $user) {
            return response()->json([
                'message' => 'Unauthenticated.',
            ], 401);
        }

        $validated = $request->validate([
            'document_name' => ['required', 'string', 'max:255'],
            'document_file' => ['required', 'file', 'max:5120', 'mimes:pdf,jpg,jpeg,png,doc,docx'],
        ]);

        $documentName = trim($validated['document_name']);
        $file = $validated['document_file'];
        $existing = StudentDocument::query()
            ->where('user_id', $user->id)
            ->where('document_name', $documentName)
            ->first();

        if ($existing) {
            Storage::disk('local')->delete($existing->path);
        }

        $path = $file->store("student-documents/{$user->id}");
        $document = StudentDocument::query()->updateOrCreate([
            'user_id' => $user->id,
            'document_name' => $documentName,
        ], [
            'original_name' => $file->getClientOriginalName(),
            'path' => $path,
            'mime_type' => $file->getClientMimeType(),
            'size' => $file->getSize(),
            'uploaded_at' => now(),
        ]);

        ActivityLog::record(
            $user,
            'mobile_prepared_document_uploaded',
            "{$user->name} uploaded prepared document {$document->document_name} from mobile.",
            $request,
            ['student_document_id' => $document->id],
        );

        ScholarshipFunnelEvent::record(
            $user,
            'prepared_document_uploaded',
            source: 'mobile',
            metadata: [
                'student_document_id' => $document->id,
                'document_name' => $document->document_name,
                'replaced_existing' => $existing !== null,
            ],
        );

        return response()->json([
            'message' => 'Prepared document saved.',
            'document' => $this->studentDocumentPayload($document),
        ]);
    }

    public function deletePreparedDocument(Request $request, StudentDocument $document): JsonResponse
    {
        [$token, $user] = $this->resolveToken($request);

        if (! $token || ! $user) {
            return response()->json([
                'message' => 'Unauthenticated.',
            ], 401);
        }

        if ($document->user_id !== $user->id) {
            return response()->json([
                'message' => 'Document not found.',
            ], 404);
        }

        Storage::disk('local')->delete($document->path);
        $documentName = $document->document_name;
        $document->delete();

        ActivityLog::record(
            $user,
            'mobile_prepared_document_deleted',
            "{$user->name} removed prepared document {$documentName} from mobile.",
            $request,
        );

        ScholarshipFunnelEvent::record(
            $user,
            'prepared_document_deleted',
            source: 'mobile',
            metadata: ['document_name' => $documentName],
        );

        return response()->json([
            'message' => 'Prepared document removed.',
        ]);
    }

    public function storeApplication(Request $request): JsonResponse
    {
        [$token, $user] = $this->resolveToken($request);

        if (! $token || ! $user) {
            return response()->json([
                'message' => 'Unauthenticated.',
            ], 401);
        }

        if (! $user->hasVerifiedEmail()) {
            return response()->json([
                'message' => 'Verify your email address before submitting an application.',
                'verification_required' => true,
            ], 403);
        }

        $profileReadiness = $user->applicantProfileReadiness();

        if (! $profileReadiness['complete']) {
            return response()->json([
                'message' => 'Complete your student profile before applying.',
                'missing_fields' => $profileReadiness['missing'],
                'profile_readiness' => $profileReadiness,
            ], 422);
        }

        if (! $profileReadiness['verified']) {
            return response()->json([
                'message' => 'Your applicant profile must be verified before you can apply. Open Supporting Evidence in your profile to upload or review your verification records.',
                'profile_verification_required' => true,
                'profile_readiness' => $profileReadiness,
                'profile_url' => '/dashboard/profile?section=verification',
            ], 403);
        }

        $validated = $request->validate([
            'scholarship_id' => [
                'required',
                Rule::exists('scholarships', 'id')->where(fn ($query) => $query->where('status', 'published')),
            ],
            'document_checklist' => ['sometimes', 'array'],
            'document_checklist.*' => ['string', 'max:255'],
            'application_answers' => ['sometimes', 'array', 'max:5'],
            'application_answers.*.question_id' => ['required', 'string', 'max:80'],
            'application_answers.*.answer' => ['nullable', 'string', 'max:1500'],
            'notes' => ['nullable', 'string', 'max:1000'],
        ]);

        $alreadyApplied = ScholarshipApplication::query()
            ->where('scholarship_id', $validated['scholarship_id'])
            ->where('applicant_id', $user->id)
            ->exists();

        if ($alreadyApplied) {
            return response()->json([
                'message' => 'You already submitted an application for this scholarship.',
            ], 422);
        }

        $scholarship = Scholarship::query()->findOrFail($validated['scholarship_id']);

        if (! $scholarship->isAcceptingApplications()) {
            return response()->json([
                'message' => $scholarship->hasReachedApplicationLimit()
                    ? 'This scholarship has reached its application limit.'
                    : ($scholarship->application_opens_at?->isFuture()
                        ? 'Applications open on '.$scholarship->application_opens_at->format('M d, Y').'.'
                        : 'This scholarship is no longer accepting applications.'),
            ], 422);
        }

        $applicationAnswers = $this->normalizeApplicationAnswers(
            $scholarship,
            $validated['application_answers'] ?? [],
        );

        ScholarshipFunnelEvent::record(
            $user,
            'application_started',
            $scholarship,
            source: 'mobile',
            metadata: ['profile_complete' => true],
            deduplicationKey: "application_started:mobile:{$user->id}:{$scholarship->id}",
        );

        $eligibilityMatch = $this->eligibilityMatch($scholarship, $user);
        $eligibilityBlockers = $this->applicationEligibilityBlockers($eligibilityMatch);

        if ($eligibilityBlockers !== []) {
            return response()->json([
                'message' => 'You are not eligible to apply for this scholarship based on your current student profile.',
                'eligibility_match' => $eligibilityMatch,
                'blocking_criteria' => $eligibilityBlockers,
            ], 422);
        }

        $requiredDocuments = collect($scholarship->application_mode === 'provider_review'
            ? []
            : $this->documentRequirements($scholarship))
            ->unique()
            ->values()
            ->all();
        $optionalDocuments = $scholarship->application_mode === 'provider_review'
            ? []
            : $this->eligibilityService->optionalDocumentRequirements($scholarship);
        $preparedDocumentNames = $requiredDocuments === []
            ? collect()
            : StudentDocument::query()
                ->where('user_id', $user->id)
                ->whereIn('document_name', $requiredDocuments)
                ->get()
                ->filter(fn (StudentDocument $document): bool => Storage::disk('local')->exists($document->path))
                ->pluck('document_name');
        $missingDocuments = collect($requiredDocuments)
            ->reject(fn (string $requirement): bool => $preparedDocumentNames->contains($requirement))
            ->values()
            ->all();

        if ($missingDocuments !== []) {
            return response()->json([
                'message' => 'Upload every required document before continuing with your application.',
                'missing_documents' => $missingDocuments,
            ], 422);
        }

        $copiedDocumentPaths = [];

        try {
            $application = DB::transaction(function () use (
                $scholarship,
                $user,
                $requiredDocuments,
                $optionalDocuments,
                $eligibilityMatch,
                $applicationAnswers,
                $validated,
                &$copiedDocumentPaths,
            ): ScholarshipApplication {
                $lockedScholarship = Scholarship::query()
                    ->whereKey($scholarship->id)
                    ->lockForUpdate()
                    ->firstOrFail();

                if ($lockedScholarship->hasReachedApplicationLimit()) {
                    throw ValidationException::withMessages([
                        'scholarship_id' => 'This scholarship has reached its application limit.',
                    ]);
                }

                $application = ScholarshipApplication::create([
                    'scholarship_id' => $scholarship->id,
                    'applicant_id' => $user->id,
                    'status' => 'submitted',
                    'document_checklist' => $requiredDocuments,
                    'optional_document_checklist' => $optionalDocuments,
                    'eligibility_score' => $eligibilityMatch['score'],
                    'eligibility_breakdown' => $eligibilityMatch,
                    'review_rubric_snapshot' => $scholarship->review_rubric ?? [],
                    'application_answers' => $applicationAnswers,
                    'notes' => $validated['notes'] ?? null,
                    'submitted_at' => now(),
                ]);

                ApplicationStatusHistory::create([
                    'scholarship_application_id' => $application->id,
                    'changed_by' => $user->id,
                    'from_status' => null,
                    'to_status' => 'submitted',
                    'review_notes' => 'Application submitted from the mobile app.',
                    'changed_at' => now(),
                ]);

                $this->attachPreparedDocumentsToApplication(
                    $user,
                    $application,
                    $requiredDocuments,
                    $optionalDocuments,
                    $copiedDocumentPaths,
                );
                $application = $this->workflowService->start($application);
                app(DecisionSupportService::class)->syncApplication($application, 'mobile_application_submitted');

                return $application;
            });
        } catch (Throwable $error) {
            foreach ($copiedDocumentPaths as $copiedPath) {
                Storage::disk('local')->delete($copiedPath);
            }

            if (ScholarshipApplication::query()
                ->where('scholarship_id', $scholarship->id)
                ->where('applicant_id', $user->id)
                ->exists()) {
                return response()->json([
                    'message' => 'You already submitted an application for this scholarship.',
                ], 422);
            }

            throw $error;
        }

        $application->refresh();
        ScholarshipFunnelEvent::record(
            $user,
            'application_submitted',
            $scholarship,
            $application,
            'mobile',
            [
                'eligibility_score' => $application->eligibility_score,
                'dss_score' => $application->dss_score,
            ],
            "application_submitted:{$application->id}",
        );

        ActivityLog::record(
            $user,
            'mobile_application_submitted',
            "{$user->name} submitted an application for {$scholarship->title} from mobile.",
            $request,
            ['application_id' => $application->id, 'scholarship_id' => $scholarship->id],
        );

        PortalNotification::create([
            'user_id' => $scholarship->provider_id,
            'type' => 'application',
            'title' => 'New scholarship application',
            'message' => "{$user->name} submitted an application for {$scholarship->title}.",
            'action_url' => '/provider/applications/review',
        ]);
        PortalNotification::create([
            'user_id' => $user->id,
            'type' => 'application_submitted',
            'title' => 'Application submitted',
            'message' => "Your application for {$scholarship->title} was submitted successfully.",
            'action_url' => '/dashboard/applications',
        ]);

        return response()->json([
            'message' => 'Application submitted successfully.',
            'application' => $this->applicationPayload($application->fresh()->load(['documents', 'schedules', 'statusHistories.actor', 'scholarship.provider.providerProfile'])),
            'stats' => $this->statsPayload($user),
        ], 201);
    }

    public function saveScholarship(Request $request, Scholarship $scholarship): JsonResponse
    {
        [$token, $user] = $this->resolveToken($request);

        if (! $token || ! $user) {
            return response()->json([
                'message' => 'Unauthenticated.',
            ], 401);
        }

        if (! $scholarship->isDiscoverable()) {
            return response()->json([
                'message' => 'Scholarship not found.',
            ], 404);
        }

        $bookmark = ScholarshipBookmark::query()->firstOrCreate([
            'scholarship_id' => $scholarship->id,
            'user_id' => $user->id,
        ]);

        if ($bookmark->wasRecentlyCreated) {
            ScholarshipFunnelEvent::record(
                $user,
                'scholarship_saved',
                $scholarship,
                source: 'mobile',
            );
        }

        return response()->json([
            'message' => 'Scholarship saved.',
            'scholarship' => $this->scholarshipPayload($scholarship->fresh()->load('provider.providerProfile'), $user),
            'stats' => $this->statsPayload($user),
        ]);
    }

    public function unsaveScholarship(Request $request, Scholarship $scholarship): JsonResponse
    {
        [$token, $user] = $this->resolveToken($request);

        if (! $token || ! $user) {
            return response()->json([
                'message' => 'Unauthenticated.',
            ], 401);
        }

        $deleted = ScholarshipBookmark::query()
            ->where('scholarship_id', $scholarship->id)
            ->where('user_id', $user->id)
            ->delete();

        if ($deleted > 0) {
            ScholarshipFunnelEvent::record(
                $user,
                'scholarship_unsaved',
                $scholarship,
                source: 'mobile',
            );
        }

        return response()->json([
            'message' => 'Scholarship removed from saved list.',
            'scholarship' => $this->scholarshipPayload($scholarship->fresh()->load('provider.providerProfile'), $user),
            'stats' => $this->statsPayload($user),
        ]);
    }

    public function logout(Request $request): JsonResponse
    {
        [$token, $user] = $this->resolveToken($request);

        if (! $token || ! $user) {
            return response()->json([
                'message' => 'Unauthenticated.',
            ], 401);
        }

        ActivityLog::record(
            $user,
            'mobile_logout',
            "{$user->name} logged out from the mobile app.",
            $request,
        );

        $token->delete();

        return response()->json([
            'message' => 'Logged out successfully.',
        ]);
    }

    public function markNotificationRead(Request $request, PortalNotification $notification): JsonResponse
    {
        [$token, $user] = $this->resolveToken($request);

        if (! $token || ! $user) {
            return response()->json([
                'message' => 'Unauthenticated.',
            ], 401);
        }

        if ($notification->user_id !== $user->id) {
            return response()->json([
                'message' => 'Notification not found.',
            ], 404);
        }

        $notification->markRead();
        $token->forceFill(['last_used_at' => now()])->save();

        return response()->json([
            'message' => 'Notification marked as read.',
            'notifications' => $this->notificationsPayload($user),
        ]);
    }

    public function acknowledgeApplicationSchedule(
        Request $request,
        ScholarshipApplication $application,
        ApplicationSchedule $schedule,
    ): JsonResponse {
        [$token, $user] = $this->resolveToken($request);

        if (! $token || ! $user) {
            return response()->json(['message' => 'Unauthenticated.'], 401);
        }

        if ($application->applicant_id !== $user->id
            || $schedule->scholarship_application_id !== $application->id) {
            return response()->json(['message' => 'Schedule not found.'], 404);
        }

        if (! ApplicationSchedulePayload::requiresApplicantAcknowledgment($schedule)) {
            return response()->json([
                'message' => 'Schedules are delivered through portal and email notifications and do not require applicant acknowledgment.',
            ], 422);
        }

        if ($schedule->status !== 'scheduled') {
            return response()->json([
                'message' => 'Only an active schedule can be acknowledged.',
            ], 422);
        }

        if ($schedule->applicant_acknowledged_at === null) {
            $schedule->update(['applicant_acknowledged_at' => now()]);
            $scheduleLabel = Str::of($schedule->type)->replace('_', ' ')->lower()->toString();

            ActivityLog::record(
                $user,
                'application_schedule_acknowledged',
                "{$user->name} acknowledged the {$scheduleLabel} schedule for application #{$application->id} from the mobile app.",
                $request,
                ['application_id' => $application->id, 'schedule_id' => $schedule->id, 'source' => 'mobile'],
            );

            if ($application->scholarship?->provider_id) {
                PortalNotification::create([
                    'user_id' => $application->scholarship->provider_id,
                    'type' => 'schedule_acknowledged',
                    'title' => ucfirst($scheduleLabel).' schedule acknowledged',
                    'message' => "{$user->name} confirmed through the mobile app that they saw the {$scheduleLabel} schedule for {$application->scholarship->title}.",
                    'action_url' => route('provider.applications.show', $application, false),
                ]);
            }
        }

        $token->forceFill(['last_used_at' => now()])->save();
        $freshApplication = $application->fresh()->load([
            'applicant.studentProfile',
            'documents',
            'schedules',
            'statusHistories.actor',
            'scholarship.provider.providerProfile',
        ]);

        return response()->json([
            'message' => 'Schedule acknowledged. The provider can now see your confirmation.',
            'schedule' => ApplicationSchedulePayload::make($schedule->fresh()),
            'application' => $this->applicationPayload($freshApplication),
        ]);
    }

    private function createToken(User $user): string
    {
        $plainToken = Str::random(80);

        MobileApiToken::create([
            'user_id' => $user->id,
            'name' => 'mobile_app',
            'token_hash' => hash('sha256', $plainToken),
            'last_used_at' => now(),
            'expires_at' => now()->addDays(config('auth.mobile_token_lifetime_days', 30)),
        ]);

        return $plainToken;
    }

    private function resolveToken(Request $request): array
    {
        $plainToken = $request->bearerToken();

        if (! $plainToken) {
            return [null, null];
        }

        $token = MobileApiToken::query()
            ->with('user')
            ->where('token_hash', hash('sha256', $plainToken))
            ->first();

        if (! $token || ($token->expires_at && $token->expires_at->isPast())) {
            return [null, null];
        }

        if ($token->user?->role !== 'applicant' || $token->user?->isSuspended() || $token->user?->must_reset_password) {
            return [null, null];
        }

        return [$token, $token->user];
    }

    private function userPayload(User $user): array
    {
        return $user->loadMissing(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload();
    }

    private function publishedScholarships()
    {
        return Scholarship::query()
            ->with('provider.providerProfile')
            ->withCount(['bookmarks', 'applications'])
            ->discoverable()
            ->orderByRaw('deadline is null')
            ->orderBy('deadline')
            ->latest();
    }

    private function statsPayload(User $user): array
    {
        return [
            'available_scholarships' => Scholarship::query()->acceptingApplications()->count(),
            'applications' => ScholarshipApplication::query()->where('applicant_id', $user->id)->count(),
            'saved' => ScholarshipBookmark::query()->where('user_id', $user->id)->count(),
        ];
    }

    private function notificationsPayload(User $user): array
    {
        return PortalNotification::query()
            ->where('user_id', $user->id)
            ->latest()
            ->limit(8)
            ->get()
            ->map(fn (PortalNotification $notification) => [
                'id' => $notification->id,
                'type' => $notification->type,
                'title' => $notification->title,
                'message' => $notification->message,
                'action_url' => $notification->action_url,
                'read_at' => $notification->read_at?->format('M d, Y h:i A'),
                'created_at' => $notification->created_at?->format('M d, Y h:i A'),
            ])
            ->values()
            ->all();
    }

    private function scholarshipPayload(Scholarship $scholarship, User $user): array
    {
        $match = $this->eligibilityMatch($scholarship, $user);
        $preparedDocuments = $this->preparedDocumentReadiness($scholarship, $user);
        $distanceKm = $this->distanceKm($user->studentProfile, $scholarship);
        $hasApplied = ScholarshipApplication::query()
            ->where('scholarship_id', $scholarship->id)
            ->where('applicant_id', $user->id)
            ->exists();
        $profileComplete = (bool) $user->applicantProfileReadiness()['complete'];
        $eligibilityBlockers = $this->applicationEligibilityBlockers($match);
        $applicationCount = $scholarship->applicationCount();
        $applicationLimitReached = $scholarship->application_limit !== null
            && $applicationCount >= $scholarship->application_limit;
        $remainingApplicationCapacity = $scholarship->application_limit === null
            ? null
            : max(0, $scholarship->application_limit - $applicationCount);
        $isAcceptingApplications = $scholarship->isAcceptingApplications();

        return [
            'id' => $scholarship->id,
            'image_path' => $scholarship->image_path,
            'logo_url' => $scholarship->logoUrl(),
            'cover_image_url' => $scholarship->coverImageUrl(),
            'image_url' => $this->scholarshipImageUrl($scholarship),
            'title' => $scholarship->title,
            'category' => $scholarship->category,
            'program_cycle' => $scholarship->program_cycle,
            'description' => $scholarship->description,
            'provider_objectives' => $scholarship->provider_objectives ?? [],
            'provider_objective_notes' => $scholarship->provider_objective_notes,
            'eligibility' => $scholarship->eligibility,
            'eligible_education_levels' => $scholarship->eligible_education_levels,
            'eligibility_rule_modes' => $scholarship->eligibilityRuleModes(),
            'education_eligibility_policy' => EducationEligibilityPolicy::normalize($scholarship->education_eligibility_policy),
            'eligible_courses' => $scholarship->eligible_courses,
            'eligible_school_types' => $scholarship->eligible_school_types,
            'eligible_year_levels' => $scholarship->eligible_year_levels,
            'eligible_locations' => $scholarship->eligible_locations,
            'income_requirement' => $scholarship->income_requirement,
            'exclude_current_scholarship_recipients' => (bool) $scholarship->exclude_current_scholarship_recipients,
            'location_name' => $scholarship->location_name,
            'location_address' => $scholarship->location_address,
            'latitude' => $scholarship->latitude,
            'longitude' => $scholarship->longitude,
            'map_url' => $this->mapUrl($scholarship),
            'embed_map_url' => $this->embedMapUrl($scholarship),
            'distance_km' => $distanceKm,
            'distance_label' => $distanceKm === null ? null : number_format($distanceKm, 1).' km away',
            'requirements' => $scholarship->requirements,
            'optional_requirements' => $scholarship->optional_requirements,
            'application_questions' => $scholarship->application_questions ?? [],
            'benefits' => $scholarship->benefitPayload(),
            'benefit_summary' => $scholarship->benefitSummary(),
            'award_amount' => $scholarship->award_amount,
            'minimum_gwa' => $scholarship->minimum_gwa,
            'minimum_grade_scale' => AcademicRequirement::normalizeScale($scholarship->minimum_grade_scale, $scholarship->minimum_gwa),
            'minimum_grade_label' => AcademicRequirement::requirementLabel($scholarship->minimum_gwa, $scholarship->minimum_grade_scale),
            'slots_available' => $scholarship->slots_available,
            'application_limit' => $scholarship->application_limit,
            'applications_count' => $applicationCount,
            'application_slots_remaining' => $remainingApplicationCapacity,
            'application_limit_reached' => $applicationLimitReached,
            'application_mode' => $scholarship->application_mode,
            'renewal_policy' => $scholarship->renewal_policy,
            'return_service_contract' => $scholarship->return_service_contract,
            'other_contract_terms' => $scholarship->other_contract_terms,
            'recipient_agreement' => $scholarship->recipient_agreement,
            'contact_email' => $scholarship->contact_email,
            'contact_number' => $scholarship->contact_number,
            'application_opens_at' => $scholarship->application_opens_at?->format('M d, Y'),
            'application_opens_date' => $scholarship->application_opens_at?->format('Y-m-d'),
            'expected_results_at' => $scholarship->expected_results_at?->format('M d, Y'),
            'support_starts_at' => $scholarship->support_starts_at?->format('M d, Y'),
            'support_ends_at' => $scholarship->support_ends_at?->format('M d, Y'),
            'official_program_url' => $scholarship->official_program_url,
            'contact_person' => $scholarship->contact_person,
            'contact_department' => $scholarship->contact_department,
            'deadline' => $scholarship->deadline?->format('M d, Y'),
            'bookmarks_count' => $scholarship->bookmarks_count ?? $scholarship->bookmarks()->count(),
            'is_saved' => ScholarshipBookmark::query()
                ->where('scholarship_id', $scholarship->id)
                ->where('user_id', $user->id)
                ->exists(),
            'has_applied' => $hasApplied,
            'is_accepting_applications' => $isAcceptingApplications,
            'can_start_application' => $isAcceptingApplications
                && $profileComplete
                && $user->applicantAcademicVerificationStatus() === 'approved'
                && $eligibilityBlockers === []
                && ! $hasApplied,
            'eligibility_match' => $match,
            'prepared_documents' => $preparedDocuments,
            'eligibility_guide' => [
                'requires_gwa' => filled($scholarship->minimum_gwa),
                'minimum_gwa' => $scholarship->minimum_gwa,
                'minimum_grade_scale' => AcademicRequirement::normalizeScale($scholarship->minimum_grade_scale, $scholarship->minimum_gwa),
                'minimum_grade_label' => AcademicRequirement::requirementLabel($scholarship->minimum_gwa, $scholarship->minimum_grade_scale),
                'required_documents' => count($this->documentRequirements($scholarship)),
                'prepared_documents' => $preparedDocuments['uploaded'],
                'note' => AcademicRequirement::requirementLabel($scholarship->minimum_gwa, $scholarship->minimum_grade_scale),
            ],
            'provider' => [
                'name' => $scholarship->provider?->provider_name ?? $scholarship->provider?->name,
                'type' => $scholarship->provider?->provider_type,
            ],
        ];
    }

    private function scholarshipImageUrl(Scholarship $scholarship): string
    {
        return $scholarship->logoUrl();
    }

    private function mapUrl(Scholarship $scholarship): ?string
    {
        if ($scholarship->latitude !== null && $scholarship->longitude !== null) {
            return "https://www.openstreetmap.org/?mlat={$scholarship->latitude}&mlon={$scholarship->longitude}#map=15/{$scholarship->latitude}/{$scholarship->longitude}";
        }

        $query = $scholarship->location_address ?: $scholarship->location_name;

        return filled($query)
            ? 'https://www.openstreetmap.org/search?query='.rawurlencode($query)
            : null;
    }

    private function embedMapUrl(Scholarship $scholarship): ?string
    {
        if ($scholarship->latitude !== null && $scholarship->longitude !== null) {
            return "https://www.openstreetmap.org/export/embed.html?marker={$scholarship->latitude},{$scholarship->longitude}&layer=mapnik";
        }

        return null;
    }

    private function distanceKm($profile, Scholarship $scholarship): ?float
    {
        if (
            $profile?->latitude === null
            || $profile?->longitude === null
            || $scholarship->latitude === null
            || $scholarship->longitude === null
        ) {
            return null;
        }

        $studentLatitude = deg2rad((float) $profile->latitude);
        $studentLongitude = deg2rad((float) $profile->longitude);
        $scholarshipLatitude = deg2rad((float) $scholarship->latitude);
        $scholarshipLongitude = deg2rad((float) $scholarship->longitude);

        $latitudeDelta = $scholarshipLatitude - $studentLatitude;
        $longitudeDelta = $scholarshipLongitude - $studentLongitude;
        $angle = (sin($latitudeDelta / 2) ** 2)
            + cos($studentLatitude) * cos($scholarshipLatitude) * (sin($longitudeDelta / 2) ** 2);
        $angle = min(1, max(0, $angle));

        return round(6371 * 2 * atan2(sqrt($angle), sqrt(1 - $angle)), 1);
    }

    private function applicationPayload(ScholarshipApplication $application): array
    {
        $workflow = $this->workflowService->payload($application);
        $dss = app(DecisionSupportService::class)->scoreApplication($application);
        $application->loadMissing('schedules');

        return [
            'id' => $application->id,
            'status' => $application->status,
            'application_state' => $workflow['application_state'],
            'workflow_stage' => $workflow['current_stage'],
            'final_outcome' => $workflow['final_outcome'],
            'workflow' => $workflow,
            'document_checklist' => $application->document_checklist ?? [],
            'optional_document_checklist' => $application->optional_document_checklist
                ?? $this->eligibilityService->optionalDocumentRequirements($application->scholarship),
            'application_answers' => $application->application_answers ?? [],
            'document_readiness' => $this->documentReadiness($application),
            'eligibility_score' => $application->eligibility_score,
            'eligibility_breakdown' => $application->eligibility_breakdown,
            'dss_score' => $dss['score'],
            'dss_recommendation' => $dss['recommendation'],
            'dss_breakdown' => $dss,
            'documents' => $application->documents->map(fn (ApplicationDocument $document) => [
                'id' => $document->id,
                'document_name' => $document->document_name,
                'original_name' => $document->original_name,
                'size' => $document->size,
                'status' => $document->status,
                'review_notes' => $document->review_notes,
                'uploaded_at' => $document->uploaded_at?->format('M d, Y h:i A'),
            ])->values(),
            'notes' => $application->notes,
            'review_notes' => $application->review_notes,
            'correction_status' => $application->correction_status,
            'correction_message' => $application->correction_message,
            'correction_targets' => $application->correction_targets ?? [],
            'correction_response' => $application->correction_response,
            'correction_requested_at' => $application->correction_requested_at?->format('M d, Y h:i A'),
            'correction_responded_at' => $application->correction_responded_at?->format('M d, Y h:i A'),
            'correction_resolved_at' => $application->correction_resolved_at?->format('M d, Y h:i A'),
            'withdrawal_reason' => $application->withdrawal_reason,
            'withdrawn_at' => $application->withdrawn_at?->format('M d, Y h:i A'),
            'waitlist_position' => $application->waitlist_position,
            'waitlisted_at' => $application->waitlisted_at?->format('M d, Y h:i A'),
            'can_withdraw' => ! $workflow['is_closed'],
            'decision_reason' => $application->decision_reason,
            'awarded_amount' => $application->awarded_amount,
            'display_award_amount' => $application->awarded_amount ?? $application->scholarship?->award_amount,
            'award_amount_source' => $application->awarded_amount !== null
                ? 'application'
                : ($application->scholarship?->award_amount !== null ? 'program' : null),
            'outcome_notes' => $application->outcome_notes,
            'outcome_at' => $application->outcome_at?->format('M d, Y'),
            'formal_application_handoff' => $this->formalApplicationHandoffPayload($application, $workflow),
            'distribution_scheduled_for' => $application->distribution_scheduled_for?->format('M d, Y'),
            'distribution_instructions' => $application->distribution_instructions,
            'schedules' => $application->schedules
                ->sortBy('scheduled_at')
                ->map(fn (ApplicationSchedule $schedule) => ApplicationSchedulePayload::make($schedule))
                ->values(),
            'timeline' => $this->timelinePayload($application),
            'submitted_at' => $application->submitted_at?->format('M d, Y h:i A'),
            'scholarship' => $application->scholarship
                ? $this->scholarshipPayload($application->scholarship, $application->applicant)
                : null,
        ];
    }

    private function normalizeApplicationAnswers(Scholarship $scholarship, array $submittedAnswers): array
    {
        $answersByQuestion = collect($submittedAnswers)
            ->filter(fn (mixed $answer): bool => is_array($answer) && filled($answer['question_id'] ?? null))
            ->keyBy(fn (array $answer): string => (string) $answer['question_id']);
        $missingRequired = [];

        $answers = collect($scholarship->application_questions ?? [])
            ->filter(fn (mixed $question): bool => is_array($question) && filled($question['id'] ?? null) && filled($question['prompt'] ?? null))
            ->map(function (array $question) use ($answersByQuestion, &$missingRequired): array {
                $questionId = (string) $question['id'];
                $answer = trim((string) data_get($answersByQuestion->get($questionId), 'answer', ''));
                $required = (bool) ($question['required'] ?? false);

                if ($required && $answer === '') {
                    $missingRequired[] = (string) $question['prompt'];
                }

                return [
                    'question_id' => $questionId,
                    'prompt' => (string) $question['prompt'],
                    'required' => $required,
                    'answer' => $answer,
                ];
            })
            ->values()
            ->all();

        if ($missingRequired !== []) {
            throw ValidationException::withMessages([
                'application_answers' => 'Answer every required provider question before submitting.',
            ]);
        }

        return $answers;
    }

    private function formalApplicationHandoffPayload(
        ScholarshipApplication $application,
        ?array $workflow = null,
    ): ?array {
        $workflow ??= $this->workflowService->payload($application);
        $formalApplicationStatus = data_get(
            collect($workflow['steps'])->firstWhere('key', 'formal_application'),
            'status',
        );

        if (! in_array($formalApplicationStatus, ['current', 'passed'], true)) {
            return null;
        }

        $scholarship = $application->scholarship;

        if (! $scholarship) {
            return null;
        }

        $mapQuery = $scholarship->handoff_location_address ?: $scholarship->handoff_location_name;

        return [
            'requirements' => $this->splitOptions($scholarship->post_qualification_requirements),
            'mode' => $scholarship->handoff_mode ?: 'provider_contact',
            'instructions' => $scholarship->handoff_instructions,
            'deadline' => $scholarship->handoff_deadline?->format('M d, Y'),
            'location_name' => $scholarship->handoff_location_name,
            'location_address' => $scholarship->handoff_location_address,
            'map_url' => filled($mapQuery)
                ? 'https://www.openstreetmap.org/search?query='.rawurlencode($mapQuery)
                : null,
            'url' => $scholarship->handoff_url,
            'contact_person' => $scholarship->contact_person,
            'contact_department' => $scholarship->contact_department,
            'contact_email' => $scholarship->contact_email,
            'contact_number' => $scholarship->contact_number,
            'notice' => 'Portal qualification lets you continue with the provider. It is not a final scholarship award.',
        ];
    }

    private function documentReadiness(ScholarshipApplication $application): array
    {
        return $this->eligibilityService->applicationDocumentReadiness($application);
    }

    private function timelinePayload(ScholarshipApplication $application): array
    {
        if ($application->statusHistories->isEmpty()) {
            return [[
                'id' => "submitted-{$application->id}",
                'to_status' => $application->status,
                'decision_reason' => $application->decision_reason,
                'review_notes' => 'Application record created.',
                'actor' => $application->applicant?->name ?? 'Applicant',
                'changed_at' => $application->submitted_at?->format('M d, Y h:i A'),
            ]];
        }

        return $application->statusHistories
            ->sortBy('changed_at')
            ->map(fn (ApplicationStatusHistory $history) => [
                'id' => $history->id,
                'to_status' => $history->to_status,
                'decision_reason' => $history->decision_reason,
                'review_notes' => $history->review_notes,
                'actor' => $history->actor?->name ?? 'System',
                'changed_at' => $history->changed_at?->format('M d, Y h:i A'),
            ])
            ->values()
            ->all();
    }

    private function eligibilityMatch(Scholarship $scholarship, User $user): array
    {
        return $this->eligibilityService->evaluate($scholarship, $user);
    }

    private function applicationEligibilityBlockers(array $eligibilityMatch): array
    {
        return $this->eligibilityService->blockers($eligibilityMatch);
    }

    private function splitOptions(?string $value): array
    {
        return $this->eligibilityService->splitOptions($value);
    }

    private function matchesAnyOption(string $value, array $options): bool
    {
        return $this->eligibilityService->matchesAnyOption($value, $options);
    }

    private function hasOpenOption(array $options): bool
    {
        return $this->eligibilityService->hasOpenOption($options);
    }

    private function isOpenOption(?string $option): bool
    {
        return $this->eligibilityService->isOpenOption($option);
    }

    private function documentRequirements(?Scholarship $scholarship): array
    {
        return $this->eligibilityService->documentRequirements($scholarship);
    }

    private function preparedDocumentReadiness(Scholarship $scholarship, User $user): array
    {
        return $this->eligibilityService->preparedDocumentReadiness($scholarship, $user);
    }

    private function syncApplicantReminders(User $user): void
    {
        $profileReadiness = $user->applicantProfileReadiness();

        if (! $profileReadiness['complete']) {
            PortalNotification::updateOrCreate([
                'user_id' => $user->id,
                'type' => 'profile_reminder',
                'title' => 'Complete your student profile',
            ], [
                'message' => "Your profile is {$profileReadiness['percent']}% complete. You can explore now, but complete it before submitting applications.",
                'action_url' => '/dashboard/profile',
            ]);
        }

        $applications = ScholarshipApplication::query()
            ->with(['documents', 'scholarship'])
            ->where('applicant_id', $user->id)
            ->whereIn('status', ['submitted', 'under_review', 'qualified', 'shortlisted', 'interview'])
            ->get();

        foreach ($applications as $application) {
            $documentReadiness = $this->documentReadiness($application);

            if (($documentReadiness['uploaded_percent'] ?? 100) >= 100) {
                continue;
            }

            $missing = collect($documentReadiness['missing'] ?? [])->take(3)->implode(', ');

            PortalNotification::updateOrCreate([
                'user_id' => $user->id,
                'type' => 'document_reminder',
                'title' => "Documents needed for {$application->scholarship?->title}",
            ], [
                'message' => $missing
                    ? "Upload or replace these requirements: {$missing}."
                    : 'Upload the remaining requirements for this application.',
                'action_url' => '/dashboard/applications',
            ]);
        }

        Scholarship::query()
            ->acceptingApplications()
            ->whereNotNull('deadline')
            ->whereDate('deadline', '>=', now()->toDateString())
            ->whereDate('deadline', '<=', now()->addDays(7)->toDateString())
            ->whereHas('bookmarks', fn ($query) => $query->where('user_id', $user->id))
            ->whereDoesntHave('applications', fn ($query) => $query->where('applicant_id', $user->id))
            ->get()
            ->each(fn (Scholarship $scholarship) => PortalNotification::updateOrCreate([
                'user_id' => $user->id,
                'type' => 'deadline_reminder',
                'title' => "Deadline near: {$scholarship->title}",
            ], [
                'message' => "This saved scholarship is due on {$scholarship->deadline?->format('M d, Y')}.",
                'action_url' => "/dashboard/scholarships/{$scholarship->id}",
            ]));
    }

    private function documentLibraryOptions(User $user): array
    {
        $commonDocuments = [
            'Certificate of enrollment',
            'Latest report card or grades',
            'Recent school ID',
            'Proof of identity',
            'Proof of residence',
            'Proof of income',
            'Certificate of indigency',
            'Parent or guardian valid ID',
            'Recommendation letter',
        ];
        $publishedRequirements = Scholarship::query()
            ->acceptingApplications()
            ->whereNotNull('requirements')
            ->pluck('requirements')
            ->flatMap(fn (?string $requirements) => $this->splitOptions($requirements));
        $applicationRequirements = ScholarshipApplication::query()
            ->with('scholarship')
            ->where('applicant_id', $user->id)
            ->get()
            ->flatMap(fn (ScholarshipApplication $application) => $this->documentRequirements($application->scholarship));

        return collect($commonDocuments)
            ->merge($publishedRequirements)
            ->merge($applicationRequirements)
            ->map(fn (string $document) => trim($document))
            ->filter()
            ->reject(fn (string $document): bool => str($document)->lower()->squish()->toString() === 'proof of no current scholarship')
            ->unique()
            ->sort()
            ->values()
            ->all();
    }

    private function studentDocumentPayload(StudentDocument $document): array
    {
        return [
            'id' => $document->id,
            'document_name' => $document->document_name,
            'original_name' => $document->original_name,
            'size' => $document->size,
            'uploaded_at' => $document->uploaded_at?->format('M d, Y h:i A'),
        ];
    }

    private function attachPreparedDocumentsToApplication(
        User $user,
        ScholarshipApplication $application,
        array $confirmedDocuments,
        array $optionalDocuments,
        array &$copiedPaths,
    ): void {
        $application->loadMissing('scholarship');
        $requirements = $confirmedDocuments !== []
            ? collect($confirmedDocuments)->map(fn (string $document) => trim($document))->filter()->values()->all()
            : $this->documentRequirements($application->scholarship);
        $requirements = collect($requirements)
            ->merge($optionalDocuments)
            ->map(fn (string $document) => trim($document))
            ->filter()
            ->unique()
            ->values()
            ->all();

        if ($requirements === []) {
            return;
        }

        $preparedDocuments = StudentDocument::query()
            ->where('user_id', $user->id)
            ->whereIn('document_name', $requirements)
            ->get();

        foreach ($preparedDocuments as $studentDocument) {
            if (! Storage::disk('local')->exists($studentDocument->path)) {
                continue;
            }

            $extension = pathinfo($studentDocument->original_name, PATHINFO_EXTENSION);
            Storage::disk('local')->makeDirectory("application-documents/{$application->id}");
            $targetPath = 'application-documents/'.$application->id.'/'.(string) Str::uuid().($extension ? ".{$extension}" : '');

            if (! Storage::disk('local')->copy($studentDocument->path, $targetPath)) {
                throw new \RuntimeException("Unable to copy {$studentDocument->document_name} into the application.");
            }

            $copiedPaths[] = $targetPath;
            ApplicationDocument::query()->updateOrCreate([
                'scholarship_application_id' => $application->id,
                'document_name' => $studentDocument->document_name,
            ], [
                'uploaded_by' => $user->id,
                'original_name' => $studentDocument->original_name,
                'path' => $targetPath,
                'mime_type' => $studentDocument->mime_type,
                'size' => $studentDocument->size,
                'status' => 'pending',
                'review_notes' => null,
                'reviewed_by' => null,
                'reviewed_at' => null,
                'uploaded_at' => now(),
            ]);
        }
    }
}

<?php

namespace App\Http\Controllers;

use App\Mail\RegistrationVerificationCodeMail;
use App\Models\ActivityLog;
use App\Models\PendingRegistration;
use App\Models\PortalNotification;
use App\Models\User;
use App\Rules\PhoneNumber;
use App\Services\PasswordResetLinkService;
use App\Support\Terms;
use Illuminate\Auth\Events\Verified;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Throwable;

class AuthController extends Controller
{
    public function register(Request $request): JsonResponse
    {
        $request->merge(['email' => strtolower(trim((string) $request->input('email')))]);
        $validated = $request->validate($this->registrationRules());
        $email = strtolower(trim($validated['email']));
        $username = trim($validated['username']);

        PendingRegistration::query()->where('expires_at', '<', now())->delete();

        $usernameConflict = PendingRegistration::query()
            ->where('username', $username)
            ->where('email', '!=', $email)
            ->exists();

        if ($usernameConflict) {
            throw ValidationException::withMessages([
                'username' => 'This username is already being used by another pending registration.',
            ]);
        }

        $verificationCode = $this->newRegistrationCode();
        $pending = PendingRegistration::query()->firstOrNew(['email' => $email]);
        $pending->fill([
            'token' => Str::random(64),
            'email' => $email,
            'username' => $username,
            'role' => $validated['role'],
            'payload' => collect($validated)->except([
                'email',
                'username',
                'password',
                'password_confirmation',
                'terms_accepted',
            ])->all(),
            'password_hash' => Hash::make($validated['password']),
            'code_hash' => Hash::make($verificationCode),
            'attempts' => 0,
            'expires_at' => now()->addMinutes(PendingRegistration::CODE_TTL_MINUTES),
            'last_sent_at' => now(),
        ])->save();

        if (! $this->sendRegistrationCode($pending, $verificationCode, $request)) {
            return response()->json([
                'message' => 'We could not send the verification code. Check the mail settings and try again.',
            ], 503);
        }

        ActivityLog::record(
            null,
            'registration_code_sent',
            "A registration code was sent to {$email}.",
            $request,
            ['email' => $email, 'role' => $pending->role],
        );

        return response()->json([
            'message' => 'We sent a six-digit verification code to your email.',
            'registration_token' => $pending->token,
            'email' => $this->maskEmail($pending->email),
            'expires_in' => PendingRegistration::CODE_TTL_MINUTES * 60,
            'resend_after' => PendingRegistration::RESEND_COOLDOWN_SECONDS,
        ], 202);
    }

    public function verifyRegistrationCode(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'registration_token' => ['required', 'string', 'size:64'],
            'code' => ['required', 'digits:6'],
        ]);

        return DB::transaction(function () use ($validated, $request): JsonResponse {
            $pending = PendingRegistration::query()
                ->where('token', $validated['registration_token'])
                ->lockForUpdate()
                ->first();

            if (! $pending || $pending->expires_at->isPast()) {
                $pending?->delete();

                return response()->json([
                    'message' => 'This verification code has expired. Return to the registration form to request a new code.',
                    'restart_required' => true,
                ], 422);
            }

            if (! Hash::check($validated['code'], $pending->code_hash)) {
                $pending->increment('attempts');
                $remainingAttempts = max(0, PendingRegistration::MAX_ATTEMPTS - $pending->attempts);

                if ($remainingAttempts === 0) {
                    $pending->delete();

                    return response()->json([
                        'message' => 'Too many incorrect attempts. Return to the registration form to request a new code.',
                        'restart_required' => true,
                    ], 422);
                }

                return response()->json([
                    'message' => "The verification code is incorrect. {$remainingAttempts} attempt".($remainingAttempts === 1 ? '' : 's').' remaining.',
                    'attempts_remaining' => $remainingAttempts,
                ], 422);
            }

            if (User::query()->where('email', $pending->email)->exists()) {
                $pending->delete();

                return response()->json([
                    'message' => 'An account with this email already exists. Please log in instead.',
                    'restart_required' => true,
                ], 422);
            }

            if (User::query()->where('username', $pending->username)->exists()) {
                $pending->delete();

                return response()->json([
                    'message' => 'This username became unavailable. Return to registration and choose another username.',
                    'restart_required' => true,
                ], 422);
            }

            $profileData = $pending->payload;
            $user = User::create([
                'email' => $pending->email,
                'username' => $pending->username,
                'role' => $pending->role,
                'password' => $pending->password_hash,
                'terms_accepted_at' => now(),
                'privacy_accepted_at' => now(),
                'terms_version' => Terms::VERSION,
            ]);
            $user->forceFill(['email_verified_at' => now()])->save();

            $profile = [
                'first_name' => $profileData['first_name'],
                'last_name' => $profileData['last_name'],
                'middle_initial' => filled($profileData['middle_initial'] ?? null)
                    ? strtoupper($profileData['middle_initial'])
                    : null,
                'contact_number' => $profileData['number'],
            ];

            if ($user->isProvider()) {
                $user->providerProfile()->create($profile);
            } else {
                $user->studentProfile()->create($profile);
            }

            $pending->delete();

            ActivityLog::record(
                $user,
                'registered',
                "{$user->name} verified their email and registered as {$user->role}.",
                $request,
            );

            return response()->json([
                'message' => 'Email verified. Your account has been created successfully.',
                'redirect' => '/login?registered=1&verified=1',
                'email_verified' => true,
            ], 201);
        });
    }

    public function resendRegistrationCode(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'registration_token' => ['required', 'string', 'size:64'],
        ]);
        $pending = PendingRegistration::query()
            ->where('token', $validated['registration_token'])
            ->first();

        if (! $pending || $pending->expires_at->isPast()) {
            $pending?->delete();

            return response()->json([
                'message' => 'This registration has expired. Return to the form to start again.',
                'restart_required' => true,
            ], 422);
        }

        $availableAt = $pending->last_sent_at?->copy()->addSeconds(PendingRegistration::RESEND_COOLDOWN_SECONDS);

        if ($availableAt?->isFuture()) {
            return response()->json([
                'message' => 'Please wait before requesting another code.',
                'retry_after' => max(1, (int) ceil(now()->diffInSeconds($availableAt))),
            ], 429);
        }

        $verificationCode = $this->newRegistrationCode();
        $pending->update([
            'code_hash' => Hash::make($verificationCode),
            'attempts' => 0,
            'expires_at' => now()->addMinutes(PendingRegistration::CODE_TTL_MINUTES),
            'last_sent_at' => now(),
        ]);

        if (! $this->sendRegistrationCode($pending, $verificationCode, $request)) {
            return response()->json([
                'message' => 'We could not resend the verification code. Check the mail settings and try again.',
            ], 503);
        }

        return response()->json([
            'message' => 'A new verification code was sent to your email.',
            'expires_in' => PendingRegistration::CODE_TTL_MINUTES * 60,
            'resend_after' => PendingRegistration::RESEND_COOLDOWN_SECONDS,
        ]);
    }

    public function login(Request $request): JsonResponse
    {
        $credentials = $request->validate([
            'login' => ['nullable', 'string', 'max:255', 'required_without:email'],
            'email' => ['nullable', 'string', 'max:255', 'required_without:login'],
            'password' => ['required', 'string'],
            'remember' => ['sometimes', 'boolean'],
        ]);

        $login = trim((string) ($credentials['login'] ?? $credentials['email']));
        $loginField = filter_var($login, FILTER_VALIDATE_EMAIL) ? 'email' : 'username';
        $loginValue = $loginField === 'email' ? strtolower($login) : $login;
        $remember = (bool) ($credentials['remember'] ?? false);
        $attemptKey = 'login-account:'.hash('sha256', mb_strtolower($loginValue));
        if (RateLimiter::tooManyAttempts($attemptKey, 5)) {
            $retryAfter = RateLimiter::availableIn($attemptKey);
            return response()->json([
                'message' => 'Too many sign-in attempts. Please wait before trying again.',
                'retry_after' => $retryAfter,
            ], 429)->header('Retry-After', (string) $retryAfter);
        }

        if (! Auth::attempt([
            $loginField => $loginValue,
            'password' => $credentials['password'],
        ], $remember)) {
            RateLimiter::hit($attemptKey, 60);
            ActivityLog::record(
                null,
                'login_failed',
                "Failed login attempt for {$loginValue}.",
                $request,
                ['login_type' => $loginField, 'login' => $loginValue],
            );

            return response()->json([
                'message' => 'The username, email, or password is incorrect.',
            ], 422);
        }

        RateLimiter::clear($attemptKey);
        $request->session()->regenerate();

        if ($request->user()->isSuspended()) {
            ActivityLog::record(
                $request->user(),
                'login_blocked_suspended',
                "{$request->user()->name} attempted to log in while suspended.",
                $request,
            );

            Auth::guard('web')->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return response()->json([
                'message' => 'Your account is suspended. Contact an administrator for help.',
            ], 403);
        }

        if ($request->user()->isManagedAccount()
            && (! $request->user()->hasVerifiedEmail() || $request->user()->must_reset_password)) {
            ActivityLog::record(
                $request->user(),
                'managed_account_setup_started',
                "{$request->user()->name} signed in to complete staff account setup.",
                $request,
            );

            return response()->json([
                'message' => $request->user()->hasVerifiedEmail()
                    ? 'Create a new password to finish setting up your staff account.'
                    : 'Verify your email address to continue setting up your staff account.',
                'redirect' => route('account.setup', absolute: false),
                'email_verified' => $request->user()->hasVerifiedEmail(),
                'must_reset_password' => (bool) $request->user()->must_reset_password,
                'user' => $request->user()->loadMissing(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload(),
            ]);
        }

        if ($request->user()->must_reset_password) {
            $reset = app(PasswordResetLinkService::class)->prepare($request->user(), $request);

            ActivityLog::record(
                $request->user(),
                'login_blocked_password_reset_required',
                "{$request->user()->name} attempted to log in with a required password reset.",
                $request,
                ['email_sent' => $reset['email_sent']],
            );

            Auth::guard('web')->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return response()->json([
                'message' => $reset['email_sent']
                    ? 'A password reset is required. We sent a reset link to your email.'
                    : 'A password reset is required, but the reset email could not be sent yet.',
                'reset_url' => $this->shouldExposeResetUrl() ? $reset['reset_url'] : null,
            ], 423);
        }

        ActivityLog::record(
            $request->user(),
            'login',
            "{$request->user()->name} logged in.",
            $request,
        );

        return response()->json([
            'message' => 'Login successful.',
            'redirect' => $this->portalPath($request->user()),
            'email_verified' => $request->user()->hasVerifiedEmail(),
            'user' => $request->user()->loadMissing(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload(),
        ]);
    }

    public function verifyEmail(Request $request, int $id, string $hash): RedirectResponse|JsonResponse
    {
        $user = User::query()->findOrFail($id);

        abort_unless(hash_equals((string) $hash, sha1($user->getEmailForVerification())), 403);

        if (! $user->hasVerifiedEmail() && $user->markEmailAsVerified()) {
            event(new Verified($user));

            PortalNotification::query()
                ->where('user_id', $user->id)
                ->where('type', 'email_verification')
                ->where('title', 'Verify your email address')
                ->update(['read_at' => now()]);

            $setupRequired = $user->isManagedAccount() && $user->must_reset_password;
            PortalNotification::create([
                'user_id' => $user->id,
                'type' => 'email_verified',
                'title' => 'Email verified',
                'message' => $setupRequired
                    ? 'Your email address is verified. Create a new password to finish setting up your staff account.'
                    : 'Your email address has been verified successfully.',
                'action_url' => $setupRequired ? '/account/setup' : $this->portalPath($user),
            ]);

            ActivityLog::record(
                $user,
                'email_verified',
                "{$user->name} verified their email address.",
                $request,
            );
        }

        if ($request->user()?->is($user)) {
            Auth::guard('web')->setUser($user->fresh());
        }

        if ($request->expectsJson()) {
            return response()->json([
                'message' => 'Email verified successfully.',
                'email_verified' => true,
            ]);
        }

        if (! $request->user()) {
            return redirect('/login?verified=1');
        }

        if ($request->user()->is($user) && $user->isManagedAccount() && $user->must_reset_password) {
            return redirect('/account/setup?verified=1');
        }

        $redirect = $this->portalPath($request->user());

        return redirect($redirect.'?verified=1');
    }

    public function resendVerificationEmail(Request $request): JsonResponse
    {
        $user = $request->user();

        abort_unless($user, 403);

        if ($user->hasVerifiedEmail()) {
            return response()->json([
                'message' => 'Your email is already verified.',
                'email_verified' => true,
                'email_verification_sent' => false,
            ]);
        }

        $emailVerificationSent = $this->sendVerificationEmail($user, $request);
        $this->syncEmailVerificationReminder($user, $emailVerificationSent);

        ActivityLog::record(
            $user,
            'email_verification_resent',
            "{$user->name} requested another email verification link.",
            $request,
        );

        return response()->json([
            'message' => $emailVerificationSent
                ? 'Verification email sent. Please check your inbox.'
                : 'Unable to send the verification email right now. Check the mail settings and try again.',
            'email_verified' => false,
            'email_verification_sent' => $emailVerificationSent,
        ]);
    }

    public function accountSetupData(Request $request): JsonResponse
    {
        $user = $request->user();

        abort_unless($user?->isManagedAccount(), 403);

        return response()->json([
            'user' => $user->loadMissing(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload(),
            'step' => $user->hasVerifiedEmail() ? 'password' : 'verification',
        ]);
    }

    public function completeAccountSetup(Request $request): JsonResponse
    {
        $user = $request->user();

        abort_unless($user?->isManagedAccount(), 403);

        if (! $user->hasVerifiedEmail()) {
            return response()->json([
                'message' => 'Verify your email address before creating a new password.',
            ], 422);
        }

        if (! $user->must_reset_password) {
            return response()->json([
                'message' => 'Your staff account setup is already complete.',
                'redirect' => $this->portalPath($user),
            ]);
        }

        $validated = $request->validate([
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        if (Hash::check($validated['password'], $user->password)) {
            throw ValidationException::withMessages([
                'password' => 'Choose a new password instead of reusing the temporary password.',
            ]);
        }

        $user->forceFill([
            'password' => $validated['password'],
            'must_reset_password' => false,
            'password_reset_required_at' => null,
        ])->save();

        DB::table('password_reset_tokens')->where('email', $user->email)->delete();

        ActivityLog::record(
            $user,
            'managed_account_setup_completed',
            "{$user->name} verified their email and replaced the temporary password.",
            $request,
        );

        PortalNotification::create([
            'user_id' => $user->id,
            'type' => 'password_changed',
            'title' => 'Staff account setup complete',
            'message' => 'Your email is verified and your temporary password has been replaced.',
            'action_url' => $this->portalPath($user),
        ]);

        return response()->json([
            'message' => 'Account setup complete. You can now use your staff workspace.',
            'redirect' => $this->portalPath($user),
            'user' => $user->fresh(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload(),
        ]);
    }

    public function logout(Request $request): JsonResponse
    {
        $user = $request->user();

        ActivityLog::record(
            $user,
            'logout',
            "{$user?->name} logged out.",
            $request,
        );

        Auth::guard('web')->logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return response()->json([
            'message' => 'Logged out successfully.',
        ]);
    }

    private function portalPath(User $user): string
    {
        return match (true) {
            $user->isAdmin() => '/admin',
            $user->isProvider() => '/provider',
            default => '/dashboard',
        };
    }

    public function forgotPassword(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'email' => ['required', 'email'],
        ]);

        $user = User::query()->where('email', $validated['email'])->first();
        $resetUrl = null;

        if ($user) {
            $reset = app(PasswordResetLinkService::class)->prepare($user, $request);
            $resetUrl = $reset['reset_url'];

            ActivityLog::record(
                $user,
                'password_reset_requested',
                "{$user->name} requested a password reset link.",
                $request,
            );
        }

        return response()->json([
            'message' => 'If that email exists, a password reset link has been prepared.',
            'reset_url' => $this->shouldExposeResetUrl() ? $resetUrl : null,
        ]);
    }

    public function resetPassword(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'email' => ['required', 'email'],
            'token' => ['required', 'string'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        $record = DB::table('password_reset_tokens')
            ->where('email', $validated['email'])
            ->first();

        if (! $record || ! Hash::check($validated['token'], $record->token) || Carbon::parse($record->created_at)->lessThan(now()->subHour())) {
            return response()->json([
                'message' => 'The reset link is invalid or expired.',
            ], 422);
        }

        $user = User::query()->where('email', $validated['email'])->firstOrFail();
        $user->forceFill([
            'password' => $validated['password'],
            'must_reset_password' => false,
            'password_reset_required_at' => null,
        ])->save();

        DB::table('password_reset_tokens')->where('email', $validated['email'])->delete();

        ActivityLog::record(
            $user,
            'password_reset_completed',
            "{$user->name} reset their password.",
            $request,
        );

        return response()->json([
            'message' => 'Password reset successful. You can now log in.',
            'redirect' => '/login',
        ]);
    }

    private function shouldExposeResetUrl(): bool
    {
        return app()->isLocal() || app()->runningUnitTests();
    }

    private function registrationRules(): array
    {
        return [
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'middle_initial' => ['nullable', 'string', 'size:1', 'regex:/^[A-Za-z]$/'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'username' => ['required', 'string', 'min:4', 'max:255', 'regex:/^[A-Za-z0-9_.-]+$/', 'unique:users,username'],
            'number' => ['required', 'string', 'max:30', new PhoneNumber],
            'role' => ['required', 'string', 'in:applicant,provider'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'terms_accepted' => ['accepted'],
        ];
    }

    private function newRegistrationCode(): string
    {
        return str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    }

    private function sendRegistrationCode(PendingRegistration $pending, string $code, Request $request): bool
    {
        try {
            Mail::to($pending->email)->send(new RegistrationVerificationCodeMail(
                $pending->payload['first_name'] ?? 'Applicant',
                $code,
                PendingRegistration::CODE_TTL_MINUTES,
            ));

            return true;
        } catch (Throwable $error) {
            ActivityLog::record(
                null,
                'registration_code_email_failed',
                "A registration code could not be sent to {$pending->email}.",
                $request,
                ['email' => $pending->email, 'error' => $error->getMessage()],
            );

            return false;
        }
    }

    private function maskEmail(string $email): string
    {
        [$local, $domain] = array_pad(explode('@', $email, 2), 2, '');
        $visible = mb_substr($local, 0, min(2, mb_strlen($local)));
        $hiddenLength = max(1, mb_strlen($local) - mb_strlen($visible));

        return $visible.str_repeat('*', $hiddenLength).'@'.$domain;
    }

    private function sendVerificationEmail(User $user, Request $request): bool
    {
        if ($user->hasVerifiedEmail()) {
            return false;
        }

        try {
            $user->sendEmailVerificationNotification();

            return true;
        } catch (Throwable $error) {
            ActivityLog::record(
                $user,
                'email_verification_email_failed',
                "Email verification link could not be sent to {$user->email}.",
                $request,
                ['error' => $error->getMessage()],
            );

            return false;
        }
    }

    private function syncEmailVerificationReminder(User $user, bool $emailSent): void
    {
        if ($user->hasVerifiedEmail()) {
            return;
        }

        PortalNotification::updateOrCreate([
            'user_id' => $user->id,
            'type' => 'email_verification',
            'title' => 'Verify your email address',
        ], [
            'message' => $emailSent
                ? 'A verification link was sent to your email. Verify your email to secure your account.'
                : 'Your email is not verified yet. Resend the verification link when mail settings are available.',
            'action_url' => null,
            'read_at' => null,
        ]);
    }
}

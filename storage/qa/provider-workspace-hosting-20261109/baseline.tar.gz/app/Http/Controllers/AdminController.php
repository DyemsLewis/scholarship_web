<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\ApplicantVerificationDocument;
use App\Models\ApplicationDocument;
use App\Models\PortalNotification;
use App\Models\ProviderVerificationDocument;
use App\Models\RecipientBenefitReceiptResponse;
use App\Models\RecipientBenefitReleaseRecord;
use App\Models\RecipientMonitoringAdjustmentRequest;
use App\Models\RecipientMonitoringCase;
use App\Models\RecipientMonitoringOversightReview;
use App\Models\RecipientMonitoringSubmission;
use App\Models\RecipientSupportDecision;
use App\Models\Scholarship;
use App\Models\ScholarshipApplication;
use App\Models\StudentProfile;
use App\Models\User;
use App\Rules\PhoneNumber;
use App\Services\AcademicRecordOcrService;
use App\Services\ApplicantEvidenceReviewService;
use App\Services\DecisionSupportService;
use App\Services\PasswordResetLinkService;
use App\Services\ProviderVerificationReviewService;
use App\Services\RecipientMonitoringCaseService;
use App\Services\ScholarshipPublicationGuard;
use App\Support\AcademicRequirement;
use App\Support\AdminWorkspace;
use App\Support\CsvExport;
use App\Support\EducationEligibilityPolicy;
use App\Support\ScholarshipEventPayload;
use App\Support\ScholarshipSelectionPlan;
use Illuminate\Auth\Events\Verified;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Throwable;

class AdminController extends Controller
{
    public function __construct(
        private readonly AcademicRecordOcrService $academicRecordOcrService,
        private readonly RecipientMonitoringCaseService $monitoringCaseService,
    ) {}

    private const ADMIN_ROLE_PERMISSION_PRESETS = [
        'Account manager' => ['manage_accounts'],
        'Review officer' => ['manage_reviews'],
        'Support officer' => ['manage_reports'],
        'Billing officer' => ['manage_billing'],
        'Finance officer' => ['view_finance'],
        'Records officer' => ['view_logs', 'export_data'],
        'Portal manager' => ['manage_accounts', 'manage_reviews', 'manage_reports', 'manage_billing', 'view_finance', 'view_logs', 'export_data'],
    ];

    public function index(Request $request): View|RedirectResponse
    {
        if (! $request->user()) {
            return redirect()->route('login');
        }

        abort_unless($request->user()->isAdmin(), 403);

        if ($workspaceRoute = AdminWorkspace::preferredRouteName($request->user())) {
            return redirect()->route($workspaceRoute);
        }

        return view('admin');
    }

    public function dashboardData(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);

        $canManageAccounts = $request->user()->hasPortalPermission('manage_accounts');
        $canManageReviews = $request->user()->hasPortalPermission('manage_reviews');
        $today = now()->startOfDay();
        $deadlineLimit = now()->addDays(30)->endOfDay();
        $recentUsers = $canManageAccounts
            ? User::query()
                ->with(['studentProfile', 'providerProfile', 'adminProfile'])
                ->latest()
                ->limit(4)
                ->get(['id', 'email', 'username', 'role', 'created_at'])
            : collect();
        $recentScholarships = $canManageReviews
            ? Scholarship::query()
                ->with('provider.providerProfile')
                ->latest('updated_at')
                ->limit(3)
                ->get()
            : collect();

        return response()->json([
            'stats' => [
                'pending_providers' => $canManageReviews ? User::query()
                    ->where('role', 'provider')
                    ->whereNull('parent_account_id')
                    ->whereHas('providerProfile', fn ($query) => $query->where('verification_status', 'pending'))
                    ->count() : 0,
                'documents_pending_review' => $canManageReviews ? ApplicationDocument::query()->where('status', 'pending')->count() : 0,
                'documents_needing_replacement' => $canManageReviews ? ApplicationDocument::query()->where('status', 'needs_replacement')->count() : 0,
                'upcoming_deadlines' => $canManageReviews ? Scholarship::query()
                    ->where('status', 'published')
                    ->whereDate('deadline', '>=', $today->toDateString())
                    ->whereDate('deadline', '<=', $deadlineLimit->toDateString())
                    ->count() : 0,
                'expired_published' => $canManageReviews ? Scholarship::query()
                    ->where('status', 'published')
                    ->whereDate('deadline', '<', $today->toDateString())
                    ->count() : 0,
                'needs_review_applications' => $canManageReviews ? ScholarshipApplication::query()
                    ->where('dss_recommendation', 'needs_review')
                    ->count() : 0,
            ],
            'recent_users' => $recentUsers->map(fn (User $user) => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role,
                'created_at' => $user->created_at?->format('M d, Y'),
            ])->values(),
            'recent_scholarships' => $recentScholarships->map(fn (Scholarship $scholarship) => [
                'id' => $scholarship->id,
                'title' => $scholarship->title,
                'provider' => $scholarship->provider?->provider_name ?? $scholarship->provider?->name,
                'image_url' => $this->scholarshipImageUrl($scholarship),
                'status' => $scholarship->status,
                'updated_at' => $scholarship->updated_at?->format('M d, Y'),
            ])->values(),
        ]);
    }

    public function manageUsers(Request $request): View|RedirectResponse
    {
        if (! $request->user()) {
            return redirect()->route('login');
        }

        abort_unless($request->user()->isAdmin(), 403);

        if (AdminWorkspace::usesAccountManagerWorkspace($request->user())) {
            return redirect()->route('admin.workspaces.accounts.directory');
        }

        if (AdminWorkspace::usesPortalManagerWorkspace($request->user())) {
            return redirect()->route('admin.workspaces.portal.accounts');
        }

        return view('admin-users');
    }

    public function accountForm(Request $request, ?User $user = null): View|RedirectResponse
    {
        if (! $request->user()) {
            return redirect()->route('login');
        }

        abort_unless($request->user()->isAdmin(), 403);

        if (AdminWorkspace::usesAccountManagerWorkspace($request->user())) {
            return redirect()->route(
                $user ? 'admin.workspaces.accounts.show' : 'admin.workspaces.accounts.create',
                $user ? ['user' => $user->id] : [],
            );
        }

        if (AdminWorkspace::usesPortalManagerWorkspace($request->user())) {
            return redirect()->route('admin.workspaces.portal.accounts', $user ? ['account' => $user->id] : ['create' => 1]);
        }

        if ($user) {
            $this->authorizeAdminAccountTarget($request->user(), $user);
        }

        return view('admin-account-form');
    }

    public function accountManagerWorkspace(Request $request): View|RedirectResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($request->user()->hasPortalPermission('manage_accounts'), 403);

        return view('admin-account-manager-workspace');
    }

    public function accountManagerWorkspaceData(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($request->user()->hasPortalPermission('manage_accounts'), 403);

        $validated = $request->validate([
            'search' => ['sometimes', 'nullable', 'string', 'max:120'],
            'role' => ['sometimes', 'nullable', Rule::in(['all', 'applicant', 'provider', 'admin'])],
            'attention' => ['sometimes', 'nullable', Rule::in(['all', 'unverified', 'password_reset', 'suspended'])],
            'page' => ['sometimes', 'integer', 'min:1'],
            'per_page' => ['sometimes', 'integer', 'min:5', 'max:50'],
        ]);

        return response()->json($this->accountDirectoryPayload($request, $validated));
    }

    public function profile(Request $request): View|RedirectResponse
    {
        if (! $request->user()) {
            return redirect()->route('login');
        }

        abort_unless($request->user()->isAdmin(), 403);

        return view('admin-profile');
    }

    public function reviews(Request $request): View|RedirectResponse
    {
        if (! $request->user()) {
            return redirect()->route('login');
        }

        abort_unless($request->user()->isAdmin(), 403);

        if (AdminWorkspace::usesReviewOfficerWorkspace($request->user())) {
            $route = match ($request->query('type')) {
                'providers' => 'admin.workspaces.reviews.providers',
                'programs' => 'admin.workspaces.reviews.programs',
                'applicants' => 'admin.workspaces.reviews.applicants',
                'benefits' => 'admin.workspaces.reviews.benefits',
                'monitoring' => 'admin.workspaces.reviews.monitoring',
                default => AdminWorkspace::REVIEW_OFFICER_ROUTE,
            };

            return redirect()->route($route);
        }

        if (AdminWorkspace::usesPortalManagerWorkspace($request->user())) {
            $query = $request->query('type') ? ['type' => $request->query('type')] : [];

            return redirect()->route('admin.workspaces.portal.reviews', $query);
        }

        return view('admin-reviews');
    }

    public function reviewOfficerWorkspace(Request $request): View|RedirectResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($request->user()->hasPortalPermission('manage_reviews'), 403);

        return view('admin-review-officer-workspace');
    }

    public function reviewOfficerWorkspaceData(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($request->user()->hasPortalPermission('manage_reviews'), 403);

        return $this->reviewsData($request);
    }

    public function reviewOfficerProviderReview(Request $request, User $provider): View|RedirectResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($request->user()->hasPortalPermission('manage_reviews'), 403);
        abort_unless($provider->isProvider() && ! $provider->isManagedAccount(), 404);

        return view('admin-provider-review', ['provider' => $provider]);
    }

    public function reviewOfficerProgramReview(Request $request, Scholarship $scholarship): View|RedirectResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($request->user()->hasPortalPermission('manage_reviews'), 403);

        return view('admin-program-review', ['scholarship' => $scholarship]);
    }

    public function reviewOfficerApplicantReview(Request $request, User $applicant): View|RedirectResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($request->user()->hasPortalPermission('manage_reviews'), 403);
        abort_unless($applicant->isApplicant(), 404);

        return view('admin-applicant-review', ['applicant' => $applicant]);
    }

    public function reviewOfficerMonitoringReview(Request $request, ScholarshipApplication $application): View|RedirectResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($request->user()->hasPortalPermission('manage_reviews'), 403);
        abort_unless($this->isRecipientMonitoringRecord($application), 404);

        return view('admin-monitoring-review', ['application' => $application]);
    }

    public function monitoringReview(
        Request $request,
        ScholarshipApplication $application,
    ): View|RedirectResponse {
        if (! $request->user()) {
            return redirect()->route('login');
        }

        abort_unless($request->user()->isAdmin(), 403);
        abort_unless($this->isRecipientMonitoringRecord($application), 404);

        if (AdminWorkspace::usesReviewOfficerWorkspace($request->user())) {
            return redirect()->route('admin.workspaces.reviews.monitoring.show', array_merge(
                $request->query(),
                ['application' => $application],
            ));
        }

        if (AdminWorkspace::usesPortalManagerWorkspace($request->user())) {
            return redirect()->route('admin.workspaces.portal.reviews.monitoring.show', array_merge(
                $request->query(),
                ['application' => $application],
            ));
        }

        return view('admin-monitoring-review', [
            'application' => $application,
        ]);
    }

    public function providerReview(Request $request, User $provider): View|RedirectResponse
    {
        if (! $request->user()) {
            return redirect()->route('login');
        }

        abort_unless($request->user()->isAdmin(), 403);
        abort_unless($provider->isProvider() && ! $provider->isManagedAccount(), 404);

        if (AdminWorkspace::usesReviewOfficerWorkspace($request->user())) {
            return redirect()->route('admin.workspaces.reviews.providers.show', array_merge(
                $request->query(),
                ['provider' => $provider],
            ));
        }

        if (AdminWorkspace::usesPortalManagerWorkspace($request->user())) {
            return redirect()->route('admin.workspaces.portal.reviews.providers.show', array_merge(
                $request->query(),
                ['provider' => $provider],
            ));
        }

        return view('admin-provider-review', [
            'provider' => $provider,
        ]);
    }

    public function applicantReview(Request $request, User $applicant): View|RedirectResponse
    {
        if (! $request->user()) {
            return redirect()->route('login');
        }

        abort_unless($request->user()->isAdmin(), 403);
        abort_unless($applicant->isApplicant(), 404);

        if (AdminWorkspace::usesReviewOfficerWorkspace($request->user())) {
            return redirect()->route('admin.workspaces.reviews.applicants.show', array_merge(
                $request->query(),
                ['applicant' => $applicant],
            ));
        }

        if (AdminWorkspace::usesPortalManagerWorkspace($request->user())) {
            return redirect()->route('admin.workspaces.portal.reviews.applicants.show', array_merge(
                $request->query(),
                ['applicant' => $applicant],
            ));
        }

        return view('admin-review-applicant-record', [
            'applicant' => $applicant,
        ]);
    }

    public function scholarshipReview(Request $request, Scholarship $scholarship): View|RedirectResponse
    {
        if (! $request->user()) {
            return redirect()->route('login');
        }

        abort_unless($request->user()->isAdmin(), 403);

        if (AdminWorkspace::usesReviewOfficerWorkspace($request->user())) {
            return redirect()->route('admin.workspaces.reviews.programs.show', array_merge(
                $request->query(),
                ['scholarship' => $scholarship],
            ));
        }

        if (AdminWorkspace::usesPortalManagerWorkspace($request->user())) {
            return redirect()->route('admin.workspaces.portal.reviews.programs.show', array_merge(
                $request->query(),
                ['scholarship' => $scholarship],
            ));
        }

        return view('admin-program-review', [
            'scholarship' => $scholarship,
        ]);
    }

    public function logs(Request $request): View|RedirectResponse
    {
        if (! $request->user()) {
            return redirect()->route('login');
        }

        abort_unless($request->user()->isAdmin(), 403);

        if (AdminWorkspace::usesRecordsOfficerWorkspace($request->user())) {
            return redirect()->route('admin.workspaces.records.activity', $request->query());
        }

        if (AdminWorkspace::usesPortalManagerWorkspace($request->user())) {
            return redirect()->route('admin.workspaces.portal.records.activity', $request->query());
        }

        return view('admin-logs');
    }

    public function recordsOfficerActivity(Request $request): View
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($request->user()->hasPortalPermission('view_logs'), 403);

        return view('admin-records-officer-workspace');
    }

    public function recordsOfficerActivityData(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($request->user()->hasPortalPermission('view_logs'), 403);

        return $this->logEntries($request);
    }

    public function recordsOfficerExports(Request $request): View
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($request->user()->hasPortalPermission('export_data'), 403);

        return view('admin-records-officer-workspace');
    }

    public function users(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);

        $validated = $request->validate([
            'search' => ['sometimes', 'nullable', 'string', 'max:120'],
            'role' => ['sometimes', 'nullable', Rule::in(['all', 'applicant', 'provider', 'admin'])],
            'page' => ['sometimes', 'integer', 'min:1'],
            'per_page' => ['sometimes', 'integer', 'min:5', 'max:50'],
        ]);

        return response()->json($this->accountDirectoryPayload($request, $validated));
    }

    private function accountDirectoryPayload(Request $request, array $validated): array
    {
        $search = trim((string) ($validated['search'] ?? ''));
        $role = $validated['role'] ?? 'all';
        $attention = $validated['attention'] ?? 'all';
        $perPage = (int) ($validated['per_page'] ?? 10);
        $visibleUsers = User::query()
            ->when($request->user()->isManagedAccount(), fn ($query) => $query->where('role', '!=', 'admin'));
        $roleCounts = (clone $visibleUsers)
            ->selectRaw('role, count(*) as total')
            ->groupBy('role')
            ->pluck('total', 'role');
        $totalUsers = (int) $roleCounts->sum();

        $query = (clone $visibleUsers)
            ->with(['studentProfile', 'providerProfile', 'adminProfile'])
            ->latest();

        if ($role !== 'all') {
            $query->where('role', $role);
        }

        match ($attention) {
            'unverified' => $query->whereNull('email_verified_at'),
            'password_reset' => $query->where('must_reset_password', true),
            'suspended' => $query->where('account_status', 'suspended'),
            default => null,
        };

        if ($search !== '') {
            $likeSearch = '%'.$search.'%';

            $query->where(function ($query) use ($likeSearch): void {
                $query
                    ->where('account_status', 'like', $likeSearch)
                    ->orWhere('email', 'like', $likeSearch)
                    ->orWhere('username', 'like', $likeSearch)
                    ->orWhere('role', 'like', $likeSearch)
                    ->orWhereHas('studentProfile', fn ($profileQuery) => $profileQuery
                        ->where('first_name', 'like', $likeSearch)
                        ->orWhere('last_name', 'like', $likeSearch)
                        ->orWhere('contact_number', 'like', $likeSearch)
                    )
                    ->orWhereHas('providerProfile', fn ($profileQuery) => $profileQuery
                        ->where('first_name', 'like', $likeSearch)
                        ->orWhere('last_name', 'like', $likeSearch)
                        ->orWhere('contact_number', 'like', $likeSearch)
                        ->orWhere('provider_name', 'like', $likeSearch)
                    )
                    ->orWhereHas('adminProfile', fn ($profileQuery) => $profileQuery
                        ->where('first_name', 'like', $likeSearch)
                        ->orWhere('last_name', 'like', $likeSearch)
                        ->orWhere('contact_number', 'like', $likeSearch)
                        ->orWhere('display_name', 'like', $likeSearch)
                    );
            });
        }

        $users = $query->paginate($perPage);

        return [
            'stats' => [
                'total_users' => $totalUsers,
                'admins' => (int) ($roleCounts['admin'] ?? 0),
                'applicants' => (int) ($roleCounts['applicant'] ?? 0),
                'providers' => (int) ($roleCounts['provider'] ?? 0),
                'active_users' => (clone $visibleUsers)->where('account_status', '!=', 'suspended')->count(),
                'recent_signups' => (clone $visibleUsers)->where('created_at', '>=', now()->subDays(7))->count(),
                'unverified_users' => (clone $visibleUsers)->whereNull('email_verified_at')->count(),
                'suspended_users' => (clone $visibleUsers)->where('account_status', 'suspended')->count(),
                'password_resets_required' => (clone $visibleUsers)->where('must_reset_password', true)->count(),
                'attention_total' => (clone $visibleUsers)
                    ->where(function ($query): void {
                        $query
                            ->whereNull('email_verified_at')
                            ->orWhere('must_reset_password', true)
                            ->orWhere('account_status', 'suspended');
                    })
                    ->count(),
            ],
            'users' => $users->getCollection()->map(fn (User $user) => [
                ...$user->publicPayload(),
                'created_at' => $user->created_at?->format('M d, Y'),
            ])->values(),
            'pagination' => [
                'current_page' => $users->currentPage(),
                'last_page' => $users->lastPage(),
                'per_page' => $users->perPage(),
                'total' => $users->total(),
                'from' => $users->firstItem(),
                'to' => $users->lastItem(),
            ],
        ];
    }

    public function showUser(Request $request, User $user): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        $this->authorizeAdminAccountTarget($request->user(), $user);

        return response()->json([
            'user' => $user->loadMissing(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload(),
            'verification_documents' => $user->isApplicant()
                ? $user->applicantVerificationDocuments()
                    ->whereIn('document_type', ApplicantVerificationDocument::PROFILE_EVIDENCE_TYPES)
                    ->latest('uploaded_at')
                    ->get()
                    ->map(fn (ApplicantVerificationDocument $document) => $this->applicantVerificationDocumentPayload($document))
                    ->values()
                : [],
        ]);
    }

    public function profileData(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);

        return response()->json([
            'user' => $request->user()->loadMissing(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload(),
        ]);
    }

    public function updateProfile(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);

        $user = $request->user();
        $validated = $request->validate([
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'middle_initial' => ['nullable', 'string', 'size:1', 'regex:/^[A-Za-z]$/'],
            'display_name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', Rule::unique('users', 'email')->ignore($user->id)],
            'username' => ['required', 'string', 'min:4', 'max:255', 'regex:/^[A-Za-z0-9_.-]+$/', Rule::unique('users', 'username')->ignore($user->id)],
            'contact_number' => ['required', 'string', 'max:30', new PhoneNumber],
        ]);

        $middleInitial = filled($validated['middle_initial'] ?? null) ? strtoupper($validated['middle_initial']) : null;

        $user->update([
            'email' => $validated['email'],
            'username' => $validated['username'],
        ]);

        $user->adminProfile()->updateOrCreate([
            'user_id' => $user->id,
        ], [
            'first_name' => $validated['first_name'],
            'last_name' => $validated['last_name'],
            'middle_initial' => $middleInitial,
            'contact_number' => $validated['contact_number'],
            'display_name' => $validated['display_name'],
        ]);

        ActivityLog::record(
            $user,
            'admin_profile_updated',
            "{$validated['display_name']} updated their admin profile.",
            $request,
            ['admin_id' => $user->id],
        );

        return response()->json([
            'message' => 'Admin profile updated successfully.',
            'user' => $user->fresh(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload(),
        ]);
    }

    public function providerReviewData(Request $request, User $provider): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($provider->isProvider() && ! $provider->isManagedAccount(), 404);

        $provider->loadMissing(['providerProfile', 'providerVerificationDocuments']);
        $provider->loadCount([
            'managedAccounts',
            'providerScholarships',
            'providerScholarships as published_programs_count' => fn ($query) => $query->where('status', 'published'),
            'providerScholarships as programs_in_review_count' => fn ($query) => $query->where('status', 'pending_review'),
        ]);

        return response()->json([
            'provider' => $this->providerReviewPayload($provider),
        ]);
    }

    public function applicantReviewData(Request $request, User $applicant): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($applicant->isApplicant(), 404);

        $applicant->loadMissing([
            'studentProfile.verifier.adminProfile',
            'studentProfile.verifier.providerProfile',
            'studentProfile.verifier.parentAccount.providerProfile',
            'applicantVerificationDocuments',
        ]);

        return response()->json([
            'applicant' => $this->applicantReviewPayload($applicant, true),
        ]);
    }

    public function reviewsData(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);

        $programStatuses = ['pending_review', 'published', 'rejected'];
        $programStatus = $request->query('program_status', 'pending_review');

        if (! is_string($programStatus) || ! in_array($programStatus, $programStatuses, true)) {
            $programStatus = 'pending_review';
        }

        $providers = User::query()
            ->with(['providerProfile', 'providerVerificationDocuments'])
            ->withCount([
                'managedAccounts',
                'providerScholarships',
                'providerScholarships as published_programs_count' => fn ($query) => $query->where('status', 'published'),
                'providerScholarships as programs_in_review_count' => fn ($query) => $query->where('status', 'pending_review'),
            ])
            ->where('role', 'provider')
            ->whereNull('parent_account_id')
            ->latest()
            ->get(['id', 'email', 'username', 'role', 'created_at']);
        $applicants = User::query()
            ->with([
                'studentProfile.verifier.adminProfile',
                'studentProfile.verifier.providerProfile',
                'studentProfile.verifier.parentAccount.providerProfile',
                'applicantVerificationDocuments',
            ])
            ->where('role', 'applicant')
            ->latest()
            ->get(['id', 'email', 'username', 'role', 'created_at']);
        $programStatusCounts = Scholarship::query()
            ->whereIn('status', $programStatuses)
            ->selectRaw('status, COUNT(*) as aggregate')
            ->groupBy('status')
            ->pluck('aggregate', 'status');
        $scholarships = Scholarship::query()
            ->with(['provider.providerProfile', 'events'])
            ->withCount('bookmarks')
            ->where('status', $programStatus)
            ->latest('updated_at')
            ->limit(12)
            ->get();
        $benefitRecords = RecipientBenefitReleaseRecord::query()
            ->with([
                'release.scholarship.provider.providerProfile',
                'application',
                'applicant.studentProfile',
                'recorder.providerProfile',
                'recorder.parentAccount.providerProfile',
            ])
            ->latest('updated_at')
            ->limit(200)
            ->get()
            ->map(fn (RecipientBenefitReleaseRecord $record): array => $this->benefitOversightPayload($record))
            ->values();
        $monitoringRecords = $this->monitoringOversightQuery()
            ->latest('updated_at')
            ->limit(200)
            ->get()
            ->map(fn (ScholarshipApplication $application): array => $this->monitoringOversightPayload($application))
            ->values();

        return response()->json([
            'stats' => [
                'providers' => $providers->count(),
                'pending_providers' => $providers->filter(fn (User $user) => $user->providerProfile?->verification_status === 'pending')->count(),
                'approved_providers' => $providers->filter(fn (User $user) => $user->providerProfile?->verification_status === 'approved')->count(),
                'rejected_providers' => $providers->filter(fn (User $user) => $user->providerProfile?->verification_status === 'rejected')->count(),
                'applicants' => $applicants->count(),
                'pending_applicants' => $applicants->filter(fn (User $user) => $user->applicantVerificationDocuments->contains('document_type', 'academic_record')
                    && ! in_array($user->studentProfile?->verification_status, ['approved', 'rejected'], true))->count(),
                'approved_applicants' => $applicants->filter(fn (User $user) => $user->applicantVerificationDocuments->contains('document_type', 'academic_record')
                    && $user->studentProfile?->verification_status === 'approved')->count(),
                'rejected_applicants' => $applicants->filter(fn (User $user) => $user->applicantVerificationDocuments->contains('document_type', 'academic_record')
                    && $user->studentProfile?->verification_status === 'rejected')->count(),
                'unsubmitted_applicants' => $applicants->filter(fn (User $user) => ! $user->applicantVerificationDocuments->contains('document_type', 'academic_record'))->count(),
                'applicant_proofs' => $applicants->sum(fn (User $user) => $user->applicantVerificationDocuments
                    ->whereIn('document_type', ApplicantVerificationDocument::PROFILE_EVIDENCE_TYPES)->count()),
                'pending_programs' => (int) ($programStatusCounts['pending_review'] ?? 0),
                'published_programs' => (int) ($programStatusCounts['published'] ?? 0),
                'rejected_programs' => (int) ($programStatusCounts['rejected'] ?? 0),
                'benefit_records' => $benefitRecords->count(),
                'benefits_released' => $benefitRecords->where('status', 'released')->count(),
                'benefits_with_receipts' => $benefitRecords->where('evidence_type', 'receipt')->count(),
                'benefits_note_only' => $benefitRecords->where('evidence_type', 'note')->count(),
                'benefits_needing_attention' => $benefitRecords->where('oversight_status', 'attention')->count(),
                'monitoring_records' => $monitoringRecords->count(),
                'monitoring_needing_attention' => $monitoringRecords->where('oversight_status', 'attention')->count(),
                'monitoring_reviewed' => $monitoringRecords->where('oversight_status', 'reviewed')->count(),
                'monitoring_stable' => $monitoringRecords->where('oversight_status', 'stable')->count(),
                'monitoring_closed' => $monitoringRecords->where('oversight_status', 'closed')->count(),
            ],
            'providers' => $providers->map(fn (User $user) => $this->providerReviewPayload($user))->values(),
            'applicants' => $applicants->map(fn (User $user) => $this->applicantReviewPayload($user))->values(),
            'scholarships' => $scholarships->map(fn (Scholarship $scholarship) => $this->scholarshipReviewPayload($scholarship))->values(),
            'benefit_records' => $benefitRecords,
            'monitoring_records' => $monitoringRecords,
            'selected_program_status' => $programStatus,
        ]);
    }

    public function monitoringReviewData(
        Request $request,
        ScholarshipApplication $application,
    ): JsonResponse {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($this->isRecipientMonitoringRecord($application), 404);

        if ($case = $this->requestedMonitoringCase($request, $application)) {
            return response()->json([
                'record' => $this->monitoringCaseOversightPayload($case),
            ]);
        }

        $application->load($this->monitoringOversightRelations());

        return response()->json([
            'record' => $this->monitoringOversightPayload($application, true),
        ]);
    }

    public function storeMonitoringOversightReview(
        Request $request,
        ScholarshipApplication $application,
    ): JsonResponse {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($this->isRecipientMonitoringRecord($application), 404);

        $validated = $request->validate([
            'outcome' => ['required', Rule::in(['reviewed', 'follow_up_required', 'escalated'])],
            'notes' => [Rule::requiredIf($request->input('outcome') !== 'reviewed'), 'nullable', 'string', 'max:2000'],
        ]);

        $case = $this->requestedMonitoringCase($request, $application);
        $application->load($this->monitoringOversightRelations());
        $current = $case
            ? $this->monitoringCaseOversightPayload($case)
            : $this->monitoringOversightPayload($application);
        $review = $application->monitoringOversightReviews()->create([
            'reviewed_by' => $request->user()->id,
            'outcome' => $validated['outcome'],
            'notes' => $validated['notes'] ?? null,
            'flags_snapshot' => $case
                ? ['case_id' => $case->id, 'items' => $current['attention_items']]
                : $current['attention_items'],
            'reviewed_at' => now(),
        ]);

        if (in_array($validated['outcome'], ['follow_up_required', 'escalated'], true)) {
            $application->loadMissing('scholarship.provider');
            $this->monitoringProviderRecipients(
                $application->scholarship,
                $validated['outcome'] === 'escalated',
            )->each(function (User $provider) use ($application, $review, $validated): void {
                PortalNotification::create([
                    'user_id' => $provider->id,
                    'type' => 'monitoring_oversight_review',
                    'title' => $validated['outcome'] === 'escalated'
                        ? 'Monitoring record escalated'
                        : 'Monitoring follow-up requested',
                    'message' => $application->scholarship?->title.': '.($validated['notes'] ?? 'Review the recipient monitoring record.'),
                    'action_url' => route('provider.monitoring.show', $application->scholarship, false),
                    'deduplication_key' => "monitoring-oversight-review:{$review->id}:{$provider->id}",
                ]);
            });
        }

        ActivityLog::record(
            $request->user(),
            'recipient_monitoring_oversight_recorded',
            "{$request->user()->name} recorded a monitoring oversight outcome.",
            $request,
            [
                'scholarship_application_id' => $application->id,
                'recipient_monitoring_case_id' => $case?->id,
                'oversight_review_id' => $review->id,
                'outcome' => $validated['outcome'],
            ],
        );

        $application->load($this->monitoringOversightRelations());

        return response()->json([
            'message' => 'Oversight review recorded.',
            'record' => $case
                ? $this->monitoringCaseOversightPayload($case->fresh())
                : $this->monitoringOversightPayload($application, true),
        ], 201);
    }

    public function viewBenefitReleaseReceipt(
        Request $request,
        RecipientBenefitReleaseRecord $record,
    ) {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless(filled($record->receipt_path) && Storage::disk('local')->exists($record->receipt_path), 404);

        return Storage::disk('local')->response($record->receipt_path, $record->receipt_original_name, [
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    public function viewMonitoringSubmission(Request $request, RecipientMonitoringSubmission $submission)
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless(filled($submission->path) && Storage::disk('local')->exists($submission->path), 404);

        return $this->privateMonitoringFileResponse($submission->path, $submission->original_name);
    }

    public function viewMonitoringAdjustmentAttachment(
        Request $request,
        RecipientMonitoringAdjustmentRequest $adjustment,
    ) {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless(filled($adjustment->attachment_path) && Storage::disk('local')->exists($adjustment->attachment_path), 404);

        return $this->privateMonitoringFileResponse($adjustment->attachment_path, $adjustment->attachment_original_name);
    }

    public function viewBenefitReceiptResponseFile(
        Request $request,
        RecipientBenefitReceiptResponse $response,
        string $kind,
    ) {
        abort_unless($request->user()?->isAdmin(), 403);
        [$path, $name] = $kind === 'resolution-proof'
            ? [$response->resolution_proof_path, $response->resolution_proof_original_name]
            : [$response->evidence_path, $response->evidence_original_name];
        abort_unless(filled($path) && Storage::disk('local')->exists($path), 404);

        return $this->privateMonitoringFileResponse($path, $name);
    }

    public function viewSupportDecisionFile(
        Request $request,
        RecipientSupportDecision $decision,
        string $kind,
    ) {
        abort_unless($request->user()?->isAdmin(), 403);
        [$path, $name] = match ($kind) {
            'applicant-response' => [$decision->applicant_response_path, $decision->applicant_response_original_name],
            'resolution-proof' => [$decision->resolution_proof_path, $decision->resolution_proof_original_name],
            default => [$decision->decision_document_path, $decision->decision_document_original_name],
        };
        abort_unless(filled($path) && Storage::disk('local')->exists($path), 404);

        return $this->privateMonitoringFileResponse($path, $name);
    }

    public function scholarshipReviewData(Request $request, Scholarship $scholarship): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);

        $scholarship->loadMissing(['provider.providerProfile', 'events']);
        $scholarship->loadCount('bookmarks');

        return response()->json([
            'scholarship' => $this->scholarshipReviewPayload($scholarship),
        ]);
    }

    public function updateScholarshipReview(Request $request, Scholarship $scholarship): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);

        $validated = $request->validate([
            'status' => ['required', Rule::in(['pending_review', 'published', 'rejected'])],
            'review_notes' => [Rule::requiredIf($request->input('status') === 'rejected'), 'nullable', 'string', 'max:1500'],
        ]);

        $allowedFrom = match ($validated['status']) {
            'published' => ['pending_review', 'published'],
            'rejected' => ['pending_review', 'published', 'rejected'],
            'pending_review' => ['pending_review', 'published', 'rejected'],
        };

        [$scholarship, $previousStatus] = DB::transaction(function () use ($scholarship, $validated, $allowedFrom): array {
            $lockedScholarship = Scholarship::query()
                ->whereKey($scholarship->id)
                ->lockForUpdate()
                ->firstOrFail();

            if (! in_array($lockedScholarship->status, $allowedFrom, true)) {
                throw ValidationException::withMessages([
                    'status' => 'Only a program that has entered admin review can receive this decision.',
                ]);
            }

            if ($validated['status'] === 'published') {
                app(ScholarshipPublicationGuard::class)->assertPublishable($lockedScholarship);
            }

            $previousStatus = $lockedScholarship->status;
            $lockedScholarship->update(['status' => $validated['status']]);

            return [$lockedScholarship, $previousStatus];
        });

        ActivityLog::record(
            $request->user(),
            'scholarship_review_updated',
            "{$request->user()->name} marked scholarship {$scholarship->title} as {$this->labelFromKey($validated['status'])}.",
            $request,
            [
                'scholarship_id' => $scholarship->id,
                'from_status' => $previousStatus,
                'to_status' => $validated['status'],
                'review_notes' => $validated['review_notes'] ?? null,
            ],
        );

        $reviewMessage = "Your scholarship {$scholarship->title} is now {$this->labelFromKey($validated['status'])}.";

        if ($validated['status'] === 'rejected') {
            $reviewMessage .= " Reason: {$validated['review_notes']}";
        }

        $this->providerNotificationRecipients($scholarship->provider_id, 'manage_programs')
            ->each(fn (User $provider) => PortalNotification::create([
                'user_id' => $provider->id,
                'type' => 'scholarship_review',
                'title' => 'Scholarship review updated',
                'message' => $reviewMessage,
                'action_url' => '/provider/programs',
            ]));

        return response()->json([
            'message' => 'Scholarship review updated.',
            'scholarship' => $this->scholarshipReviewPayload(
                $scholarship->fresh(['provider.providerProfile', 'events']),
            ),
        ]);
    }

    public function updateProviderVerification(Request $request, User $provider): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($provider->isProvider() && ! $provider->isManagedAccount(), 404);

        if (is_string($request->input('verification_notes'))) {
            $request->merge(['verification_notes' => trim($request->input('verification_notes'))]);
        }

        $validated = $request->validate([
            'verification_status' => ['required', 'string', 'in:pending,approved,rejected'],
            'verification_notes' => [Rule::requiredIf($request->input('verification_status') === 'rejected'), 'nullable', 'string', 'max:1500'],
            'expected_review_token' => ['required', 'string', 'size:64'],
        ]);
        $provider = app(ProviderVerificationReviewService::class)->decide($request, $provider, $validated);

        return response()->json([
            'message' => 'Provider verification updated.',
            'provider' => $this->providerReviewPayload($provider),
        ]);
    }

    public function updateApplicantVerification(Request $request, User $applicant): JsonResponse
    {
        return DB::transaction(function () use ($request, $applicant): JsonResponse {
            $applicant = User::query()->lockForUpdate()->findOrFail($applicant->id);
            abort_unless($request->user()?->isAdmin(), 403);
            abort_unless($applicant->isApplicant(), 404);

            $applicant->loadMissing(['studentProfile', 'applicantVerificationDocuments']);
            $previousStatus = $applicant->applicantAcademicVerificationStatus();
            $requestedStatus = $request->input('verification_status');
            $isReopening = $previousStatus === 'approved' && $requestedStatus === 'pending';

            $validated = $request->validate([
                'verification_status' => ['required', Rule::in(['pending', 'approved', 'rejected'])],
                'verification_notes' => [
                    Rule::requiredIf($requestedStatus === 'rejected' || $isReopening),
                    'nullable',
                    'string',
                    'max:1500',
                ],
                'academic_grading_scale' => ['prohibited'],
                'academic_result' => ['prohibited'],
            ]);

            $academicRecord = $applicant->applicantVerificationDocuments
                ->firstWhere('document_type', 'academic_record');

            if ($validated['verification_status'] === 'approved' && ! $applicant->applicantVerificationDocuments()
                ->where('document_type', 'academic_record')
                ->exists()) {
                return response()->json([
                    'message' => 'The applicant must upload an academic record before the academic result can be verified.',
                ], 422);
            }

            if ($validated['verification_status'] === 'approved' && $this->academicRecordOcrService->configured()) {
                if ($academicRecord?->ocr_status !== AcademicRecordOcrService::STATUS_SUCCEEDED
                    && $applicant->studentProfile?->academic_result_source !== 'admin_review') {
                    return response()->json([
                        'message' => 'Review the Academic results in the academic evidence before recording the final profile outcome.',
                    ], 422);
                }
            }

            if ($validated['verification_status'] === 'approved' && ! $applicant->applicantVerificationDocuments()
                ->where('document_type', 'recent_school_id')
                ->exists()) {
                return response()->json([
                    'message' => 'The applicant must upload a recent school ID before the profile can be verified.',
                ], 422);
            }

            if ($validated['verification_status'] === 'approved') {
                $missingEvidence = ApplicantVerificationDocument::missingRequiredTypesFor($applicant);

                if ($missingEvidence !== []) {
                    return response()->json([
                        'message' => 'Upload all required profile evidence before verification: '.collect($missingEvidence)
                            ->map(fn (string $type): string => ApplicantVerificationDocument::EVIDENCE_DETAILS[$type]['label'])
                            ->implode(', ').'.',
                        'missing_evidence' => $missingEvidence,
                    ], 422);
                }
            }

            if ($validated['verification_status'] === 'approved') {
                app(ApplicantEvidenceReviewService::class)->assertReady($applicant);
                $scale = $applicant->studentProfile?->grading_scale;
                validator([
                    'academic_grading_scale' => $scale,
                    'academic_result' => $applicant->studentProfile?->gwa,
                ], [
                    'academic_grading_scale' => ['required', Rule::in(AcademicRequirement::SCALES)],
                    'academic_result' => AcademicRequirement::requiresNumeric($scale)
                        ? ['required', 'numeric', 'gt:0', $scale === 'grade_point' ? 'max:5' : 'max:100'] : ['nullable'],
                ], ['*.required' => 'Complete the Academic results review in the academic evidence first.'])->validate();
            }
            if ($isReopening) {
                app(ApplicantEvidenceReviewService::class)->resetReviews($applicant, trim($validated['verification_notes']));
            }

            $notes = filled($validated['verification_notes'] ?? null)
                ? trim($validated['verification_notes'])
                : null;

            DB::transaction(function () use ($applicant, $validated, $notes, $request): void {
                $profileUpdates = [
                    'verification_status' => $validated['verification_status'],
                    'verification_notes' => $notes,
                    'verified_by' => $validated['verification_status'] === 'pending' ? null : $request->user()->id,
                    'verified_at' => $validated['verification_status'] === 'approved' ? now() : null,
                ];

                StudentProfile::withoutEvents(fn () => $applicant->studentProfile()->updateOrCreate(['user_id' => $applicant->id], $profileUpdates));

            });

            ActivityLog::record(
                $request->user(),
                'applicant_profile_verification_updated',
                "{$request->user()->name} marked applicant {$applicant->name} as {$validated['verification_status']}.",
                $request,
                [
                    'applicant_id' => $applicant->id,
                    'previous_status' => $previousStatus,
                    'verification_status' => $validated['verification_status'],
                    'verification_notes' => $notes,
                    'verification_source' => 'admin',
                ],
            );

            $message = match ($validated['verification_status']) {
                'approved' => 'Your applicant profile has been verified against the submitted identity, school, household, and residence records by the platform review team.',
                'rejected' => 'Your profile supporting evidence needs to be replaced before your information can be verified.',
                default => 'Your profile verification was reopened for platform review.',
            };

            if ($notes) {
                $message .= " Review note: {$notes}";
            }

            PortalNotification::create([
                'user_id' => $applicant->id,
                'type' => 'applicant_profile_verification',
                'title' => 'Profile verification updated',
                'message' => $message,
                'action_url' => '/dashboard/profile',
            ]);

            $freshApplicant = $applicant->fresh([
                'studentProfile.verifier.adminProfile',
                'studentProfile.verifier.providerProfile',
                'studentProfile.verifier.parentAccount.providerProfile',
                'applicantVerificationDocuments',
            ]);

            return response()->json([
                'message' => 'Applicant profile verification updated.',
                'user' => $freshApplicant->publicPayload(),
                'verification_documents' => $freshApplicant->applicantVerificationDocuments
                    ->whereIn('document_type', ApplicantVerificationDocument::PROFILE_EVIDENCE_TYPES)
                    ->sortByDesc('uploaded_at')
                    ->map(fn (ApplicantVerificationDocument $document) => $this->applicantVerificationDocumentPayload($document))
                    ->values(),
                'applicant' => $this->applicantReviewPayload($freshApplicant, true),
            ]);
        });
    }

    public function viewApplicantVerificationDocument(Request $request, ApplicantVerificationDocument $document)
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless(in_array($document->document_type, ApplicantVerificationDocument::PROFILE_EVIDENCE_TYPES, true), 403);
        abort_unless(Storage::disk('local')->exists($document->path), 404);

        return Storage::disk('local')->response($document->path, $document->original_name, [
            'Cache-Control' => 'no-store, private',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    public function viewApplicantProfilePhoto(Request $request, User $applicant)
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($applicant->isApplicant(), 404);

        $profile = $applicant->studentProfile;
        abort_unless($profile?->profile_photo_path, 404);
        abort_unless(Storage::disk('local')->exists($profile->profile_photo_path), 404);

        return Storage::disk('local')->response(
            $profile->profile_photo_path,
            $profile->profile_photo_original_name ?: 'applicant-photo',
            [
                'Cache-Control' => 'private, no-store',
                'X-Content-Type-Options' => 'nosniff',
            ],
        );
    }

    public function reviewApplicantProfilePhoto(Request $request, User $applicant): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless($applicant->isApplicant(), 404);

        $validated = $request->validate([
            'action' => ['required', Rule::in(['approve', 'request_replacement'])],
            'reason' => [
                Rule::requiredIf($request->input('action') === 'request_replacement'),
                'nullable',
                'string',
                'min:5',
                'max:1000',
            ],
        ]);
        $profile = $applicant->studentProfile()->firstOrCreate(['user_id' => $applicant->id]);

        if ($validated['action'] === 'approve' && blank($profile->profile_photo_path)) {
            return response()->json(['message' => 'The applicant has not uploaded a 2x2 photo yet.'], 422);
        }

        $needsReplacement = $validated['action'] === 'request_replacement';
        $profile->update([
            'profile_photo_review_status' => $needsReplacement ? 'needs_replacement' : 'approved',
            'profile_photo_review_note' => $needsReplacement ? $validated['reason'] : null,
            'profile_photo_reviewed_by' => $request->user()->id,
            'profile_photo_reviewed_at' => now(),
            'profile_photo_review_application_id' => null,
        ]);

        PortalNotification::updateOrCreate(
            [
                'user_id' => $applicant->id,
                'deduplication_key' => "profile-photo-review:{$applicant->id}",
            ],
            [
                'type' => 'profile_photo_review',
                'title' => $needsReplacement ? 'Replace your applicant photo' : 'Applicant photo reviewed',
                'message' => $needsReplacement
                    ? "An administrator requested a new 2x2 photo. Reason: {$validated['reason']}"
                    : 'An administrator checked your applicant photo.',
                'action_url' => $needsReplacement ? '/dashboard/profile?section=personal&photo=replace' : '/dashboard/profile',
                'read_at' => null,
            ],
        );

        ActivityLog::record(
            $request->user(),
            $needsReplacement ? 'applicant_profile_photo_replacement_requested' : 'applicant_profile_photo_approved',
            $needsReplacement
                ? "{$request->user()->name} requested a replacement 2x2 photo from {$applicant->name}."
                : "{$request->user()->name} approved the 2x2 photo for {$applicant->name}.",
            $request,
            [
                'applicant_id' => $applicant->id,
                'photo_review_status' => $profile->profile_photo_review_status,
                'reason' => $profile->profile_photo_review_note,
            ],
        );

        $freshApplicant = $applicant->fresh([
            'studentProfile.verifier.adminProfile',
            'studentProfile.verifier.providerProfile',
            'studentProfile.verifier.parentAccount.providerProfile',
            'applicantVerificationDocuments',
        ]);

        return response()->json([
            'message' => $needsReplacement
                ? 'The applicant was asked to upload a new 2x2 photo.'
                : 'The applicant photo was marked as acceptable.',
            'applicant' => $this->applicantReviewPayload($freshApplicant, true),
        ]);
    }

    public function downloadProviderVerificationDocument(Request $request, ProviderVerificationDocument $document)
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless(Storage::disk('local')->exists($document->path), 404);

        return Storage::disk('local')->download($document->path, $document->original_name, [
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    public function viewProviderVerificationDocument(Request $request, ProviderVerificationDocument $document)
    {
        abort_unless($request->user()?->isAdmin(), 403);
        abort_unless(Storage::disk('local')->exists($document->path), 404);

        return Storage::disk('local')->response($document->path, $document->original_name, [
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    public function storeUser(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);

        $actor = $request->user();
        $validated = $request->validate([
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'middle_initial' => ['nullable', 'string', 'size:1', 'regex:/^[A-Za-z]$/'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'username' => ['required', 'string', 'min:4', 'max:255', 'regex:/^[A-Za-z0-9_.-]+$/', 'unique:users,username'],
            'contact_number' => ['required', 'string', 'max:30', new PhoneNumber],
            'role' => ['required', 'string', 'in:applicant,provider,admin'],
            'account_title' => [Rule::requiredIf($request->input('role') === 'admin'), 'nullable', 'string', 'max:80'],
            'permissions' => [Rule::requiredIf($request->input('role') === 'admin'), 'nullable', 'array', 'min:1'],
            'permissions.*' => ['string', Rule::in(User::ADMIN_PERMISSIONS)],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        if ($validated['role'] === 'admin') {
            abort_if($actor->isManagedAccount(), 403, 'Only a primary administrator can create admin accounts.');
            $validated['permissions'] = $this->adminPermissionsForRole(
                $validated['account_title'],
                $validated['permissions'],
            );
        }

        $middleInitial = filled($validated['middle_initial'] ?? null) ? strtoupper($validated['middle_initial']) : null;
        $displayName = trim($validated['first_name'].' '.($middleInitial ? $middleInitial.'. ' : '').$validated['last_name']);

        $profile = [
            'first_name' => $validated['first_name'],
            'last_name' => $validated['last_name'],
            'middle_initial' => $middleInitial,
            'contact_number' => $validated['contact_number'],
        ];

        $user = DB::transaction(function () use ($validated, $actor, $profile, $displayName): User {
            $user = User::create([
                'parent_account_id' => $validated['role'] === 'admin' ? $actor->id : null,
                'email' => $validated['email'],
                'username' => $validated['username'],
                'role' => $validated['role'],
                'account_title' => $validated['role'] === 'admin' ? trim($validated['account_title']) : null,
                'permissions' => $validated['role'] === 'admin'
                    ? array_values(array_unique($validated['permissions']))
                    : null,
                'password' => $validated['password'],
                'must_reset_password' => $validated['role'] === 'admin',
                'password_reset_required_at' => $validated['role'] === 'admin' ? now() : null,
            ]);

            match ($user->role) {
                'admin' => $user->adminProfile()->create([
                    ...$profile,
                    'display_name' => $displayName,
                ]),
                'provider' => $user->providerProfile()->create([
                    ...$profile,
                    'provider_name' => $displayName,
                    'verification_status' => 'pending',
                ]),
                default => $user->studentProfile()->create($profile),
            };

            return $user;
        });

        ActivityLog::record(
            $request->user(),
            'account_created',
            "{$request->user()->name} created {$user->role} account {$user->email}.",
            $request,
            [
                'created_user_id' => $user->id,
                'created_user_role' => $user->role,
                'permissions' => $user->permissions ?? [],
            ],
        );

        $emailVerificationSent = null;

        if ($user->isAdmin()) {
            PortalNotification::create([
                'user_id' => $user->id,
                'type' => 'staff_account_created',
                'title' => 'Your staff account is ready',
                'message' => "Your Scholarship Portal {$user->account_title} account has been created. Username: {$user->username}. Sign in using the temporary password, verify your email, and create a new password before entering the workspace.",
                'action_url' => '/login',
                'deduplication_key' => "staff_account_created:{$user->id}",
            ]);

            $emailVerificationSent = true;

            try {
                $user->sendEmailVerificationNotification();
            } catch (Throwable $error) {
                $emailVerificationSent = false;
                ActivityLog::record(
                    $user,
                    'email_verification_email_failed',
                    "Email verification link could not be sent to {$user->email}.",
                    $request,
                    ['error' => $error->getMessage()],
                );
            }

            PortalNotification::updateOrCreate([
                'user_id' => $user->id,
                'type' => 'email_verification',
                'title' => 'Verify your email address',
            ], [
                'message' => $emailVerificationSent
                    ? 'A verification link was sent to your email. Verify it before replacing your temporary password.'
                    : 'Your email is not verified. Resend the verification link from the account setup page.',
                'action_url' => '/account/setup',
                'read_at' => null,
            ]);
        }

        return response()->json([
            'message' => $user->isAdmin()
                ? ($emailVerificationSent
                    ? 'Staff account created. Share the temporary password securely; a verification email was sent.'
                    : 'Staff account created, but the verification email could not be sent. The user can resend it after signing in.')
                : 'Account created successfully.',
            'email_verification_sent' => $emailVerificationSent,
            'user' => $user->fresh(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload(),
        ], 201);
    }

    public function updateUser(Request $request, User $user): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);

        $actor = $request->user();
        $this->authorizeAdminAccountTarget($actor, $user);
        $willBeManagedAdmin = $request->input('role') === 'admin'
            && ($user->isManagedAccount() || ! $user->isAdmin());

        $validated = $request->validate([
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'middle_initial' => ['nullable', 'string', 'size:1', 'regex:/^[A-Za-z]$/'],
            'email' => ['required', 'email', 'max:255', Rule::unique('users', 'email')->ignore($user->id)],
            'username' => ['required', 'string', 'min:4', 'max:255', 'regex:/^[A-Za-z0-9_.-]+$/', Rule::unique('users', 'username')->ignore($user->id)],
            'contact_number' => ['required', 'string', 'max:30', new PhoneNumber],
            'role' => ['required', 'string', 'in:applicant,provider,admin'],
            'account_title' => [Rule::requiredIf($willBeManagedAdmin), 'nullable', 'string', 'max:80'],
            'permissions' => [Rule::requiredIf($willBeManagedAdmin), 'nullable', 'array', 'min:1'],
            'permissions.*' => ['string', Rule::in(User::ADMIN_PERMISSIONS)],
            'password' => ['nullable', 'string', 'min:8', 'confirmed'],
        ]);

        if ($validated['role'] !== $user->role) {
            return response()->json([
                'message' => 'Account roles cannot be changed after registration. Create a separate account for a different portal role.',
            ], 422);
        }

        if ($validated['role'] === 'admin') {
            abort_if($actor->isManagedAccount(), 403, 'Only a primary administrator can manage admin accounts.');

            if ($willBeManagedAdmin) {
                $validated['permissions'] = $this->adminPermissionsForRole(
                    $validated['account_title'],
                    $validated['permissions'],
                );
            }
        }

        $previousRole = $user->role;
        $emailChanged = strcasecmp($user->email, $validated['email']) !== 0;

        if ($previousRole !== $validated['role'] && $user->managedAccounts()->exists()) {
            return response()->json([
                'message' => 'Reassign or suspend this account\'s managed staff before changing its role.',
            ], 422);
        }

        if ($previousRole === 'admin' && $validated['role'] !== 'admin' && $this->lastActiveAdminWouldBeLost($user)) {
            return response()->json([
                'message' => 'At least one active admin account must remain.',
            ], 422);
        }

        $middleInitial = filled($validated['middle_initial'] ?? null) ? strtoupper($validated['middle_initial']) : null;
        $displayName = trim($validated['first_name'].' '.($middleInitial ? $middleInitial.'. ' : '').$validated['last_name']);
        $userPayload = [
            'email' => $validated['email'],
            'username' => $validated['username'],
            'role' => $validated['role'],
            'parent_account_id' => $willBeManagedAdmin
                ? ($user->parent_account_id ?: $actor->id)
                : ($validated['role'] === 'provider' && $previousRole === 'provider'
                    ? $user->parent_account_id
                    : null),
            'account_title' => $willBeManagedAdmin
                ? trim($validated['account_title'])
                : ($validated['role'] === 'provider' && $previousRole === 'provider'
                    ? $user->account_title
                    : null),
            'permissions' => $willBeManagedAdmin
                ? array_values(array_unique($validated['permissions']))
                : ($validated['role'] === 'provider' && $previousRole === 'provider'
                    ? $user->permissions
                    : null),
        ];

        if (filled($validated['password'] ?? null)) {
            $userPayload['password'] = $validated['password'];
        }

        $profile = [
            'first_name' => $validated['first_name'],
            'last_name' => $validated['last_name'],
            'middle_initial' => $middleInitial,
            'contact_number' => $validated['contact_number'],
        ];
        DB::transaction(function () use ($user, $userPayload, $profile, $displayName, $emailChanged): void {
            $user->fill($userPayload);

            if ($emailChanged) {
                $user->email_verified_at = null;
            }

            $user->save();

            match ($user->role) {
                'admin' => $user->adminProfile()->updateOrCreate([
                    'user_id' => $user->id,
                ], [
                    ...$profile,
                    'display_name' => $displayName,
                ]),
                'provider' => $user->providerProfile()->updateOrCreate([
                    'user_id' => $user->id,
                ], [
                    ...$profile,
                    'provider_name' => $user->providerProfile?->provider_name ?: $displayName,
                    'verification_status' => $user->providerProfile?->verification_status ?: 'pending',
                    'verified_by' => $user->providerProfile?->verified_by,
                    'verified_at' => $user->providerProfile?->verified_at,
                ]),
                default => $user->studentProfile()->updateOrCreate([
                    'user_id' => $user->id,
                ], $profile),
            };

        });

        if ($emailChanged) {
            try {
                $user->sendEmailVerificationNotification();
            } catch (Throwable $error) {
                ActivityLog::record(
                    $request->user(),
                    'email_verification_email_failed',
                    "Email verification link could not be sent to {$user->email}.",
                    $request,
                    ['updated_user_id' => $user->id, 'error' => $error->getMessage()],
                );
            }

            PortalNotification::updateOrCreate([
                'user_id' => $user->id,
                'type' => 'email_verification',
                'title' => 'Verify your email address',
            ], [
                'message' => 'Your email address was changed by an administrator. Verify the new address before using verification-protected actions.',
                'action_url' => null,
                'read_at' => null,
            ]);
        }

        ActivityLog::record(
            $request->user(),
            'account_updated',
            "{$request->user()->name} updated {$user->role} account {$user->email}.",
            $request,
            [
                'updated_user_id' => $user->id,
                'previous_role' => $previousRole,
                'current_role' => $user->role,
                'permissions' => $user->permissions ?? [],
            ],
        );

        return response()->json([
            'message' => 'Account updated successfully.',
            'user' => $user->fresh(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload(),
        ]);
    }

    public function updateUserStatus(Request $request, User $user): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        $this->authorizeAdminAccountTarget($request->user(), $user);

        $validated = $request->validate([
            'account_status' => ['required', Rule::in(['active', 'suspended'])],
            'suspension_reason' => ['nullable', 'required_if:account_status,suspended', 'string', 'max:1000'],
        ]);

        $status = $validated['account_status'];

        if ($status === 'suspended') {
            if ($user->is($request->user())) {
                return response()->json([
                    'message' => 'You cannot suspend your own admin account.',
                ], 422);
            }

            if ($this->lastActiveAdminWouldBeLost($user)) {
                return response()->json([
                    'message' => 'At least one active admin account must remain.',
                ], 422);
            }

            $user->forceFill([
                'account_status' => 'suspended',
                'suspended_at' => now(),
                'suspended_by' => $request->user()->id,
                'suspension_reason' => $validated['suspension_reason'],
            ])->save();
        } else {
            $user->forceFill([
                'account_status' => 'active',
                'suspended_at' => null,
                'suspended_by' => null,
                'suspension_reason' => null,
            ])->save();
        }

        ActivityLog::record(
            $request->user(),
            'account_status_updated',
            "{$request->user()->name} marked {$user->email} as {$this->labelFromKey($status)}.",
            $request,
            ['updated_user_id' => $user->id, 'account_status' => $status],
        );

        PortalNotification::create([
            'user_id' => $user->id,
            'type' => 'account_status',
            'title' => $status === 'suspended' ? 'Account suspended' : 'Account reactivated',
            'message' => $status === 'suspended'
                ? 'Your account has been suspended. Contact an administrator for help.'
                : 'Your account has been reactivated. You can sign in again.',
            'action_url' => $status === 'active' ? '/login' : null,
        ]);

        return response()->json([
            'message' => $status === 'suspended' ? 'Account suspended.' : 'Account reactivated.',
            'user' => $user->fresh(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload(),
        ]);
    }

    public function forcePasswordReset(Request $request, User $user): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        $this->authorizeAdminAccountTarget($request->user(), $user);

        $user->forceFill([
            'must_reset_password' => true,
            'password_reset_required_at' => now(),
        ])->save();

        $reset = app(PasswordResetLinkService::class)->prepare($user, $request);

        ActivityLog::record(
            $request->user(),
            'account_password_reset_forced',
            "{$request->user()->name} forced a password reset for {$user->email}.",
            $request,
            ['updated_user_id' => $user->id, 'email_sent' => $reset['email_sent']],
        );

        PortalNotification::create([
            'user_id' => $user->id,
            'type' => 'password_reset_required',
            'title' => 'Password reset required',
            'message' => 'An administrator requires you to reset your password before signing in again.',
            'action_url' => null,
        ]);

        return response()->json([
            'message' => $reset['email_sent']
                ? 'Password reset required. A reset link was sent to the user.'
                : 'Password reset required, but the reset email could not be sent yet.',
            'reset_url' => $this->shouldExposeResetUrl() ? $reset['reset_url'] : null,
            'user' => $user->fresh(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload(),
        ]);
    }

    public function verifyUserEmail(Request $request, User $user): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        $this->authorizeAdminAccountTarget($request->user(), $user);

        if (! $user->hasVerifiedEmail() && $user->markEmailAsVerified()) {
            event(new Verified($user));

            PortalNotification::query()
                ->where('user_id', $user->id)
                ->where('type', 'email_verification')
                ->where('title', 'Verify your email address')
                ->update(['read_at' => now()]);

            PortalNotification::create([
                'user_id' => $user->id,
                'type' => 'email_verified',
                'title' => 'Email verified',
                'message' => 'An administrator verified your email address.',
                'action_url' => $user->isProvider() ? '/provider' : '/dashboard',
            ]);
        }

        ActivityLog::record(
            $request->user(),
            'account_email_verified_by_admin',
            "{$request->user()->name} verified {$user->email}.",
            $request,
            ['updated_user_id' => $user->id],
        );

        return response()->json([
            'message' => 'Email marked as verified.',
            'user' => $user->fresh(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload(),
        ]);
    }

    public function resendUserVerificationEmail(Request $request, User $user): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);
        $this->authorizeAdminAccountTarget($request->user(), $user);

        if ($user->hasVerifiedEmail()) {
            return response()->json([
                'message' => 'This email is already verified.',
                'email_verification_sent' => false,
                'user' => $user->loadMissing(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload(),
            ]);
        }

        $emailSent = true;

        try {
            $user->sendEmailVerificationNotification();
        } catch (Throwable $error) {
            $emailSent = false;

            ActivityLog::record(
                $user,
                'email_verification_email_failed',
                "Email verification link could not be sent to {$user->email}.",
                $request,
                ['error' => $error->getMessage()],
            );
        }

        PortalNotification::updateOrCreate([
            'user_id' => $user->id,
            'type' => 'email_verification',
            'title' => 'Verify your email address',
        ], [
            'message' => $emailSent
                ? 'A verification link was sent to your email. Verify your email to secure your account.'
                : 'Your email is not verified yet. Ask an administrator to resend the link when mail settings are available.',
            'action_url' => null,
            'read_at' => null,
        ]);

        ActivityLog::record(
            $request->user(),
            'account_email_verification_resent_by_admin',
            "{$request->user()->name} resent email verification for {$user->email}.",
            $request,
            ['updated_user_id' => $user->id, 'email_sent' => $emailSent],
        );

        return response()->json([
            'message' => $emailSent
                ? 'Verification email sent.'
                : 'Unable to send the verification email right now.',
            'email_verification_sent' => $emailSent,
            'user' => $user->fresh(['studentProfile', 'providerProfile', 'adminProfile'])->publicPayload(),
        ]);
    }

    public function logEntries(Request $request): JsonResponse
    {
        abort_unless($request->user()?->isAdmin(), 403);

        $validated = $request->validate([
            'page' => ['sometimes', 'integer', 'min:1'],
            'per_page' => ['sometimes', 'integer', 'min:5', 'max:25'],
            'action' => ['sometimes', 'string', 'max:80'],
            'actor_role' => ['sometimes', 'nullable', Rule::in(['all', 'admin', 'provider', 'applicant', 'system'])],
            'search' => ['sometimes', 'nullable', 'string', 'max:120'],
        ]);

        $perPage = (int) ($validated['per_page'] ?? 10);
        $action = $validated['action'] ?? 'all';
        $actorRole = $validated['actor_role'] ?? 'all';
        $search = trim((string) ($validated['search'] ?? ''));
        $baseQuery = ActivityLog::query();
        $actions = (clone $baseQuery)
            ->selectRaw('action, count(*) as total')
            ->groupBy('action')
            ->orderBy('action')
            ->pluck('total', 'action');

        $query = ActivityLog::query()->latest();

        if ($action !== 'all') {
            $query->where('action', $action);
        }

        if ($actorRole === 'system') {
            $query->whereNull('actor_role');
        } elseif ($actorRole !== 'all') {
            $query->where('actor_role', $actorRole);
        }

        if ($search !== '') {
            $likeSearch = '%'.$search.'%';
            $query->where(function ($searchQuery) use ($likeSearch): void {
                $searchQuery
                    ->where('description', 'like', $likeSearch)
                    ->orWhere('actor_name', 'like', $likeSearch)
                    ->orWhere('ip_address', 'like', $likeSearch);
            });
        }

        $logs = $query->paginate($perPage);

        return response()->json([
            'entries' => $logs->getCollection()->map(fn (ActivityLog $log) => [
                'id' => $log->id,
                'actor_name' => $log->actor_name ?? 'System',
                'actor_role' => $log->actor_role,
                'action' => $log->action,
                'description' => $log->description,
                'ip_address' => $log->ip_address,
                'metadata' => $log->metadata,
                'metadata_summary' => $this->metadataSummary($log->metadata ?? []),
                'created_at' => $log->created_at?->format('M d, Y h:i A'),
            ])->values(),
            'pagination' => [
                'current_page' => $logs->currentPage(),
                'last_page' => $logs->lastPage(),
                'per_page' => $logs->perPage(),
                'total' => $logs->total(),
                'from' => $logs->firstItem(),
                'to' => $logs->lastItem(),
            ],
            'filters' => [
                'all' => ActivityLog::query()->count(),
                ...$actions->all(),
            ],
            'roles' => [
                'all' => ActivityLog::query()->count(),
                'admin' => ActivityLog::query()->where('actor_role', 'admin')->count(),
                'provider' => ActivityLog::query()->where('actor_role', 'provider')->count(),
                'applicant' => ActivityLog::query()->where('actor_role', 'applicant')->count(),
                'system' => ActivityLog::query()->whereNull('actor_role')->count(),
            ],
        ]);
    }

    public function exportUsers(Request $request)
    {
        abort_unless($request->user()?->isAdmin(), 403);

        ActivityLog::record(
            $request->user(),
            'records_users_exported',
            'Exported user account records.',
            $request,
            [
                'record_count' => User::query()->count(),
                'filename' => 'scholarship-users.csv',
            ],
        );

        return response()->streamDownload(function () {
            $handle = fopen('php://output', 'w');
            CsvExport::writeRow($handle, ['ID', 'Name', 'Email', 'Email Verified', 'Username', 'Contact Number', 'Role', 'Account Status', 'Must Reset Password', 'Created At']);

            User::query()
                ->with(['studentProfile', 'providerProfile', 'adminProfile'])
                ->orderBy('id')
                ->chunk(200, function ($users) use ($handle) {
                    foreach ($users as $user) {
                        CsvExport::writeRow($handle, [
                            $user->id,
                            $user->name,
                            $user->email,
                            $user->hasVerifiedEmail() ? 'Yes' : 'No',
                            $user->username,
                            $user->contact_number,
                            $user->role,
                            $user->account_status ?? 'active',
                            $user->must_reset_password ? 'Yes' : 'No',
                            $user->created_at?->format('Y-m-d H:i:s'),
                        ]);
                    }
                });

            fclose($handle);
        }, 'scholarship-users.csv', ['Content-Type' => 'text/csv']);
    }

    public function exportApplications(Request $request)
    {
        abort_unless($request->user()?->isAdmin(), 403);

        ActivityLog::record(
            $request->user(),
            'records_applications_exported',
            'Exported scholarship application records.',
            $request,
            [
                'record_count' => ScholarshipApplication::query()->count(),
                'filename' => 'scholarship-applications.csv',
            ],
        );

        return response()->streamDownload(function () {
            $handle = fopen('php://output', 'w');
            CsvExport::writeRow($handle, ['ID', 'Scholarship', 'Provider', 'Applicant', 'Email', 'Status', 'DSS Score', 'DSS Recommendation', 'Eligibility Score', 'Decision Reason', 'Awarded Amount', 'Distribution Date', 'Distribution Instructions', 'Outcome Date', 'Outcome Notes', 'Submitted At', 'Documents Confirmed', 'Uploaded Documents', 'Pending Documents', 'Applicant Notes', 'Review Notes']);

            ScholarshipApplication::query()
                ->with(['applicant.studentProfile', 'documents', 'scholarship.provider.providerProfile'])
                ->orderBy('id')
                ->chunk(200, function ($applications) use ($handle) {
                    foreach ($applications as $application) {
                        app(DecisionSupportService::class)->syncApplication($application);
                        CsvExport::writeRow($handle, [
                            $application->id,
                            $application->scholarship?->title,
                            $application->scholarship?->provider?->provider_name ?? $application->scholarship?->provider?->name,
                            $application->applicant?->name,
                            $application->applicant?->email,
                            $application->status,
                            $application->dss_score,
                            $application->dss_recommendation,
                            $application->eligibility_score,
                            $application->decision_reason,
                            $application->awarded_amount,
                            $application->distribution_scheduled_for?->format('Y-m-d'),
                            $application->distribution_instructions,
                            $application->outcome_at?->format('Y-m-d'),
                            $application->outcome_notes,
                            $application->submitted_at?->format('Y-m-d H:i:s'),
                            implode('; ', $application->document_checklist ?? []),
                            $application->documents->count(),
                            $application->documents->where('status', 'pending')->count(),
                            $application->notes,
                            $application->review_notes,
                        ]);
                    }
                });

            fclose($handle);
        }, 'scholarship-applications.csv', ['Content-Type' => 'text/csv']);
    }

    public function exportMonitoring(Request $request)
    {
        abort_unless($request->user()?->isAdmin(), 403);

        $validated = $request->validate([
            'status' => ['sometimes', 'nullable', Rule::in(['all', 'attention', 'open', 'reviewed', 'stable', 'closed'])],
            'application_id' => ['sometimes', 'nullable', 'integer', 'exists:scholarship_applications,id'],
            'case_id' => ['sometimes', 'nullable', 'integer', 'exists:recipient_monitoring_cases,id'],
        ]);
        $status = $validated['status'] ?? 'all';

        if (blank($validated['application_id'] ?? null)) {
            return $this->exportMonitoringCases(
                $request,
                $status,
                filled($validated['case_id'] ?? null) ? (int) $validated['case_id'] : null,
            );
        }

        $query = $this->monitoringOversightQuery()->orderBy('id');

        if (filled($validated['application_id'] ?? null)) {
            $query->whereKey((int) $validated['application_id']);
        }

        $records = $query->get()
            ->map(fn (ScholarshipApplication $application): array => $this->monitoringOversightPayload($application))
            ->when($status !== 'all', fn ($items) => $items->where('oversight_status', $status))
            ->values();
        $filename = filled($validated['application_id'] ?? null)
            ? "recipient-monitoring-application-{$validated['application_id']}.csv"
            : 'recipient-monitoring-'.$status.'.csv';

        ActivityLog::record(
            $request->user(),
            'records_monitoring_exported',
            'Exported recipient monitoring records.',
            $request,
            [
                'record_count' => $records->count(),
                'status' => $status,
                'application_id' => $validated['application_id'] ?? null,
                'filename' => $filename,
            ],
        );

        return response()->streamDownload(function () use ($records): void {
            $handle = fopen('php://output', 'w');
            CsvExport::writeRow($handle, [
                'Application ID',
                'Recipient',
                'Email',
                'Program',
                'Provider',
                'Support Status',
                'Oversight Status',
                'Attention Items',
                'Requirements Confirmed',
                'Requirements Total',
                'Benefits Released',
                'Benefit Records',
                'Last Activity',
                'Latest Admin Outcome',
                'Latest Admin Note',
                'Reviewed At',
            ]);

            foreach ($records as $record) {
                CsvExport::writeRow($handle, [
                    $record['application_id'],
                    $record['applicant_name'],
                    $record['applicant_email'],
                    $record['program_title'],
                    $record['provider_name'],
                    $record['support_status_label'],
                    $record['oversight_label'],
                    collect($record['attention_items'])->pluck('title')->implode('; '),
                    $record['requirements_confirmed'],
                    $record['requirements_total'],
                    $record['released_total'],
                    $record['release_total'],
                    $record['last_activity_at'],
                    data_get($record, 'last_review.outcome_label'),
                    data_get($record, 'last_review.notes'),
                    data_get($record, 'last_review.reviewed_at'),
                ]);
            }

            fclose($handle);
        }, $filename, ['Content-Type' => 'text/csv']);
    }

    private function exportMonitoringCases(
        Request $request,
        string $status,
        ?int $caseId = null,
    ) {
        $records = RecipientMonitoringCase::query()
            ->with(['cycle', 'application', 'applicant'])
            ->when($caseId, fn ($query) => $query->whereKey($caseId))
            ->orderBy('id')
            ->get()
            ->map(fn (RecipientMonitoringCase $case): array => $this->monitoringCaseOversightPayload($case))
            ->when($status !== 'all', function ($items) use ($status) {
                return $items->filter(fn (array $record): bool => match ($status) {
                    'open' => ! in_array($record['case_status'], ['closed', 'waived', 'cancelled'], true),
                    'stable' => $record['oversight_status'] === 'open',
                    default => $record['oversight_status'] === $status,
                });
            })
            ->values();
        $filename = $caseId
            ? "recipient-monitoring-case-{$caseId}.csv"
            : 'recipient-monitoring-'.$status.'.csv';

        ActivityLog::record(
            $request->user(),
            'records_monitoring_exported',
            'Exported monitoring case oversight records.',
            $request,
            [
                'record_count' => $records->count(),
                'status' => $status,
                'recipient_monitoring_case_id' => $caseId,
                'filename' => $filename,
            ],
        );

        return response()->streamDownload(function () use ($records): void {
            $handle = fopen('php://output', 'w');
            CsvExport::writeRow($handle, [
                'Case ID',
                'Recipient',
                'Email',
                'Program',
                'Provider',
                'Check-in',
                'Case Status',
                'Due Status',
                'Due Date',
                'Oversight Status',
                'Current Exception',
                'Next Action Owner',
                'Next Action',
                'Requirements Confirmed',
                'Requirements Total',
                'Latest Admin Outcome',
                'Latest Admin Note',
                'Reviewed At',
            ]);

            foreach ($records as $record) {
                CsvExport::writeRow($handle, [
                    $record['case_id'],
                    $record['applicant_name'],
                    $record['applicant_email'],
                    $record['program_title'],
                    $record['provider_name'],
                    $record['cycle_title'],
                    $record['case_status_label'],
                    $record['due_status_label'],
                    $record['due_on'],
                    $record['oversight_label'],
                    data_get($record, 'current_issue.title'),
                    data_get($record, 'provider_action.role_label'),
                    data_get($record, 'provider_action.label'),
                    $record['requirements_confirmed'],
                    $record['requirements_total'],
                    data_get($record, 'last_review.outcome_label'),
                    data_get($record, 'last_review.notes'),
                    data_get($record, 'last_review.reviewed_at'),
                ]);
            }

            fclose($handle);
        }, $filename, ['Content-Type' => 'text/csv']);
    }

    private function adminPermissionsForRole(string $accountTitle, array $permissions): array
    {
        return self::ADMIN_ROLE_PERMISSION_PRESETS[$accountTitle]
            ?? array_values(array_unique($permissions));
    }

    private function authorizeAdminAccountTarget(User $actor, User $target): void
    {
        abort_if(
            $actor->isManagedAccount() && $target->isAdmin(),
            403,
            'Delegated administrators cannot manage administrator accounts.',
        );
    }

    private function providerNotificationRecipients(int $providerId, string $permission)
    {
        return User::query()
            ->where('role', 'provider')
            ->where(function ($query) use ($providerId): void {
                $query->whereKey($providerId)->orWhere('parent_account_id', $providerId);
            })
            ->get()
            ->filter(fn (User $provider) => $provider->hasPortalPermission($permission));
    }

    private function lastActiveAdminWouldBeLost(User $user): bool
    {
        if (! $user->isAdmin() || ! $user->isActive()) {
            return false;
        }

        return User::query()
            ->where('role', 'admin')
            ->where('account_status', 'active')
            ->whereKeyNot($user->id)
            ->doesntExist();
    }

    private function shouldExposeResetUrl(): bool
    {
        return app()->isLocal() || app()->runningUnitTests();
    }

    private function metadataSummary(array $metadata): string
    {
        if ($metadata === []) {
            return '';
        }

        return collect($metadata)
            ->map(fn ($value, string $key) => "{$key}: {$value}")
            ->implode(' | ');
    }

    private function scholarshipReviewPayload(Scholarship $scholarship): array
    {
        return [
            'id' => $scholarship->id,
            'provider_id' => $scholarship->provider_id,
            'title' => $scholarship->title,
            'category' => $scholarship->category,
            'program_cycle' => $scholarship->program_cycle,
            'description' => $scholarship->description,
            'provider_objectives' => $scholarship->provider_objectives ?? [],
            'provider_objective_notes' => $scholarship->provider_objective_notes,
            'eligibility' => $scholarship->eligibility,
            'eligibility_conditions' => $scholarship->eligibility_conditions ?? [],
            'eligibility_rule_modes' => $scholarship->eligibilityRuleModes(),
            'education_eligibility_policy' => EducationEligibilityPolicy::normalize($scholarship->education_eligibility_policy),
            'provider' => $scholarship->provider?->provider_name ?? $scholarship->provider?->name,
            'provider_email' => $scholarship->provider?->email,
            'provider_type' => $scholarship->provider?->provider_type,
            'provider_website' => $scholarship->provider?->provider_website,
            'provider_address' => $scholarship->provider?->provider_address,
            'provider_description' => $scholarship->provider?->provider_description,
            'provider_contact_email' => $scholarship->provider?->providerProfile?->provider_contact_email,
            'provider_contact_number' => $scholarship->provider?->providerProfile?->provider_contact_number,
            'provider_verification_status' => $scholarship->provider?->providerProfile?->verification_status,
            'status' => $scholarship->status,
            'logo_url' => $scholarship->logoUrl(),
            'cover_image_url' => $scholarship->coverImageUrl(),
            'image_url' => $this->scholarshipImageUrl($scholarship),
            'benefits' => $scholarship->benefitPayload(),
            'benefit_summary' => $scholarship->benefitSummary(),
            'award_amount' => $scholarship->award_amount,
            'minimum_gwa' => $scholarship->minimum_gwa,
            'minimum_grade_scale' => AcademicRequirement::normalizeScale($scholarship->minimum_grade_scale, $scholarship->minimum_gwa),
            'minimum_grade_label' => AcademicRequirement::requirementLabel($scholarship->minimum_gwa, $scholarship->minimum_grade_scale),
            'deadline' => $scholarship->deadline?->format('M d, Y'),
            'application_opens_at' => $scholarship->application_opens_at?->format('M d, Y'),
            'expected_results_at' => $scholarship->expected_results_at?->format('M d, Y'),
            'support_starts_at' => $scholarship->support_starts_at?->format('M d, Y'),
            'support_ends_at' => $scholarship->support_ends_at?->format('M d, Y'),
            'official_program_url' => $scholarship->official_program_url,
            'requirements' => $scholarship->requirements,
            'optional_requirements' => $scholarship->optional_requirements,
            'post_qualification_requirements' => $scholarship->post_qualification_requirements,
            'handoff_mode' => $scholarship->handoff_mode,
            'handoff_instructions' => $scholarship->handoff_instructions,
            'handoff_deadline' => $scholarship->handoff_deadline?->format('M d, Y'),
            'handoff_location_name' => $scholarship->handoff_location_name,
            'handoff_location_address' => $scholarship->handoff_location_address,
            'handoff_url' => $scholarship->handoff_url,
            'review_rubric' => $scholarship->review_rubric ?? [],
            'application_questions' => $scholarship->application_questions ?? [],
            'eligible_courses' => $scholarship->eligible_courses,
            'return_service_contract' => $scholarship->return_service_contract,
            'other_contract_terms' => $scholarship->other_contract_terms,
            'recipient_agreement' => $scholarship->recipient_agreement,
            'eligible_education_levels' => $scholarship->eligible_education_levels,
            'eligible_school_types' => $scholarship->eligible_school_types,
            'eligible_year_levels' => $scholarship->eligible_year_levels,
            'eligible_locations' => $scholarship->eligible_locations,
            'income_requirement' => $scholarship->income_requirement,
            'exclude_current_scholarship_recipients' => (bool) $scholarship->exclude_current_scholarship_recipients,
            'location_name' => $scholarship->location_name,
            'location_address' => $scholarship->location_address,
            'latitude' => $scholarship->latitude,
            'longitude' => $scholarship->longitude,
            'map_url' => $this->mapUrl($scholarship),
            'slots_available' => $scholarship->slots_available,
            'application_limit' => $scholarship->application_limit,
            'application_mode' => $scholarship->application_mode,
            'selection_stages' => ScholarshipSelectionPlan::normalize($scholarship->selection_stages),
            'program_events' => $scholarship->events
                ->sortBy('scheduled_at')
                ->map(fn ($event) => ScholarshipEventPayload::make($event))
                ->values(),
            'renewal_policy' => $scholarship->renewal_policy,
            'contact_email' => $scholarship->contact_email,
            'contact_number' => $scholarship->contact_number,
            'contact_person' => $scholarship->contact_person,
            'contact_department' => $scholarship->contact_department,
            'bookmarks_count' => $scholarship->bookmarks_count ?? 0,
            'views_count' => $scholarship->views_count,
            'created_at' => $scholarship->created_at?->format('M d, Y h:i A'),
            'updated_at' => $scholarship->updated_at?->format('M d, Y h:i A'),
            'provider_terms_accepted_at' => $scholarship->provider_terms_accepted_at?->format('M d, Y h:i A'),
            'provider_terms_version' => $scholarship->provider_terms_version,
        ];
    }

    private function scholarshipImageUrl(Scholarship $scholarship): string
    {
        return $scholarship->logoUrl();
    }

    private function mapUrl(Scholarship $scholarship): ?string
    {
        if ($scholarship->latitude !== null && $scholarship->longitude !== null) {
            return "https://www.openstreetmap.org/?mlat={$scholarship->latitude}&mlon={$scholarship->longitude}#map=15/{$scholarship->latitude}/{$scholarship->longitude}";
        }

        $query = $scholarship->location_address ?: $scholarship->location_name;

        return filled($query)
            ? 'https://www.openstreetmap.org/search?query='.rawurlencode($query)
            : null;
    }

    private function documentPayload(ApplicationDocument $document): array
    {
        return [
            'id' => $document->id,
            'document_name' => $document->document_name,
            'original_name' => $document->original_name,
            'size' => $document->size,
            'status' => $document->status,
            'review_notes' => $document->review_notes,
            'reviewed_by' => $document->reviewer?->name,
            'reviewed_at' => $document->reviewed_at?->format('M d, Y h:i A'),
            'uploaded_at' => $document->uploaded_at?->format('M d, Y h:i A'),
            'download_url' => route('documents.download', $document),
        ];
    }

    private function providerReviewPayload(User $provider): array
    {
        $profile = $provider->providerProfile;

        return [
            ...$provider->publicPayload(),
            'legal_name' => $profile?->legal_name,
            'registration_authority' => $profile?->registration_authority,
            'registration_number' => $profile?->registration_number,
            'registration_date' => $profile?->registration_date?->format('M d, Y'),
            'representative_position' => $profile?->representative_position,
            'document_review' => app(ProviderVerificationReviewService::class)->summary($provider),
            'verification_documents' => $provider->providerVerificationDocuments
                ->sortByDesc('created_at')
                ->map(fn (ProviderVerificationDocument $document) => $this->verificationDocumentPayload($document))
                ->values(),
            'team_members_count' => (int) ($provider->managed_accounts_count ?? 0),
            'programs_count' => (int) ($provider->provider_scholarships_count ?? 0),
            'published_programs_count' => (int) ($provider->published_programs_count ?? 0),
            'programs_in_review_count' => (int) ($provider->programs_in_review_count ?? 0),
            'created_at' => $provider->created_at?->format('M d, Y'),
        ];
    }

    private function applicantReviewPayload(User $applicant, bool $includeOversightHistory = false): array
    {
        return [
            ...$applicant->publicPayload(),
            'profile_photo_url' => filled($applicant->studentProfile?->profile_photo_path)
                ? route('admin.applicants.profile-photo.view', $applicant)
                : null,
            'academic_scan_required' => $this->academicRecordOcrService->configured(),
            'verification_documents' => $applicant->applicantVerificationDocuments
                ->whereIn('document_type', ApplicantVerificationDocument::PROFILE_EVIDENCE_TYPES)
                ->sortByDesc('uploaded_at')
                ->map(fn (ApplicantVerificationDocument $document) => $this->applicantVerificationDocumentPayload($document))
                ->values(),
            'verification_oversight' => $this->applicantVerificationOversightPayload($applicant, $includeOversightHistory),
            'can_review_evidence' => auth()->user()?->isAdmin()
                && auth()->user()->hasPortalPermission('manage_reviews')
                && ! AdminWorkspace::usesPortalManagerWorkspace(auth()->user()),
            'evidence_review_history_url' => route('admin.applicants.evidence-review-history', $applicant, false),
            'created_at' => $applicant->created_at?->format('M d, Y'),
        ];
    }

    private function applicantVerificationOversightPayload(User $applicant, bool $includeHistory = false): array
    {
        $profile = $applicant->studentProfile;
        $verifier = $profile?->verifier;
        $status = $applicant->applicantAcademicVerificationStatus();
        $source = match (true) {
            $verifier?->isProvider() => 'provider',
            $verifier?->isAdmin() => 'admin',
            $status === 'approved' => 'legacy',
            default => 'unassigned',
        };
        $providerOrganization = null;

        if ($source === 'provider' && $verifier) {
            $providerOwner = $verifier->providerOrganizationOwner();
            $providerOrganization = $providerOwner->providerProfile?->provider_name ?: $providerOwner->name;
        }

        $oversight = [
            'status' => $status,
            'source' => $source,
            'source_label' => match ($source) {
                'provider' => 'Provider review',
                'admin' => 'Admin review',
                'legacy' => 'Earlier record',
                default => 'Awaiting review',
            },
            'reviewer_name' => $verifier?->name,
            'provider_organization' => $providerOrganization,
            'verified_at' => $profile?->verified_at?->format('M d, Y h:i A'),
            'review_note' => $profile?->verification_notes,
            'can_reopen' => $status === 'approved',
            'context' => null,
            'history' => [],
        ];

        if (! $includeHistory) {
            return $oversight;
        }

        $logs = ActivityLog::query()
            ->whereIn('action', [
                'applicant_profile_verified_by_provider',
                'applicant_profile_verification_updated',
            ])
            ->where('metadata->applicant_id', $applicant->id)
            ->latest('id')
            ->get();
        $providerLog = $logs->firstWhere('action', 'applicant_profile_verified_by_provider');

        if ($providerLog) {
            $applicationId = (int) data_get($providerLog->metadata, 'application_id');
            $application = $applicationId > 0
                ? ScholarshipApplication::query()
                    ->with('scholarship.provider.providerProfile')
                    ->whereKey($applicationId)
                    ->where('applicant_id', $applicant->id)
                    ->first()
                : null;

            if ($application?->scholarship) {
                $oversight['context'] = [
                    'application_id' => $application->id,
                    'program_id' => $application->scholarship_id,
                    'program_title' => $application->scholarship->title,
                    'provider_name' => $application->scholarship->provider?->provider_name
                        ?: $application->scholarship->provider?->name,
                    'is_current' => $source === 'provider',
                    'program_review_url' => route('admin.scholarships.review.show', $application->scholarship_id),
                ];
            }
        }

        $oversight['history'] = $logs
            ->map(function (ActivityLog $log): array {
                $metadata = $log->metadata ?? [];
                $status = $log->action === 'applicant_profile_verified_by_provider'
                    ? 'approved'
                    : (data_get($metadata, 'verification_status') ?: 'pending');
                $source = $log->actor_role === 'provider' ? 'provider' : 'admin';
                $title = match (true) {
                    $log->action === 'applicant_profile_verified_by_provider' => 'Verified by provider',
                    $status === 'approved' => 'Verified by admin',
                    $status === 'rejected' => 'Replacement requested',
                    default => 'Verification reopened',
                };

                return [
                    'id' => $log->id,
                    'action' => $log->action,
                    'title' => $title,
                    'description' => $log->description,
                    'source' => $source,
                    'source_label' => $source === 'provider' ? 'Provider review' : 'Admin review',
                    'actor_name' => $log->actor_name,
                    'previous_status' => data_get($metadata, 'previous_status'),
                    'status' => $status,
                    'reason' => data_get($metadata, 'verification_notes'),
                    'application_id' => data_get($metadata, 'application_id'),
                    'program_id' => data_get($metadata, 'scholarship_id'),
                    'created_at' => $log->created_at?->format('M d, Y h:i A'),
                ];
            })
            ->values();

        return $oversight;
    }

    private function requestedMonitoringCase(
        Request $request,
        ScholarshipApplication $application,
    ): ?RecipientMonitoringCase {
        if (! $request->filled('case')) {
            return $application->monitoringCases()
                ->orderByRaw("CASE WHEN due_status = 'overdue' THEN 0 WHEN next_action_role = 'provider' THEN 1 ELSE 2 END")
                ->orderBy('effective_due_at')
                ->first();
        }

        $caseId = filter_var($request->input('case'), FILTER_VALIDATE_INT);
        abort_unless($caseId, 404);

        return $application->monitoringCases()->whereKey($caseId)->firstOrFail();
    }

    private function monitoringProviderRecipients(?Scholarship $program, bool $includeOwner)
    {
        $owner = $program?->provider;
        if (! $program || ! $owner) {
            return collect();
        }

        $recipients = User::query()
            ->where('role', 'provider')
            ->where('account_status', 'active')
            ->where(function ($query) use ($owner): void {
                $query->whereKey($owner->id)
                    ->orWhere('parent_account_id', $owner->id);
            })
            ->get()
            ->filter(fn (User $user): bool => $user->hasPortalPermission('manage_monitoring')
                && $user->canAccessProviderProgram($program)
            );

        if ($includeOwner && $owner->isActive()) {
            $recipients->push($owner);
        }
        if ($recipients->isEmpty() && $owner->isActive()) {
            $recipients->push($owner);
        }

        return $recipients->unique('id')->values();
    }

    private function monitoringCaseOversightPayload(RecipientMonitoringCase $case): array
    {
        $case->loadMissing(['cycle.requirements', 'application', 'applicant.studentProfile']);
        $application = $case->application;
        $case = $this->monitoringCaseService->sync($case->cycle, $application);
        $case->load([
            'cycle.requirements',
            'events.actor',
            'applicant.studentProfile',
            'application.scholarship.provider.providerProfile',
            'application.monitoringOversightReviews.reviewer.adminProfile',
        ]);
        $application = $case->application;
        $submissions = $application->monitoringSubmissions()
            ->with('requirement')
            ->where('recipient_monitoring_cycle_id', $case->recipient_monitoring_cycle_id)
            ->get();
        $adjustments = $application->monitoringAdjustmentRequests()
            ->with(['requirement', 'decider'])
            ->where('recipient_monitoring_cycle_id', $case->recipient_monitoring_cycle_id)
            ->get();
        $interventions = $application->monitoringInterventions()
            ->with(['requirement', 'creator'])
            ->where('recipient_monitoring_cycle_id', $case->recipient_monitoring_cycle_id)
            ->get();
        $casePayload = $this->monitoringCaseService->payload(
            $case,
            $adjustments,
            $interventions,
            true,
            'provider',
        );
        $requirements = $case->cycle->requirements
            ->where('required', true)
            ->map(function ($requirement) use ($case, $submissions): array {
                $submission = $submissions->firstWhere(
                    'recipient_monitoring_cycle_requirement_id',
                    $requirement->id,
                );
                $reviewStatus = $submission?->review_status;
                $status = match (true) {
                    in_array($reviewStatus, ['met', 'excused'], true) => 'confirmed',
                    in_array($reviewStatus, ['needs_correction', 'needs_replacement', 'not_met'], true) => 'attention',
                    $submission !== null => 'review_pending',
                    $case->due_status === 'overdue' => 'overdue',
                    default => 'waiting',
                };

                return [
                    'id' => $requirement->id,
                    'title' => $requirement->title,
                    'status' => $status,
                    'status_label' => match ($status) {
                        'confirmed' => 'Confirmed',
                        'attention' => 'Correction needed',
                        'review_pending' => 'Provider review',
                        'overdue' => 'Overdue',
                        default => 'Waiting',
                    },
                    'file' => $submission?->path ? [
                        'name' => $submission->original_name,
                        'view_url' => route('admin.monitoring-submissions.view', $submission),
                    ] : null,
                ];
            })
            ->values();

        if ($requirements->isEmpty()) {
            $submission = $submissions->firstWhere('recipient_monitoring_cycle_requirement_id', null);
            $reviewStatus = $submission?->review_status;
            $status = match (true) {
                in_array($reviewStatus, ['met', 'excused'], true) => 'confirmed',
                in_array($reviewStatus, ['needs_correction', 'needs_replacement', 'not_met'], true) => 'attention',
                $submission !== null => 'review_pending',
                $case->due_status === 'overdue' => 'overdue',
                default => 'waiting',
            };
            $requirements->push([
                'id' => 'cycle-'.$case->recipient_monitoring_cycle_id,
                'title' => $case->cycle->title,
                'status' => $status,
                'status_label' => match ($status) {
                    'confirmed' => 'Confirmed',
                    'attention' => 'Correction needed',
                    'review_pending' => 'Provider review',
                    'overdue' => 'Overdue',
                    default => 'Waiting',
                },
                'file' => $submission?->path ? [
                    'name' => $submission->original_name,
                    'view_url' => route('admin.monitoring-submissions.view', $submission),
                ] : null,
            ]);
        }

        $issue = $this->monitoringCaseIssue($case, $casePayload);
        $latestReview = $application->monitoringOversightReviews
            ->first(fn (RecipientMonitoringOversightReview $review): bool => (int) data_get($review->flags_snapshot, 'case_id') === $case->id
            );
        $reviewIsCurrent = $latestReview?->reviewed_at
            && $latestReview->reviewed_at->greaterThanOrEqualTo($case->updated_at);
        $oversightStatus = match (true) {
            $reviewIsCurrent && $latestReview->outcome === 'reviewed' => 'reviewed',
            $case->isClosed() => 'closed',
            $issue !== null => 'attention',
            default => 'open',
        };

        return [
            'application_id' => $application->id,
            'case_id' => $case->id,
            'applicant_name' => $case->applicant?->name,
            'applicant_email' => $case->applicant?->email,
            'applicant_photo_url' => filled($case->applicant?->studentProfile?->profile_photo_path)
                ? route('admin.applicants.profile-photo.view', $case->applicant)
                : null,
            'program_title' => $application->scholarship?->title,
            'provider_name' => $application->scholarship?->provider?->providerProfile?->provider_name
                ?: $application->scholarship?->provider?->name,
            'cycle_title' => $case->cycle?->title,
            'case_status' => $casePayload['status'],
            'case_status_label' => $casePayload['status_label'],
            'due_status' => $casePayload['due_status'],
            'due_status_label' => $casePayload['due_status_label'],
            'due_on' => $casePayload['effective_due_label'],
            'oversight_status' => $oversightStatus,
            'oversight_label' => match ($oversightStatus) {
                'attention' => 'Needs admin attention',
                'reviewed' => 'Admin reviewed',
                'closed' => 'Check-in closed',
                default => 'No current exception',
            },
            'current_issue' => $issue,
            'attention_items' => $issue ? [$issue] : [],
            'provider_action' => $case->due_status === 'overdue' ? [
                'key' => 'resolve_overdue',
                'role' => 'provider',
                'role_label' => 'Provider',
                'label' => 'Resolve the overdue check-in',
            ] : $casePayload['next_action'],
            'requirements' => $requirements,
            'requirements_total' => $requirements->count(),
            'requirements_confirmed' => $requirements->where('status', 'confirmed')->count(),
            'exception_context' => $casePayload['exception_context'],
            'timeline' => $casePayload['history'],
            'last_review' => $latestReview ? [
                'outcome' => $latestReview->outcome,
                'outcome_label' => match ($latestReview->outcome) {
                    'follow_up_required' => 'Provider follow-up required',
                    'escalated' => 'Escalated',
                    default => 'Reviewed',
                },
                'notes' => $latestReview->notes,
                'reviewed_by' => $latestReview->reviewer?->name,
                'reviewed_at' => $latestReview->reviewed_at?->format('M d, Y h:i A'),
            ] : null,
        ];
    }

    private function monitoringCaseIssue(
        RecipientMonitoringCase $case,
        array $casePayload,
    ): ?array {
        if ($case->isClosed()) {
            return null;
        }

        $age = (int) ($case->updated_at?->copy()->startOfDay()->diffInDays(now()->startOfDay()) ?? 0);
        $overdueDays = (int) ($case->effective_due_at?->copy()->startOfDay()->diffInDays(now()->startOfDay()) ?? 0);

        return match (true) {
            $case->due_status === 'overdue' => [
                'severity' => $overdueDays >= 7 ? 'high' : 'medium',
                'source' => 'check_in',
                'title' => 'Check-in is past due',
                'detail' => $overdueDays.' day'.($overdueDays === 1 ? '' : 's').' overdue. '.$casePayload['status_reason'],
            ],
            $case->status === 'extension_pending' => [
                'severity' => 'medium',
                'source' => 'request',
                'title' => 'Recipient request needs a decision',
                'detail' => $casePayload['status_reason'],
            ],
            $case->status === 'follow_up' => [
                'severity' => 'medium',
                'source' => 'follow_up',
                'title' => 'Provider follow-up remains open',
                'detail' => $casePayload['status_reason'],
            ],
            $case->next_action_role === 'provider' && $age >= 2 => [
                'severity' => $age >= 7 ? 'high' : 'medium',
                'source' => 'provider_action',
                'title' => $casePayload['next_action']['label'] ?? 'Provider action is waiting',
                'detail' => 'Waiting for provider action for '.$age.' day'.($age === 1 ? '' : 's').'.',
            ],
            default => null,
        };
    }

    private function monitoringOversightQuery()
    {
        return ScholarshipApplication::query()
            ->with($this->monitoringOversightRelations())
            ->where(function ($query): void {
                $query
                    ->whereIn('status', ['awarded', 'distribution_scheduled', 'disbursed', 'renewed', 'benefits_terminated'])
                    ->orWhereHas('monitoringSubmissions')
                    ->orWhereHas('benefitReleaseRecords')
                    ->orWhereHas('supportDecisions');
            });
    }

    private function monitoringOversightRelations(): array
    {
        return [
            'scholarship.provider.providerProfile',
            'scholarship.monitoringCycles.requirements',
            'applicant.studentProfile',
            'monitoringSubmissions.cycle',
            'monitoringSubmissions.requirement',
            'monitoringAdjustmentRequests.cycle',
            'monitoringAdjustmentRequests.requirement',
            'monitoringAdjustmentRequests.decider',
            'monitoringInterventions.cycle',
            'monitoringInterventions.requirement',
            'monitoringInterventions.creator',
            'benefitReleaseRecords.release',
            'benefitReleaseRecords.receiptResponse.resolver',
            'benefitReleaseRecords.recorder',
            'supportDecisions.decider',
            'supportDecisions.resolver',
            'monitoringOversightReviews.reviewer.adminProfile',
        ];
    }

    private function isRecipientMonitoringRecord(ScholarshipApplication $application): bool
    {
        return in_array($application->status, ['awarded', 'distribution_scheduled', 'disbursed', 'renewed', 'benefits_terminated'], true)
            || $application->monitoringSubmissions()->exists()
            || $application->benefitReleaseRecords()->exists()
            || $application->supportDecisions()->exists();
    }

    private function monitoringOversightPayload(
        ScholarshipApplication $application,
        bool $detailed = false,
    ): array {
        $application->loadMissing($this->monitoringOversightRelations());
        $attentionItems = collect();
        $requirements = collect();
        $submissions = $application->monitoringSubmissions;
        $adjustments = $application->monitoringAdjustmentRequests;
        $today = now()->startOfDay();

        foreach ($application->scholarship?->monitoringCycles ?? collect() as $cycle) {
            if (! in_array($cycle->status, ['published', 'closed'], true)) {
                continue;
            }

            $cycleRequirements = $cycle->requirements->where('required', true);
            $cycleRequirements = $cycleRequirements->isNotEmpty() ? $cycleRequirements : collect([null]);

            foreach ($cycleRequirements as $requirement) {
                $submission = $requirement
                    ? $submissions->firstWhere('recipient_monitoring_cycle_requirement_id', $requirement->id)
                    : $submissions->first(fn ($item) => $item->recipient_monitoring_cycle_id === $cycle->id
                        && $item->recipient_monitoring_cycle_requirement_id === null);
                $adjustment = $adjustments
                    ->where('recipient_monitoring_cycle_id', $cycle->id)
                    ->when($requirement, fn ($items) => $items->where('recipient_monitoring_cycle_requirement_id', $requirement->id))
                    ->where('status', 'approved')
                    ->sortByDesc('decided_at')
                    ->first();
                $dueAt = $adjustment?->approved_due_at
                    ?? $cycle->due_at?->copy()->addDays((int) $cycle->grace_period_days);
                $reviewStatus = $submission?->review_status;
                $status = match (true) {
                    in_array($reviewStatus, ['met', 'excused'], true) => 'confirmed',
                    in_array($reviewStatus, ['needs_replacement', 'not_met'], true) => 'attention',
                    $submission !== null => 'review_pending',
                    $dueAt?->copy()->endOfDay()->isBefore($today) => 'overdue',
                    default => 'upcoming',
                };
                $title = $requirement?->title ?: $cycle->title;

                if ($status === 'overdue') {
                    $attentionItems->push([
                        'severity' => 'high',
                        'source' => 'requirement',
                        'title' => 'Requirement is overdue',
                        'detail' => $title.' has no submission.',
                    ]);
                } elseif ($status === 'attention') {
                    $attentionItems->push([
                        'severity' => 'high',
                        'source' => 'requirement',
                        'title' => 'Requirement was not confirmed',
                        'detail' => $title.' needs replacement or did not meet the recorded requirement.',
                    ]);
                } elseif ($status === 'review_pending') {
                    $attentionItems->push([
                        'severity' => 'medium',
                        'source' => 'requirement',
                        'title' => 'Submission awaits provider review',
                        'detail' => $title.' was submitted but has no completed review.',
                    ]);
                }

                $requirements->push([
                    'id' => $requirement?->id ?: "cycle-{$cycle->id}",
                    'title' => $title,
                    'cycle_title' => $cycle->title,
                    'due_on' => $dueAt?->format('M d, Y'),
                    'status' => $status,
                    'status_label' => match ($status) {
                        'confirmed' => 'Confirmed',
                        'attention' => 'Needs correction',
                        'review_pending' => 'Provider review pending',
                        'overdue' => 'Overdue',
                        default => 'Upcoming',
                    },
                    'review_result' => $submission?->review_notes,
                    'file' => $submission?->path ? [
                        'name' => $submission->original_name,
                        'view_url' => route('admin.monitoring-submissions.view', $submission),
                    ] : null,
                ]);
            }
        }

        foreach ($adjustments->where('status', 'pending') as $adjustment) {
            $attentionItems->push([
                'severity' => 'medium',
                'source' => 'adjustment',
                'title' => 'Adjustment request is pending',
                'detail' => ($adjustment->requirement?->title ?: $adjustment->cycle?->title ?: 'Monitoring requirement').' needs a provider decision.',
            ]);
        }

        foreach ($application->monitoringInterventions->where('status', 'open') as $intervention) {
            if ($intervention->follow_up_on?->copy()->endOfDay()->isBefore($today)) {
                $attentionItems->push([
                    'severity' => 'high',
                    'source' => 'intervention',
                    'title' => 'Follow-up is overdue',
                    'detail' => $intervention->summary,
                ]);
            }
        }

        foreach ($application->benefitReleaseRecords as $record) {
            $response = $record->receiptResponse;

            if ($response?->status === 'open') {
                $attentionItems->push([
                    'severity' => 'high',
                    'source' => 'benefit',
                    'title' => 'Recipient reported a release issue',
                    'detail' => $record->release?->title ?: 'Benefit release',
                ]);
            } elseif (in_array($record->status, ['missed', 'withheld'], true)) {
                $attentionItems->push([
                    'severity' => 'medium',
                    'source' => 'benefit',
                    'title' => $record->status === 'withheld' ? 'Benefit was withheld' : 'Recipient missed a release',
                    'detail' => $record->release?->title ?: 'Benefit release',
                ]);
            } elseif ($record->status === 'released' && blank($record->receipt_path) && blank($record->notes)) {
                $attentionItems->push([
                    'severity' => 'medium',
                    'source' => 'benefit',
                    'title' => 'Release has no supporting evidence',
                    'detail' => $record->release?->title ?: 'Benefit release',
                ]);
            }
        }

        $latestDecision = $application->supportDecisions->first();
        if ($latestDecision?->response_status === 'open') {
            $attentionItems->push([
                'severity' => 'high',
                'source' => 'outcome',
                'title' => 'Support outcome response is unresolved',
                'detail' => $this->labelFromKey((string) $latestDecision->applicant_response_type),
            ]);
        } elseif ($latestDecision?->decision === 'terminated') {
            $attentionItems->push([
                'severity' => 'medium',
                'source' => 'outcome',
                'title' => 'Support ended early',
                'detail' => $latestDecision->reason ?: $this->labelFromKey((string) $latestDecision->reason_category),
            ]);
        }

        $latestReview = $application->monitoringOversightReviews->first();
        $activityAt = collect([
            $application->updated_at,
            $application->scholarship?->monitoringCycles->max('updated_at'),
            $submissions->max('updated_at'),
            $adjustments->max('updated_at'),
            $application->monitoringInterventions->max('updated_at'),
            $application->benefitReleaseRecords->max('updated_at'),
            $application->benefitReleaseRecords->pluck('receiptResponse')->filter()->max('updated_at'),
            $application->supportDecisions->max('updated_at'),
        ])->filter()->sortByDesc(fn ($date) => $date->timestamp)->first();
        $reviewIsCurrent = $latestReview?->reviewed_at
            && (! $activityAt || $latestReview->reviewed_at->greaterThanOrEqualTo($activityAt));
        $isClosed = in_array($latestDecision?->decision, ['completed', 'terminated'], true)
            || $application->status === 'benefits_terminated';
        $oversightStatus = match (true) {
            $reviewIsCurrent && in_array($latestReview->outcome, ['follow_up_required', 'escalated'], true) => 'attention',
            $reviewIsCurrent && $latestReview->outcome === 'reviewed' => 'reviewed',
            $attentionItems->isNotEmpty() => 'attention',
            $isClosed => 'closed',
            default => 'stable',
        };
        $confirmedRequirements = $requirements->where('status', 'confirmed')->count();
        $releasedBenefits = $application->benefitReleaseRecords->where('status', 'released')->count();

        $payload = [
            'application_id' => $application->id,
            'applicant_id' => $application->applicant_id,
            'applicant_name' => $application->applicant?->name,
            'applicant_email' => $application->applicant?->email,
            'program_id' => $application->scholarship_id,
            'program_title' => $application->scholarship?->title,
            'provider_name' => $application->scholarship?->provider?->providerProfile?->provider_name
                ?: $application->scholarship?->provider?->name,
            'application_status' => $application->status,
            'support_status' => $latestDecision?->decision ?: 'active',
            'support_status_label' => $latestDecision
                ? match ($latestDecision->decision) {
                    'renewed' => 'Support renewed',
                    'completed' => 'Support completed',
                    'terminated' => 'Support ended early',
                    default => $this->labelFromKey((string) $latestDecision->decision),
                }
                : 'Support active',
            'oversight_status' => $oversightStatus,
            'oversight_label' => match ($oversightStatus) {
                'attention' => 'Needs admin attention',
                'reviewed' => 'Admin reviewed',
                'closed' => 'Support closed',
                default => 'No current issue',
            },
            'attention_items' => $attentionItems->values(),
            'requirements_total' => $requirements->count(),
            'requirements_confirmed' => $confirmedRequirements,
            'release_total' => $application->benefitReleaseRecords->count(),
            'released_total' => $releasedBenefits,
            'last_activity_at' => $activityAt?->format('M d, Y h:i A'),
            'last_review' => $latestReview ? [
                'outcome' => $latestReview->outcome,
                'outcome_label' => match ($latestReview->outcome) {
                    'follow_up_required' => 'Provider follow-up required',
                    'escalated' => 'Escalated',
                    default => 'Reviewed',
                },
                'notes' => $latestReview->notes,
                'reviewed_by' => $latestReview->reviewer?->name,
                'reviewed_at' => $latestReview->reviewed_at?->format('M d, Y h:i A'),
            ] : null,
            'review_url' => route('admin.monitoring.show', $application),
        ];

        if (! $detailed) {
            return $payload;
        }

        $timeline = collect();
        foreach ($submissions as $submission) {
            $timeline->push([
                'id' => 'submission-'.$submission->id,
                'type' => 'requirement',
                'title' => $submission->requirement?->title ?: $submission->cycle?->title ?: 'Monitoring submission',
                'detail' => $submission->review_notes ?: $submission->applicant_note,
                'status_label' => $this->labelFromKey((string) $submission->review_status),
                'occurred_at' => ($submission->reviewed_at ?? $submission->submitted_at)?->format('M d, Y h:i A'),
                'sort_at' => ($submission->reviewed_at ?? $submission->submitted_at)?->timestamp ?? 0,
                'files' => $submission->path ? [[
                    'name' => $submission->original_name,
                    'view_url' => route('admin.monitoring-submissions.view', $submission),
                ]] : [],
            ]);
        }
        foreach ($adjustments as $adjustment) {
            $timeline->push([
                'id' => 'adjustment-'.$adjustment->id,
                'type' => 'adjustment',
                'title' => 'Adjustment: '.($adjustment->requirement?->title ?: $adjustment->cycle?->title ?: 'Monitoring requirement'),
                'detail' => $adjustment->decision_notes ?: $adjustment->explanation,
                'status_label' => $this->labelFromKey($adjustment->status),
                'occurred_at' => ($adjustment->decided_at ?? $adjustment->created_at)?->format('M d, Y h:i A'),
                'sort_at' => ($adjustment->decided_at ?? $adjustment->created_at)?->timestamp ?? 0,
                'files' => $adjustment->attachment_path ? [[
                    'name' => $adjustment->attachment_original_name,
                    'view_url' => route('admin.monitoring-adjustments.attachment', $adjustment),
                ]] : [],
            ]);
        }
        foreach ($application->monitoringInterventions as $intervention) {
            $timeline->push([
                'id' => 'intervention-'.$intervention->id,
                'type' => 'follow_up',
                'title' => $intervention->summary,
                'detail' => $intervention->completion_notes ?: $intervention->action_required,
                'status_label' => $this->labelFromKey($intervention->status),
                'occurred_at' => ($intervention->completed_at ?? $intervention->created_at)?->format('M d, Y h:i A'),
                'sort_at' => ($intervention->completed_at ?? $intervention->created_at)?->timestamp ?? 0,
                'files' => [],
            ]);
        }
        foreach ($application->benefitReleaseRecords as $record) {
            $response = $record->receiptResponse;
            $files = collect();
            if ($record->receipt_path) {
                $files->push(['name' => $record->receipt_original_name, 'view_url' => route('admin.benefit-release-records.receipt', $record)]);
            }
            if ($response?->evidence_path) {
                $files->push(['name' => $response->evidence_original_name, 'view_url' => route('admin.benefit-receipt-responses.file', [$response, 'recipient-evidence'])]);
            }
            if ($response?->resolution_proof_path) {
                $files->push(['name' => $response->resolution_proof_original_name, 'view_url' => route('admin.benefit-receipt-responses.file', [$response, 'resolution-proof'])]);
            }
            $timeline->push([
                'id' => 'release-'.$record->id,
                'type' => 'benefit',
                'title' => $record->release?->title ?: 'Benefit release',
                'detail' => $response?->issue_details ?: $record->notes ?: $record->release?->benefit_description,
                'status_label' => $response?->status === 'open' ? 'Recipient issue open' : $this->labelFromKey($record->status),
                'occurred_at' => ($record->recorded_at ?? $record->release?->release_at)?->format('M d, Y h:i A'),
                'sort_at' => ($record->recorded_at ?? $record->release?->release_at)?->timestamp ?? 0,
                'files' => $files->values(),
            ]);
        }
        foreach ($application->supportDecisions as $decision) {
            $files = collect();
            if ($decision->decision_document_path) {
                $files->push(['name' => $decision->decision_document_original_name, 'view_url' => route('admin.support-decisions.file', [$decision, 'decision-document'])]);
            }
            if ($decision->applicant_response_path) {
                $files->push(['name' => $decision->applicant_response_original_name, 'view_url' => route('admin.support-decisions.file', [$decision, 'applicant-response'])]);
            }
            if ($decision->resolution_proof_path) {
                $files->push(['name' => $decision->resolution_proof_original_name, 'view_url' => route('admin.support-decisions.file', [$decision, 'resolution-proof'])]);
            }
            $timeline->push([
                'id' => 'decision-'.$decision->id,
                'type' => 'outcome',
                'title' => match ($decision->decision) {
                    'renewed' => 'Support renewed',
                    'completed' => 'Support completed',
                    'terminated' => 'Support ended early',
                    default => $this->labelFromKey($decision->decision),
                },
                'detail' => $decision->resolution_notes ?: $decision->applicant_response_message ?: $decision->reason ?: $decision->next_period_terms,
                'status_label' => $decision->response_status === 'open' ? 'Response unresolved' : $this->labelFromKey($decision->reason_category ?: $decision->decision),
                'occurred_at' => ($decision->resolved_at ?? $decision->applicant_responded_at ?? $decision->decided_at)?->format('M d, Y h:i A'),
                'sort_at' => ($decision->resolved_at ?? $decision->applicant_responded_at ?? $decision->decided_at)?->timestamp ?? 0,
                'files' => $files->values(),
            ]);
        }

        return [
            ...$payload,
            'requirements' => $requirements->values(),
            'timeline' => $timeline->sortByDesc('sort_at')->values()->map(function (array $item): array {
                unset($item['sort_at']);

                return $item;
            }),
            'oversight_history' => $application->monitoringOversightReviews->map(fn (RecipientMonitoringOversightReview $review): array => [
                'id' => $review->id,
                'outcome' => $review->outcome,
                'outcome_label' => match ($review->outcome) {
                    'follow_up_required' => 'Provider follow-up required',
                    'escalated' => 'Escalated',
                    default => 'Reviewed',
                },
                'notes' => $review->notes,
                'flags_count' => count($review->flags_snapshot ?? []),
                'reviewed_by' => $review->reviewer?->name,
                'reviewed_at' => $review->reviewed_at?->format('M d, Y h:i A'),
            ])->values(),
        ];
    }

    private function privateMonitoringFileResponse(?string $path, ?string $name)
    {
        return Storage::disk('local')->response($path, $name, [
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    private function benefitOversightPayload(RecipientBenefitReleaseRecord $record): array
    {
        $release = $record->release;
        $scholarship = $release?->scholarship;
        $hasReceipt = filled($record->receipt_path) && Storage::disk('local')->exists($record->receipt_path);
        $hasNote = filled($record->notes);
        $isOverdue = in_array($record->status, ['scheduled', 'prepared'], true)
            && $release?->release_at?->isPast();
        $flags = collect();

        if ($isOverdue) {
            $flags->push('Release date passed without a completed recipient result.');
        }

        if (in_array($record->status, ['missed', 'withheld'], true)) {
            $flags->push($record->status === 'withheld'
                ? 'The provider withheld this recipient benefit; review the stated reason.'
                : 'The recipient was marked as having missed the release schedule.');
        }

        if ($record->status === 'released' && ! $hasReceipt) {
            $flags->push($hasNote
                ? 'Receipt was confirmed by provider note only; no signed file was uploaded.'
                : 'No receipt file or acknowledgement note is available.');
        }

        if ($record->status === 'released'
            && $release?->requires_original_verification
            && ! $record->originals_verified) {
            $flags->push('The release required original-document verification, but it was not recorded.');
        }

        $oversightStatus = $flags->isNotEmpty()
            ? 'attention'
            : ($record->status === 'released' && $hasReceipt ? 'documented' : 'pending');
        $evidenceType = $hasReceipt ? 'receipt' : ($hasNote ? 'note' : 'none');

        return [
            'id' => $record->id,
            'status' => $record->status,
            'status_label' => match ($record->status) {
                'prepared' => 'Prepared for release',
                'released' => 'Released to recipient',
                'missed' => 'Recipient missed schedule',
                'withheld' => 'Release withheld',
                default => 'Scheduled',
            },
            'oversight_status' => $oversightStatus,
            'oversight_label' => match ($oversightStatus) {
                'documented' => 'Receipt documented',
                'attention' => 'Review needed',
                default => 'Pending release',
            },
            'oversight_flags' => $flags->values(),
            'evidence_type' => $evidenceType,
            'evidence_label' => match ($evidenceType) {
                'receipt' => 'Receipt file',
                'note' => 'Provider note only',
                default => 'No evidence yet',
            },
            'provider_name' => $scholarship?->provider?->providerProfile?->provider_name
                ?: $scholarship?->provider?->name,
            'program_id' => $scholarship?->id,
            'program_title' => $scholarship?->title,
            'program_review_url' => $scholarship ? route('admin.scholarships.review.show', $scholarship) : null,
            'applicant_id' => $record->applicant_id,
            'applicant_name' => $record->applicant?->name,
            'applicant_email' => $record->applicant?->email,
            'applicant_review_url' => $record->applicant
                ? route('admin.applicants.review.show', $record->applicant)
                : null,
            'release_title' => $release?->title,
            'benefit_description' => $release?->benefit_description,
            'amount_label' => $release?->amount !== null
                ? 'PHP '.number_format((float) $release->amount, 2)
                : null,
            'release_method' => $release?->release_method,
            'release_method_label' => $this->labelFromKey((string) ($release?->release_method ?: 'provider_arrangement')),
            'location' => $release?->location,
            'scheduled_at' => $release?->release_at?->format('M d, Y h:i A'),
            'released_at' => $record->released_at?->format('M d, Y h:i A'),
            'recorded_at' => $record->recorded_at?->format('M d, Y h:i A'),
            'recorded_by' => $record->recorder?->name,
            'requires_original_verification' => (bool) $release?->requires_original_verification,
            'originals_verified' => (bool) $record->originals_verified,
            'notes' => $record->notes,
            'receipt' => $hasReceipt ? [
                'name' => $record->receipt_original_name,
                'mime_type' => $record->receipt_mime_type,
                'size' => $record->receipt_size,
                'view_url' => route('admin.benefit-release-records.receipt', $record),
            ] : null,
        ];
    }

    private function verificationDocumentPayload(ProviderVerificationDocument $document): array
    {
        return [
            ...app(ProviderVerificationReviewService::class)->documentMetadata($document),
            'id' => $document->id,
            'document_type' => $document->document_type,
            'original_name' => $document->original_name,
            'mime_type' => $document->mime_type,
            'size' => $document->size,
            'status' => $document->status,
            'review_notes' => $document->review_notes,
            'uploaded_at' => $document->uploaded_at?->format('M d, Y h:i A'),
            'view_url' => route('admin.provider-verification-documents.view', $document),
            'download_url' => route('admin.provider-verification-documents.download', $document),
            'review_url' => route('admin.provider-verification-documents.review', $document),
        ];
    }

    private function applicantVerificationDocumentPayload(ApplicantVerificationDocument $document): array
    {
        return [
            'id' => $document->id,
            'document_type' => $document->document_type,
            'label' => ApplicantVerificationDocument::EVIDENCE_DETAILS[$document->document_type]['label'] ?? str($document->document_type)->headline()->toString(),
            'supports' => ApplicantVerificationDocument::EVIDENCE_DETAILS[$document->document_type]['supports'] ?? null,
            'claim_fields' => ApplicantEvidenceReviewService::CLAIMS[$document->document_type] ?? [],
            'file_available' => Storage::disk('local')->exists($document->path),
            'original_name' => $document->original_name,
            'mime_type' => $document->mime_type,
            'size' => $document->size,
            'status' => $document->status,
            'review_notes' => $document->review_notes,
            ...$document->reviewPayload(),
            'review_url' => route('admin.applicant-verification-documents.review', $document, false),
            'ocr_status' => $document->ocr_status ?? AcademicRecordOcrService::STATUS_NOT_REQUESTED,
            'ocr_provider' => $document->ocr_provider,
            'ocr_grade' => $document->ocr_grade,
            'ocr_grading_scale' => $document->ocr_grading_scale,
            'ocr_label' => $document->ocr_label,
            'ocr_message' => $document->ocr_message,
            'ocr_processed_at' => $document->ocr_processed_at?->format('M d, Y h:i A'),
            'uploaded_at' => $document->uploaded_at?->format('M d, Y h:i A'),
            'view_url' => route('admin.applicant-verification-documents.view', $document),
        ];
    }

    private function labelFromKey(string $value): string
    {
        return str($value)->replace('_', ' ')->title()->toString();
    }
}

<script setup>
import { staffQueueReturn } from '../../../support/staffQueueState.js';
import { computed, onMounted, ref } from 'vue';
import ApplicantPagePreviewModal from '../../../components/ApplicantPagePreviewModal.vue';
import EducationEligibilitySummary from '../../../components/EducationEligibilitySummary.vue';
import UserScholarshipDetailPage from '../../UserScholarshipDetailPage.vue';
import ProviderSidebar from '../ProviderSidebar.vue';

const programId = document.getElementById('app')?.dataset.programId;
const program = ref(null);
const isLoading = ref(true);
const errorMessage = ref('');
const showFullDescription = ref(false);
const previewOpen = ref(false);
const previewScenario = ref('general');

const descriptionIsLong = computed(() => (program.value?.description?.length ?? 0) > 360);
const visibleDescription = computed(() => {
    const description = program.value?.description || 'No program summary has been added.';

    if (!descriptionIsLong.value || showFullDescription.value) return description;

    return `${description.slice(0, 360).trim()}...`;
});

const timelineRows = computed(() => {
    if (!program.value) return [];

    return [
        { label: 'Applications open', value: program.value.timeline.opens || 'Not set' },
        { label: 'Application deadline', value: program.value.timeline.deadline.display },
        { label: 'Expected results', value: program.value.timeline.results || 'Not set' },
        { label: 'Support starts', value: program.value.timeline.support_starts || 'Not set' },
        { label: 'Support ends', value: program.value.timeline.support_ends || 'Not set' },
    ];
});

function statusClass(tone) {
    return {
        positive: 'border-emerald-200 bg-emerald-50 text-emerald-800',
        attention: 'border-amber-200 bg-amber-50 text-amber-800',
        waiting: 'border-sky-200 bg-sky-50 text-sky-800',
        neutral: 'border-slate-200 bg-slate-100 text-slate-700',
    }[tone] ?? 'border-slate-200 bg-slate-100 text-slate-700';
}

function capacityValue(value, suffix) {
    return value === null ? 'Not set' : `${value} ${suffix}`;
}

function workspaceColumn(index) {
    const count = program.value.workspace_links.length;
    if (count === 1) return 'col-span-6';
    if ([2, 4].includes(count) || (count === 5 && index >= 3)) return 'col-span-3';
    return 'col-span-2';
}

async function loadProgram() {
    isLoading.value = true;
    errorMessage.value = '';

    try {
        const response = await window.axios.get(`/provider/programs/${programId}/data`);
        program.value = response.data.program;
    } catch (error) {
        errorMessage.value = error.response?.data?.message
            || 'This program record could not be loaded.';
    } finally {
        isLoading.value = false;
    }
}

onMounted(loadProgram);
const originatingWorkspace = staffQueueReturn(window, 'programWorkspaces');
const canBrowsePrograms = computed(() => Boolean(program.value?.actions.directory_url)
    || (!program.value && window.portalUser?.permissions?.includes('manage_programs')));
const backToQueue = computed(() => originatingWorkspace || (canBrowsePrograms.value
    ? staffQueueReturn(window, 'programs', program.value?.actions.directory_url || '/provider/programs')
    : '/provider'));
const backLabel = computed(() => originatingWorkspace ? 'Back to queue' : canBrowsePrograms.value ? 'Back to programs' : 'Back to dashboard');
</script>

<template>
    <main class="student-shell">
        <ProviderSidebar />

        <section class="student-page" aria-labelledby="program-record-title">
            <div class="provider-program-workspace mx-auto max-w-[94rem]">
                <a :href="backToQueue" class="inline-flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-slate-950">
                    <i class="fa-solid fa-arrow-left text-xs" aria-hidden="true"></i>
                    {{ backLabel }}
                </a>

                <div v-if="isLoading" class="mt-5 border border-slate-200 bg-white px-6 py-12 text-center shadow-sm">
                    <span class="mx-auto grid h-9 w-9 place-items-center bg-slate-100 text-slate-500" aria-hidden="true"><i class="fa-solid fa-circle-notch animate-spin text-sm"></i></span>
                    <p class="mt-2 text-sm font-semibold text-slate-500">Loading program record...</p>
                </div>

                <div v-else-if="errorMessage" class="mt-5 border-l-4 border-rose-500 bg-rose-50 px-5 py-4 text-sm font-semibold text-rose-800" role="alert">
                    {{ errorMessage }}
                </div>

                <template v-else-if="program">
                    <header class="mt-5 border border-slate-200 border-t-2 border-t-slate-950 bg-white shadow-sm">
                        <div class="flex items-center justify-between gap-8 px-6 py-5">
                            <div class="flex min-w-0 flex-1 items-center gap-4">
                                <img :src="program.logo_url" :alt="`${program.title} logo`" class="h-12 w-12 shrink-0 border border-slate-200 bg-white object-contain p-1" @error="$event.currentTarget.src = '/uploads/scholarship-default.jpg'">
                                <div class="min-w-0">
                                    <p class="program-label font-bold uppercase text-amber-700">Program record</p>
                                    <h1 id="program-record-title" class="program-page-title mt-1 font-display font-bold tracking-tight text-slate-950">{{ program.title }}</h1>
                                    <p class="program-text mt-2 text-sm text-slate-600">
                                        {{ program.category || 'Uncategorized' }}<template v-if="program.cycle"> · {{ program.cycle }}</template>
                                    </p>
                                </div>
                            </div>
                            <div class="program-page-actions">
                                <span :class="['program-status inline-flex border px-3 py-1.5 font-bold uppercase tracking-wide', statusClass(program.status.tone)]">
                                    {{ program.status.label }}
                                </span>
                                <button v-if="program.actions.preview_url" type="button" class="program-action inline-flex h-10 items-center gap-2 border border-slate-300 bg-white px-4 text-sm font-bold text-slate-700 hover:border-slate-950" @click="previewOpen = true">
                                    <i class="fa-solid fa-eye text-[10px]" aria-hidden="true"></i>
                                    Applicant preview
                                </button>
                                <a v-if="program.actions.edit_url" :href="program.actions.edit_url" class="program-action inline-flex h-10 items-center gap-2 bg-slate-950 px-4 text-sm font-bold text-white hover:bg-slate-800">
                                    <i class="fa-solid fa-pen text-[10px]" aria-hidden="true"></i>
                                    Edit program
                                </a>
                            </div>
                        </div>

                        <div class="program-summary grid grid-cols-4 border-t border-slate-200 bg-slate-50">
                            <div class="flex items-center gap-3 border-r border-slate-200 px-5 py-4">
                                <span class="grid h-9 w-9 shrink-0 place-items-center bg-white text-slate-600" aria-hidden="true"><i class="fa-solid fa-file-lines text-sm"></i></span>
                                <div class="min-w-0"><p class="program-label font-bold uppercase text-slate-600">Applications</p><p class="mt-1 text-sm font-bold text-slate-950">{{ program.capacity.applications }} received</p></div>
                            </div>
                            <div class="flex items-center gap-3 border-r border-slate-200 px-5 py-4">
                                <span class="grid h-9 w-9 shrink-0 place-items-center bg-white text-slate-600" aria-hidden="true"><i class="fa-solid fa-users-line text-sm"></i></span>
                                <div class="min-w-0"><p class="program-label font-bold uppercase text-slate-600">Application limit</p><p class="mt-1 text-sm font-bold text-slate-950">{{ capacityValue(program.capacity.application_limit, 'applicants') }}</p></div>
                            </div>
                            <div class="flex items-center gap-3 border-r border-slate-200 px-5 py-4">
                                <span class="grid h-9 w-9 shrink-0 place-items-center bg-white text-slate-600" aria-hidden="true"><i class="fa-solid fa-award text-sm"></i></span>
                                <div class="min-w-0"><p class="program-label font-bold uppercase text-slate-600">Recipient capacity</p><p class="mt-1 text-sm font-bold text-slate-950">{{ capacityValue(program.capacity.recipient_slots, 'slots') }}</p></div>
                            </div>
                            <div class="flex items-center gap-3 px-5 py-4">
                                <span class="grid h-9 w-9 shrink-0 place-items-center bg-white text-slate-600" aria-hidden="true"><i class="fa-solid fa-clock-rotate-left text-sm"></i></span>
                                <div class="min-w-0"><p class="program-label font-bold uppercase text-slate-600">Last updated</p><p class="mt-1 text-sm font-bold text-slate-950">{{ program.updated_display || 'Not available' }}</p></div>
                            </div>
                        </div>
                    </header>

                    <section v-if="program.workspace_links?.length" class="mt-4 border border-slate-200 bg-white shadow-sm" aria-labelledby="program-workspaces-heading">
                        <header class="flex items-center gap-3 border-b border-slate-200 px-6 py-4">
                            <span class="program-icon grid h-9 w-9 shrink-0 place-items-center rounded-sm bg-slate-100 text-slate-600" aria-hidden="true"><i class="fa-solid fa-table-list text-sm"></i></span>
                            <div>
                                <h2 id="program-workspaces-heading" class="text-lg font-bold text-slate-950">Program workspaces</h2>
                                <p class="mt-0.5 text-sm text-slate-600">Open a queue already filtered to this program.</p>
                            </div>
                        </header>
                        <nav aria-labelledby="program-workspaces-heading" class="grid grid-cols-6 gap-px bg-slate-200">
                            <a v-for="(link, index) in program.workspace_links" :key="link.key" :href="link.url" :class="workspaceColumn(index)" class="flex min-w-0 items-center gap-3 bg-white px-6 py-4 text-slate-700 hover:bg-slate-50 focus-visible:z-10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-slate-700">
                                <span class="program-icon grid h-9 w-9 shrink-0 place-items-center rounded-sm bg-slate-100 text-slate-600" aria-hidden="true"><i :class="[link.icon, 'text-sm']"></i></span>
                                <span class="min-w-0 flex-1">
                                    <span class="program-text block text-sm font-bold text-slate-950">{{ link.label }}</span>
                                    <span class="program-text mt-0.5 block text-xs text-slate-600">{{ link.description }}</span>
                                </span>
                                <i class="fa-solid fa-arrow-right shrink-0 text-xs text-slate-500" aria-hidden="true"></i>
                            </a>
                        </nav>
                    </section>

                    <article class="mt-4 divide-y divide-slate-200 border border-slate-200 bg-white shadow-sm">
                        <section class="px-7 py-6" aria-labelledby="program-summary-heading">
                            <div class="flex items-center gap-3">
                                <span class="program-icon grid h-9 w-9 shrink-0 place-items-center bg-slate-950 text-sm text-amber-300" aria-hidden="true">
                                    <i class="fa-solid fa-align-left" aria-hidden="true"></i>
                                </span>
                                <div>
                                    <p class="program-label font-bold uppercase text-amber-700">Overview</p>
                                    <h2 id="program-summary-heading" class="text-lg font-bold text-slate-950">Program summary</h2>
                                </div>
                            </div>
                            <p id="program-summary-description" class="program-text mt-4 whitespace-pre-line text-sm leading-7 text-slate-700">{{ visibleDescription }}</p>
                            <EducationEligibilitySummary :policy="program.education_eligibility_policy" :modes="program.eligibility_rule_modes" />
                            <button v-if="descriptionIsLong" type="button" class="program-action mt-2 text-sm font-bold text-amber-700 hover:text-amber-900" :aria-expanded="showFullDescription" aria-controls="program-summary-description" @click="showFullDescription = !showFullDescription">
                                {{ showFullDescription ? 'Show less' : 'Read full summary' }}
                            </button>
                        </section>

                        <section class="px-7 py-6" aria-labelledby="program-timeline-heading">
                            <div class="flex items-center gap-3">
                                <span class="program-icon grid h-9 w-9 shrink-0 place-items-center bg-slate-100 text-sm text-slate-700" aria-hidden="true">
                                    <i class="fa-regular fa-calendar" aria-hidden="true"></i>
                                </span>
                                <div>
                                    <p class="program-label font-bold uppercase text-slate-600">Schedule</p>
                                    <h2 id="program-timeline-heading" class="text-lg font-bold text-slate-950">Program timeline</h2>
                                </div>
                            </div>
                            <dl class="mt-4 divide-y divide-slate-200 border-y border-slate-200">
                                <div v-for="row in timelineRows" :key="row.label" class="grid grid-cols-[16rem_minmax(0,1fr)] items-center gap-4 py-3 text-sm">
                                    <dt class="font-medium text-slate-500">{{ row.label }}</dt>
                                    <dd class="program-text font-semibold text-slate-900">{{ row.value }}</dd>
                                </div>
                            </dl>
                        </section>

                        <section class="px-7 py-6" aria-labelledby="program-selection-heading">
                            <div class="flex items-center gap-3">
                                <span class="program-icon grid h-9 w-9 shrink-0 place-items-center bg-slate-100 text-sm text-slate-700" aria-hidden="true">
                                    <i class="fa-solid fa-list-check" aria-hidden="true"></i>
                                </span>
                                <div>
                                    <p class="program-label font-bold uppercase text-slate-600">Process</p>
                                    <h2 id="program-selection-heading" class="text-lg font-bold text-slate-950">Selection stages</h2>
                                </div>
                            </div>
                            <ol v-if="program.selection_stages.length" class="mt-4 flex flex-wrap gap-2">
                                <li v-for="(stage, index) in program.selection_stages" :key="`${stage}-${index}`" class="inline-flex items-center border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-semibold text-slate-800">
                                    <span class="mr-2 text-xs font-bold text-amber-700">{{ index + 1 }}</span>
                                    {{ stage }}
                                </li>
                            </ol>
                            <div v-else class="mt-4 flex items-center gap-3 border-y border-slate-200 py-4">
                                <span class="grid h-9 w-9 shrink-0 place-items-center bg-slate-100 text-slate-500" aria-hidden="true"><i class="fa-solid fa-list-check text-sm"></i></span>
                                <p class="text-sm text-slate-500">No selection stages are recorded.</p>
                            </div>
                        </section>

                        <section class="px-7 py-6" aria-labelledby="program-support-heading">
                            <div class="flex items-center justify-between gap-4">
                                <div class="flex items-center gap-3">
                                    <span class="program-icon grid h-9 w-9 shrink-0 place-items-center bg-slate-100 text-sm text-slate-700" aria-hidden="true">
                                        <i class="fa-solid fa-hand-holding-heart" aria-hidden="true"></i>
                                    </span>
                                    <div>
                                        <p class="program-label font-bold uppercase text-slate-600">Award</p>
                                        <h2 id="program-support-heading" class="text-lg font-bold text-slate-950">Scholarship support</h2>
                                    </div>
                                </div>
                                <a v-if="program.actions.monitoring_plan_url" :href="program.actions.monitoring_plan_url" class="program-action inline-flex h-9 shrink-0 items-center gap-2 rounded-[5px] border border-slate-300 bg-white px-3 text-xs font-bold text-slate-700 hover:border-slate-600">
                                    Monitoring plan <i class="fa-solid fa-arrow-right text-[9px]" aria-hidden="true"></i>
                                </a>
                            </div>
                            <div class="mt-4 border-y border-slate-200 py-4">
                                <p class="program-text text-sm font-semibold text-slate-900">{{ program.support.summary }}</p>
                                <p class="mt-1 text-xs text-slate-500">{{ program.support.benefit_count }} recorded benefit{{ program.support.benefit_count === 1 ? '' : 's' }}</p>
                            </div>
                        </section>
                    </article>
                </template>
            </div>
        </section>

        <ApplicantPagePreviewModal
            :open="previewOpen"
            :title="program?.title || 'Scholarship program'"
            description="Review the saved program exactly as an applicant will see it."
            :status="program?.status?.label || 'Preview'"
            :scenario="previewScenario"
            show-scenario
            :full-page-url="program?.actions?.preview_url || ''"
            @close="previewOpen = false"
            @update:scenario="previewScenario = $event"
        >
            <UserScholarshipDetailPage
                v-if="previewOpen"
                :key="`${programId}-${previewScenario}`"
                embedded
                :scholarship-id="programId"
                :preview-data-url="program?.actions?.preview_data_url || ''"
                :initial-scenario="previewScenario"
                :preview-status="program?.status?.label || 'Preview'"
            />
        </ApplicantPagePreviewModal>
    </main>
</template>
